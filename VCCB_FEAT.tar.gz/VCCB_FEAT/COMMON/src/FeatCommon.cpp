/**
 * @file        VlibUtility.c
 * @brief       utility functions
 */

#include "FeatCommon.h"
#include "FeatMrdc.h"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatFullConfig.h"
#include "FeatMeasurements.hpp"
#include "FeatTrace.h"
#include "FeatRbInfo.h"
#include "FeatUeHistory.h"
#include "FeatLtmHo.h"
#include "FeatCa.hpp"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"

#include "StateCommon.h"
#include "StateMeasurements.h"
#include "StateHandleAll.h"
#include "StateHandleSaMrdc.h"

#include "MsgNgapStore.h"
#include "MsgNgapSend.h"
#include "MsgVccbSend.h"

#include "FeatLb.hpp" //SVR23B FGR-LC0710
#include "MsgQueueManager.h"
#include "MsgX2apSend.h"
#include "UplinkStatusTriggeredMobility.hpp"

#ifdef VCCB_IPC_TEST
#include "VccbBtEventChecker.h"
#endif

static pthread_mutex_t gNasInfoAllocMutex = PTHREAD_MUTEX_INITIALIZER;  // [SAM_GV_IMPROVEMENT]

/**
 * @brief     Set all call states
 * @param     ptCi : call context pointer
 * @param     state : specific call state
 */
void VLIB_SetCurStateAll(callInfo_type *ptCi, enumVccbCallState_type state)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(state, MAX_VCCB_STATE);

    bool isStateChanged = false;  // CONN to XXX or XXX to CONN

    MACRO_CHG_CALL_STATE(state);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->prevFnState, MAX_VCCB_STATE);
    ptCi->stateInitTime = time(NULL);  // AUDIT ::2012.05.15 YOONBY

    VCCB_PRINT_CALL_MSG(ptCi, "%s: state Change %s(%d) --> %s(%d) \n", __FUNCTION__,
        FnVCCB_GetStrStateName(ptCi->prevFnState), ptCi->prevFnState, FnVCCB_GetStrStateName(state), state);

    ptCi->srb3Prohibited = 0;

#ifdef VCCB_IPC_TEST
    FnBT_OnEvent_StateChange_Enter(ptCi);
#endif

    // DB -> other
    if ((STATE_DB == ptCi->prevFnState && STATE_DB != state) ||
        (STATE_Conn == ptCi->prevFnState && STATE_Conn != state) ||
        (STATE_Inact_Suspend == ptCi->prevFnState && STATE_Inact_Suspend != state))
    {
#ifdef __CNF__
        if (ERROR == FnVCCB_BackupCallInfo(ptCi))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_BackupCallInfo ERROR in %s\n", __FUNCTION__);
        }
#else
        HAS_BACKUP_DATA_CALL_PARTIAL(ptCi, &ptCi->state, sizeof(ptCi->state));
#endif

        isStateChanged = true;

        if (ptCi->longCallDetectionTimer.id > 0)
        {
            VCCB_CLEAR_TIMER(&ptCi->longCallDetectionTimer, CANCEL_TIMER);
        }
    }

    // other -> DB
    if ((STATE_DB == state && STATE_DB != ptCi->prevFnState) ||
        (STATE_Conn == state && STATE_Conn != ptCi->prevFnState) ||
        (STATE_Inact_Suspend == state && STATE_Inact_Suspend != ptCi->prevFnState))
    {
        isStateChanged = true;

        VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
        const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

        if (NEED_TO_AUDIT_AUPF(pGnb->yangTimer.cpLongCallDetectTime, ptCi->flag.setupFlag))
        {
            VLIB_AttachTimer(&ptCi->longCallDetectionTimer, ptCi, timInternalLongCallDetect_id);
        }

        FnVCCB_InitCslInfo_CaScellFlag(ptCi);
    }

    if (VCCM_IsUeIdleState(ptCi->callType, state))
    {
        VLIB_startManagementUeThrRfTrace(ptCi, ptCi->servCellNum);
        // Setting STATE_DB/STATE_Conn state means some ongoing procedure was finished
        ptCi->security.snCounterChangeFlag = FALSE;

        ptCi->hoInfo.qDiscardMR = FALSE;
        ptCi->CallUserInactivity.desiredNotiLevelChanged = FALSE;

        ptCi->drbIdsReuse = 0;

        if (isStateChanged == true)
        {
            FnVCCB_ClearDrbTnlNeedModifyFlag(*ptCi);

            ptCi->flag.toRespFlag = 0;

            FnVCCB_ProcIdleStateForLastVisitedPSCellInformation(ptCi);

            if (IsAvailable_MrdcInfo())
            {
                MNInfo_type *ptMnSrcInfo = &ptCi->mrdcInfo.MNInfo[SRC_MN];
                MNInfo_type *ptMnTgtInfo = &ptCi->mrdcInfo.MNInfo[TGT_MN];

                // Exception processing, if the data remains, it is considered abnormal and deleted.
                if (ptMnTgtInfo->m.usage == VCCB_FLAG_ON)
                {
                    VCCB_PRINT_CALL_LOG_UPM(ptCi, "PCell Change : %d/%llu -> %d/%llu \n",
                            (int)ptMnSrcInfo->m.mnNRCGI, (unsigned long long)ptMnSrcInfo->mnNRCGI.ci,
                            (int)ptMnTgtInfo->m.mnNRCGI, (unsigned long long)ptMnTgtInfo->mnNRCGI.ci);

                    *ptMnSrcInfo = *ptMnTgtInfo;

                    FnVCCB_InitMrdcMnInfo(ptMnTgtInfo);
                }

                VLIB_FreeBuffAllMrdcInfo(ptCi, PL_COMMENT);
                FnVCCB_ClearInstantFlagOfMrdcInfo(ptCi);
                // FGR-CC5200:FR680
                // need to update stats forcely if SN resource is removed without sending ueContextRelease in MN Side (i.e RESET...)
                // in general, attempt made was cleared except for termination the procedure abnormally without collecting stats.
                // so if stats has been colleted normally, this behaviour will not be effective.
                if (IS_NRDC_MN(ptCi))
                {
                    FnVCCB_UpdateNrdcModStats(ptCi, NrdcModMn_MnInit_PrepFail, NULL, false);
                    FnVCCB_UpdateNrdcModStats(ptCi, NrdcModMn_SnInit_Fail, NULL, false);
                }
                else if (IS_NRDC_SN(ptCi))
                {
                    FnVCCB_UpdateNrdcModStats(ptCi, NrdcModSn_MnInit_PrepFail, NULL, false);
                    FnVCCB_UpdateNrdcModStats(ptCi, NrdcModSn_SnInit_Fail, NULL, false);
                }
            }
            else if (ptCi->callType == E_CALLTYPE_SA) // FGR-CC5200:FR680
            {
                FnVCCB_UpdateNrdcModStats(ptCi, NrdcModMn_MnInit_PrepFail, NULL, false);
                FnVCCB_UpdateNrdcModStats(ptCi, NrdcModMn_SnInit_Fail, NULL, false);
            }

            // Debug Print
            FnVCCB_PrintAllResponseFlag(ptCi, __func__, NO);
        }

        OFF_PDU_SESSION_PROC_NO_RESP(ptCi->flag.setupFlag);

        INIT_MOD_PROC_INFO(ptCi);
        SET_PROC_FOR_STAT(ptCi, MAX_PROC_FOR_STAT);
    }

    // SVR22B FGR-CC0103: send RRC Inactive Transition Report Request
    if (IS_SUPPORT_RRC_INACTIVE(ptCi))
    {
        if (ptCi->state == STATE_Conn || ptCi->state == STATE_Inact_Suspend)
        {
            // manage to send RRC Inactive Transition Report to AMF
            FnVCCB_Proc_RRCInactiveTransitionReport(ptCi);
        }
    }

#ifdef VCCB_IPC_TEST
    FnBT_OnEvent_StateChange_Leave(ptCi);
#endif

    return;
}

/**
 * @brief     Clear all response flags in call context
 * @param     ptCi : call context pointer
 */
int16_t VLIB_ClearAllRespFlags(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint32_t srb;
    uint32_t erab;
    uint32_t gnb;
    callPDUSessInfo_type *pDi;
    uint32_t pdu;
    callSRBInfo_type *pSi;
    callERABInfo_type *pRi;
    callGNBInfo_type *pEi;
    pathInfo_type *pPi;

    ptCi->flag.respFlag = 0;

    for (srb = 0; srb < MAX_SRB_PER_CALL; srb++)
    {
        if (!IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[srb]))) continue;
        pSi = &(ptCi->srbInfo[srb]);
        pSi->flag.respFlag = 0;
    }

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        for (pdu = 0; pdu < MAX_PDU_SESS_PER_CALL; pdu++)
        {
            if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[pdu]))) continue;
            pDi = &(ptCi->pduSess[pdu]);
            pDi->flag.respFlag = 0;
        }
    }
    else
    {
        for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
        {
            if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[erab]))) continue;
            pRi = &(ptCi->erabInfo[erab]);
            pRi->flag.respFlag = 0;
        }
    }

    for (gnb = 0; gnb < MAX_GNB_PER_CALL; gnb++)
    {
        if (!IS_VALID_NODE(GNB_NODE, ptCi, &(ptCi->gnbInfo[gnb]))) continue;
        pEi = &(ptCi->gnbInfo[gnb]);
        pEi->flag.respFlag = 0;

        if (ptCi->callType == E_CALLTYPE_SA)
        {
            continue;
        }
        else
        {
            for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
            {
                if (!IS_VALID_NODE(PATH_NODE, pEi, &(pEi->dlPath[erab]))) continue;
                pPi = &(pEi->dlPath[erab]);
                pPi->flag.respFlag = 0;
            }

            for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
            {
                if (!IS_VALID_NODE(PATH_NODE, pEi, &(pEi->ulPath[erab]))) continue;
                pPi = &(pEi->ulPath[erab]);
                pPi->flag.respFlag = 0;
            }
        }
    }

    return GOOD;
}

/**
 * @brief     Check all release flag is on or not
 * @param     ptCi : call context pointer
 * @return    ERROR : some release flag still on
 * @return    GOOD : all release flag is off
 */
int16_t VLIB_CheckAllReleased(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint32_t srb;
    uint32_t erab;
    uint32_t gnb;
    callSRBInfo_type *pSi;
    callERABInfo_type *pRi;
    callGNBInfo_type *pEi;
    pathInfo_type *pPi;

    if (ptCi->flag.releaseFlag)
    {
        VCCB_PRINT_CALL_DATA(ptCi, "ptCi/Flag = %llX\n", 1ULL * ptCi->flag.releaseFlag);
        return ERROR;
    }

    for (srb = 0; srb < MAX_SRB_PER_CALL; srb++)
    {
        if (!IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[srb]))) continue;
        pSi = &(ptCi->srbInfo[srb]);
        if (pSi->flag.releaseFlag)
        {
            VCCB_PRINT_CALL_DATA(ptCi, "Srb/Flag = %u/%X.\n", srb, pSi->flag.releaseFlag);
            return ERROR;
        }
    }

    for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
    {
        if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[erab]))) continue;
        pRi = &(ptCi->erabInfo[erab]);
        if (pRi->flag.releaseFlag)
        {
            VCCB_PRINT_CALL_DATA(ptCi, "Erab/Flag = %u/%X.\n", erab, pRi->flag.releaseFlag);
            return ERROR;
        }
    }

    for (gnb = 0; gnb < MAX_GNB_PER_CALL; gnb++)
    {
        if (!IS_VALID_NODE(GNB_NODE, ptCi, &(ptCi->gnbInfo[gnb]))) continue;
        pEi = &(ptCi->gnbInfo[gnb]);
        if (pEi->flag.releaseFlag)
        {
            VCCB_PRINT_CALL_DATA(ptCi, "Gnb/Flag = %u/%X.\n", gnb, pEi->flag.releaseFlag);
            return ERROR;
        }

        for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
        {
            if (!IS_VALID_NODE(PATH_NODE, pEi, &(pEi->dlPath[erab]))) continue;
            pPi = &(pEi->dlPath[erab]);
            if (pPi->flag.releaseFlag)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "Gnb/Erab/dlFlag = %u/%u/%X.\n", gnb, erab, pPi->flag.releaseFlag);
                return ERROR;
            }
        }

        for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
        {
            if (!IS_VALID_NODE(PATH_NODE, pEi, &(pEi->ulPath[erab]))) continue;
            pPi = &(pEi->ulPath[erab]);
            if (pPi->flag.releaseFlag)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "Gnb/Erab/ulFlag = %u/%u/%X.\n", gnb, erab, pPi->flag.releaseFlag);
                return ERROR;
            }
        }
    }

    return GOOD;
}

/**
 * @brief     Clear all release flag as 0
 * @param     ptCi : call context pointer
 */
int16_t VLIB_ClearAllReleaseFlags(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint32_t srb;
    uint32_t erab;
    uint32_t gnb;
    callSRBInfo_type *pSi;
    callERABInfo_type *pRi;
    callGNBInfo_type *pEi;
    pathInfo_type *pPi;
    callPDUSessInfo_type *pDi;
    uint32_t pdu;

    ptCi->flag.releaseFlag = 0;

    for (srb = 0; srb < MAX_SRB_PER_CALL; srb++)
    {
        if (!IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[srb]))) continue;
        pSi = &(ptCi->srbInfo[srb]);
        pSi->flag.releaseFlag = 0;
    }

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        for (pdu = 0; pdu < MAX_PDU_SESS_PER_CALL; pdu++)
        {
            if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[pdu]))) continue;
            pDi = &(ptCi->pduSess[pdu]);
            pDi->flag.releaseFlag = 0;
        }
    }
    else
    {
        for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
        {
            if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[erab]))) continue;
            pRi = &(ptCi->erabInfo[erab]);
            pRi->flag.releaseFlag = 0;
        }
    }

    for (gnb = 0; gnb < MAX_GNB_PER_CALL; gnb++)
    {
        if (!IS_VALID_NODE(GNB_NODE, ptCi, &(ptCi->gnbInfo[gnb]))) continue;
        pEi = &(ptCi->gnbInfo[gnb]);
        pEi->flag.releaseFlag = 0;

        for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
        {
            if (!IS_VALID_NODE(PATH_NODE, pEi, &(pEi->dlPath[erab]))) continue;
            pPi = &(pEi->dlPath[erab]);
            pPi->flag.releaseFlag = 0;
        }

        for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
        {
            if (!IS_VALID_NODE(PATH_NODE, pEi, &(pEi->ulPath[erab]))) continue;
            pPi = &(pEi->ulPath[erab]);
            pPi->flag.releaseFlag = 0;
        }
    }

    return GOOD;
}

/**
 * @brief     Clear refusedTargetFR1CellsForFR2FR1HO array in callInfo
 * @param     ptCi : call context pointer
 */
void VLIB_ClearRefusedTargetFR1CellsList(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t loop = 0;

    for (loop = 0; loop < MAX_REFUSED_TARGET_FR1_CELLS_PER_CALL; loop++)
    {
        ptCi->refusedTargetFR1CellsForFR2FR1HO[loop].status = N_EQUIP;
        ptCi->refusedTargetFR1CellsForFR2FR1HO[loop].globalGnbId.gnbId.id = 0;
        ptCi->refusedTargetFR1CellsForFR2FR1HO[loop].globalGnbId.gnbId.idLength = 0;
        ptCi->refusedTargetFR1CellsForFR2FR1HO[loop].cellId = 0;
    }

    return;
}

const std::vector<std::string> flagStrings = {
    "RRC_CONNECTION_FLAG", // 0
    "NGC_CONNECTION_FLAG", // 1
    "UE_CAPA_INQUIRY_FLAG", // 2
    "RRC_RECONFIG_FLAG", // 3
    "UE_CTXT_MODIFY_FLAG", // 4
    "SECURITY_MODE_CMD_FLAG", // 5
    "NMB_UE_RESOURCE_FLAG", // 6
    "F1_UECAPA_EUTRA_OMIT", // 7
    "SN_NODE_MOD_ACK_RCV_FLAG", // 8
    "SN_NODE_REL_ACK_RCV_FLAG", // 9
    "E1_REL_COMPLT_RCV_FLAG", // 10
    "F1_REL_COMPLT_RCV_FLAG", // 11
    "MENB_CONNECTION_FLAG", // 12
    "SGNB_MOD_CONF_FLAG", // 13
    "F1_CTXT_MODRSP_FLAG", // 14
    "E1_CTXT_MODRSP_FLAG", // 15
    "SGNB_REC_CMPL_FLAG", // 16
    "SGNB_MOD_REQ_FLAG", // 17
    "F1_RESOURCE_FLAG", // 18
    "E1_RESOURCE_FLAG", // 19
    "F1_RESOURCE_TGT_FLAG", // 20
    "F1_REL_CMP_RCV_TGT_FLAG", // 21
    "CGCFINFO_NEED_FWD_FLAG", // 22
    "UECAPA_NEED_FWD_FLAG", // 23
    "SGNB_ADD_REQ_FLAG", // 24
    "SGNB_REC_COMP_FLAG", // 25
    "SCG_CELLGRPCFG_REQ_FLAG", // 26
    "BAND_COMB_CHG_FLAG", // 27
    "SGNB_ADD_REQ_TGT_FLAG", // 28
    "MENB_CONN_TGT_FLAG", // 29
    "X2_SN_STATUS_FLAG", // 30
    "NOT-USE", // 31
    "NG_INIT_SETUP_FLAG", // 32
    "MENB_SRC_X2_REL_REQ_FLAG", // 33
    "SN_STATUS_FLAG", // 34
    "E1_PDCP_SN_FLAG", // 35
    "F1_CELLGROUPCONFIG_FLAG", // 36
    "F1_RSC_PREPARATION_FLAG", // 37
    "F1_RESOURCE_OLD_FLAG", // 38
    "NOT-USE", // 39
    "NOT-USE", // 40
    "NOT-USE", // 41
    "PDU_SESSION_PROC_NO_RESP", // 42
    "NRRRC_CELLGROUPCONFIG_FLAG", // 43
    "ALLOWED_BAND_COMB_CHG_FLAG", // 44
    "F1_CTXT_MODRSP_TGT_FLAG", // 45
    "NAS_STORED_FLAG", // 46
    "NRRRC_UE_ASSISTANCE_INFO_FLAG", // 47
    "PDUSESS_MODIFY_CONFIRM_FLAG", // 48
    "XN_U_ADDRESS_IND_FLAG", // 49
    "MGNB_CONNECTION_FLAG", // 50
    "NOT-USE", // 51
    "SN_NODE_REL_REQ_WAIT_FLAG", // 52
    "F1_ECID_MEAS_INIT_REQD_FLAG", // 53
    "SN_NODE_ADD_ACK_RCV_FLAG", // 54
    "SN_NODE_CHANGE_CONFIRM_RCV_FLAG", // 55
    "NOT-USE", // 56
    "XN_UE_CONTEXT_RELEASE_RCV_FLAG", // 57
    "SN_ADDITION_PREPARATION_FLAG", // 58
    "TRF_BASED_NR_TO_EUTRA_HO_REQUIRED", // 59
    "MGNB_CONNECTION_TGT_FLAG", // 60
    "F1_ECID_SRS_POSITIONING_REQ_FLAG", // 61
    "F1_ACCESS_SUCCESS_FLAG", // 62
};

std::string FnVCCB_ChangeRespFlag2Str(uint64_t flags) {
    std::ostringstream oss;
    bool first = true;

    for (size_t i = 0; i < flagStrings.size(); ++i) {
        if ((flags >> i) & 1) {
            if (!first) {
                oss << ", ";
            }
            first = false;
            oss << flagStrings[i];
        }
    }

    return oss.str();
}

void FnVCCB_PrintDebugFlag(callInfo_type *ptCi, uint64_t value, const char *pWord)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(pWord);

    // not trigger
    if (value == 0) return;

    if (ptCi == NULL)
    {
        VCCB_PRINT_ERROR("%s: %s\n", pWord, FnVCCB_ChangeRespFlag2Str(value).c_str());
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "%s: %s\n", pWord, FnVCCB_ChangeRespFlag2Str(value).c_str());
    }
}

void FnVCCB_PrintAllResponseFlag_Detail(callInfo_type *ptCi, const char *ptFunc)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptFunc);

    char strBuff[MAX_CMD_STR_BUF];

    // SRB - respFlag
    {
        int srb = 0;
        callSRBInfo_type *ptSi = NULL;
        for (srb = 0; srb < MAX_SRB_PER_CALL; srb++)
        {
            if (!IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[srb]))) continue;

            ptSi = &(ptCi->srbInfo[srb]);

            if (ptSi->flag.respFlag == 0) continue;

            snprintf(strBuff, MAX_CMD_STR_BUF, "SRB#%d - respFlag", srb);

            FnVCCB_PrintDebugFlag(ptCi, ptSi->flag.respFlag, strBuff);
        }
    }

    // PDU - respFlag
    if (ptCi->callType == E_CALLTYPE_SA)
    {
        int pdu = 0;
        callPDUSessInfo_type *ptPi = NULL;
        for (pdu = 0; pdu < MAX_PDU_SESS_PER_CALL; pdu++)
        {
            if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[pdu]))) continue;

            ptPi = &(ptCi->pduSess[pdu]);

            if (ptPi->flag.respFlag == 0) continue;

            snprintf(strBuff, MAX_CMD_STR_BUF, "PDU#%d - respFlag", pdu);

            FnVCCB_PrintDebugFlag(ptCi, ptPi->flag.respFlag, strBuff);
        }
    }
    else  // NSA
    {
        uint32_t erab;
        uint32_t gnb;

        {
            callERABInfo_type *ptRi = NULL;

            for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
            {
                if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[erab]))) continue;

                ptRi = &(ptCi->erabInfo[erab]);

                if (ptRi->flag.respFlag == 0) continue;

                snprintf(strBuff, MAX_CMD_STR_BUF, "ERAB#%u - respFlag", erab);

                FnVCCB_PrintDebugFlag(ptCi, ptRi->flag.respFlag, strBuff);
            }
        }

        {
            callGNBInfo_type *ptGi = NULL;
            pathInfo_type *ptPi = NULL;

            for (gnb = 0; gnb < MAX_GNB_PER_CALL; gnb++)
            {
                if (!IS_VALID_NODE(GNB_NODE, ptCi, &(ptCi->gnbInfo[gnb]))) continue;

                ptGi = &(ptCi->gnbInfo[gnb]);

                if (ptGi->flag.respFlag == 0)
                {
                    snprintf(strBuff, MAX_CMD_STR_BUF, "GNB#%u - respFlag", gnb);

                    FnVCCB_PrintDebugFlag(ptCi, ptGi->flag.respFlag, strBuff);
                }

                for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
                {
                    if (!IS_VALID_NODE(PATH_NODE, ptGi, &(ptGi->dlPath[erab]))) continue;

                    ptPi = &(ptGi->dlPath[erab]);

                    if (ptPi->flag.respFlag == 0) continue;

                    snprintf(strBuff, MAX_CMD_STR_BUF, "GNB#%u/ERAB#%u/DL - respFlag", gnb, erab);

                    FnVCCB_PrintDebugFlag(ptCi, ptPi->flag.respFlag, strBuff);
                }

                for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
                {
                    if (!IS_VALID_NODE(PATH_NODE, ptGi, &(ptGi->ulPath[erab]))) continue;
                    ptPi = &(ptGi->ulPath[erab]);

                    if (ptPi->flag.respFlag == 0) continue;

                    snprintf(strBuff, MAX_CMD_STR_BUF, "GNB#%u/ERAB#%u/UL - respFlag", gnb, erab);

                    FnVCCB_PrintDebugFlag(ptCi, ptPi->flag.respFlag, strBuff);
                }
            }
        }
    }
}

bool FnVCCB_IsNeed_PrintAllResponseFlagDetail(callInfo_type *ptCi, uint8_t isForcedPrintDetail)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // DEBUG Flag
    if (DBG->flag.logInitFlag)
    {
        return true;
    }

    // Forced Print Case
    if (isForcedPrintDetail == YES)
    {
        return true;
    }

    // UE Trace Case
    if (ptCi->debugTrace == VCCB_FLAG_ON)
    {
        return true;
    }

    return false;
}

void FnVCCB_PrintAllResponseFlag(callInfo_type *ptCi, const char *ptFunc, uint8_t isForcedPrintDetail)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptFunc);

    int16_t ret = VLIB_CheckAllConnected(ptCi);
    if (ret == GOOD)
    {
        return;
    }

    VCCB_PRINT_CALL_ERROR(ptCi,
        "[Warning] The possibility exists that certain messages are not OFF_BIT. (R:%d, F:%s, U:%lu)\n", ret, ptFunc,
        ptCi->flag.respFlag);

    // ptCi->flag.respFlag
    if (ptCi->flag.respFlag)
    {
        FnVCCB_PrintDebugFlag(ptCi, ptCi->flag.respFlag, "CALL - respFlag");
    }

    if (FnVCCB_IsNeed_PrintAllResponseFlagDetail(ptCi, isForcedPrintDetail))
    {
        FnVCCB_PrintAllResponseFlag_Detail(ptCi, ptFunc);
    }
}

/**
 * @brief     Check if all response flag is 0
 * @param     ptCi : call context pointer
 * @return    ERROR : some response flag still on
 * @return    GOOD : all response flag is off
 */
int16_t VLIB_CheckAllConnected(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint32_t srb;
    uint32_t erab;
    uint32_t gnb;
    callSRBInfo_type *pSi;
    callERABInfo_type *pRi;
    callGNBInfo_type *pEi;
    pathInfo_type *pPi;

    if (ptCi->flag.respFlag)
    {
        VCCB_PRINT_CALL_DATA(
            ptCi, "ptCi/Flag = 0x%016llX (%llu)\n", 1ULL * ptCi->flag.respFlag, 1ULL * ptCi->flag.respFlag);
        return ERROR;
    }

    if (ptCi->ltmUeInfo.respFlag)
    {
        VCCB_PRINT_CALL_DATA(
            ptCi, "[LTM] ptCi/Flag = 0x%llx (%llu)\n", 1ULL * ptCi->ltmUeInfo.respFlag, 1ULL * ptCi->ltmUeInfo.respFlag);
        return ERROR;
    }

    for (srb = 0; srb < MAX_SRB_PER_CALL; srb++)
    {
        if (!IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[srb]))) continue;
        pSi = &(ptCi->srbInfo[srb]);
        if (pSi->flag.respFlag)
        {
            VCCB_PRINT_CALL_DATA(ptCi, "Srb/Flag = %u/0x%llu.\n", srb, 1ULL * pSi->flag.respFlag);
            return ERROR;
        }
    }

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        callPDUSessInfo_type *pDi;
        uint32_t pdu;

        for (pdu = 0; pdu < MAX_PDU_SESS_PER_CALL; pdu++)
        {
            if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[pdu]))) continue;
            pDi = &(ptCi->pduSess[pdu]);
            if (pDi->flag.respFlag)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "Pdu/Flag = %u/0x(%llu).\n", pdu, 1ULL * pDi->flag.respFlag);
                return ERROR;
            }
        }
    }
    else
    {
        for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
        {
            if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[erab]))) continue;
            pRi = &(ptCi->erabInfo[erab]);
            if (pRi->flag.respFlag)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "Erab/Flag = %u/0x%llu.\n", erab, 1ULL * pRi->flag.respFlag);
                return ERROR;
            }
        }

        for (gnb = 0; gnb < MAX_GNB_PER_CALL; gnb++)
        {
            if (!IS_VALID_NODE(GNB_NODE, ptCi, &(ptCi->gnbInfo[gnb]))) continue;
            pEi = &(ptCi->gnbInfo[gnb]);
            if (pEi->flag.respFlag)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "Gnb/Flag = %u/0x%llu.\n", gnb, 1ULL * pEi->flag.respFlag);
                return ERROR;
            }

            for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
            {
                if (!IS_VALID_NODE(PATH_NODE, pEi, &(pEi->dlPath[erab]))) continue;
                pPi = &(pEi->dlPath[erab]);
                if (pPi->flag.respFlag)
                {
                    VCCB_PRINT_CALL_DATA(ptCi, "Gnb/Erab/dlFlag = %u/%u/0x%llu.\n", gnb, erab, 1ULL * pPi->flag.respFlag);
                    return ERROR;
                }
            }

            for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
            {
                if (!IS_VALID_NODE(PATH_NODE, pEi, &(pEi->ulPath[erab]))) continue;
                pPi = &(pEi->ulPath[erab]);
                if (pPi->flag.respFlag)
                {
                    VCCB_PRINT_CALL_DATA(ptCi, "Gnb/Erab/ulFlag = %u/%u/0x%llu.\n", gnb, erab, 1ULL * pPi->flag.respFlag);
                    return ERROR;
                }
            }
        }
    }

    return GOOD;
}

/**
 * @brief     Get BPLMN List at CellNum
 * @param     ptCi : pointer of callInfo
 * @param     cellNum : cell number
 * @param     pt_b_plmn_list : [out] pointer of BPLMNList
 */

int16_t VLIB_getBPLMN(const callInfo_type *ptCi, uint32_t cellNum, allowedPlmnList_Type *pt_b_plmn_list)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pt_b_plmn_list);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    const PLMN_IdentityInfoList_type *ptBplmnList = &pCell->sib1.plmn_IdentityInfoList;
    const PLMN_IdentityList_type *ptBpmnIdList = NULL;

    // set init value
    pt_b_plmn_list->num_plmn = 0;

    // validation check : cell
    if (pCell->status == EQUIP)
    {
        uint32_t plmnIdx = 0;

        if (pCell->configuredTacIndication == CI_use)
        {
            uint32_t maxLoop = MIN(pCell->cellPlmn.numOfPLMN, MAX_PLMN_INDEX);
            for (plmnIdx = 0; plmnIdx < maxLoop; plmnIdx++)
            {
                if (pt_b_plmn_list->num_plmn >= MAX_NUM_PLMN) break;

                pt_b_plmn_list->plmn[pt_b_plmn_list->num_plmn++].longId = pCell->cellPlmn.servedPlmn[plmnIdx];
            }
        }
        else
        {
            uint32_t plmnInfoIdx = 0;
            uint8_t foundFlag = FALSE;

            // find and set bplmn list
            for (plmnInfoIdx = 0; plmnInfoIdx < MIN(ptBplmnList->nrofPLMN_IdentityInfo, MAX_NUM_PLMN); plmnInfoIdx++)
            {
                ptBpmnIdList = &ptBplmnList->plmn_IdentityInfo[plmnInfoIdx].plmn_IdentityList;

                for (plmnIdx = 0; plmnIdx < MIN(ptBpmnIdList->nrofPLMN_Identity, MAX_NUM_PLMN); plmnIdx++)
                {
                    if (pt_b_plmn_list->num_plmn >= MAX_NUM_PLMN) break;

                    pt_b_plmn_list->plmn[pt_b_plmn_list->num_plmn++].longId =
                        ptBpmnIdList->plmn_Identity[plmnIdx].longId;

                    if (foundFlag == FALSE) foundFlag = TRUE;
                }
            }

            if (foundFlag == FALSE)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "Failed to get Cell#%d BPLMN. (status=%u, plmnInfoIdx=%u)\n", cellNum,
                    pCell->status, plmnInfoIdx);
            }
        }
    }

    // exception case : cell is not equip, invalid sib, ...
    if (pt_b_plmn_list->num_plmn == 0)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "Failed to get Cell#%d BPLMN. (status=%u, plmnListCnt=%u, cellPlmnCnt=%u, SN=%u)\n", cellNum, pCell->status,
            ptBplmnList->nrofPLMN_IdentityInfo, pCell->cellPlmn.numOfPLMN, IS_NRDC_SN(ptCi));

        return BREAK;
    }

    return GOOD;
}  // }}}

/**
 * @brief     Get plmn index of gNB level (plmn-index-info/plmn-index-entries(ACPF) or gnb-plmn-info (NVGNB))
 * @param     ptCi : pointer of callInfo
 * @param     pServPlmnIndex : pointer with PLMN idx
 * @param     plmnLongId : PLMN's long ID
 */
int16_t VLIB_getMultipleGnbPlmnIndexInfo(const callInfo_type *ptCi, uint8_t *pServPlmnIndex, uint32_t plmnLongId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pServPlmnIndex);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint8_t plmnInfoIdx = 0;

    for (plmnInfoIdx = 0; plmnInfoIdx < MAX_PLMN_INDEX; plmnInfoIdx++)
    {
        const plmnIdInfo_type *pGnbPlmn = &pGnb->plmnIndexInfo[plmnInfoIdx];

        if (pGnbPlmn->shmStatus != EQUIP) continue;

        if (plmnLongId == pGnbPlmn->longId)
        {
            *pServPlmnIndex = (uint8_t)pGnbPlmn->plmnIndex;
            return GOOD;
        }
        VCCB_PRINT_CALL_COMMENT(ptCi, "plmnInfoIdx[%d], plmnLongId[0x%0X], pGnbPlmn->longId[0x%0X]\n", plmnInfoIdx,
            plmnLongId, pGnbPlmn->longId);
    }

    return ERROR;
}

/**
 * @brief     Get plmn index of gNB level (plmn-index-info/plmn-index-entries(ACPF) or gnb-plmn-info (NVGNB))
 * @param     gnbNum : which gNB to be checked for PLMN idx
 * @param     pServPlmnIndex : pointer with PLMN idx
 * @param     plmnLongId : PLMN's long ID
 */
int16_t VLIB_getMultipleGnbPlmnIndexInfo(uint16_t gnbNum, uint8_t *pServPlmnIndex, uint32_t plmnLongId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pServPlmnIndex);
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    uint8_t plmnInfoIdx = 0;

    for (plmnInfoIdx = 0; plmnInfoIdx < MAX_PLMN_INDEX; plmnInfoIdx++)
    {
        const plmnIdInfo_type *pGnbPlmn = &pGnb->plmnIndexInfo[plmnInfoIdx];

        if (pGnbPlmn->shmStatus != EQUIP) continue;

        if (plmnLongId == pGnbPlmn->longId)
        {
            *pServPlmnIndex = (uint8_t)pGnbPlmn->plmnIndex;
            return GOOD;
        }
        VCCB_PRINT_COMMENT("plmnInfoIdx[%d], plmnLongId[0x%0X], pGnbPlmn->longId[0x%0X]\n", plmnInfoIdx,
            plmnLongId, pGnbPlmn->longId);
    }

    return ERROR;
}

/**
 * @brief     Check if SpCell PLMN exists in SCell's PLMNs
 * @param     servingPlmn : plmn of spCell
 * @param     sCellNum : cellNum of SCell
 * @return    TRUE : SpCell's plmn exist in SCell's PLMNs
 * @return    FALSE : PLMNs differ
 */
uint8_t VLIB_CheckCellPlmn(uint32_t servingPlmn, uint16_t sCellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_FALSE(sCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[sCellNum];
    uint8_t idx = 0;

    for (idx = 0; idx < MIN(pCell->cellPlmn.numOfPLMN, MAX_PLMN_INDEX); ++idx)
    {
        if (pCell->cellPlmn.servedPlmn[idx] == servingPlmn)
        {
            return TRUE;
        }
    }

    return FALSE;
}

/**
 * @brief     Check if SpCell PLMN exists in neighbor PLMNs
 * @param     servingPlmn : plmn of spCell
 * @param     ptNbrGnbCellInfo : pointer to neighbor cell info
 * @return    TRUE : SpCell's plmn exist in SCell's PLMNs
 * @return    FALSE : PLMNs differ
 */
uint8_t VLIB_CheckNeighborPlmn(uint32_t servingPlmn, nbrGnbCellInfo_type *ptNbrGnbCellInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptNbrGnbCellInfo);
    uint8_t idx = 0;

    for (idx = 0; idx < MAX_PLMN_INDEX; ++idx)
    {
        if (EQUIP != ptNbrGnbCellInfo->cellPlmnInfo[idx].shmStatus)
        {
            continue;
        }
        if (servingPlmn == ptNbrGnbCellInfo->cellPlmnInfo[idx].longId)
        {
            return TRUE;
        }
    }

    return FALSE;
}
/**
 * @brief     Check if SpCell PLMN exists in SCell's PLMNs and return its index
 * @param     servingPlmn : plmn of spCell
 * @param     sCellNum : cellNum of SCell
 * @param     retIdx : pointer with PLMN idx
 * @return    TRUE : SpCell's plmn exist in SCell's PLMNs
 * @return    FALSE : PLMNs differ
 */
uint8_t VLIB_GetCellPlmnIdx(uint32_t servingPlmn, uint16_t sCellNum, uint8_t *retIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_FALSE(sCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[sCellNum];
    uint8_t idx = 0;

    for (idx = 0; idx < MIN(pCell->cellPlmn.numOfPLMN, MAX_PLMN_INDEX); ++idx)
    {
        if (pCell->cellPlmn.servedPlmn[idx] == servingPlmn)
        {
            *retIdx = idx;
            return TRUE;
        }
    }

    return FALSE;
}

/**
 * @brief     Check whether the target cell belongs to the gNB
 * @param     plmnId : PLMN of target cell
 * @param     cellIdentity : gNB ID + cell Id (36bits) of target cell
 * @param     gnbNum : number of current gNB
 * @return    TRUE : target cell belongs to the gNB
 * @return    FALSE : target cell no belongs to the gNB
 */
int16_t VLIB_isCellBelongsToGnb(plmnId_type *plmnId, uint64_t *cellIdentity, uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(plmnId);
    VALID_E_POINT_CHECK_FALSE(cellIdentity);
    VCCB_CHECK_VALID_GNBNUM_FALSE(gnbNum);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    uint16_t cellNum = MAX_CELL_NUM_VCCB;

    /* 1. Check gNB ID */
    const uint32_t gnbId = VLIB_NrCellId2GnbId(pGnb->globalGnbId.gnbId.idLength, *cellIdentity);
    if (gnbId != pGnb->globalGnbId.gnbId.id)
    {
        return FALSE;
    }

    /* 2. Check PLMN */
    if (FALSE == VCOM_CheckPlmnIdentical(&pGnb->globalGnbId.plmn, plmnId))
    {
        return FALSE;
    }

    /* 3. Get Cell Identity */
    const uint16_t cellId = VLIB_NrCellId2CellId(pGnb->globalGnbId.gnbId.idLength, *cellIdentity);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellId, MAX_CELL_IDENTITY);

    /* 4. Check whether Cell Identity exists in current gNB */
    int16_t status = FnVCCB_GetCellNumFromCellId(gnbNum, cellId, &cellNum);
    if (status != GOOD)
    {
        return FALSE;
    }

    return TRUE;
}

/**
 * @brief       Get cell number from CGI
 * @param[in]   cgi : CGI
 * @param[out]  ptCellNum : pointer to cell number
 */
int16_t VLIB_FindCellNumFromCGI(cgi_type cgi, CellNum_type *ptCellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCellNum);

    for (uint16_t gnbNum = 0; MAX_GNB_PER_SYS > gnbNum; ++gnbNum)
    {
        const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

        if (EQUIP != pGnb->status)
        {
            continue;
        }

        const uint8_t gnbIdLength = pGnb->globalGnbId.gnbId.idLength;
        const uint32_t cellGnbId = VLIB_NrCellId2GnbId(gnbIdLength, cgi.ci);

        if (false == VCCB_IS_SAME_GNB(cellGnbId, cgi.plmn.longId, gnbNum))
        {
            continue;
        }

        const uint16_t localCellId = VLIB_NrCellId2CellId(gnbIdLength, cgi.ci);

        if (GOOD != FnVCCB_GetCellNumFromCellId(gnbNum, localCellId, ptCellNum))
        {
            return ERROR;
        }

        return GOOD;
    }

    return ERROR;
}

nasMessage_type *FnVCCB_GetNasMeassInfo(uint16_t nasIdx)
{
    AUTO_TRACE_FUNC;

    if (nasIdx < VCCB_MAX_NAS_NUM)
    {
        return &CFG->nas.nasMessage[nasIdx];
    }

    return NULL;
}

/**
 * @brief     Allocate table for call NAS context
 */
int16_t VLIB_AllocNasInfo(nasInfo_type *ptNas, uint8_t idx, uint32_t len, uint8_t *ptVal)
{
    AUTO_TRACE_FUNC;

    uint16_t poolIdx;
    nasInformation_type *ptNasPool = &CFG->nas;

    VALID_E_POINT_CHECK_ERROR(ptNas);
    VCCB_CHECK_E_RANGE_AND_RETURN(idx, VCCB_MAX_NAS_NUM_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(len, MAX_NGAP_NAS_LEN + 1);

    ///// MUTEX LOCK /////
    MUTEX_LOCK(&gNasInfoAllocMutex);

    // Assign nasIndex
    ptNas->nasIndex[idx] = ptNasPool->nasIndex;

    ptNasPool->nasIndex++;
    if (ptNasPool->nasIndex >= VCCB_MAX_NAS_NUM) ptNasPool->nasIndex = 0;

    ///// MUTEX UNLOCK /////
    MUTEX_UNLOCK(&gNasInfoAllocMutex);

    poolIdx = ptNas->nasIndex[idx];
    VCCB_CHECK_E_RANGE_AND_RETURN(poolIdx, VCCB_MAX_NAS_NUM);

    nasMessage_type *ptItem = FnVCCB_GetNasMeassInfo(poolIdx);
    VALID_E_POINT_CHECK_ERROR(ptItem);

    ptItem->length = (uint16_t)len;
    memcpy(ptItem->data, ptVal, len);

    return GOOD;
}

/**
 * @brief     Convert address type from MdsIp_Type to TLA
 */
void VLIB_ConvertMdsIp_Type2TLA(uint8_t *TLAddr, uint16_t *numTLAbit, MdsIp_Type addr)
{
    AUTO_TRACE_FUNC;

    uint32_t loop;

    if (TLAddr == NULL)
    {
        VCCB_PRINT_ERROR("TLAddr(=NULL) in VLIB_ConvertMdsIp_Type2TLA\n");
        return;
    }
    if (numTLAbit == NULL)
    {
        VCCB_PRINT_ERROR("numTLAbit(=NULL) in VLIB_ConvertMdsIp_Type2TLA\n");
        return;
    }

    if (addr.IpVer == 4)
    {
        *numTLAbit = ADDRLEN_IPV4 * 8;
    }
    else
    {
        *numTLAbit = ADDRLEN_IPV6 * 8;
    }

    if (addr.IpVer == 4)
    {
        // memcpy(TLAddr, (char *)&addr.Ip.V4, ADDRLEN_IPV4);
        TLAddr[0] = (uint8_t)(addr.Ip.V4 >> 24) & 0x00FF;
        TLAddr[1] = (addr.Ip.V4 >> 16) & 0x00FF;
        TLAddr[2] = (addr.Ip.V4 >> 8) & 0x00FF;
        TLAddr[3] = addr.Ip.V4 & 0x00FF;
    }
    else
    {
        // memcpy(TLAddr, &addr.Ip.V6, ADDRLEN_IPV6);
        for (loop = 0; loop < ADDRLEN_IPV6; loop++)
        {
            TLAddr[loop] = addr.Ip.V6[loop];
        }
    }
}

bool isOutGoingHo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    switch (ptCi->mroInfo.ue.hoInitiated)
    {
        /* Inter-gNB */
        case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:
        case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:
            return TRUE;

        /* Intra-gNB */
        case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:
        case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
            return TRUE;  // HO_IN (Outgoing)

        /* Other */
        default:
            return FALSE;
    }

    return FALSE;
}

/**
 * @brief     Set DRB and QoS Flow which included in failed PDU to Idle
 */
void VLIB_setDrbAndQosFlowsToIdleInModifyFailedPdu(callInfo_type *ptCi, callPDUSessInfo_type *ptPi, uint8_t callPduIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPi);
    VCCB_CHECK_E_RANGE_AND_VOID(callPduIdx, MAX_PDU_SESS_PER_CALL);

    uint8_t pduDrbIdx = 0;
    uint8_t pduQosFlowIdx = 0, callQosFlowIdx = 0;
    uint16_t callDrbIdx = 0;
    callDRBInfo_type *ptDi = NULL;
    qosFlowInfo_type *ptQi = NULL;

    // Release DRBs which fail to setup and modify
    for (pduDrbIdx = 0; pduDrbIdx < MAX_DRB_PER_PDU_SESS; pduDrbIdx++)
    {
        callDrbIdx = ptCi->pduSess[callPduIdx].drbIndex[pduDrbIdx];  // put Drb Pool's data
        if (callDrbIdx >= MAX_DRB_PER_SA_CALL) continue;

        ptDi = &(ptCi->drb[callDrbIdx]);
        if (!IS_VALID_NODE(DRB_NODE, ptCi, ptDi)) continue;

        const bool isSetupCase = {ptDi->drbStatus == S_Setup || ptDi->drbStatus == S_FailToSetup};
        const bool isModCase =  {ptDi->drbStatus == S_Modify || ptDi->drbStatus == S_FailToModify};
        const bool isMultiUpPartialSuccState = {ptCi->endPointInfo.srvAupfNum > 1 && STATE_INTER_Compl_T == ptCi->state};

        if (isSetupCase ||
            (isModCase && (ptDi->firstReqStatusInThisProcedure == S_Setup && !isMultiUpPartialSuccState)))
        {
            if (VLIB_FreeCallDrbInfoUnderPdu(ptCi, callPduIdx, pduDrbIdx) != GOOD)
            {
                VCCB_PRINT_ERROR("VLIB_FreeCallDrbInfoUnderPdu ERROR!! \n");
            }
            SET_DRB_STATUS(ptCi, callDrbIdx, S_Idle);
        }
        else
        {
            // S_FailToModify, S_Release, S_FailToRelease : Currently No Case (If DRB Modify Rollback is Supported, To do something).
            // S_Idle, S_Null : No Change. So No Action.
            // Do nothing.
        }
        ptCi->drb[callDrbIdx].prevDrbStatus = S_Idle;
        ptCi->drb[callDrbIdx].failCause = CAUSE_NO_FAULT;
    }

    // Release Qos Flow which fail to setup and modify
    for (pduQosFlowIdx = 0; pduQosFlowIdx < MAX_QOS_FLOW_PER_PDU_SESS; pduQosFlowIdx++)
    {
        callQosFlowIdx = (uint8_t)ptCi->pduSess[callPduIdx].qosFlowIndex[pduQosFlowIdx];
        if (callQosFlowIdx >= MAX_QOS_FLOW_PER_CALL) continue;

        ptQi = &ptCi->qosFlow[callQosFlowIdx];
        if (!IS_VALID_NODE(QOSFLOW_NODE, ptCi, ptQi)) continue;

        if (ptQi->qosFlowStatus == S_Idle) continue;

        const bool isSetupCase = {ptQi->qosFlowStatus == S_Setup || ptQi->qosFlowStatus == S_FailToSetup};
        const bool isModCase =  {ptQi->qosFlowStatus == S_Modify || ptQi->qosFlowStatus == S_FailToModify};
        const bool isMultiUpPartialSuccState = {ptCi->endPointInfo.srvAupfNum > 1 && STATE_INTER_Compl_T == ptCi->state};

        if (isSetupCase ||
            (isModCase && (ptQi->firstReqStatusInThisProcedure == S_Setup && !isMultiUpPartialSuccState)))
        {
            if (VLIB_FreeCallQosFlowInfoUnderPdu(ptCi, callPduIdx, pduQosFlowIdx) != GOOD)
            {
                VCCB_PRINT_ERROR("VLIB_FreeCallQosFlowInfoUnderPdu ERROR!! \n");
            }
        }
        // S_FailToModify  : Set to Idle
        // S_Release       : No Case But Set to Idle.
        // S_FailToRelease : Set to Idle

        SET_QOSFLOW_STATUS(ptCi, callQosFlowIdx, S_Idle);
        ptCi->qosFlow[callQosFlowIdx].prevQosFlowStatus = S_Idle;
        ptCi->qosFlow[callQosFlowIdx].failCause = CAUSE_NO_FAULT;
        CLEAR_RETAIN_STAT_EVENT(ptCi->qosFlow[callQosFlowIdx].retainStat);
        if (ptCi->qosFlow[callQosFlowIdx].usage == CI_use)
        {
            SET_QOSFLOW_RETAIN_STAT_CAPABLE_FLAG(&ptCi->qosFlow[callQosFlowIdx], VCCB_FLAG_ON);
        }


        /* Add the initialize data forwarding information */
        memset(&ptCi->qosFlow[callQosFlowIdx].dataFwdInfo, 0, sizeof(ptCi->qosFlow[callQosFlowIdx].dataFwdInfo));

        /* Add the initialize releaseInfo */
        memset(&ptCi->qosFlow[callQosFlowIdx].releaseInfo, 0, sizeof(ptCi->qosFlow[callQosFlowIdx].releaseInfo));
    }

    return;
}


/**
 * @brief     Set radio bearer status to idle
 */
void VLIB_setBearerStatusToIdle(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t srb, erab;
    uint8_t callPduIdx;
    const bool isMultiUpPartialSuccState = {ptCi->endPointInfo.srvAupfNum > 1 && STATE_INTER_Compl_T == ptCi->state};
    callPDUSessInfo_type *ptPi = NULL;

    for (srb = 0; srb < MAX_SRB_PER_CALL; srb++)
    {
        if (!IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[srb]))) continue;

        if ((ptCi->srbInfo[srb].srbStatus == ERAB_Release) || (ptCi->srbInfo[srb].srbStatus == ERAB_FailToSetup))
        {
            if (VLIB_FreeCallSrbInfo(ptCi, srb) != GOOD)
            {
                VCCB_PRINT_ERROR("VLIB_FreeCallSrbInfo ERROR!! \n");
            }
            if (ptCi->srb3Idx == srb)
            {
                ptCi->srb3Idx = MAX_SRB_PER_CALL;
            }
        }

        ptCi->srbInfo[srb].srbStatus = ERAB_Idle;
    }

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        // Failure STAT.
        if (ptCi->cause.callFault.callFaultCause != CAUSE_NO_FAULT)
        {
            VLIB_PduSessionResourceSetup_CollectStat_PutCi(ptCi);
            VLIB_DrbSetup_CollectStat_PutCi(ptCi);
            VLIB_QosFlowSetup_CollectStat_PutCi(ptCi);
        }

        if (DBG->flag.reuseDrbId == FLAG_ON)
        {
            ptCi->drbIdPool = 0;  // drbIdPool is initialized and reset for preventing drbId management error
        }

        // Check if Signaling Inactivity Timer Restart
        FnVCCB_CheckBearerAndUpdateSignalingUserInactivity(ptCi);

        for (callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
        {
            if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[callPduIdx]))) continue;
            if (ptCi->pduSess[callPduIdx].usage != CI_use) continue;

            ptPi = &ptCi->pduSess[callPduIdx];
            ptPi->isSpecificSlice = false;
            ptPi->specificSliceHasFailInNgStore = false;
            switch (ptPi->pduSessStatus)
            {
                case S_Setup:
                    if (IS_NRDC_SN(ptCi) && (FALSE == FnVCCB_ExistValidSNTermBearerInPdu(ptCi, ptPi)))
                    {
                        if (FALSE == VLIB_setDrbsToIdleInPdu(ptCi, ptPi, callPduIdx))
                        {
                            continue;
                        }
                        VLIB_setQosFlowsToIdleInPdu(ptCi, ptPi, callPduIdx, VCCB_FLAG_ON);
                    }
                    else
                    {
                        // Unreachable status
                        VCCB_PRINT_CALL_ERROR(ptCi,
                            "VLIB_setBearerStatusToIdle invalid PDU status(S_Setup) during PDU "
                            "processing operation.\n");
                    }
                    break;
                case S_Idle:  // For NR-DC case, to adjust abnormal drb status
                case S_Modify:
                    if (FALSE == VLIB_setDrbsToIdleInPdu(ptCi, ptPi, callPduIdx))
                    {
                        continue;
                    }
                    VLIB_setQosFlowsToIdleInPdu(ptCi, ptPi, callPduIdx, VCCB_FLAG_ON);

                    if (ptPi->firstReqStatusInThisProcedure == S_Setup)
                    {
                        MACRO_STAT_PMCC_PDU_SETUP_FAMILY_ALL(
                            PduSetupSucc, ptCi, &(ptCi->pduSess[callPduIdx]), 0, 0, 0, 0);

                        FnVCCB_SetSliceLbTriggerEvent(ptCi, S_Setup); //SVR23B FGR-LC0710
                    }
                    else if (ptPi->firstReqStatusInThisProcedure == S_Modify)
                    {
                        // PDU Modify Stat
                        if (ptPi->pduStatistic.attemptFlag[PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP] == ATTEMPT_MADE)
                        {
                            MACRO_STAT_PMCC_PDU(STAT_PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP, PduSetupSucc, ptCi, ptPi, 0, 0, 0, 0);
                        }
                    }
                    break;
                case S_Release:
                    if (VLIB_FreeCallPduInfo(ptCi, callPduIdx) != GOOD)  // DRB, QosFlow also released in here
                    {
                        VCCB_PRINT_ERROR("VLIB_FreeCallPduInfo ERROR!! \n");
                    }

                    FnVCCB_SetSliceLbTriggerEvent(ptCi, S_Release); //SVR23B FGR-LC0710
                    break;
                case S_FailToSetup:
                case S_FailToModify:
                    if (ptPi->firstReqStatusInThisProcedure == S_Setup && !isMultiUpPartialSuccState)
                    {
                        // Statistics
                        if (ptPi->pduStatistic.attemptFlag[PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI] == ATTEMPT_MADE)
                        {
                            VLIB_PduSessionResourceSetup_CollectStat_FailedPduItem(
                                ptCi, ptPi->failCause, callPduIdx, STAT_PDU_SESSION_RESOURCE_SETUP_PLMN_SNSSAI);
                        }

                        if (VCCB_FLAG_ON == ptCi->bitFlag.isPartialDrbForRreDuringHo)
                        {
                            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Skip VLIB_FreeCallPduInfo pdu:%d isPartialDrbForRreDuringHo(%llu)!\n",
                                ptPi->pduSessId, 1ULL * ptCi->bitFlag.isPartialDrbForRreDuringHo);
                            continue;
                        }

                        if (VLIB_FreeCallPduInfo(ptCi, callPduIdx) != GOOD)  // DRB, QosFlow also released in here
                        {
                            VCCB_PRINT_ERROR("VLIB_FreeCallPduInfo ERROR!! \n");
                        }
                    }
                    else  // Modify -> Modify Fail
                    {
                        // VLIB_FreeCallPduInfo should not be called because the failed PDU should also be maintained
                        // The DRB/QosFlow resource that failed to set up is released.
                        // If DRB/QosFlow to be modify are included, call will be released without calling this function.

                        if (ptPi->firstReqStatusInThisProcedure == S_Modify)
                        {
                            // PDU Modify Stat
                            if (ptPi->pduStatistic.attemptFlag[PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP] == ATTEMPT_MADE)
                            {
                                VLIB_PduSessionResourceSetup_CollectStat_FailedPduItem(
                                    ptCi, ptPi->failCause, callPduIdx, STAT_PDU_SESSION_RESOURCE_MODIFY_PLMN_SNSSAI_RFSP);
                            }
                        }
                        VLIB_setDrbAndQosFlowsToIdleInModifyFailedPdu(ptCi, ptPi, callPduIdx);
                    }
                    break;
                default:
                    break;
            }

            ptCi->pduSess[callPduIdx].failCause = CAUSE_NO_FAULT;
            SET_PDU_STATUS(ptCi, callPduIdx, S_Idle);
            ptCi->pduSess[callPduIdx].prevPduSessStatus = S_Idle;
            ptCi->pduSess[callPduIdx].flag.respFlag = 0;
            ptCi->pduSess[callPduIdx].flag.releaseFlag = 0;
            ptCi->pduSess[callPduIdx].snRejRelCause.present = VCCB_FLAG_OFF;
        }
        ptCi->traceVoNR = (uint8_t)FnVCCB_CheckIsVoNRInService(ptCi);
        // Check Data Inactivity by DRB.
        FnVCCB_CheckBearerAndUpdateDataUserInactivity(ptCi);
        FnVCCB_FinalizeAfterDrbPartial(ptCi);
        FnVCCB_InitSavedRequestedFlagForPduQosFlowVonr(ptCi);
        FnVCCB_ClearAllMrdcFlags(ptCi);
    }
    else
    {
        VLIB_PrepareLatestReleasedQcis(ptCi, TRUE);
        for (erab = 0; erab < MAX_ERAB_PER_CALL; erab++)
        {
            if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[erab]))) continue;

            if (ptCi->erabInfo[erab].erabStatus == ERAB_Release)
            {
                VLIB_CalculateErabHoldTime(ptCi, &(ptCi->erabInfo[erab]), CAL_STOP);
                if (VLIB_FreeCallErabInfo(ptCi, erab) != GOOD)
                {
                    VCCB_PRINT_ERROR("VLIB_FreeCallErabInfo ERROR!! \n");
                }
            }
            ptCi->erabInfo[erab].erabQos.qciValue.oldQCI = ptCi->erabInfo[erab].erabQos.qciValue.QCI;
            ptCi->erabInfo[erab].preveBearerType = ptCi->erabInfo[erab].bearerType;
            ptCi->erabInfo[erab].erabStatus = ERAB_Idle;
            ptCi->erabInfo[erab].prevErabStatus = ERAB_Idle;
            ptCi->erabInfo[erab].ulPdcpPathToMod = UlConfigBearer_ModOff;
        }
    }

    ptCi->f1Info.f1UeContextToRemove_flag = VCCB_FLAG_OFF;

    // SVR26A P2 FGR-RC0100 FR550
    // Defensive code
    // SCC is not considered.
    if (FnVCCB_IsVoNRCall(ptCi) == FALSE)
    {
        if (ptCi->caInfo.releaseCaA4ForVoNROn == TRUE)
        {
            ptCi->caInfo.releaseCaA4ForVoNROn = FALSE;
            if (ERROR == VCCB_PrepareAdditionalMeasConfig(ptCi))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_PrepareAdditionalMeasConfig ERROR!!\n");
            }
            else //GOOD
            {
                VCCB_RETURN_ON_CALL_VOID(ptCi, VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full),
                        "VCCM_enqueueAction(ENQUEUE_ACTION_MEAS_RECONFIG) fail!\n");
            }
        }
    }
}

/**
 * @brief     Convert address type from TLA to MdsIp_Type
 */
MdsIp_Type VLIB_ConvertTLA2MdsIp_Type(const uint8_t *TLAddr, uint16_t numTLAbit)
{
    AUTO_TRACE_FUNC;

    MdsIp_Type addr;
    uint32_t loop;

    addr.IpVer = 4;
    addr.Ip.V4 = 0;

    if (TLAddr == NULL)
    {
        VCCB_PRINT_ERROR("TLAddr(=NULL) in VLIB_ConvertTLA2MdsIp_Type\n");
        return (addr);
    }

    if (numTLAbit == (ADDRLEN_IPV6 * 8))
    {
        addr.IpVer = 6;
    }
    else
    {
        addr.IpVer = 4;
    }

    if (addr.IpVer == 4)
    {
        // memcpy((char *)&addr.Ip.V4, TLAddr, ADDRLEN_IPV4);
        for (loop = 0; loop < ADDRLEN_IPV4; loop++)
        {
            addr.Ip.V4 = (addr.Ip.V4 << 8) + TLAddr[loop];
        }
    }
    else
    {
        // memcpy(&addr.Ip.V6, TLAddr, ADDRLEN_IPV6);
        for (loop = 0; loop < ADDRLEN_IPV6; loop++)
        {
            addr.Ip.V6[loop] = TLAddr[loop];
        }
    }

    return (addr);
}

int16_t FnVCCB_CheckMccMncValidity(uint8_t *ptValue, uint8_t len)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptValue);

    int index = 0;

    // Discard
    if (ptValue[0] == 'F' && ptValue[1] == 'F' && ptValue[2] == 'F')
    {
        return ERROR;
    }

    for (index = 0; index < MIN(len, MAX_MCC_MNC_CHAR_SIZE); index++)
    {
        if (ptValue[index] < '0' || ptValue[index] > '9')
        {
            VCCB_PRINT_ERROR("Can't convert PLMN ID - MCC contains invalid character(%c). (Input:%c%c%c)\n",
                ptValue[index], ptValue[0], ptValue[1], ptValue[2]);
            return ERROR;
        }
    }

    return GOOD;
}

int16_t FnVCCB_ConvertCharMccToS2Type(uint8_t *ptMcc, uint8_t mccLen, s2_type *ptS2Type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptMcc);
    VALID_E_POINT_CHECK_ERROR(ptS2Type);

    int16_t status = GOOD;

    status = FnVCCB_CheckMccMncValidity(ptMcc, mccLen);
    if (status == ERROR) return status;

    ptS2Type->mcc = 0;

    switch (mccLen)
    {
        case 1:
        case 2:
            VCCB_PRINT_ERROR("Invalid MCC Length!(%d)\n", mccLen);
            return ERROR;
        case 3:
            ptS2Type->mcc =
                (uint32_t)((((ptMcc[0] - '0') & 0xF) << 8) | (((ptMcc[1] - '0') & 0xF) << 4) | ((ptMcc[2] - '0') & 0xF)) & e_BitMask_12bit;
            break;

        default:
            break;
    }

    return GOOD;
}

int16_t FnVCCB_ConvertCharMncToS2Type(uint8_t *ptMnc, uint8_t mncLen, s2_type *ptS2Type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptMnc);
    VALID_E_POINT_CHECK_ERROR(ptS2Type);

    int16_t status = GOOD;

    status = FnVCCB_CheckMccMncValidity(ptMnc, mncLen);
    if (status == ERROR) return status;

    ptS2Type->mnc = 0;

    switch (mncLen)
    {
        case 1:
            VCCB_PRINT_ERROR("Invalid MNC Length!(%d)\n", mncLen);
            return ERROR;
        case 2:
            // ptS2Type->mnc = (((ptMnc[0] - '0') & 0xF) << 4) | ((ptMnc[1] - '0') & 0xF);
            ptS2Type->mnc = (uint32_t)((((ptMnc[0] - '0') & 0xF) << 8) | (((ptMnc[1] - '0') & 0xF) << 4) | 0xF) & e_BitMask_12bit;
            break;
        case 3:
            ptS2Type->mnc =
                (uint32_t)((((ptMnc[0] - '0') & 0xF) << 8) | (((ptMnc[1] - '0') & 0xF) << 4) | ((ptMnc[2] - '0') & 0xF)) & e_BitMask_12bit;
            break;

        default:
            break;
    }

    return GOOD;
}

int16_t FnVCCB_GetS2TypeMccMnc(const dal_value_t *ptValue, s2_type *ptS2Type, enumMccMnc_type type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptValue);
    VALID_E_POINT_CHECK_ERROR(ptS2Type);

    char *value = NULL;
    uint32_t len = 0;

    value = DAL_GET_CBUFPTR(ptValue);
    len = DAL_GET_BUFSIZE(ptValue);

    switch (type)
    {
        case MCC_TYPE:
            return FnVCCB_ConvertCharMccToS2Type((uint8_t *)value, (uint8_t)len, ptS2Type);

        case MNC_TYPE:
            return FnVCCB_ConvertCharMncToS2Type((uint8_t *)value, (uint8_t)len, ptS2Type);

        default:
            break;
    }

    return GOOD;
}

/*
 * @brief   Get MCC and MNC
 *
 * @param[in]       p_value : pointer to value of MCC or MNC
 * @param[in/out]   nbrEnbCellInfo : pointer to nbrEnbCellInfo_type
 * @param[in]       plmn_Index : array index
 * @param[in]       type : whether it is MCC or MNC (MCC_TYPE, MNC_TYPE)
 * @return          GOOD/ERROR
 */
void VLIB_GetNbrEnbCellMccMnc(dal_value_t *p_value, nbrEnbCellInfo_type *nbrEnbCellInfo, uint8_t plmn_Index, enumMccMnc_type type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(p_value);
    VALID_E_POINT_CHECK_VOID(nbrEnbCellInfo);
    VCCB_CHECK_E_RANGE_AND_VOID(plmn_Index, MAX_NUM_PLMN_LTE);

    if (MCC_TYPE == type)
    {
        if (p_value->type == DAL_C_NOEXISTS)
        {
            nbrEnbCellInfo->cellPlmnInfo[plmn_Index].s2.mcc = 0xFFF;
        }
        else
        {
            if (ERROR == FnVCCB_GetS2TypeMccMnc(p_value, &nbrEnbCellInfo->cellPlmnInfo[plmn_Index].s2, MCC_TYPE))
            {
                nbrEnbCellInfo->cellPlmnInfo[plmn_Index].s2.mcc = 0xFFF;
            }
        }
    }
    else if (MNC_TYPE == type)
    {
        if (p_value->type == DAL_C_NOEXISTS)
        {
            nbrEnbCellInfo->cellPlmnInfo[plmn_Index].s2.mnc = 0xFFF;
        }
        else
        {
            if (ERROR == FnVCCB_GetS2TypeMccMnc(p_value, &nbrEnbCellInfo->cellPlmnInfo[plmn_Index].s2, MNC_TYPE))
            {
                nbrEnbCellInfo->cellPlmnInfo[plmn_Index].s2.mnc = 0xFFF;
            }
        }
    }

    if (0xFFF != nbrEnbCellInfo->cellPlmnInfo[plmn_Index].s2.mcc &&
        0xFFF != nbrEnbCellInfo->cellPlmnInfo[plmn_Index].s2.mnc)
    {
        nbrEnbCellInfo->cellPlmnInfo[plmn_Index].shmStatus = EQUIP;
    }
    else
    {
        nbrEnbCellInfo->cellPlmnInfo[plmn_Index].shmStatus = N_EQUIP;
    }
}

/*
 * @brief   Get MCC and MNC
 *
 * @param[in]       p_value : pointer to value of MCC or MNC
 * @param[in/out]   nbrGnbCellInfo : pointer to nbrGnbCellInfo_type
 * @param[in]       plmn_Index : array index
 * @param[in]       type : whether it is MCC or MNC (MCC_TYPE, MNC_TYPE)
 * @return          GOOD/ERROR
 */
void VLIB_GetNbrGnbCellMccMnc(dal_value_t *p_value, nbrGnbCellInfo_type *nbrGnbCellInfo, uint8_t plmn_Index, enumMccMnc_type type)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(p_value);
    VALID_E_POINT_CHECK_VOID(nbrGnbCellInfo);
    VCCB_CHECK_E_RANGE_AND_VOID(plmn_Index, MAX_PLMN_INDEX);

    if (MCC_TYPE == type)
    {
        if (p_value->type == DAL_C_NOEXISTS)
        {
            nbrGnbCellInfo->cellPlmnInfo[plmn_Index].s2.mcc = 0xFFF;
        }
        else
        {
            if (ERROR == FnVCCB_GetS2TypeMccMnc(p_value, &nbrGnbCellInfo->cellPlmnInfo[plmn_Index].s2, MCC_TYPE))
            {
                nbrGnbCellInfo->cellPlmnInfo[plmn_Index].s2.mcc = 0xFFF;
            }
        }
    }
    else if (MNC_TYPE == type)
    {
        if (p_value->type == DAL_C_NOEXISTS)
        {
            nbrGnbCellInfo->cellPlmnInfo[plmn_Index].s2.mnc = 0xFFF;
        }
        else
        {
            if (ERROR == FnVCCB_GetS2TypeMccMnc(p_value, &nbrGnbCellInfo->cellPlmnInfo[plmn_Index].s2, MNC_TYPE))
            {
                nbrGnbCellInfo->cellPlmnInfo[plmn_Index].s2.mnc = 0xFFF;
            }
        }
    }

    if (0xFFF != nbrGnbCellInfo->cellPlmnInfo[plmn_Index].s2.mcc &&
        0xFFF != nbrGnbCellInfo->cellPlmnInfo[plmn_Index].s2.mnc)
    {
        nbrGnbCellInfo->cellPlmnInfo[plmn_Index].shmStatus = EQUIP;
    }
    else
    {
        nbrGnbCellInfo->cellPlmnInfo[plmn_Index].shmStatus = N_EQUIP;
    }
}

/*
 * @brief   Get NR Frequency Band
 *
 * @param[in]       p_value : pointer to value of MCC or MNC
 * @param[in/out]   nbrGnbCellInfo : pointer to nbrGnbCellInfo_type
 * @param[in]       idx : array index
 * @return          GOOD/ERROR
 */
void VLIB_GetNbrGnbCellFreqBand(dal_value_t *p_value, nbrGnbCellInfo_type *nbrGnbCellInfo, uint8_t idx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(p_value);
    VALID_E_POINT_CHECK_VOID(nbrGnbCellInfo);
    VCCB_CHECK_E_RANGE_AND_VOID(idx, MAX_FREQBAND_PER_CELL);

    int16_t temp = DAL_GET_INT16(p_value);
    if (temp < 0)
        nbrGnbCellInfo->freqBandInfoList[idx].status = CI_no_use;
    else
    {
        nbrGnbCellInfo->freqBandInfoList[idx].nRFrequencyBand = ((uint16_t)temp) & e_BitMask_15bit;
        nbrGnbCellInfo->freqBandInfoList[idx].status = CI_use;
    }
}

/**
 * @brief     Get message peer information
 */
uint8_t VLIB_GetMsgPeerInfo(uint32_t blockType)
{
    AUTO_TRACE_FUNC;

    switch (blockType)
    {
        case BLOCK_VNMB:
            return BLK_VNMB;

        case BLOCK_VCCB:
            return BLK_VCCB;

        case BLOCK_VNLB:
            return BLK_VNLB;
        case BLOCK_OSAB:
            return BLK_OSAB;

        default:
            return BLK_UNKNOWN;
    }
}

/**
 * @brief     Get CellNum from PhysCellId
 */
int16_t VLIB_GetCellNumFromPhysCellId(
    callInfo_type *ptCi, uint16_t gnbNum, uint16_t physCellId, uint32_t ssbFrequency, uint16_t *cellNum)
{
    AUTO_TRACE_FUNC;

    uint16_t tmpCellNum = 0, loop;
    uint8_t matchedFlag = VCCB_FLAG_OFF;
    uint8_t isMatchedCellExist = FALSE;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(cellNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    failedPCIInfo_type *pFailedPCIInfo = &THREAD_INFO->call[ptCi->myThreadId].failedPCIInfoForRecovery;

    const uint16_t maxCellNum = MAX_CELL_NUM_VCCB;
    const VccbCellInfo_type *const pCells = CELLINFO;

    if (ssbFrequency != UNKNOWN_ARFCN)  // This case is for that ssbFrequency is included in measResult2NR
    {
        for (loop = 0; loop < maxCellNum; loop++)
        {
            const VccbCellInfo_type *const pCell = &pCells[loop];

            if (pCell->pldState != EQUIP)
            {
                continue;
            }

            if (pCell->gnbNum != gnbNum)
            {
                continue;
            }

            if ((pCell->phyCellId == physCellId) && (pCell->ssbArfcn == ssbFrequency))
            {
                isMatchedCellExist = TRUE;
                if (ERROR == VCCM_CheckCellInService(ptCi, loop, FALSE, FALSE))
                {
                    continue;
                }

                if (matchedFlag == VCCB_FLAG_OFF)
                {
                    *cellNum = loop;
                    matchedFlag = VCCB_FLAG_ON;
                }
                else
                {
                    // if there is same combination of ssbFrequency and phyCellId in other cell,
                    // cellNum couldn't be get.

                    // This case is not recovery target
                    pFailedPCIInfo->failedDueToRecoveryTargetParam = FALSE;

                    VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbFrequency, StatEndcSpCellSelFail_nonNrcgi_SamePciAndSsbFeqInMoreCells);

                    return ERROR;
                }
            }
        }

        if (matchedFlag == VCCB_FLAG_ON)
        {
            return GOOD;
        }
        else
        {
            if (isMatchedCellExist == FALSE)
            {
                // Cannot find Cell using the physCellId and ssbArfcn: Recovery Target
                pFailedPCIInfo->failedDueToRecoveryTargetParam = TRUE;

                VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbFrequency, StatEndcSpCellSelFail_nonNrcgi_PciAndSsbFeqNoAvailable);
            }
            else
            {
                enumStatSpCellSelectionFailCause_type cause =
                    (ptCi->bitFlag.spCellSelCellBarredWithSwitchOff && pGnb->cfg.endcAddWithSwitchingOffCells)
                        ? StatEndcSpCellSelFail_nonNrcgi_MibCellBarred : StatEndcSpCellSelFail_nonNrcgi_CellOosOrBarred;

                VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbFrequency, cause);
                ptCi->bitFlag.spCellSelCellBarredWithSwitchOff = false;
            }
        }
    }
    // If ssbFrequency is UNKNOWN_ARFCN, then VCCB check only phyCellId.
    else
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(physCellId, MAX_PHYSICAL_CELL_ID + 1);

        // If there are Cells with the same PCI or there is no Cell with the PCI,
        // the PCI is excluded from the cell selection target.
        if (pGnb->env.pcidInfo[physCellId].usedCellCount != 1)
        {
            if (pGnb->env.pcidInfo[physCellId].usedCellCount == 0)
            {
                // Cannot find Cell using the physCellId: Recovery Target
                pFailedPCIInfo->failedDueToRecoveryTargetParam = TRUE;
                VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbFrequency, StatEndcSpCellSelFail_nonNrcgi_PciAndSsbFeqNoAvailable);
            }
            else
            {
                VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbFrequency, StatEndcSpCellSelFail_nonNrcgi_SamePciAndSsbFeqInMoreCells);
            }

            return ERROR;
        }

        tmpCellNum = pGnb->env.pcidInfo[physCellId].usedCellNum;
        VCCB_CHECK_E_RANGE_AND_RETURN(tmpCellNum, maxCellNum);

        const VccbCellInfo_type *const pCell = &pCells[tmpCellNum];

        if (ERROR == VCCM_CheckCellInService(ptCi, tmpCellNum, FALSE, FALSE))
        {
            enumStatSpCellSelectionFailCause_type cause =
                (ptCi->bitFlag.spCellSelCellBarredWithSwitchOff && pGnb->cfg.endcAddWithSwitchingOffCells)
                    ? StatEndcSpCellSelFail_nonNrcgi_MibCellBarred : StatEndcSpCellSelFail_nonNrcgi_CellOosOrBarred;

            VLIB_SaveCauseOfRejectCandidateCell(ptCi, pCell->cellIdentity, ssbFrequency, cause);
            ptCi->bitFlag.spCellSelCellBarredWithSwitchOff = false;
            return ERROR;
        }

        if (pCell->gnbNum != gnbNum)
        {
            return ERROR;
        }

        if (pCell->phyCellId == physCellId)
        {
            *cellNum = tmpCellNum;
            return GOOD;
        }
    }

    return ERROR;
}

/**
 * @brief     QSort cellList using rsrp in Descending Order
 */
int VLIB_QsortCandidateCellRsrpDescendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    candidateCellForSort_type a, b;

    VALID_E_POINT_CHECK_ERROR(arg1);
    VALID_E_POINT_CHECK_ERROR(arg2);

    a = *(candidateCellForSort_type *)arg1;
    b = *(candidateCellForSort_type *)arg2;

    // b-a for descending order
    if (a.rsrp > b.rsrp)
    {
        return -1;
    }
    if (a.rsrp < b.rsrp)
    {
        return 1;
    }

    return 0;
}

/**
 * @brief     QSort cellList using cell priority in Descending Order
 */
int VLIB_QsortCandidateCellPriorityDescendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    candidateCellForSort_type a, b;

    VALID_E_POINT_CHECK_ERROR(arg1);
    VALID_E_POINT_CHECK_ERROR(arg2);

    a = *(candidateCellForSort_type *)arg1;
    b = *(candidateCellForSort_type *)arg2;

    // b-a for descending order
    if (a.priority > b.priority)
    {
        return -1;
    }
    if (a.priority < b.priority)
    {
        return 1;
    }

    return 0;
}

/**
 * @brief     QSort candidatesNrFreqItems using cellReselectionPriority, cellReselectionSubpriority and freqIdx in
 * Descending Order
 */
int VLIB_QsortCandidateNrFreqItemsDescendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(arg1);
    VALID_E_POINT_CHECK_ERROR(arg2);

    rfspFreqItem_type a, b;
    uint8_t reselectionPriorityA = 0, reselectionPriorityB = 0;

    a = *(rfspFreqItem_type *)arg1;
    b = *(rfspFreqItem_type *)arg2;

    // b-a for descending order

    reselectionPriorityA = (uint8_t)(a.cellReselectionPriority * 10);
    if (CI_use == a.cellReselectionSubpriorityUsage)
    {  // Need to add 1. Because cellReselectionSubpriority is enum value, so 0.2 value is 0.
        reselectionPriorityA = (uint8_t)(reselectionPriorityA + a.cellReselectionSubpriority + 1);
    }

    reselectionPriorityB = (uint8_t)(b.cellReselectionPriority * 10);
    if (CI_use == b.cellReselectionSubpriorityUsage)
    {  // Need to add 1. Because cellReselectionSubpriority is enum value, so 0.2 value is 0.
        reselectionPriorityB = (uint8_t)(reselectionPriorityB + b.cellReselectionSubpriority + 1);
    }

    if (reselectionPriorityA > reselectionPriorityB)
    {
        return -1;
    }
    else if (reselectionPriorityA < reselectionPriorityB)
    {
        return 1;
    }

    if (a.freqIdx < b.freqIdx)
    {
        return -1;
    }
    else if (a.freqIdx > b.freqIdx)
    {
        return 1;
    }

    return 0;
}


/**
 * @brief     QSort candidatesNrFreqItems using nrdcCellReselectionPriority, nrdcCellReselectionSubpriority and freqIdx in
 * Descending Order
 */
int VLIB_QsortCandidateNrFreqItemsNrdcDescendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(arg1);
    VALID_E_POINT_CHECK_ERROR(arg2);

    rfspFreqItem_type a, b;
    uint8_t reselectionPriorityA = 0, reselectionPriorityB = 0;

    a = *(rfspFreqItem_type *)arg1;
    b = *(rfspFreqItem_type *)arg2;

    // b-a for descending order

    reselectionPriorityA = (uint8_t)(a.nrdcCellReselectionPriority * 10);
    if (CI_use == a.nrdcCellReselectionSubpriorityUsage)
    {  // Need to add 1. Because nrdcCellReselectionSubpriority is enum value, so 0.2 value is 0.
        reselectionPriorityA = (uint8_t)(reselectionPriorityA + a.nrdcCellReselectionSubpriority + 1);
    }

    reselectionPriorityB = (uint8_t)(b.nrdcCellReselectionPriority * 10);
    if (CI_use == b.nrdcCellReselectionSubpriorityUsage)
    {  // Need to add 1. Because nrdcCellReselectionSubpriority is enum value, so 0.2 value is 0.
        reselectionPriorityB = (uint8_t)(reselectionPriorityB + b.nrdcCellReselectionSubpriority + 1);
    }

    if (reselectionPriorityA > reselectionPriorityB)
    {
        return -1;
    }
    else if (reselectionPriorityA < reselectionPriorityB)
    {
        return 1;
    }

    if (a.freqIdx < b.freqIdx)
    {
        return -1;
    }
    else if (a.freqIdx > b.freqIdx)
    {
        return 1;
    }

    return 0;
}

/**
 * @brief     QSort cellList using cell ueCount in Ascending Order
 */
int VLIB_QsortCandidateCellUeCountAscendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ZERO(arg1);
    VALID_E_POINT_CHECK_ZERO(arg2);

    const candidateCellForSort_type &a = *(candidateCellForSort_type *)arg1;
    const candidateCellForSort_type &b = *(candidateCellForSort_type *)arg2;

    // a-b for ascending order
    if (a.ueCount < b.ueCount)
    {
        return -1;
    }
    if (a.ueCount > b.ueCount)
    {
        return 1;
    }

    return 0;
}

/**
 * @brief Update Cell List of All DU.
 *
 */
void VLIB_UpdateCellListOfAllDu(uint16_t gnbNum)
{
    AUTO_TRACE_FUNC;

    uint16_t loop;
    uint16_t cellNum;
    uint16_t endPointF1Index;

    gnbDuInfo_type *pGnbDu = NULL;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    VALID_E_POINT_CHECK_VOID(pGnb->gnbDu);
    VALID_E_POINT_CHECK_VOID(CELLINFO);

    for (endPointF1Index = 0; endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP; endPointF1Index++)
    {
        pGnbDu = &pGnb->gnbDu[endPointF1Index];
        for (loop = 0; loop < MAX_CELL_PER_DU; loop++)
        {
            if (pGnbDu->cellInDu[loop].status == EQUIP)
            {
                // VLIB_UpdateCellStatusHistory should be called before DB gets initialized
                VLIB_UpdateCellStatusHistory(pGnbDu->cellInDu[loop].cellNum, RESET_CELLLIST_ALLDU);
            }
            pGnbDu->cellInDu[loop].status = N_EQUIP;
            pGnbDu->cellInDu[loop].cellNum = MAX_CELL_NUM_VCCB;  // init
            pGnbDu->nrofCells = 0;
        }
    }

    for (cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
    {
        const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

        if (EQUIP != pCell->pldState)
        {
            continue;
        }

        if (pCell->gnbNum != gnbNum)
        {
            continue;
        }

        if (pCell->endPointF1Index >= MAX_GNB_DU_PER_GNB_CU_CP)
        {
            continue;
        }

        pGnbDu = &pGnb->gnbDu[pCell->endPointF1Index];
        if (pGnbDu->nrofCells >= MAX_CELL_PER_DU)
        {
            continue;
        }
        pGnbDu->cellInDu[pGnbDu->nrofCells].status = EQUIP;
        pGnbDu->cellInDu[pGnbDu->nrofCells++].cellNum = cellNum;
        VLIB_UpdateCellStatusHistory(cellNum, UPDATE_CELLLIST_ALLDU);
    }

    for (endPointF1Index = 0; endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP; endPointF1Index++)
    {
#ifdef __CNF__
        FnVCCB_RedisUpdateGnbInfoFlagOn(gnbNum);
#else
        HAS_BACKUP_DATA_PER_GNB(
            gnbNum, VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_0, &pGnb->gnbDu[endPointF1Index], sizeof(gnbDuInfo_type));
#endif
    }

    return;
}

/**
 * @brief Update Cell List of a DU.
 *
 */
void VLIB_UpdateCellListOfDu(uint16_t gnbNum, uint16_t endPointF1Idx)
{
    AUTO_TRACE_FUNC;
    uint16_t cellNum = 0;
    gnbDuInfo_type *pGnbDu = NULL;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    VALID_E_POINT_CHECK_VOID(pGnb->gnbDu);
    VALID_E_POINT_CHECK_VOID(CELLINFO);
    VCCB_CHECK_E_RANGE_AND_VOID(endPointF1Idx, MAX_GNB_DU_PER_GNB_CU_CP);

    uint8_t isBackupNeeded[MAX_GNB_DU_PER_GNB_CU_CP] = {0};
    uint16_t loop = 0;

    for (cellNum = 0; cellNum < MAX_CELL_NUM_VCCB; cellNum++)
    {
        const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

        if (EQUIP != pCell->pldState)
        {
            continue;
        }

        if (pCell->gnbNum != gnbNum)
        {
            continue;
        }

        if (pCell->endPointF1Index != endPointF1Idx)
        {
            continue;
        }

        pGnbDu = &pGnb->gnbDu[endPointF1Idx];
        if (pGnbDu->nrofCells >= MAX_CELL_PER_DU)
        {
            continue;
        }
        pGnbDu->cellInDu[pGnbDu->nrofCells].status = EQUIP;
        pGnbDu->cellInDu[pGnbDu->nrofCells++].cellNum = cellNum;
        VLIB_UpdateCellStatusHistory(cellNum, UPDATE_CELLLIST_DU);
        isBackupNeeded[endPointF1Idx] = 1;
    }

    for (loop = 0; loop < MAX_GNB_DU_PER_GNB_CU_CP; ++loop)
    {
        if (isBackupNeeded[loop])
        {
#ifdef __CNF__
            FnVCCB_RedisUpdateGnbInfoFlagOn(gnbNum);
#else
            HAS_BACKUP_DATA_PER_GNB(
                gnbNum, VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_0, &pGnb->gnbDu[loop], sizeof(gnbDuInfo_type));
#endif
        }
    }

    return;
}

/**
 * @brief Add Cell to Cell List of a DU.
 *
 */
void VLIB_AddCellToCellListOfDu(uint16_t gnbNum, uint16_t cellNum, uint16_t endPointF1Idx)
{
    AUTO_TRACE_FUNC;
    uint16_t loop = 0, nrofCells = 0;
    gnbDuInfo_type *pGnbDu = NULL;

    VALID_E_POINT_CHECK_VOID(CELLINFO);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(endPointF1Idx, MAX_GNB_DU_PER_GNB_CU_CP);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    VALID_E_POINT_CHECK_VOID(pGnb->gnbDu);

    pGnbDu = &pGnb->gnbDu[endPointF1Idx];
    if (pGnbDu->nrofCells >= MAX_CELL_PER_DU)
    {
        return;
    }

    for (loop = 0; loop < MAX_CELL_PER_DU; loop++)
    {
        if (pGnbDu->cellInDu[loop].status != EQUIP) continue;

        if (nrofCells >= pGnbDu->nrofCells) break;

        if (pGnbDu->cellInDu[loop].cellNum == cellNum)
        {
            VCCB_PRINT_DATA("%s: cellNum(%d) is already exist in gnbDu\n", __FUNCTION__, cellNum);
            return;
        }
        nrofCells++;
    }

    for (loop = 0; loop < MAX_CELL_PER_DU; loop++)
    {
        if (pGnbDu->cellInDu[loop].status != EQUIP) break;
    }

    if (loop >= MAX_CELL_PER_DU)
    {
        VCCB_PRINT_ERROR("%s: no available space for cellNum(%d). re-init CellList.\n", __FUNCTION__, cellNum);
        pGnbDu->nrofCells = 0;
#ifdef __CNF__
        FnVCCB_RedisUpdateGnbInfoFlagOn(gnbNum);
#else
        HAS_BACKUP_DATA_PER_GNB(gnbNum, VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_0, pGnbDu, sizeof(gnbDuInfo_type));
#endif
        VLIB_UpdateCellListOfDu(gnbNum, endPointF1Idx);
        return;
    }

    pGnbDu->cellInDu[loop].status = EQUIP;
    pGnbDu->cellInDu[loop].cellNum = cellNum;
    pGnbDu->nrofCells++;
#ifdef __CNF__
    FnVCCB_RedisUpdateGnbInfoFlagOn(gnbNum);
#else
    HAS_BACKUP_DATA_PER_GNB(gnbNum, VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_0, pGnbDu, sizeof(gnbDuInfo_type));
#endif

    return;
}

/**
 * @brief Del Cell from Cell List of a DU.
 *
 */
void VLIB_DelCellFromCellListOfDu(uint16_t gnbNum, uint16_t cellNum, uint16_t endPointF1Idx, uint16_t cause)
{
    AUTO_TRACE_FUNC;
    uint16_t loop = 0;
    gnbDuInfo_type *pGnbDu = NULL;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(endPointF1Idx, MAX_GNB_DU_PER_GNB_CU_CP);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    VALID_E_POINT_CHECK_VOID(pGnb->gnbDu);

    pGnbDu = &pGnb->gnbDu[endPointF1Idx];
    if (pGnbDu->nrofCells == 0)
    {
        VCCB_PRINT_ERROR("%s: Not found cellNum(%d) in endPointF1Idx(%d) (nrofCells = %d)\n",
                __FUNCTION__, cellNum, endPointF1Idx, pGnbDu->nrofCells);
        return;
    }

    for (loop = 0; loop < MAX_CELL_PER_DU; loop++)
    {
        if (pGnbDu->cellInDu[loop].status != EQUIP) continue;

        if (pGnbDu->cellInDu[loop].cellNum == cellNum)
        {
            pGnbDu->cellInDu[loop].status = N_EQUIP;
            if (cause ==
                ENDPOINT_F1_CHANGED)  // if endPointF1Index value is changed, delete it from the previous DU info
            {
                // VLIB_UpdateCellStatusHistory should be called before DB gets initialized
                VLIB_UpdateCellStatusHistory(cellNum, cause);
            }
            pGnbDu->cellInDu[loop].cellNum = MAX_CELL_NUM_VCCB;  // init
            pGnbDu->nrofCells--;
#ifdef __CNF__
            FnVCCB_RedisUpdateGnbInfoFlagOn(gnbNum);
#else
            HAS_BACKUP_DATA_PER_GNB(gnbNum, VCCB_HAS_KEY_GNB_CFG_GNBDU_INFO_GNB_0, pGnbDu, sizeof(gnbDuInfo_type));
#endif
            return;
        }
    }

    VCCB_PRINT_ERROR("%s: Not found cellNum(%d) in endPointF1Idx(%d) (nrofCells = %d)\n",
            __FUNCTION__, cellNum, endPointF1Idx, pGnbDu->nrofCells);
    return;
}

/**
 * @brief     QSort uint16_t Ascending Order
 */
int VLIB_QsortUint16AscendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    if (*(uint16_t *)arg1 < *(uint16_t *)arg2)
    {
        return -1;
    }
    if (*(uint16_t *)arg1 > *(uint16_t *)arg2)
    {
        return 1;
    }

    return 0;
}

/**
 * @brief     QSort uint32_t Ascending Order
 *
 * @param[out]      arg1 :          first arg to compare
 * @param[in]       arg2 :          second arg to compare
 * @return          result :        -1 / 0 / 1
 */
int VLIB_QsortUint32AscendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    if (*(uint32_t *)arg1 < *(uint32_t *)arg2)
    {
        return -1;
    }
    if (*(uint32_t *)arg1 > *(uint32_t *)arg2)
    {
        return 1;
    }

    return 0;
}

/**
 * @brief     Update PCID usedCellCount for checking duplication
 */
void VLIB_UpdatePcidUsedCellCount(uint16_t gnbNum, uint16_t cellNum, uint8_t prevServiceState)
{
    AUTO_TRACE_FUNC;

    uint16_t phyCellId;
    uint16_t loop;

    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    phyCellId = pCell->phyCellId;
    VCCB_CHECK_E_RANGE_AND_VOID(phyCellId, MAX_PHYSICAL_CELL_ID + 1);

    if (IS_CELL_INS(cellNum) && prevServiceState != CELL_INS /*access_s5gtype_f1_cell_in_service*/)
    {
        pGnb->env.pcidInfo[phyCellId].usedCellCount++;
        pGnb->env.pcidInfo[phyCellId].usedCellNum = cellNum;
    }
    else if (!IS_CELL_INS(cellNum) && prevServiceState == CELL_INS /*access_s5gtype_f1_cell_in_service*/)
    {
        if (pGnb->env.pcidInfo[phyCellId].usedCellCount > 0)
        {
            pGnb->env.pcidInfo[phyCellId].usedCellCount--;
        }

        if (pGnb->env.pcidInfo[phyCellId].usedCellCount == 0)
        {
            pGnb->env.pcidInfo[phyCellId].usedCellNum = UNKNOWN_CELL;
        }

        if (pGnb->env.pcidInfo[phyCellId].usedCellNum == cellNum)
        {
            for (loop = 0; loop < MAX_CELL_NUM_VCCB; loop++)
            {
                const VccbCellInfo_type *const pCellLoop = &CELLINFO[loop];
                if (pCellLoop->gnbNum != gnbNum) continue;

                if (pCellLoop->phyCellId == phyCellId)
                {
                    pGnb->env.pcidInfo[phyCellId].usedCellNum = loop;
                    break;
                }
            }
        }
    }
    else
    {
        VCCB_PRINT_COMMENT("cellNum(%d) prevServiceState(%d) IS_CELL_INS(%d) : pcidInfo table not needed to update\n",
            cellNum, prevServiceState, IS_CELL_INS(cellNum));
        return;
    }

#ifndef HOST_SIM
#ifdef __CNF__
    FnVCCB_RedisUpdateGnbInfoFlagOn(gnbNum);
#else
    HAS_BACKUP_DATA_PER_GNB(
        gnbNum, VCCB_HAS_KEY_GNB_ENV_INFO_GNB_0, &pGnb->env.pcidInfo[phyCellId], sizeof(pcidInfo_type))
#endif
#endif

    return;
}

/** Check whether given callinfo contains AM_RLC bearers. */
int VLIB_IsAmDrbPresent(const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int i;

    for (i = 0; i < MAX_ERAB_PER_CALL; i++)
    {
        if (ptCi->erabInfo[i].usage == CI_use && ptCi->erabInfo[i].rbInfo.rlcMode == AM_RLC)
        {
            return TRUE;
        }
    }

    return FALSE;
}

/*
 * @brief      This function calculates Transmission Bandwidth (MHz) based on NRSystemBandwidth
 *             and NrSubCarrierSpacing. Returns 0 if given values are invalid. Reference doc.
 *             3GPP TS 38.104 V15.5.0 - section 5.3.2 - Transmission bandwidth configuration
 * @param      nrSysBw, nrSCS
 * @return     Transmission Bandwidth
 */
uint32_t VLIB_NrbScs2Bw(enumNrSystemBandwidth_type nrSysBw, enumNrSubCarrierSpacing_type nrSCS)
{
    AUTO_TRACE_FUNC;
    uint32_t transmissionBw = 0;
    if (nrSCS == ci_Nr_scs15)
    {
        switch (nrSysBw)
        {
            case ci_NrSystemBandwidth_nrb25:
                transmissionBw = 5;
                break;
            case ci_NrSystemBandwidth_nrb52:
                transmissionBw = 10;
                break;
            case ci_NrSystemBandwidth_nrb79:
                transmissionBw = 15;
                break;
            case ci_NrSystemBandwidth_nrb106:
                transmissionBw = 20;
                break;
            case ci_NrSystemBandwidth_nrb133:
                transmissionBw = 25;
                break;
            case ci_NrSystemBandwidth_nrb160:
                transmissionBw = 30;
                break;
            case ci_NrSystemBandwidth_nrb216:
                transmissionBw = 40;
                break;
            case ci_NrSystemBandwidth_nrb270:
                transmissionBw = 50;
                break;
            default:
                transmissionBw = 0;
        }
    }
    else if (nrSCS == ci_Nr_scs30)
    {
        switch (nrSysBw)
        {
            case ci_NrSystemBandwidth_nrb11:
                transmissionBw = 5;
                break;
            case ci_NrSystemBandwidth_nrb24:
                transmissionBw = 10;
                break;
            case ci_NrSystemBandwidth_nrb38:
                transmissionBw = 15;
                break;
            case ci_NrSystemBandwidth_nrb51:
                transmissionBw = 20;
                break;
            case ci_NrSystemBandwidth_nrb65:
                transmissionBw = 25;
                break;
            case ci_NrSystemBandwidth_nrb78:
                transmissionBw = 30;
                break;
            case ci_NrSystemBandwidth_nrb106:
                transmissionBw = 40;
                break;
            case ci_NrSystemBandwidth_nrb133:
                transmissionBw = 50;
                break;
            case ci_NrSystemBandwidth_nrb162:
                transmissionBw = 60;
                break;
            case ci_NrSystemBandwidth_nrb189:
                transmissionBw = 70;
                break;
            case ci_NrSystemBandwidth_nrb217:
                transmissionBw = 80;
                break;
            case ci_NrSystemBandwidth_nrb245:
                transmissionBw = 90;
                break;
            case ci_NrSystemBandwidth_nrb273:
                transmissionBw = 100;
                break;
            default:
                transmissionBw = 0;
        }
    }
    else if (nrSCS == ci_Nr_scs60)
    {
        switch (nrSysBw)
        {
            case ci_NrSystemBandwidth_nrb11:
                transmissionBw = 10;
                break;
            case ci_NrSystemBandwidth_nrb18:
                transmissionBw = 15;
                break;
            case ci_NrSystemBandwidth_nrb24:
                transmissionBw = 20;
                break;
            case ci_NrSystemBandwidth_nrb31:
                transmissionBw = 25;
                break;
            case ci_NrSystemBandwidth_nrb38:
                transmissionBw = 30;
                break;
            case ci_NrSystemBandwidth_nrb51:
                transmissionBw = 40;
                break;
            case ci_NrSystemBandwidth_nrb65:
            case ci_NrSystemBandwidth_nrb66:
                transmissionBw = 50;
                break;
            case ci_NrSystemBandwidth_nrb79:
                transmissionBw = 60;
                break;
            case ci_NrSystemBandwidth_nrb93:
                transmissionBw = 70;
                break;
            case ci_NrSystemBandwidth_nrb107:
                transmissionBw = 80;
                break;
            case ci_NrSystemBandwidth_nrb121:
                transmissionBw = 90;
                break;
            case ci_NrSystemBandwidth_nrb132:
            case ci_NrSystemBandwidth_nrb135:
                transmissionBw = 100;
                break;
            case ci_NrSystemBandwidth_nrb264:
                transmissionBw = 200;
                break;
            default:
                transmissionBw = 0;
        }
    }
    else if (nrSCS == ci_Nr_scs120)
    {
        switch (nrSysBw)
        {
            case ci_NrSystemBandwidth_nrb32:
                transmissionBw = 50;
                break;
            case ci_NrSystemBandwidth_nrb66:
                transmissionBw = 100;
                break;
            case ci_NrSystemBandwidth_nrb132:
                transmissionBw = 200;
                break;
            case ci_NrSystemBandwidth_nrb264:
                transmissionBw = 400;
                break;
            default:
                transmissionBw = 0;
        }
    }

    return transmissionBw;
}

/*
 * @brief      This function converts Arfcn to Frequency in KHz. It is based on table
 *             from 3GPP TS 38.104 version 15.5.0 Rel 15 - table 5.4.2.1.
 * @param      uint32_t arfcn
 * @return     uint32_t frequency (KHz) or invalid(0xffffffff)
 */
uint32_t VLIB_Arfcn2Freq(uint32_t arfcn)
{
    AUTO_TRACE_FUNC;

    if (arfcn < 600000)
    {
        return (0 + 5 * (arfcn - 0));
    }
    if (arfcn < 2016667)
    {
        return (3000000 + 15 * (arfcn - 600000));
    }
    if (arfcn <= 3279165)
    {
        return (24250080 + 60 * (arfcn - 2016667));
    }

    VCCB_PRINT_ERROR("%s: Invalid NR ARFCN(%u)\n", __FUNCTION__, arfcn);

    return 0xffffffff;
}

/*
 * @brief      This function converts Frequency to Arfcn. It is based on the table
 *             from 3GPP TS 38.104 version 15.5.0 Rel 15 - table 5.4.2.1-1.
 * @param      uint32_t freqKhz
 * @return     uint32_t arfcn or invalid(0xffffffff)
 */
uint32_t VLIB_Freq2Arfcn(uint32_t freqKhz)
{
    AUTO_TRACE_FUNC;

    if (freqKhz < 3000000)
    {
        return (((freqKhz - 0) / 5) + 0);
    }
    if (freqKhz < 24250000)
    {
        return (((freqKhz - 3000000) / 15) + 600000);
    }
    if (freqKhz < 100000000)
    {
        // Make sure it not less than range min value as the formula does not work for frequencies (24250000..24250079).
        const auto fixedFreqKhz = ((freqKhz < 24250080) ? 24250080 : freqKhz);
        return (((fixedFreqKhz - 24250080) / 60) + 2016667);
    }

    VCCB_PRINT_ERROR("%s: Invalid frequency(%u KHz)\n", __FUNCTION__, freqKhz);

    return 0xffffffff;
}

int FnVCCB_FindXnEndPointIndexListByGnbIdPartial(
    callInfo_type *ptCi, uint16_t gnbNum, uint32_t gnbIdPartial, uint16_t xnIndexList[MAX_XN_NBR_PER_GNB])
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    VALID_E_POINT_CHECK_ERROR(xnIndexList);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    int size = 0;
    uint16_t xnIdx;
    for (xnIdx = 0; xnIdx < MAX_XN_NBR_PER_GNB; xnIdx++)
    {
        xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(ptCi->gnbNum, xnIdx);

        if (pXnNbr == NULL) continue;

        /* 1. Valid Check For EndPointXn */
        if (pXnNbr->status != EQUIP) continue;

        VCCB_PRINT_CALL_COMMENT(ptCi, "[xnIdx=%d] Check gnbId=%u\n", xnIdx, pXnNbr->gnbId.id);

        if (pXnNbr->xnapLinkState != CI_use) continue;

        /* Node Type */
        if (pXnNbr->ngRanNodeType != ngRanNode_GnbType) continue;

        /* 2. Valid Check For Neighbour in EndPointXn */
        /* 2.1. PLMN */
        if (pXnNbr->present.plmnMcc == OPT_NOT_PRESENT) continue;
        if (pXnNbr->present.plmnMnc == OPT_NOT_PRESENT) continue;
        if (pXnNbr->plmn.longId != pGnb->globalGnbId.plmn.longId) continue;

        /* 2.2 GnbId */
        if (pXnNbr->present.ngRanNodeId == OPT_NOT_PRESENT) continue;

        if (((pXnNbr->gnbId.id) & 0xFFFF) != ((gnbIdPartial)&0xFFFF)) continue;

        xnIndexList[size++] = xnIdx;
        VCCB_PRINT_CALL_COMMENT(ptCi, "Add gnbId=%u, size=%d\n", pXnNbr->gnbId.id, size);
    }
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Found %d Neighbor gNB(s) with matching LSB 16bit.\n", size);

    return size;
}

uint16_t fnVLIB_FindXnEndPointIndexByGnbId(uint16_t gnbNum, vccbGlobalGnbId_type *pTgtGnbId)
{
    uint16_t xnIdx = MAX_XN_NBR_PER_GNB;

    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(pTgtGnbId, xnIdx);

    if (gnbNum >= MAX_GNB_PER_SYS)
    {
        VCCB_PRINT_ERROR("Invalid Range(Name:gnbNum, Value:%d, Max:%d)\n", gnbNum, MAX_GNB_PER_SYS);
        return MAX_XN_NBR_PER_GNB;
    }

    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION_WO_CALL(
        "[DEBUG-fnVLIB_FindXnEndPointIndexByGnbId] Start (Mcc/Mnc: %X, Gnb: %u/%u)\n", pTgtGnbId->plmn.longId,
        pTgtGnbId->gnbId.id, pTgtGnbId->gnbId.idLength);


    if (pGnb->globalGnbId.gnbId.id == pTgtGnbId->gnbId.id &&
        pGnb->globalGnbId.plmn.longId == pTgtGnbId->plmn.longId)
    {
        xnIdx = XNIDX_FOR_INTRA_GNB_NRDC;
    }
    else
    {
        /* Search Nbr Cell In EndPointXn */
        for (xnIdx = 0; xnIdx < MAX_XN_NBR_PER_GNB; xnIdx++)
        {
            xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(gnbNum, xnIdx);

            if (pXnNbr == NULL) continue;

            /* 1. Valid Check For EndPointXn */
            if (pXnNbr->status != EQUIP) continue;

            VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION_WO_CALL(
                "[%02u] xnapLink:%u, NodeType:%u. Mcc/Mnc: %u/%u/%X, Gnb:%u/%u/%u\n", xnIdx, pXnNbr->xnapLinkState,
                pXnNbr->ngRanNodeType, pXnNbr->present.plmnMcc, pXnNbr->present.plmnMnc, pXnNbr->plmn.longId,
                pXnNbr->present.ngRanNodeId, pXnNbr->gnbId.id, pXnNbr->gnbId.idLength);

            if (pXnNbr->xnapLinkState != CI_use) continue;

            /* Node Type */
            if (pXnNbr->ngRanNodeType != ngRanNode_GnbType) continue;

            /* 2. Valid Check For Neighbour in EndPointXn */
            /* 2.1. PLMN */
            if (pXnNbr->present.plmnMcc == OPT_NOT_PRESENT) continue;
            if (pXnNbr->present.plmnMnc == OPT_NOT_PRESENT) continue;
            if (pXnNbr->plmn.longId != pTgtGnbId->plmn.longId) continue;

            /* 2.2 GnbId */
            if (pXnNbr->present.ngRanNodeId == OPT_NOT_PRESENT) continue;
            if (pXnNbr->gnbId.idLength != pTgtGnbId->gnbId.idLength) continue;
            if (pXnNbr->gnbId.id != pTgtGnbId->gnbId.id) continue;

            VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION_WO_CALL("[%02u] Selected Xn Index!\n", xnIdx);

            break;
        }
    }

    /* Not Exist Nbr Cell In EndPointXn */
    if (FnVCCB_CheckValidEndPointXn_ForSN(xnIdx) == false)
    {
        xnIdx = MAX_XN_NBR_PER_GNB;
    }

    VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION_WO_CALL(
        "[DEBUG-fnVLIB_FindXnEndPointIndexByGnbId] End (xnIdx:%u)\n", xnIdx);

    return xnIdx;
}

uint16_t fnVLIB_FindXnEndPointIndexByNbrIdx(callInfo_type *ptCi, uint16_t cellNum, uint16_t nbrIdx,
    nbrGnbCellInfo_type **ptGnbCellInfo /* If not null fill info */)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_XN_NBR_PER_GNB);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, MAX_XN_NBR_PER_GNB);
    VCCB_CHECK_E_RANGE_AND_VAL(nbrIdx, MAX_NBR_PER_CELL, MAX_XN_NBR_PER_GNB);

    int16_t status = GOOD;
    nbrGnbCellInfo_type *nbrGnbCellInfo = NULL;

    if (ptGnbCellInfo != NULL) *ptGnbCellInfo = NULL;

    /* Get NbrCell */
    status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &nbrGnbCellInfo);
    if (status != EQUIP)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "cellNum(%u) nbrIdx(%u) could not find CELL Nbr information in %s.\n", cellNum, nbrIdx, __func__);
        return MAX_XN_NBR_PER_GNB;
    }

    /* Protection Code */
    VALID_E_POINT_CHECK_RET_VAL(nbrGnbCellInfo, MAX_XN_NBR_PER_GNB);

    if (ptGnbCellInfo != NULL) *ptGnbCellInfo = nbrGnbCellInfo;

    /* Search NbrCell In EndPointXn */
    uint16_t xnIdx = fnVLIB_FindXnEndPointIndexByGnbId(ptCi->gnbNum, &nbrGnbCellInfo->globalGnbId);
    if (xnIdx >= MAX_XN_NBR_PER_GNB)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "cellNum(%u) nbrIdx(%u) could not find XN Nbr information in %s.\n", cellNum, nbrIdx, __func__);
        return MAX_XN_NBR_PER_GNB;
    }

    return xnIdx;
}

uint16_t fnVLIB_FindXnEndPointIndexByEnbId(uint16_t gnbNum, enbId_type *pEnbId, plmnId_type *pPlmn)
{
    uint16_t xnIdx = MAX_XN_NBR_PER_GNB;

    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(pEnbId, xnIdx);
    VALID_E_POINT_CHECK_RET_VAL(pPlmn, xnIdx);

    if (gnbNum >= MAX_GNB_PER_SYS)
    {
        VCCB_PRINTF_ERR("Invalid Range(Name:gnbNum, Value:%d, Max:%d)\n", gnbNum, MAX_GNB_PER_SYS);
        return MAX_XN_NBR_PER_GNB;
    }

    /* Search Nbr Cell In EndPointXn */
    for (xnIdx = 0; xnIdx < MAX_XN_NBR_PER_GNB; xnIdx++)
    {
        xnNbrInfo_type *pXnNbr = FnVCCB_GetXnNbrInfo(gnbNum, xnIdx);

        if (pXnNbr == NULL) continue;

        /* Node Type */
        if (pXnNbr->ngRanNodeType != ngRanNode_ngEnbType) continue;

        /* 1. Valid Check For EndPointXn */
        if (pXnNbr->status != EQUIP) continue;
        if (pXnNbr->xnapLinkState != CI_use) continue;

        /* 2. Valid Check For Neighbour in EndPointXn */
        /* 2.1. PLMN */
        if (pXnNbr->present.plmnMcc == OPT_NOT_PRESENT) continue;
        if (pXnNbr->present.plmnMnc == OPT_NOT_PRESENT) continue;
        if (pXnNbr->plmn.s2.mcc != pPlmn->s2.mcc || pXnNbr->plmn.s2.mnc != pPlmn->s2.mnc) continue;

        /* 2.2 EnbId */
        if (pXnNbr->present.ngRanNodeId == OPT_NOT_PRESENT) continue;
        if (pXnNbr->enbId.idType != pEnbId->idType) continue;
        if (pXnNbr->enbId.id != pEnbId->id) continue;

        break;
    }

    /* Not Exist Nbr Cell In EndPointXn */
    if (xnIdx >= MAX_XN_NBR_PER_GNB)
    {
        xnIdx = MAX_XN_NBR_PER_GNB;
    }

    return xnIdx;
}

xnNbrInfo_type *FnVCCB_GetXnNbrInfo(uint16_t gnbNum, uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_VALID_GNBNUM_NULL(gnbNum);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    if (FnVCCB_CheckValidEndPointXn_ForSN(endPointIdx) == false)
    {
        VCCB_PRINT_ERROR("EndPointIndex is out of range (gnbNum:%u, epIdx:%u)\n", gnbNum, endPointIdx);
        return NULL;
    }

    if (endPointIdx == XNIDX_FOR_INTRA_GNB_NRDC)
    {
        xnNbrInfo_type *pIntraNbr = &pGnb->intraXnNbr;

        pIntraNbr->status = pGnb->status;
        pIntraNbr->xnapLinkState = (pGnb->status == EQUIP ? CI_use : CI_no_use);

        pIntraNbr->present.ngRanNodeId = OPT_PRESENT;
        pIntraNbr->ngRanNodeType = ngRanNode_GnbType;
        pIntraNbr->gnbId = pGnb->globalGnbId.gnbId;

        pIntraNbr->present.plmnMcc = OPT_PRESENT;
        pIntraNbr->present.plmnMnc = OPT_PRESENT;
        pIntraNbr->plmn.longId = pGnb->globalGnbId.plmn.longId;

        // other attribute not Setting..
        // amfSetInfo
        // remoteIpAddress

        return pIntraNbr;
    }

    if (endPointIdx < MAX_XN_NBR_PER_GNB)
    {
        return &pGnb->xnNbr[endPointIdx];
    }

    return NULL;
}

void fnVLIB_check_support_data_forwarding_per_5QI(callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t isTarget)
{
    AUTO_TRACE_FUNC;

    uint16_t fiveQi;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptQi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    if (ptQi->qosParam.qosCharacteristics != ci_qos_char_non_dynamic_5qi)
    {
        return;
    }

    fiveQi = (uint16_t)ptQi->qosParam.nonDyna.fiveQi;

    // SVACE - UNREACHABLE_CODE
    // WID:89392251 This statement in the source code might be unreachable during program execution.
    // if( fiveQi >= MAX_5QI_VALUE )
    // {
    //     return;
    // }

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfo5qi(ptCi->servCellNum, ptCi->gnbNum, fiveQi);
    VALID_E_POINT_CHECK_VOID(pPdcpInfo);

    if (pPdcpInfo->shmStatus == N_EQUIP)
    {
        return;
    }

    /* Data Forwarding feature determine whether to allow data forwarding(ul/dl) per 5QI */
    if (isTarget == FALSE)
    {
        /*for 19A release srcDlFwd parameter will decide forwarding on both links
         *this change is introduced to mitigate migration issues in the future*/
        if (pPdcpInfo->srcDlFwd == TRUE)
        {
            ptQi->dataFwdInfo.dlForwardProposed = TRUE;
            if (pPdcpInfo->srcUlFwd == TRUE)
            {
                ptQi->dataFwdInfo.ulForwardProposed = TRUE;
            }
        }
    }
    else
    {
        if (ptQi->dataFwdInfo.dlForwardProposed == TRUE)
        {
            /* if dlFwdProposed is supported and target supports DL fwd, set ptQi->dataFwdInfo.dlForward to 'TRUE' */
            if (pPdcpInfo->tgtDlFwd == TRUE)
            {
                ptQi->dataFwdInfo.dlForward = TRUE;
            }
        }

        if (ptQi->dataFwdInfo.ulForwardProposed == TRUE)
        {
            /* if ulFwdProposed is supported and target supports UL fwd, set ptQi->dataFwdInfo.ulForward to 'TRUE' */
            if (pPdcpInfo->tgtUlFwd == TRUE)
            {
                ptQi->dataFwdInfo.ulForward = TRUE;
            }
        }
    }

    return;
}

enumDataForwardingState_type FnVCCB_GetDataForwardingState(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, DataForwarding_Proposal);

    // State Based
    switch (ptCi->state)
    {
        case STATE_INTRA_DU_SnRelB:
        case STATE_INTER_DU_SnRelB:
            return DataForwarding_Accept;

        default:
            break;
    }

    // Scenario Based
    if (VHCM_isSaHandoverUE(ptCi))
    {
        if (ptCi->hoInfo.isTarget == TRUE)
        {
            return DataForwarding_Accept;
        }

        return DataForwarding_Proposal;
    }

    return DataForwarding_Proposal;
}

static void FnVCCB_GetQosFlowFowardingAccpet(
    callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t *pDlFowardAccept, uint8_t *pUlFowardAccept)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptQi);
    VALID_E_POINT_CHECK_VOID(pDlFowardAccept);
    VALID_E_POINT_CHECK_VOID(pUlFowardAccept);

    *pDlFowardAccept = TRUE;
    *pUlFowardAccept = TRUE;

    // turned on by default since 21D Pkg
    if (DBG->flag.tgtRspBasedQfiFwd == VCCB_FLAG_OFF)
    {
        return;
    }

    // TGT_RSP_BASED_QFI_DATA_FWD_21D Target's response condition added as of 21D Pkg
    if (ptCi->stateCmd == IntraRatHO_cmd || ptCi->stateCmd == InterRatHO_cmd)  // HO Case
    {
        // Update DB
        *pDlFowardAccept = ptQi->dataFwdInfo.dlForwardAccepted;
        *pUlFowardAccept = ptQi->dataFwdInfo.ulForwardAccepted;
    }
}

static void VLIB_checkQosFlowForwardedOnTunnels_Proposal(
    callInfo_type *ptCi, callPDUSessInfo_type *ptPi, qosFlowInfo_type *ptQi, uint8_t *pDl, uint8_t *pUl)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptQi);
    VALID_E_POINT_CHECK_VOID(pDl);
    VALID_E_POINT_CHECK_VOID(pUl);

    pdcpInfo5qi_type *pPdcpInfo = NULL;
    callDRBInfo_type *ptDi = NULL;

    // 1. Get PDCP Information For Dl/Ul Fowarding Proposal
    {
        uint8_t fiveQi = ptQi->qosParam.nonDyna.fiveQi;
        pPdcpInfo = FnVCCB_GetPdcpInfo5qi(ptCi->servCellNum, ptCi->gnbNum, fiveQi);
        VALID_E_POINT_CHECK_VOID(pPdcpInfo);
    }

    // 2. Get DRB Information For DRB Forwarding
    {
        const uint16_t drbIdxInCall = ptQi->drbIdxInCall;

        if (drbIdxInCall >= MAX_DRB_PER_SA_CALL)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "drbIdxInCall Over!! (fn:%s, flowId:%u, drbIdx:%u)\n", __func__, ptQi->flowId, drbIdxInCall);
            return;
        }

        ptDi = &ptCi->drb[drbIdxInCall];
    }

    // When UP allows only DL or UL, FLAG is controlled respectively.
    // Example : Req(both) -> resp(dl or ul)

    const uint8_t dbDLSrcEnabled = pPdcpInfo->srcDlFwd;
    const uint8_t dbULSrcEnabled = pPdcpInfo->srcUlFwd;

    const uint8_t dlTnlModifyForDrb = ptDi->dataFwdInfo.gtpTunnel.dl.fNeedModify;
    const uint8_t ulTnlModifyForDrb = ptDi->dataFwdInfo.gtpTunnel.ul.fNeedModify;

    const uint8_t dlTnlModifyForPdu = ptPi->nGuFwdTunnel.dl.fNeedModify;
    const uint8_t ulTnlModifyForPdu = ptPi->nGuFwdTunnel.ul.fNeedModify;

    uint8_t dlFowardAccept = TRUE;
    uint8_t ulFowardAccept = TRUE;

    FnVCCB_GetQosFlowFowardingAccpet(ptCi, ptQi, &dlFowardAccept, &ulFowardAccept);

    // DRB Forwarding
    *pDl = (uint8_t)(*pDl | (dlTnlModifyForDrb && dbDLSrcEnabled && dlFowardAccept));
    *pUl = (uint8_t)(*pUl | (ulTnlModifyForDrb && dbULSrcEnabled && ulFowardAccept));

    // PDU Forwarding
    *pDl = (uint8_t)(*pDl | (dlTnlModifyForPdu && dbDLSrcEnabled && dlFowardAccept));
    *pUl = (uint8_t)(*pUl | (ulTnlModifyForPdu && dbULSrcEnabled && ulFowardAccept));

    if (DBG->flag.tgtRspBasedQfiFwd == VCCB_FLAG_ON)
    {
        if (ptCi->stateCmd == IntraRatHO_cmd || ptCi->stateCmd == InterRatHO_cmd)  // HO Case
        {
            VCCB_PRINT_CALL_DATA(ptCi,
                "[TGT_QFI] Serving DL/UL: flowId:%d config:%d/%d proposed:%u/%u accepted:%u/%u sel:%u/%u\n",
                ptQi->flowId, dbDLSrcEnabled, dbULSrcEnabled, ptQi->dataFwdInfo.dlForwardProposed,
                ptQi->dataFwdInfo.ulForwardProposed, dlFowardAccept, ulFowardAccept, *pDl, *pUl);
        }
    }
}

static void VLIB_checkQosFlowForwardedOnTunnels_Accept(qosFlowInfo_type *ptQi, uint8_t *pDl, uint8_t *pUl)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptQi);
    VALID_E_POINT_CHECK_VOID(pDl);
    VALID_E_POINT_CHECK_VOID(pUl);

    *pDl = ptQi->dataFwdInfo.dlForward;
    *pUl = ptQi->dataFwdInfo.ulForward;
}

void VLIB_checkQosFlowForwardedOnTunnels(callInfo_type *ptCi, callPDUSessInfo_type *ptPi, qosFlowInfo_type *ptQi,
    uint8_t *pDl, uint8_t *pUl, enumDataForwardingState_type targetGnb)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPi);
    VALID_E_POINT_CHECK_VOID(ptQi);
    VALID_E_POINT_CHECK_VOID(pDl);
    VALID_E_POINT_CHECK_VOID(pUl);

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    *pDl = *pUl = FALSE;

    if (CI_use != ptQi->usage)
    {
        return;
    }

    if (targetGnb == DataForwarding_Accept)
    {
        VLIB_checkQosFlowForwardedOnTunnels_Accept(ptQi, pDl, pUl);
        return;
    }

    VLIB_checkQosFlowForwardedOnTunnels_Proposal(ptCi, ptPi, ptQi, pDl, pUl);

    return;
}

/*
 * @brief      This function check whether target gnb is in Xn Ho BlackList Xn
 * @param      uint16_t gnbNum
 * @param      vccbGlobalGnbId_type *pTgtGnbId
 * @return     int16_t  TRUE, FALSE, ERROR
 */
int16_t VLIB_IsHoBlackListXn(uint16_t gnbNum, vccbGlobalGnbId_type *pTgtGnbId)
{  //{{{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(gnbNum, MAX_GNB_PER_SYS);
    VALID_E_POINT_CHECK_ERROR(pTgtGnbId);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    const xnHoBlackNbrInfo_type *hoBlackListXn;
    uint16_t gnbIdx;

    for (gnbIdx = 0; gnbIdx < MAX_XN_NBR_PER_GNB; gnbIdx++)
    {
        hoBlackListXn = &pGnb->xnHoBlackList[gnbIdx];

        if (EQUIP != hoBlackListXn->status) continue;

        if (hoBlackListXn->gnbId.id == pTgtGnbId->gnbId.id &&
            hoBlackListXn->gnbId.idLength == pTgtGnbId->gnbId.idLength &&
            hoBlackListXn->gnbPlmn.longId == pTgtGnbId->plmn.longId)
        {  // gnb is in hoBlackListXn
            return TRUE;
        }
    }
    return FALSE;
}  //}}}

/**
 * @brief   Returns GOOD if PCell's arfcn is found in SPID Info per PLMN
 *          It checks for SPID if SPID based Local Network Support for EN-DC is enabled.
 * @param   ptCi : call context pointer
 * @param   plmnIdx : Index of PLMN to check
 * @return  GOOD/ERROR, GOOD if cell is available
 */
int16_t VLIB_IsPCellAndPlmnAvailableForUe(const callInfo_type *ptCi, uint8_t plmnIdx, uint32_t ssbArfcn)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(plmnIdx, MAX_PLMN_INDEX);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t spidIdx = SPID_CELL_DEFAULTS_INDEX;

    if (IS_NRDC_SN(ptCi))
    {
        // In case of NRDC, spid based for plmn is not required.
        return GOOD;
    }

    if (VCCB_FLAG_OFF == pGnb->cfg.spidInfoPerPlmn[plmnIdx].spidBasedForPlmnEnable)
    {
        return GOOD;
    }

    if (OPT_NOT_PRESENT != ptCi->ueInfo.rfsp.rfspPresent)
    {
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(ptCi->ueInfo.rfsp.subscriberProfile, 1, MAX_SPID_VALUE);
        if (VCCB_FLAG_ON == pGnb->cfg.spidInfoPerPlmn[plmnIdx]
                                .spidBasedServingCellSelectionEntries[ptCi->ueInfo.rfsp.subscriberProfile]
                                .spidInUseFlag)
        {
            spidIdx = ptCi->ueInfo.rfsp.subscriberProfile;
        }
    }

    if (NULL == bsearch(&ssbArfcn,
                    pGnb->cfg.spidInfoPerPlmn[plmnIdx].spidBasedServingCellSelectionEntries[spidIdx].spCellArfcn,
                    pGnb->cfg.spidInfoPerPlmn[plmnIdx].spidBasedServingCellSelectionEntries[spidIdx].numSpCellArfcn,
                    sizeof(ssbArfcn), VLIB_QsortUint32AscendingOrder))
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "ssbArfcn(%u) not found for spid idx(%u) and plmn idx(%u)\n", ssbArfcn, spidIdx, plmnIdx);
        return BREAK;
    }
    return GOOD;
}

/**
 * @brief   Returns GOOD if PCell is available for UE.
 *          It checks for SPID if SPID based Local Network Support for EN-DC is enabled.
 * @param   ptCi : call context pointer
 * @param   ssbArfcn : ssbArfcn of PCell to check
 * @param   ptHrl : handover restriction list
 * @return  GOOD/ERROR, GOOD if cell is available
 */
int16_t VLIB_IsPCellAvailableForUe(callInfo_type *ptCi, uint32_t ssbArfcn, hoRestrictInfo_type *ptHrl)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptHrl);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    if (IS_NRDC_SN(ptCi))
    {
        // In case of NRDC, spid based serving cell selection is not required.
        return GOOD;
    }

    if (OPT_NOT_PRESENT != ptCi->ueInfo.rfsp.rfspPresent)
    {
        if(ptCi->ueInfo.rfsp.subscriberProfile < 1 || ptCi->ueInfo.rfsp.subscriberProfile > MAX_SPID_VALUE)
        {
            VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbArfcn, StatEndcSpCellSelFail_Spid_PlmnSpidOutOfRange);
        }
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(ptCi->ueInfo.rfsp.subscriberProfile, 1, MAX_SPID_VALUE);
    }

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (VCCB_FLAG_OFF == pGnb->cfg.spidBasedServingCellSelectionEnable)
    {
        return GOOD;
    }

    if (UNKNOWN_ARFCN == ssbArfcn)
    {
        VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbArfcn, StatEndcSpCellSelFail_Spid_SsbFreqNotInCandidateInfoList);

        return ERROR;
    }

    uint8_t plmnIdx = MAX_PLMN_INDEX;
    uint8_t hrlPlmnIdx = MAX_PLMN_INDEX;
    if (TRUE == ptHrl->existFlag)
    {
        if ((GOOD == VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &plmnIdx, ptHrl->servedPlmn.longId)) &&
            (GOOD == VLIB_IsPCellAndPlmnAvailableForUe(ptCi, plmnIdx, ssbArfcn)))
        {
            return GOOD;
        }
        else
        {
            for (hrlPlmnIdx = 0; hrlPlmnIdx < MIN(ptHrl->numEplmn, X2_maxnoofEPLMNs); ++hrlPlmnIdx)
            {
                if ((GOOD == VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &plmnIdx, ptHrl->ePlmn[hrlPlmnIdx].longId)) &&
                    (GOOD == VLIB_IsPCellAndPlmnAvailableForUe(ptCi, plmnIdx, ssbArfcn)))
                {
                    return GOOD;
                }
            }
        }
        VCCB_PRINT_CALL_MSG(
            ptCi, "Cell with ssbArfcn(%u) not available on Handover Restriction List as PSCell\n", ssbArfcn);

        VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbArfcn, StatEndcSpCellSelFail_Spid_PlmnInHrlNotSupported);

        return BREAK;
    }
    else
    {
        for (plmnIdx = 0; plmnIdx < MAX_PLMN_INDEX; ++plmnIdx)
        {
            if (EQUIP != pGnb->plmnIndexInfo[plmnIdx].shmStatus)
            {
                continue;
            }
            if (GOOD == VLIB_IsPCellAndPlmnAvailableForUe(ptCi, plmnIdx, ssbArfcn))
            {
                return GOOD;
            }
        }
    }
    VCCB_PRINT_CALL_MSG(ptCi, "Cell with ssbArfcn(%u) not available as PSCell\n", ssbArfcn);

    VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbArfcn, StatEndcSpCellSelFail_Spid_PlmnSpidSsbFreqNotConfigured);

    return BREAK;
}

/**
 * @brief   Returns GOOD if SCell is available for UE.
 *          It checks for SPID if SPID based Local Network Support for EN-DC is enabled.
 * @param   ptCi : call context pointer
 * @param   ssbArfcn : ssbArfcn of SCell to check
 * @return  GOOD/ERROR, GOOD if cell is available
 */
int16_t VLIB_IsSCellAvailableForUe(callInfo_type *ptCi, uint32_t ssbArfcn)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (VCCB_FLAG_OFF == pGnb->cfg.spidBasedServingCellSelectionEnable)
    {
        return GOOD;
    }

    uint16_t spidIdx = SPID_CELL_DEFAULTS_INDEX;
    uint8_t plmnIdx;
    int16_t result = VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &plmnIdx, ptCi->ueInfo.servedPlmn.longId);

    if (GOOD != result)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Cannot get PLMN from VLIB_getMultipleGnbPlmnIndexInfo, result = %u!\n", result);
        return result;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(plmnIdx, MAX_PLMN_INDEX);

    if (VCCB_FLAG_OFF == pGnb->cfg.spidInfoPerPlmn[plmnIdx].spidBasedForPlmnEnable)
    {
        return GOOD;
    }
    if (OPT_NOT_PRESENT != ptCi->ueInfo.rfsp.rfspPresent)
    {
        VCCB_CHECK_RANGE_MIN_MAX_AND_RETURN_ERROR(ptCi->ueInfo.rfsp.subscriberProfile, 1, MAX_SPID_VALUE);
        if (VCCB_FLAG_ON == pGnb->cfg.spidInfoPerPlmn[plmnIdx]
                                .spidBasedServingCellSelectionEntries[ptCi->ueInfo.rfsp.subscriberProfile]
                                .spidInUseFlag)
        {
            spidIdx = ptCi->ueInfo.rfsp.subscriberProfile;
        }
    }

    if (NULL == bsearch(&ssbArfcn,
                    pGnb->cfg.spidInfoPerPlmn[plmnIdx].spidBasedServingCellSelectionEntries[spidIdx].sCellArfcn,
                    pGnb->cfg.spidInfoPerPlmn[plmnIdx].spidBasedServingCellSelectionEntries[spidIdx].numSCellArfcn,
                    sizeof(ssbArfcn), VLIB_QsortUint32AscendingOrder))
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "Cell ssbArfcn(%u), serving PLMN idx (%u) not available as SCell\n", ssbArfcn, plmnIdx);
        result = BREAK;
    }

    return result;
}

/**
 * @brief   Returns GOOD if all serving cells are FR2 only
 * @param   ptCi : call context pointer
 * @return  GOOD/ERROR/BREAK
 */
int16_t VLIB_IsAllServingCellsFr2Only(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint16_t cellIdx = 0;

    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    // Check PCell
    if (MIN_A6_NR_ARFCN > pCell->ssbArfcn)
    {
        return BREAK;
    }

    // Check SCells
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        if (scells[cellIdx].state != SCELL_STATE_ADDED)
        {
            continue;
        }
        if (MIN_A6_NR_ARFCN > scells[cellIdx].ssbArfcn)
        {
            return BREAK;
        }
    }

    // all serving cells are FR2
    return GOOD;
}

/**
 * @brief   Returns DU's cells frequency range information.
 * @param   ptCi : call context pointer
 * @return  enumServFreqRange_type
 */
enumServFreqRange_type VLIB_GetDuCellsFreqRange(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, ServFreqRange_Unknown);

    bool fr1Flag = false;
    bool fr2Flag = false;

#ifndef __NVGNB__
    cellSelection_type cellSelection = FnVCCB_GetCellSelectionForConfig(ptCi);
    uint16_t cellNum = cellSelection.cellNum;
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, ServFreqRange_Unknown);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    VCCB_CHECK_E_RANGE_AND_VAL(pCell->endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP, ServFreqRange_Unknown);
    VCCB_CHECK_E_RANGE_AND_VAL(pCell->gnbNum, MAX_GNB_PER_SYS, ServFreqRange_Unknown);

    const gnbDuInfo_type *const pGnbDu = &GNBINFO[pCell->gnbNum].gnbDu[pCell->endPointF1Index];

    const uint16_t maxLoop = MAX_CELL_PER_DU;
#else
    const uint16_t maxLoop = MAX_CELL_NUM_VCCB;
#endif

    const VccbCellInfo_type *pDuCell = NULL;
    uint16_t loop = 0;
    for (loop = 0; loop < maxLoop; loop++)
    {
#ifndef __NVGNB__
        if (EQUIP != pGnbDu->cellInDu[loop].status)
        {
            continue;
        }
        const uint16_t duCellNum = pGnbDu->cellInDu[loop].cellNum;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(duCellNum, MAX_CELL_NUM_VCCB);
        pDuCell = &CELLINFO[duCellNum];
#else
        pDuCell = &CELLINFO[loop];
#endif

        if ((EQUIP != pDuCell->status) || (EQUIP != pDuCell->pldState))
        {
            continue;
        }

        if (MIN_A6_NR_ARFCN > pDuCell->ssbArfcn)
        {
            fr1Flag = true;
        }
        else
        {
            fr2Flag = true;
        }

        if (fr1Flag && fr2Flag)
        {
            break;
        }
    }

    if (fr1Flag && fr2Flag)
    {
        return ServFreqRange_FR1andFR2;
    }
    if (fr1Flag)
    {
        return ServFreqRange_FR1only;
    }
    if (fr2Flag)
    {
        return ServFreqRange_FR2only;
    }

    return ServFreqRange_Unknown;
}

void FnVCCB_ClearDrbTnlNeedModifyFlag(callInfo_type &rCall)
{
    if (rCall.callType == E_CALLTYPE_NSA) return;

    for (uint8_t drbIdx = 0; drbIdx < MAX_DRB_PER_CALL; drbIdx++)
    {
        callDRBInfo_type &rDrb = rCall.drb[drbIdx];
        if(rDrb.f1uDlInfo.fNeedModify == VCCB_FLAG_ON)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "DRB[%d] f1uDlInfo Tnl NeedModify flag is not cleared!!\n", drbIdx);
            rDrb.f1uDlInfo.fNeedModify = VCCB_FLAG_OFF;
        }
        if(rDrb.f1uUlInfo.fNeedModify == VCCB_FLAG_ON)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "DRB[%d] f1uUlInfo Tnl NeedModify flag is not cleared!!\n", drbIdx);
            rDrb.f1uUlInfo.fNeedModify = VCCB_FLAG_OFF;
        }
        if(rDrb.xNuDlInfo.fNeedModify == VCCB_FLAG_ON)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "DRB[%d] xNuDlInfo Tnl NeedModify flag is not cleared!!\n", drbIdx);
            rDrb.xNuDlInfo.fNeedModify = VCCB_FLAG_OFF;
        }
        if(rDrb.xNuUlInfo.fNeedModify == VCCB_FLAG_ON)
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "DRB[%d] xNuUlInfo NeedModify flag is not cleared!!\n", drbIdx);
            rDrb.xNuUlInfo.fNeedModify = VCCB_FLAG_OFF;
        }
    }
}

int16_t VLIB_IsNeedTnlUpdate(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    // This call needs 2nd E1 BearerContext Setup/Modification(TNL update from AUPF) after F1 UeContextSetup
    // Procedure(on PDUChg_F1Mod) because it has newly added DRBs(S_Setup, S_Modify)
    uint8_t drbIdx = 0;

    for (drbIdx = 0; drbIdx < MAX_DRB_PER_CALL; drbIdx++)
    {
        if (ptCi->drb[drbIdx].usage != CI_use) continue;

        if (ptCi->drb[drbIdx].f1uDlInfo.fNeedModify == 1)
        {
            return GOOD;
        }
    }
    return ERROR;
}

/**
 *  @brief   Get PLD gnbIdx form gnbId
 **/
int VRRM_GetEutraCellInfoPldGnbIdxFromGnbId(uint32_t gnbId, uint16_t endPointX2Idx, uint16_t *ptGnbIdx)
{
    AUTO_TRACE_FUNC;

    if ((TRUE == FOO.VF_MultipleOperatorRanSupport) || (VCOM_getSystemType() == e_VCCB_NVGNB))
    {
        return GOOD;
    }

    VALID_E_POINT_CHECK_ERROR(ptGnbIdx);
    VCCB_CHECK_E_RANGE_AND_RETURN(endPointX2Idx, MAX_ENB_PER_GNB_CU_CP);

    uint16_t gnbIdx;

    for (gnbIdx = 0; gnbIdx < MAX_GNB_PER_SYS; gnbIdx++)
    {
        if (CFG->pldEutraCellInfo[gnbIdx][endPointX2Idx].status != EQUIP) continue;

        if (CFG->pldEutraCellInfo[gnbIdx][endPointX2Idx].gNBId == gnbId)
        {
            *ptGnbIdx = gnbIdx;
            VCCB_PRINT_COMMENT(
                "%s [%d:%d] found gnbIdx:%d from gnbId:%d\n", __func__, gnbIdx, endPointX2Idx, gnbIdx, gnbId);
            return GOOD;
        }
    }

    VCCB_PRINT_COMMENT("%s [%d:%d] not found gnbIdx from gnbId:%d\n", __func__, gnbIdx, endPointX2Idx, gnbId);
    VCCB_PRINT_COMMENT(
        "Check (itscp_vccb get cfg gnb eutraCellInfo) and PLDEutraCellInfo(0x%08X)\n", REL_EUTRA_CELL_INFO_ID);
    return ERROR;
}

/****************************************************************************
 * @brief           Update Enb Cell Info
 *
 * When the pcell is changed by performing HO in LTE,
 * It is necessary to update the ARFCN and BW of the ECGI.
 *
 * @param[in]       ptCi :   Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VLIB_UpdateEnbCellInfo(callInfo_type *ptCi, uint8_t interMnHoFlag)
{
    AUTO_TRACE_FUNC;

    uint16_t endPointX2Idx;
    uint16_t pldGnbIdx;
    uint8_t cellId = 0;

    PLDEutraCellInfo *ptEutraCellInfo = NULL;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    /* Get endPointX2Idx */
    if (VCCB_FLAG_ON == interMnHoFlag)
    {
        endPointX2Idx = ptCi->hoInfo.targetEnb.x2Idx;
    }
    else
    {
        endPointX2Idx = ptCi->endPointInfo.x2Idx;
    }
    VCCB_CHECK_E_RANGE_AND_RETURN(endPointX2Idx, MAX_ENB_PER_GNB_CU_CP);

    /* Get gnbIdx from gnbId */
#ifdef __NVGNB__
    pldGnbIdx = ptCi->gnbNum;
#else
    if (TRUE == FOO.VF_MultipleOperatorRanSupport)
    {
        pldGnbIdx = ptCi->gnbNum;
    }
    else
    {
        pldGnbIdx = MAX_GNB_PER_SYS;
    }
#endif
    if (ERROR == VRRM_GetEutraCellInfoPldGnbIdxFromGnbId(pGnb->globalGnbId.gnbId.id, endPointX2Idx, &pldGnbIdx))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Fail to GetEutraCellInfoPldGnbIdxFromGnbId(gnbId:%u)\n", pGnb->globalGnbId.gnbId.id);
        return ERROR;
    }
    VCCB_CHECK_E_RANGE_AND_RETURN(pldGnbIdx, MAX_GNB_PER_SYS);
    ptEutraCellInfo = &CFG->pldEutraCellInfo[pldGnbIdx][endPointX2Idx];

    /* Get cell ID */
    cellId = ((ptCi->eCGI.ci) & 0xFFL);  // eNB ID: 20bits, cell ID : 8bits (TBD: in case of Short Macro eNB)

    /* Fill celltype */
    ptCi->rscCoordBkp.eNBCellInfo.cellType = ptEutraCellInfo->cellType[cellId];

    /* Fill data */
    switch (ptCi->rscCoordBkp.eNBCellInfo.cellType)
    {
        case ci_DUPLEXTYPE_FDD:
            ptCi->rscCoordBkp.eNBCellInfo.u.fdd.earfcnUl = ptEutraCellInfo->earfcnUl[cellId];
            ptCi->rscCoordBkp.eNBCellInfo.u.fdd.earfcnDl = ptEutraCellInfo->earfcnDl[cellId];
            ptCi->rscCoordBkp.eNBCellInfo.u.fdd.ebandwidthUl = (uint16_t)ptEutraCellInfo->ebandwidthUl[cellId];
            ptCi->rscCoordBkp.eNBCellInfo.u.fdd.ebandwidthDl = (uint16_t)ptEutraCellInfo->ebandwidthDl[cellId];
            break;
        case ci_DUPLEXTYPE_TDD:
            ptCi->rscCoordBkp.eNBCellInfo.u.tdd.earfcn = ptEutraCellInfo->earfcnDl[cellId];
            ptCi->rscCoordBkp.eNBCellInfo.u.tdd.ebandwidth = (uint16_t)ptEutraCellInfo->ebandwidthDl[cellId];
            break;
        default:
            // cell(status:N_EQUIP) type is 0xFF
            VCCB_PRINT_CALL_ERROR(ptCi, "%s: Invalid duplexMode(%d) for cell(%d)\n", __FUNCTION__,
                ptEutraCellInfo->cellType[cellId], cellId);
            return ERROR;
    }

    /* Fill vendor info */
    if (VCCB_FLAG_ON == interMnHoFlag)
    {
        ptCi->hoInfo.targetEnb.eNBInfo.x2VendorInd = (uint8_t)ptEutraCellInfo->samsungVendorInd;
    }
    else
    {
        ptCi->eNBInfo.x2VendorInd = (uint8_t)ptEutraCellInfo->samsungVendorInd;
    }

    return GOOD;
}

/**
 * @brief           Find servedPlmn of MRL in SIB1 PLMN
 * @param[in]       ptCi :   Call information / callInfo_type
 * @return          status : GOOD, ERROR / int16_t
 */
int16_t VLIB_FindPlmnInSIB1Plmn(callInfo_type *ptCi, uint32_t reqPlmnLongId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint32_t loop1, loop2;
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    for (loop1 = 0; loop1 < MIN(pCell->sib1.plmn_IdentityInfoList.nrofPLMN_IdentityInfo, MAX_NUM_PLMN); loop1++)
    {
        const PLMN_IdentityInfo_type *pPlmnInfo = &pCell->sib1.plmn_IdentityInfoList.plmn_IdentityInfo[loop1];

        for (loop2 = 0; loop2 < MIN(pPlmnInfo->plmn_IdentityList.nrofPLMN_Identity, MAX_NUM_PLMN); loop2++)
        {
            const plmnId_type *pPlmn = &pPlmnInfo->plmn_IdentityList.plmn_Identity[loop2];

            if (reqPlmnLongId == pPlmn->longId)
            {
                return GOOD;
            }
        }
    }

    return ERROR;
}

/**
 * @brief     find arfcn in MO and set redirection info
 */
int16_t VLIB_SetRedirectionInfoObjectByArfcn(callInfo_type *ptCi, uint32_t arfcn)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int index;
    measurementObjectUe_type *pMeasObj = NULL;

    for (index = 0; index < MAX_NR_OF_OBJECT_ID; index++)
    {
        pMeasObj = &ptCi->measurementsConfiguration.measurementObjects.installedItems[index];
        if (CI_use != pMeasObj->usage) continue;

        switch (pMeasObj->conf.ratType)
        {
            case measRatNr:
                if (arfcn == VCCB_GetMeasObjectSsbFreq(*pMeasObj))
                {
                    VLIB_CreateRedirectionInfoNrFromMeasObjectUe(&ptCi->redirectionInfo.rat.nr, &pMeasObj->conf.rat.nr);
                    ptCi->redirectionInfo.redirType = INTRA_RAT_REDIRECTION;
                    return GOOD;
                }
                break;
            case measRatEutra:
                if (arfcn == VCCB_GetMeasObjectCarrierFreq(*pMeasObj))
                {
                    VLIB_CreateRedirectionInfoEutraFromMeasObjectUe(
                        &ptCi->redirectionInfo.rat.eutra, &pMeasObj->conf.rat.eutra);
                    ptCi->redirectionInfo.redirType = INTER_RAT_REDIRECTION;
                    return GOOD;
                }
                break;
            default:
                break;
        }
    }

    return ERROR;
}

/**
 * @brief     set redirection info using MO
 */
int16_t VLIB_SetRedirectionInfoObjectByMO(callInfo_type *ptCi, measurementObjectUe_type *pMeasObj)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMeasObj);

    if (CI_use == pMeasObj->usage)
    {
        switch (pMeasObj->conf.ratType)
        {
            case measRatNr:
                VLIB_CreateRedirectionInfoNrFromMeasObjectUe(&ptCi->redirectionInfo.rat.nr, &pMeasObj->conf.rat.nr);
                ptCi->redirectionInfo.redirType = INTRA_RAT_REDIRECTION;
                return GOOD;

            case measRatEutra:
                VLIB_CreateRedirectionInfoEutraFromMeasObjectUe(
                    &ptCi->redirectionInfo.rat.eutra, &pMeasObj->conf.rat.eutra);
                ptCi->redirectionInfo.redirType = INTER_RAT_REDIRECTION;
                return GOOD;

            default:
                break;
        }
    }

    return ERROR;
}

int16_t VCCM_CheckCellInService(
    callInfo_type *ptCi, uint16_t cellNum, uint16_t isEquippedCell, uint16_t printErrorLog)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    // 1. Check if Cell is Equipped
    if ((TRUE == isEquippedCell) && (EQUIP != pCell->status))
    {
        if (printErrorLog)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_CheckCellInService  Cell is not Equipped(cellNum: %d)\n", cellNum);
        }

        return ERROR;
    }

    // 2. Check if Cell is In-service.
    if (FALSE == VLIB_IsInServiceCell(ptCi, cellNum, printErrorLog))
    {
        return ERROR;
    }

    // 3. Check if Cell is barred.
    // NR_CONN_MC_21D - SDL Cell is in NRRRC_barred in case of Intra-gNB Neighbor Cell
    if (TRUE == VLIB_IsCellBarred(ptCi, cellNum, printErrorLog))
    {
        return ERROR;
    }

    return GOOD;
}

int16_t VCCM_CheckInterGnbHandoverTarget(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTER_NB && ptCi->hoInfo.isTarget == TRUE)
    {
        return GOOD;
    }

    return ERROR;
}

int16_t VCCM_CheckInterGnbRRETarget(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if ((RrcReestablish_cmd == ptCi->stateCmd) &&
        (RRE_TYPE_INTER_GNB == ptCi->ueInfo.reestablishInfo.reestablishType) &&
        (TRUE == ptCi->ueInfo.reestablishInfo.isTargetGnb))
    {
        return GOOD;
    }

    return ERROR;
}

/**
 * @brief Get slice load control information for specified gNB and slice index
 * @param gnbNum gNB number (0 to MAX_GNB_PER_SYS-1)
 * @param sliceIdx Slice index (0 to MAX_ACTIVE_SLICE_NUM-1)
 * @return Pointer to slice load control info if valid, NULL otherwise
*/
const sliceLoadControlInfo_type* FnVCCB_GetSliceLoadControlInfo(uint16_t gnbNum, uint8_t sliceIdx)
{
    VCCB_CHECK_E_RANGE_AND_NULL(gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_NULL(sliceIdx, MAX_ACTIVE_SLICE_NUM);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    const sliceLoadControlInfo_type *pSlice = &pGnb->sliceLoadControlInfo[sliceIdx];

    if (pSlice->usage != CI_use) return NULL;
    if (pSlice->plmnIndex_exist != VCCB_FLAG_ON) return NULL;
    if (pSlice->sst_exist != VCCB_FLAG_ON) return NULL;

    VCCB_CHECK_E_RANGE_AND_NULL(pSlice->plmnIndex, MAX_PLMN_INDEX);

    return pSlice;
}

int16_t VLIB_CheckifSupportedSNSSAIList(
    callInfo_type *ptCi, callSNSSAI_type &rTgtSnssai, uint32_t plmnLongId, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    // Debug only
    if (DBG->flag.isSkipSnssaiSelection)
    {
        return GOOD;
    }

    /* 1. Compare S-NSSAI of PDU Session with Cell Info */
    if (VLIB_CheckNssaiWithCellInfo(ptCi, rTgtSnssai, cellNum, plmnLongId) != GOOD)
    {
        // if (DBG->flag.logSliceAware)
        {
            // check itscp_vccb get cfg gnb supportedSliceInfoCell [cellIdentity]
            if ((int)rTgtSnssai.sdPresent != OPT_NOT_PRESENT)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "Not Allowed : Not Supported S-NSSAI on CellInfo[%u]. (SNSSAI(sst/sd) : %u/%u)\n",
                    cellNum, rTgtSnssai.sst, rTgtSnssai.sd);
                VCCB_PRINT_CALL_ERROR(ptCi, "Check itscp_vccb get cfg gnb supportedSliceInfoCell [cellIdentity]\n");
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "Not Allowed : Not Supported S-NSSAI on CellInfo[%u]. (SNSSAI(sst/sd) : %u/-))\n",
                    cellNum, rTgtSnssai.sst);
                VCCB_PRINT_CALL_ERROR(ptCi, "Check itscp_vccb get cfg gnb supportedSliceInfoCell [cellIdentity]\n");
            }
        }

        return ERROR;
    }
#ifndef __NVGNB__  // NVGNB not supports E1 SNSSAI but Cell SNSSAI only. (FGR-SVR0601 Network Slicing Configuration for
                   // RAN FR20, 41)
    /* 2. Compare S-NSSAI of PDU Session with E1 Info */
    if (VLIB_CheckNssaiWithE1Info(ptCi, rTgtSnssai, plmnLongId) != GOOD)
    {
        // if (DBG->flag.logSliceAware)
        {
            // check itscp_vccb get cfg gnb supportedSliceInfoAupf
            if ((int)rTgtSnssai.sdPresent != OPT_NOT_PRESENT)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "Not Allowed : Not Supported S-NSSAI on AUPF. (SNSSAI(sst/sd) : %u/%u))\n",
                    rTgtSnssai.sst, rTgtSnssai.sd);
                VCCB_PRINT_CALL_ERROR(ptCi, "Check itscp_vccb get cfg gnb supportedSliceInfoAupf\n");
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "Not Allowed : Not Supported S-NSSAI on AUPF. (SNSSAI(sst/sd) : %u/-))\n",
                    rTgtSnssai.sst);
                VCCB_PRINT_CALL_ERROR(ptCi, "Check itscp_vccb get cfg gnb supportedSliceInfoAupf\n");
            }
        }

        return ERROR;
    }
#endif

    return GOOD;
}

int16_t VLIB_CheckNssaiWithCellInfo(
    callInfo_type *ptCi, callSNSSAI_type &rTgtSnssai, uint16_t reqCellNum, uint32_t reqPlmnLongId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(reqCellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type *const pCell = &CELLINFO[reqCellNum];

    uint32_t iPlmn, iNssai;
    uint32_t maxPlmnCnt, maxSnssaiCnt;

    /* Compare S-NSSAI of PDU Session with Cell Info */
    /* Compare PLMN */
    maxPlmnCnt = MIN(pCell->cellPlmn.numOfPLMN, MAX_PLMN_INDEX);
    for (iPlmn = 0; iPlmn < maxPlmnCnt; iPlmn++)
    {
        if (reqPlmnLongId == pCell->cellPlmn.servedPlmn[iPlmn])
        {
            maxSnssaiCnt = MIN(pCell->cellPlmn.supportedSnssaiGrpCntPerPlmn[iPlmn], MAX_SNSSAI_GRP_PER_PLMN_CELL);

            /* For Old Version DU, If match PLMN and has no S-NSSAI, then return GOOD */
            if( maxSnssaiCnt == 0 )
            {
                VCCB_PRINT_CALL_COMMENT( ptCi, "There is no S-NSSAI Group for PLMN(%u)\n", pCell->cellPlmn.supportedSnssaiGrpCntPerPlmn[iPlmn]);
                return GOOD;
            }

            for( iNssai = 0; iNssai < maxSnssaiCnt; iNssai++ )
            {
                // check rTgtSnssai.sstSd is between snssaiGrp to (supportedSnssaiGrp + supportedSnssaiGrpLength)
                if( (pCell->cellPlmn.supportedSnssaiGrp[iPlmn][iNssai] <= rTgtSnssai.sstSd) &&
                    (rTgtSnssai.sstSd < (pCell->cellPlmn.supportedSnssaiGrp[iPlmn][iNssai] + pCell->cellPlmn.supportedSnssaiGrpLength[iPlmn][iNssai])) )
                {
                    return GOOD;
                }
            }  // for(iNssai = 0; iNssai < maxSnssaiCnt; iNssai++)
        }
    }  // for(iPlmn=0; iPlmn < maxPlmnCnt; iPlmn++)

    return ERROR;
}

int16_t VLIB_CheckNssaiWithE1Info(callInfo_type *ptCi, callSNSSAI_type &rTgtSnssai, uint32_t reqPlmnLongId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint32_t iPlmn, iNssai;
    uint32_t maxPlmnCnt, maxSnssaiCnt;
    uint32_t endPointIdx = 0;
    const AupfStatusInfo_type *pGnbCuUp = NULL;

    /* Compare S-NSSAI of PDU Session with E1 Info */
    for (endPointIdx = 0; endPointIdx < MAX_GNB_CU_UP_PER_GNB_CU_CP; endPointIdx++)
    {
        pGnbCuUp = &pGnb->aupf.gnbCuUp[endPointIdx];

        if (pGnbCuUp->status != EQUIP) continue;
        if (pGnbCuUp->serviceState != OpState_enabled) continue;

        if ((pGnbCuUp->cnSupport != E1_c_5gc) && (pGnbCuUp->cnSupport != E1_CNSupport_both)) continue;

        /* Compare PLMN */
        maxPlmnCnt = MIN(pGnbCuUp->plmnCnt, MAX_E1_SUPPORTED_PLMN);
        for (iPlmn = 0; iPlmn < maxPlmnCnt; iPlmn++)
        {
            if (reqPlmnLongId == pGnbCuUp->plmn[iPlmn])
            {
                /* Compare S-NSSAI */
                maxSnssaiCnt = MIN(pGnbCuUp->supportedSnssaiGrpCntPerPlmn[iPlmn], MAX_SNSSAI_GRP_PER_PLMN_AUPF);
                for (iNssai = 0; iNssai < maxSnssaiCnt; iNssai++)
                {
                    if ( (pGnbCuUp->supportedSnssaiGrp[iPlmn][iNssai] <= rTgtSnssai.sstSd) &&
                         (rTgtSnssai.sstSd < (pGnbCuUp->supportedSnssaiGrp[iPlmn][iNssai] + pGnbCuUp->supportedSnssaiGrpLength[iPlmn][iNssai])) )
                    {
                        /* Find and Return GOOD */
                        VCCB_PRINT_CALL_COMMENT(ptCi, "PDU session's S-NSSAI(%u) is included in with UP's S-NSSAI(%u ~ %u)\n",
                            rTgtSnssai.sstSd,
                            pGnbCuUp->supportedSnssaiGrp[iPlmn][iNssai],
                            pGnbCuUp->supportedSnssaiGrp[iPlmn][iNssai] + pGnbCuUp->supportedSnssaiGrpLength[iPlmn][iNssai]);
                        return GOOD;
                    }
                }  // for(iNssai = 0; iNssai < maxSnssaiCnt; iNssai++)
            }
        }  // for(iPlmn=0; iPlmn < maxPlmnCnt; iPlmn++)
    }      // for (endPointIdx = 0; endPointIdx < MAX_GNB_CU_UP_PER_GNB_CU_CP; endPointIdx++)

    return ERROR;
}

bool FnVCCB_CheckIfAllPduSessSuppSNSSAIList(callInfo_type *ptCi, const uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    for (callPDUSessInfo_type &rPduSess : ptCi->pduSess)
    {
        if (CI_use != rPduSess.usage)
        {
            continue;
        }

        if (GOOD != VLIB_CheckifSupportedSNSSAIList(ptCi, rPduSess.sNssai, ptCi->ueInfo.servedPlmn.longId, cellNum))
        {
            return false;
        }
    }

    return true;
}

/**
 *  @brief This function acquires the integrity check and SNSSAI List for xnTaiInfo.
 *  @return GOOD : Allowed PDU, ERROR : Function Error
 */
int16_t VLIB_GetSupportedSNSSAIListInXnTaiInfo(callInfo_type *ptCi, xnTaiInfo_type *ptXnTai,
    candidateNbrInformation_type *pNbrInfo, uint32_t candidatePlmnLongId, sNssaiList_type *ptOutputSnssaiList)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptXnTai);
    VALID_E_POINT_CHECK_ERROR(pNbrInfo);
    VALID_E_POINT_CHECK_ERROR(ptOutputSnssaiList);

    ptOutputSnssaiList->sNssaiCnt = 0;

    if (ptXnTai->status != EQUIP)
    {
        return GOOD;
    }

    if (ptXnTai->serviceState != OpState_enabled)
    {
        return GOOD;
    }

    uint32_t iTai = 0;
    uint32_t maxTaiSupportCnt = MIN(ptXnTai->taiSupportCnt, MAX_XN_TAI_SUPPORT_COUNT);

    for (iTai = 0; iTai < maxTaiSupportCnt; iTai++)
    {
        /* Range Check */
        if (ptOutputSnssaiList->sNssaiCnt >= MAX_XN_TAI_SUPPORT_COUNT) break;

        /* Compare PLMN */
        if (candidatePlmnLongId != ptXnTai->plmn[iTai]) continue;

        /* Compare TAC */
        if (pNbrInfo->nbrTaiInfo.tac != ptXnTai->tac[iTai]) continue;

        /* Store S-NSSAI */
        ptOutputSnssaiList->sNssai[ptOutputSnssaiList->sNssaiCnt] = ptXnTai->sNssai[iTai];
        ptOutputSnssaiList->sNssaiCnt++;
    }

    return GOOD;
}

/**
 *  @brief This function provides the operation to acquire SNSSAI List of Other GNB.
 *  @return GOOD : Allowed PDU, ERROR : Function Error
 */
int16_t VLIB_GetSupportedSNSSAIListInOtherGnb(callInfo_type *ptCi, uint16_t targetEndPointXn,
    candidateNbrInformation_type *pNbrInfo, uint32_t candidatePlmnLongId, sNssaiList_type *ptOutputSnssaiList)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pNbrInfo);
    VALID_E_POINT_CHECK_ERROR(ptOutputSnssaiList);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint32_t endPointXnIdx = 0;

    for (endPointXnIdx = 0; endPointXnIdx < MAX_XN_NBR_PER_GNB; endPointXnIdx++)
    {
        // Excluding targetEndPointXn is checked.
        // 1) If targetEndPointXn is within the valid range, it is excluded from the search target of EndPointXn.
        // 2) If targetEndPointXn is not within the valid range, all EndPointXn is searched.
        if (endPointXnIdx == targetEndPointXn) continue;

        xnTaiInfo_type *ptOtherGnb = &pGnb->xnGnbInfo[endPointXnIdx];

        // Search Other Gnb
        int16_t status =
            VLIB_GetSupportedSNSSAIListInXnTaiInfo(ptCi, ptOtherGnb, pNbrInfo, candidatePlmnLongId, ptOutputSnssaiList);
        VCCB_RETURN_ON_CALL_ERROR(
            ptCi, status, "VLIB_GetSupportedSNSSAIListInXnTaiInfo Error! (EndPointIdx:%u).\n", endPointXnIdx);

        if (ptOutputSnssaiList->sNssaiCnt > 0)
        {
            if (DBG->flag.logSliceAware)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "SNSSAI was acquired by Other GNB (xnIdx:%u/snssaiCnt:%u) (tgtXnIdx:%d)\n", 
                    endPointXnIdx, ptOutputSnssaiList->sNssaiCnt, targetEndPointXn);
            }

            return GOOD;
        }
    }

    return GOOD;
}

/**
 *  @brief This function extracts the SNSSAI List supported based on the Target TAI in the Inter-gNB HO environment.
 *  @return GOOD : Allowed PDU, ERROR : Function Error
 */
int16_t VLIB_GetSupportedSNSSAIListInServingForInterGnb(callInfo_type *ptCi, uint32_t xnIdx,
    candidateNbrInformation_type *pNbrInfo, uint32_t candidatePlmnLongId, sNssaiList_type *ptOutputSnssaiList)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptOutputSnssaiList);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(xnIdx, MAX_XN_NBR_PER_GNB);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    xnTaiInfo_type *ptTargetGnb = &pGnb->xnGnbInfo[xnIdx];

    if (ptTargetGnb->status != EQUIP)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Target GNB DB is Not EQUIP(%d/%d) (xnIdx:%u, xnNbrGnbId:%u, nbrGnbIdx:%u)\n",
            ptTargetGnb->status, ptTargetGnb->serviceState, xnIdx, pGnb->xnNbr[xnIdx].gnbId.id,
            pNbrInfo->globalGnbId.gnbId.id);
        return GOOD;
    }

    // Found TAI and Get Snssai List
    // ptTargetGnb(pGnb->xnGnbInfo): PLDXnGnbStatus (TAI list Per End Point)
    int16_t status =
        VLIB_GetSupportedSNSSAIListInXnTaiInfo(ptCi, ptTargetGnb, pNbrInfo, candidatePlmnLongId, ptOutputSnssaiList);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VLIB_GetSupportedSNSSAIListInXnTaiInfo Error!!\n");

    return GOOD;
}

/**
 *  @brief This function extracts the SNSSAI List supported based on the Target TAI in the Inter-gNB HO environment.
 *  @return GOOD : Allowed PDU, BREAK : Not Allowed PDU, ERROR : Function Error
 */
int16_t VLIB_GetSupportedSNSSAIListForInterGnb(callInfo_type *ptCi, candidateNbrInformation_type *pNbrInfo,
    uint32_t candidatePlmnLongId, sNssaiList_type *ptOutputSnssaiList)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptOutputSnssaiList);
    VALID_E_POINT_CHECK_ERROR(pNbrInfo);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    int16_t status;

    /* Search NbrCell In EndPointXn */
    uint16_t xnIdx = fnVLIB_FindXnEndPointIndexByGnbId(ptCi->gnbNum, &pNbrInfo->globalGnbId);
    // FGR-MC1021 - Slice Aware Mobility Control - FR40.CACP.SR1.HD1.DD1
    // 1) VCCB stores and updates the slice aware information per TAI of the target gNB.
    if (xnIdx < MAX_XN_NBR_PER_GNB)
    {
        status = VLIB_GetSupportedSNSSAIListInServingForInterGnb(
            ptCi, xnIdx, pNbrInfo, candidatePlmnLongId, ptOutputSnssaiList);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VLIB_GetSupportedSNSSAIListInServingForInterGnb Error!!\n");

        // If the TAI has been searched, the function is terminated.
        // If the TAI has not been searched, proceed to the next procedure.
        if (ptOutputSnssaiList->sNssaiCnt > 0)
        {
            if (DBG->flag.logSliceAware)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "SNSSAI was acquired by Target GNB (xnIdx:%u/snssaiCnt:%u)\n", 
                    xnIdx, ptOutputSnssaiList->sNssaiCnt);
            }

            return GOOD;
        }
    }

    // When the TAI is the same, the following operations are performed based on the standard that has the same slice
    // aware information Provide Intra gNB environment with higher priority than Inter gNB environment

    // FGR-MC1021 - Slice Aware Mobility Control - FR40.CACP.SR1.HD2.DD1
    // 2) VCCB stores and updates the slice aware information per TAI of the serving gNB.
    // {{{

    // pGnb->gnbXnTaiInfo : PLDGnbXnTaiInfo (TAI list Per Serving gNB)
    status = VLIB_GetSupportedSNSSAIListInXnTaiInfo(
        ptCi, &pGnb->gnbXnTaiInfo, pNbrInfo, candidatePlmnLongId, ptOutputSnssaiList);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VLIB_GetSupportedSNSSAIListInXnTaiInfo(Serving) Error!!\n");

    // If the TAI has been searched, the function is terminated.
    // If the TAI has not been searched, proceed to the next procedure.
    if (ptOutputSnssaiList->sNssaiCnt > 0)
    {
        if (DBG->flag.logSliceAware)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "SNSSAI was acquired by Serving GNB (xnIdx:%u/snssaiCnt:%u)\n", 
                xnIdx, ptOutputSnssaiList->sNssaiCnt);
        }

        return GOOD;
    }
    // }}}

    // FGR-MC1021 - Slice Aware Mobility Control - FR40.CACP.SR1.HD3.DD1
    // 3) VCCB checks whether the slice aware of other gNB TAI is supported in the order of FR40.
    status = VLIB_GetSupportedSNSSAIListInOtherGnb(ptCi, xnIdx, pNbrInfo, candidatePlmnLongId, ptOutputSnssaiList);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VLIB_GetSupportedSNSSAIListInOtherGnb Error!!\n");

    if (ptOutputSnssaiList->sNssaiCnt > 0)
    {
        // VCCB_PRINT_CALL_ERROR(ptCi, "SNSSAI was acquired by other GNB (xnIdx:%u/snssaiCnt:%u))\n", 
        //    xnIdx, ptOutputSnssaiList->sNssaiCnt);

        return GOOD;
    }

    return GOOD;
}

/**
 *  @brief This function checks whether the SNSSAI of the PDU Session is supported by the target.
 *  @return GOOD : Allowed PDU, BREAK : Not Allowed PDU, ERROR : Function Error
 */
int16_t VLIB_CheckifSupportedSNSSAIListForInterGnb(callInfo_type *ptCi, callSNSSAI_type &rTgtSnssai,
    candidateNbrInformation_type *pNbrInfo, uint32_t candidatePlmnLongId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pNbrInfo);

    int16_t status;
    sNssaiList_type sNssaiList;

    // Debug only
    if (DBG->flag.isSkipSnssaiSelection)
    {
        return GOOD;  // Allow
    }

    sNssaiList.sNssaiCnt = 0;

    // 1. Get sNssai List by TAI
    status = VLIB_GetSupportedSNSSAIListForInterGnb(ptCi, pNbrInfo, candidatePlmnLongId, &sNssaiList);
    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, status, "VLIB_GetSupportedSNSSAIListForInterGnb Error!! (nbrIdx:%d).\n", pNbrInfo->nbrIdx);

    // 2. Check Not Found TAI : TAI was not found, Allow Slice by not provided TAI
    if (sNssaiList.sNssaiCnt == 0)
    {
        // If information is not provided, it is always judged as support.
        if (DBG->flag.logSliceAware)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "Allowed : TAI Information is not provided, it is always judged as support. "
                "(nbr:%u, SNSSAI:%u[%u/%s])\n",
                pNbrInfo->nbrIdx, rTgtSnssai.sstSd, rTgtSnssai.sst, 
                (rTgtSnssai.sdPresent == OPT_NOT_PRESENT)?"-":(std::to_string(static_cast<uint32_t>(rTgtSnssai.sd)).c_str()));
        }
        return GOOD;  // Allow
    }

    // 3. Check Fount TAI
    uint32_t sNssaiIdx = 0;
    uint32_t maxSnssaiSupportCnt = MIN(sNssaiList.sNssaiCnt, MAX_XN_TAI_SUPPORT_COUNT);

    for (sNssaiIdx = 0; sNssaiIdx < maxSnssaiSupportCnt; sNssaiIdx++)
    {
        /* Compare S-NSSAI */
        if (sNssaiList.sNssai[sNssaiIdx] == rTgtSnssai.sstSd)
        {
            // Allow Slice in Source GNB. : TAI was found, and the SNSSAI information does match.
            if (DBG->flag.logSliceAware)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "Allowed : TAI/SNSSAI information does match. (nbr:%u, SNSSAI:%u[%u/%s])\n",
                    pNbrInfo->nbrIdx, rTgtSnssai.sstSd, rTgtSnssai.sst, 
                    (rTgtSnssai.sdPresent == OPT_NOT_PRESENT)?"-":(std::to_string(static_cast<uint32_t>(rTgtSnssai.sd)).c_str()));
            }

            return GOOD;  // Allow
        }
    }

    // 4. Not Exist NSSAI
    // Not Allow Slice in Target GNB. : TAI was found, but the SNSSAI information does not match.
    // check "itscp_vccb get cfg gnbXnTai" or "itscp_vccb get cfg xnGnb"
    if (DBG->flag.logSliceAware)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "Not Allowed : Not Supported S-NSSAI in NBR (nbr:%u, SNSSAI:%u[%u/%s])\n",
            pNbrInfo->nbrIdx, rTgtSnssai.sstSd, rTgtSnssai.sst, 
            (rTgtSnssai.sdPresent == OPT_NOT_PRESENT)?"-":(std::to_string(static_cast<uint32_t>(rTgtSnssai.sd)).c_str()));
    }

    return BREAK;  // Not Allow
}

void VLIB_ChangeBitOfIntraFreqInMeasObjectSelection(uint32_t *pMeasObjectSelection, int32_t isIntraFreqPresent)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pMeasObjectSelection);

    if (isIntraFreqPresent)
    {
        ONBIT(*pMeasObjectSelection, INTRAFREQ_OBJECT_IDX);
    }
    else
    {
        OFFBIT(*pMeasObjectSelection, INTRAFREQ_OBJECT_IDX);
    }
}

/****************************************************************************
 * @brief           Convert eutraAllowedMeasBandwidth_type to NRB
 *
 * @param[in]       enumEutraBandwidth                   : uint8_t (eutraAllowedMeasBandwidth_type)
 * @return          eutraBandwidth in Nrb - 0 by default : uint8_t
 ****************************************************************************/
uint8_t VLIB_ConvertEnumEutraBandwidthMbwToNrb(uint8_t enumEutraBandwidth)
{
    // AUTO_TRACE_FUNC not needed in such simple function - performance reasons
    switch (enumEutraBandwidth)
    {
        case eutraAllowedMeasBandwidth_mbw6:
            return 6;
        case eutraAllowedMeasBandwidth_mbw15:
            return 15;
        case eutraAllowedMeasBandwidth_mbw25:
            return 25;
        case eutraAllowedMeasBandwidth_mbw50:
            return 50;
        case eutraAllowedMeasBandwidth_mbw75:
            return 75;
        case eutraAllowedMeasBandwidth_mbw100:
            return 100;
        default:
            return 0;
    }
}

/****************************************************************************
 * @brief           Convert enumNrSubCarrierSpacing_type to kHz
 *
 * @param[in]       enumSubCarrierSpacing                   : uint8_t (enumNrSubCarrierSpacing_type)
 * @return          subCarrierSpacing in kHz - 0 by default : uint8_t
 ****************************************************************************/
uint8_t VLIB_ConvertEnumNrSubCarrierSpacingToKHz(uint8_t enumNrSubCarrierSpacing)
{
    // AUTO_TRACE_FUNC not needed in such simple function - performance reasons
    switch (enumNrSubCarrierSpacing)
    {
        case ci_Nr_scs15:
            return 15;
        case ci_Nr_scs30:
            return 30;
        case ci_Nr_scs60:
            return 60;
        case ci_Nr_scs120:
            return 120;
        case ci_Nr_scs240:
            return 240;
        case ci_Nr_scsMAX:
            return 0;
        default:
            return 0;
    }
}

/****************************************************************************
 * @brief           Convert enumNrSystemBandwidth_type to nRB
 *
 * @param[in]       enumSubCarrierSpacing                   : uint16_t (enumNrSubCarrierSpacing_type)
 * @return          NrSystemBandwidth in nRB - 0 by default : uint16_t
 ****************************************************************************/
uint16_t VLIB_ConvertEnumNrSystemBandwidthToNrb(uint16_t enumNrSystemBandwidth)
{
    // AUTO_TRACE_FUNC not needed in such simple function - performance reasons
    switch (enumNrSystemBandwidth)
    {
        case ci_NrSystemBandwidth_nrb11:
            return 11;
        case ci_NrSystemBandwidth_nrb18:
            return 18;
        case ci_NrSystemBandwidth_nrb24:
            return 24;
        case ci_NrSystemBandwidth_nrb25:
            return 25;
        case ci_NrSystemBandwidth_nrb31:
            return 31;
        case ci_NrSystemBandwidth_nrb32:
            return 32;
        case ci_NrSystemBandwidth_nrb38:
            return 38;
        case ci_NrSystemBandwidth_nrb51:
            return 51;
        case ci_NrSystemBandwidth_nrb52:
            return 52;
        case ci_NrSystemBandwidth_nrb65:
            return 65;
        case ci_NrSystemBandwidth_nrb66:
            return 66;
        case ci_NrSystemBandwidth_nrb78:
            return 78;
        case ci_NrSystemBandwidth_nrb79:
            return 79;
        case ci_NrSystemBandwidth_nrb93:
            return 93;
        case ci_NrSystemBandwidth_nrb106:
            return 106;
        case ci_NrSystemBandwidth_nrb107:
            return 107;
        case ci_NrSystemBandwidth_nrb121:
            return 121;
        case ci_NrSystemBandwidth_nrb132:
            return 132;
        case ci_NrSystemBandwidth_nrb133:
            return 133;
        case ci_NrSystemBandwidth_nrb135:
            return 135;
        case ci_NrSystemBandwidth_nrb160:
            return 160;
        case ci_NrSystemBandwidth_nrb162:
            return 162;
        case ci_NrSystemBandwidth_nrb189:
            return 189;
        case ci_NrSystemBandwidth_nrb216:
            return 216;
        case ci_NrSystemBandwidth_nrb217:
            return 217;
        case ci_NrSystemBandwidth_nrb245:
            return 245;
        case ci_NrSystemBandwidth_nrb264:
            return 264;
        case ci_NrSystemBandwidth_nrb270:
            return 270;
        case ci_NrSystemBandwidth_nrb273:
            return 273;
        default:
            return 0;
    }
}

/****************************************************************************
 * @brief           Calculate difference if grater than 0 or return 0 otherwise
 *
 * @param[in]       value_1           : uint32_t
 * @param[in]       value_2           : uint32_t
 * @return          difference        : uint32_t
 ****************************************************************************/
uint32_t VLIB_PositiveDiffOrZero(uint32_t first, uint32_t second) { return first > second ? (first - second) : 0; }

bool VHCM_isForcedHoRestriction(callInfo_type const *ptCi)
{
    AUTO_TRACE_FUNC;

    // check the forced ho timer is needed
    if (FnVCCB_GetSaMeas(*ptCi).forcedHoState == FORCED_HO_ACTIVE)
    {
        return true;
    }

    return false;
}

/**
 * @brief           Find plmnIndex from plmnIndexInfo based on a value of servedPlmn
 *
 * @param[in]       ptCi : call context / callInfo_type
 * @return          plmnIndex, MAX_PLMN_INDEX when index is not found / uint8_t
 */
uint8_t VLIB_FindGnbPlmnIndexOfCall(const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_PLMN_INDEX);

    uint8_t plmnIndex = MAX_PLMN_INDEX;
    const auto ueServingPlmn = VCCB_GetUeServingPlmn(*ptCi);
    if (GOOD == VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &plmnIndex, ueServingPlmn.longId))
    {
        return plmnIndex;
    }

    return plmnIndex;
}

/****************************************************************************
 * @brief           Checks if given UE can use object containing plmnBasedControl
 *                  based on provided plmn index and service group id
 *
 * @param[in]       ptCi : call context / callInfo_type
 * @param[in]       plmnBasedControl : plmn based control object
 * @param[in]       callPlmnIndex : plmn index of a call
 * @param[in]       callSvcGrpId : service group id of a call
 * @return          GOOD : plmnBasedControl can be used
 * @return          BREAK/ERROR : plmnBasedControl can NOT be used
 ****************************************************************************/
int16_t VLIB_CanPlmnBasedControlBeUsedWithCustomIds(
    const callInfo_type *ptCi, const PlmnBasedControl &plmnBasedControl, uint8_t callPlmnIndex, uint8_t callSvcGrpId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

#ifdef IPC_TEST
    VCCB_PRINT_CALL_COMMENT(ptCi, "callSvcGrpId:%d plmnIndex:%d\n", callSvcGrpId, callPlmnIndex);
#endif

    if (MAX_PLMN_INDEX > callPlmnIndex)
    {
        const auto &plmnSupportEntry = plmnBasedControl.plmn[callPlmnIndex];
        if (CI_use == plmnSupportEntry.usage)
        {
            /* allowed PLMN with matched PLMN */
            if (plmnOption_notAllowed == plmnSupportEntry.option)
            {
                return BREAK;
            }
        }
        else if (notMatchedPlmn_notAllowed == plmnBasedControl.notMatchedPlmnOption)
        {
            return BREAK;
        }
    }
    else if (notMatchedPlmn_notAllowed == plmnBasedControl.notMatchedPlmnOption)
    {
        return BREAK;
    }

    /* Check the service Group Id */
    if (E_CALLTYPE_SA == ptCi->callType)
    {
        const auto &serviceGroupEntry = plmnBasedControl.serviceGroupEntries[callSvcGrpId];
        if ((MAX_SVC_GRP_DB_NUM > callSvcGrpId) && (CI_use == serviceGroupEntry.usage))
        {
            if (serviceGroupOption_notAllowed == serviceGroupEntry.option)
            {
                return BREAK;
            }
        }
    }
    else  // NSA
    {
        if (MAX_PLMN_INDEX > callPlmnIndex)
        {
            const auto &plmnSupportEntry = plmnBasedControl.plmn[callPlmnIndex];
            if ((CI_use == plmnSupportEntry.usage) && (MAX_ENDC_SVCGRP_ID > callSvcGrpId))
            {
                const auto &endcServiceGroupEntry = plmnSupportEntry.endcServiceGroupEntries[callSvcGrpId];
                if ((CI_use == endcServiceGroupEntry.usage) && (serviceGroupOption_notAllowed == endcServiceGroupEntry.option))
                {
                    return BREAK;
                }
            }
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Checks if given UE can use object containing plmnBasedControl
 *                  based on call's own plmn index and service group id
 *
 * @param[in]       ptCi : call context / callInfo_type
 * @param[in]       plmnBasedControl : plmn based control object
 * @param[in]       callPlmnIndex : plmn index of a call
 * @param[in]       callSvcGrpId : service group id of a call
 * @return          GOOD : plmnBasedControl can be used
 * @return          BREAK/ERROR : plmnBasedControl can NOT be used
 ****************************************************************************/
int16_t VLIB_CanPlmnBasedControlBeUsed(const callInfo_type *ptCi, const PlmnBasedControl &plmnBasedControl)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    const uint8_t callPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    const uint8_t svcGrpId = FnVCCB_GetSvcGrpId(const_cast<callInfo_type &>(*ptCi), FALSE);

    int16_t status = VLIB_CanPlmnBasedControlBeUsedWithCustomIds(ptCi, plmnBasedControl, callPlmnIndex, svcGrpId);

    return status;
}

/* Init Load distribution control DB */
void FnVCCB_MainInitOnDemandMobilityControl(void)
{
    AUTO_TRACE_FUNC;

    onDemandLoadDistInfo_type prev, *pCtrl = &ENV->onDemandLoadDistCtrl;

    prev = *pCtrl;

    // Detach the timer if attached
    MACRO_CHECK_AND_DETACH(VCCB_ODHO_LOAD_DIST_TIMER);

    // Init
    memset(pCtrl, 0, sizeof(onDemandLoadDistInfo_type));
    VCCB_CLEAR_TIMER(&VCCB_ODHO_LOAD_DIST_TIMER, INIT_TIMER);  // id = -1

    // Load Distribution Parameters
    pCtrl->ldCtrlInfo = prev.ldCtrlInfo;
}

/* Init onDemand Mobility control DB */
void FnVCCB_InitOnDemandMobilityControlOnCell(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);

    onDemandMobilityControlInfo_type *pTr = &pCell->onDemandHoInfo;

    pTr->onDemandHoSupport = false;
    pTr->operationMode = ODHO_FORCED_HO_AND_TIMER_BASE_RELEASE;
    pTr->preferRatForVoiceCall = ODHO_PREFER_NR;
    pTr->preferRatForDataCall = ODHO_PREFER_NR;
    pTr->timerForCallRelease = DEFAULT_TIME_CALL_RELEASE;
    pTr->includeEmergHpaOnOff = false;
    pTr->emergHpaMode = ODHO_EMERG_AND_HPA;
}

/* Init NRDC RFSP based operation mode of cell */
void FnVCCB_InitNrdcRfspBasedOprMode(NrdcCellInfo_type *pNrdcCellInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pNrdcCellInfo);

    memset(pNrdcCellInfo->nrdcRfspBasedOprMode, 0, sizeof(pNrdcCellInfo->nrdcRfspBasedOprMode));
}

/* Init DL traffic status configuration of cell */
void FnVCCB_InitDlTrfStatusRptCfg(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);

    memset(pCell->dlTrfStatusCfg, 0, sizeof(pCell->dlTrfStatusCfg));
}

/* Init Traffic Monitoring configuration RFSP of cell */
void FnVCCB_InitTrafficMonitoringCfgRfsp(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);

    memset(pCell->trfMonitoringCfgRfsp, 0, sizeof(pCell->trfMonitoringCfgRfsp));
}

bool FnVCCB_MainCheckValidationForLdTimer(struct timespec currTime)
{
    AUTO_TRACE_FUNC;

    onDemandLoadDistInfo_type *pCtrl = &ENV->onDemandLoadDistCtrl;

    // calculate diffTime with lastExpiredTime : currTime - lastExpiredTime
    // If diffTime < VCCB_ODHO_LOAD_DIST_TIMER_VAL*VCCB_ODHO_PERIOD_MARGIN_RATIO, it is abnormal
    long diffTime = VLIB_getTickDifferenceWithTime(pCtrl->lastExpiredTime, currTime);
    if (diffTime < VCCB_ODHO_TIMER_PERIOD_MARGIN)  // 80ms by default
    {
        return false;
    }

    return true;
}

/*Init UE Distribution Ratio of cell*/
void FnVCCB_InitIdleModeInfoUeDistributionRatio(VccbCellInfo_type *pCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(pCell);

    memset(pCell->lbCfg.idleModeInfo.ueDistributionRatio_caProfile, 0, sizeof(pCell->lbCfg.idleModeInfo.ueDistributionRatio_caProfile));
}

/* Manages the shutdown status of the system/CPC/gNB/cell.

 * Shutdown Cell Condition :
 * 1) System/cpc shutdown or
 * 2) gNB shutdown in which the Cell is or
 * 3) Cell switchingOffOngoing is TRUE
 */

bool FnVCCB_IsTheCellConditionForOnDemandHo(uint16_t cellNum)
{
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    // System
    if (ENV->system_admin_state == admin_shuttingdown)
        return true;

    // CPC
    if (ENV->cpc_admin_state == admin_shuttingdown)
        return true;

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    VCCB_CHECK_E_RANGE_AND_VAL(pCell->gnbNum, MAX_GNB_PER_SYS, false);

    // GNB
    const VccbGnbInfo_type *const pGnb = &GNBINFO[pCell->gnbNum];
    if (pGnb->gnb_admin_state == admin_shuttingdown)
        return true;

    // Cell
    if (pCell->switchingOffOngoing == TRUE)
        return true;

    return false;
}

bool FnVCCB_IsEligibleCellForOnDemandHO(uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    onDemandLoadDistInfo_type *pCtrl = &ENV->onDemandLoadDistCtrl;

    // EQUIP
    if (pCell->status != EQUIP)
    {
        return false;
    }

    // Range
    if (pCell->gnbNum >= MAX_GNB_PER_SYS)
    {
        return false;
    }

    // Check service state of Cell - CELL_INS and CELL_BARRED are OK
    if (CELL_OOS == pCell->serviceState)
    {
        /* Init timer info */
        INIT_CELL_TIME_FOR_ODF(pCtrl, cellNum);
        return false;
    }

    if (true != FnVCCB_IsTheCellConditionForOnDemandHo(cellNum))
    {
        INIT_CELL_TIME_FOR_ODF(pCtrl, cellNum);
        return false;
    }

    // If there is at least 1 NSA UE attached before switchOffOngoing state skip checking if cell uses onDemandHoSupport.
    if ((pCell->cfg.assignedEnDcCellCallCountForStat - pCell->cfg.assignedSwitchOffOngoingEnDcCellCallCount) > 0) // FGR-CC5000 FR3310 & FR3530
    {
        // SgNB initiated SN Release Procedure will be triggered for NSA UEs.
        return true;
    }

    // Although ODHO is not supported, if cell is fr2 and then continue to check
    // more whether nrdc-sn calls are exist.
    if (!IS_SUPPORT_ODHO(cellNum) && FnVCCB_IsFr1Freq(pCell->ssbArfcn))
    {
        INIT_CELL_TIME_FOR_ODF(pCtrl, cellNum);
        return false;
    }

    return true;
}

void FnVCCB_UpdateTimeInfoForOnDemandMobilityCell(uint16_t cellNum, struct timespec currTime)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    onDemandLoadDistInfo_type *pCtrl = &ENV->onDemandLoadDistCtrl;
    const onDemandMobilityControlInfo_type *pCtrlCell = NULL;
    long diffTime;

    VCCB_PRINT_SA_ON_DEMAND_HO("[ODF_HO] %s cellNum(%d) !! \n", __func__, cellNum);

    // Update shutdown time
    diffTime = VLIB_getTickDifferenceWithTime(pCtrl->shutdownCellInfo[cellNum].shutdownTime, currTime);
    if ((IS_INITIAL_SHUTDOWN_TIME(pCtrl->shutdownCellInfo[cellNum].shutdownTime)) || (diffTime == 0))
    {
        // update shutdownTime
        pCtrl->shutdownCellInfo[cellNum].shutdownTime = currTime;

        /* init expired flag */
        pCtrl->shutdownCellInfo[cellNum].expiredFlag = false;
    }
    else
    {
        pCtrlCell = &pCell->onDemandHoInfo;

        // update call release timer expired
        if (pCtrl->shutdownCellInfo[cellNum].expiredFlag == false)
        {
            if (diffTime > pCtrlCell->timerForCallRelease)  // 5000 ms by default
            {
                pCtrl->shutdownCellInfo[cellNum].expiredFlag = true;
                VCCB_PRINT_SA_ON_DEMAND_HO("[ODF_HO] timerForCallRelease expired cell(%d) !! \n", cellNum);
            }
        }
    }
}

int16_t FnVCCB_MainUpdateOnDemandMobilityControl(struct timespec currTime)
{
    AUTO_TRACE_FUNC;

    onDemandLoadDistInfo_type *pCtrl = &ENV->onDemandLoadDistCtrl;
    uint16_t cellIdx, cnt = 0;
    bool run = false;
    const uint32_t maxCellNum = MAX_CELL_NUM_VCCB;

    // check all cells if shutting down
    for (cellIdx = 0; cellIdx < maxCellNum; cellIdx++)
    {
        // Mgmt Target Cells for ODF HO
        if (true != FnVCCB_IsEligibleCellForOnDemandHO(cellIdx)) continue;

        // Update shutdown time
        FnVCCB_UpdateTimeInfoForOnDemandMobilityCell(cellIdx, currTime);

        // shutdownCell supporting on-demand mobility
        run = true;
        cnt++;  // for debugging
    }

    // there is no shutdown cell
    if (run == false)
    {
        FnVCCB_MainInitOnDemandMobilityControl();
        MACRO_CHECK_AND_DETACH(VCCB_ODHO_LOAD_DIST_TIMER);

        VCCB_PRINT_SA_ON_DEMAND_HO("[ODF_HO] Finished - No more shutdown cells!! \n");
        return BREAK;
    }

    VCCB_PRINT_SA_ON_DEMAND_HO("[ODF_HO] %s cell count:%d \n", __func__, cnt);

    if (!IS_TIMER_VALID(VCCB_ODHO_LOAD_DIST_TIMER))  // No running timer
    {
        // Start Main Load Distribution timer
        VLIB_AttachTimerCore(&VCCB_ODHO_LOAD_DIST_TIMER, 0, timInternalLoadDistForOnDemandHo_id, 0, 0,
            (int)VCCB_ODHO_LOAD_DIST_TIMER_VAL, VCCB_NONUE_ADDR.MdsPort, VCCB_TIMER_PERIODIC, 0);

        VCCB_PRINT_SA_ON_DEMAND_HO(
            "[ODF_HO] LoadDistForOnDemandHo Timer(%d ms) Start !! \n", VCCB_ODHO_LOAD_DIST_TIMER_VAL);
    }

    // update lastExpiredTime to currTime
    pCtrl->lastExpiredTime = currTime;

    // exit If CPC is HAS_STANDBY
    // P220531-00135 fixed
    if (e_VCCB_ACPF_VNF == VCOM_getSystemType() && HAS_STANDBY == CFG->hasCpc.State)
    {
        return BREAK;
    }

    return GOOD;
}

bool FnVCCB_CheckNeedToCallRelease(uint8_t opMode, bool timerExpired)
{
    AUTO_TRACE_FUNC;

    switch (opMode)
    {
        case ODHO_FORCED_HO_AND_TIMER_BASE_RELEASE:
        case ODHO_TIMER_BASE_RELEASE:
            if (timerExpired == true)
            {
                return true;
            }
            break;
        default:
            break;
    }

    return false;
}

bool FnVCCB_CheckNeedToMeasConfForOndemandHO(callInfo_type *ptCi, uint8_t opMode, bool timerExpired)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    // If already selected as on-demand MeasConfig target UE
    if (ptCi->onDemandInfo.targetUe == TRUE)
    {
        return false;
    }

    switch (opMode)
    {
        case ODHO_FORCED_HO_AND_TIMER_BASE_RELEASE:
            if (timerExpired == false)
            {
                return true;
            }
            break;

        case ODHO_FORCED_HO:
            return true;

        default:
            break;
    }

    return false;
}

int16_t FnVCCB_IsHighPriorityCall(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (ptCi->ueInfo.establishmentCause == ci_highPriorityAccess)
    {
        VCCB_PRINT_CALL_DATA(ptCi, "%s The call is confirmed as a high priority call.\n", __func__);
        return TRUE;
    }

    return FALSE;
}

bool FnVCCB_IsAllowedEmergHpaUeForOnDemandHo(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, false);

    const int16_t isEmergencyCall = VCCM_CheckEmergencyCall(ptCi);
    const int16_t isHighPriorCall = FnVCCB_IsHighPriorityCall(ptCi);

    // allowed in case of neither emergency nor high priority call, normal call
    if (isEmergencyCall == FALSE && isHighPriorCall == FALSE)
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi, "[ODF_HO] UE is neither EmergencyCall nor HighPriorityCall\n");
        return true;
    }

    onDemandMobilityControlInfo_type &rOnDemandHoInfo = CELLINFO[cellNum].onDemandHoInfo;

    VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi,
        "[ODF_HO] cellNum:%d emergCall:%d hpaCall:%d includeEmergHpaOnOff:%d emergHpaMode:%d\n",
        cellNum, isEmergencyCall, isHighPriorCall, rOnDemandHoInfo.includeEmergHpaOnOff, rOnDemandHoInfo.emergHpaMode);

    if (rOnDemandHoInfo.includeEmergHpaOnOff == FALSE)
    {
        // UE Emergency/High Priority Call not a target UE
        return false;
    }

    switch (rOnDemandHoInfo.emergHpaMode)
    {
        case ODHO_HPA_ONLY:
            if (isHighPriorCall) return true;
            break;

        case ODHO_EMERG_ONLY:
            if (isEmergencyCall) return true;
            break;

        case ODHO_EMERG_AND_HPA:
            if (isEmergencyCall || isHighPriorCall) return true;
            break;

        default:
            break;
    }

    /* Can't be On Demand Target, return false */
    return false;
}

bool FnVCCB_IsAllowedUeForOnDemandHo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    /* Usage, state==STATE_Conn or STATE_DB, stateCmd==IdleCmd, if not return false */
    if ( (ptCi->usage != CI_use) || (ptCi->stateCmd != Idle_cmd) ||
         ((ptCi->state != STATE_Conn) && (ptCi->state != STATE_DB)) )
    {
        return false;
    }

    const uint16_t cellNum = ptCi->servCellNum;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, false);

    if (true != FnVCCB_IsTheCellConditionForOnDemandHo(cellNum))
    {
        return false;
    }

    if(E_CALLTYPE_NSA == ptCi->callType) // FGR-CC5000 FR3310
    {
        if (ptCi->bitFlag.ueAttachedToSwitchingOffOngoingCell == TRUE) // FGR-CC5000 FR3530
        {
            return false;
        }
        // SgNB initiated SN Release Procedure will be triggered.
        return true;
    }
    else if (IS_NRDC_SN(ptCi))  // FGR-CC5200:FR290
    {
        // SNRelease Procedure will be triggered.
        return true;
    }

    if (not IS_SUPPORT_ODHO(cellNum))
    {
        return false;
    }

    if (not FnVCCB_IsAllowedEmergHpaUeForOnDemandHo(ptCi, cellNum))
    {
        return false;
    }

    /* FallBack UE, don't select, return false */
    if (IS_FALLBACK_CASE(ptCi))
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi, "[ODF_HO] UE Fallback \n");
        return false;
    }

    /* forced restriction timer, if forced restrict is enable, return false */
    if (VHCM_isForcedHoRestriction(ptCi) == true)
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi, "[ODF_HO] UE while ForcedHoRestriction \n");
        return false;
    }

    /* On-Demand Mobility allowed, return TRUE */
    return true;
}

void FnVCCB_MainSelectUeForOnDemandMobility()
{
    AUTO_TRACE_FUNC;

    int threadId;
    uint32_t numCheckUePerPeriod = 0, callId, ueIndex = 0;
    uint32_t numSelectedUePerCell[MAX_CELL_PER_VNF] = {
        0,
    };
    bool releaseFlag = false, expiredFlag = false;
    enumOpModeForOnDemandMobility_type opMode;
    callInfo_type *ptCi = NULL;
    uint32_t ho_cnt = 0, redirect_cnt = 0;  // dbg
    uint32_t snRelCnt = 0;
    uint32_t endcRelCnt = 0;

    // For enhanced performance from function calls
    const uint8_t maxCallThreadId = MAX_CALL_THREAD_NUM_VCCB;
    const uint32_t maxNumUePerPeriod = MAX_NUM_ODHO_CHECK_UE_PER_PERIOD;
    const uint32_t maxCallNum = MAX_CALL_NUM_VCCB;
    const uint32_t maxCellNum = MAX_CELL_NUM_VCCB;
    const uint32_t maxNumUePerCell = MAX_NUM_ODHO_UE_PER_CELL;
    const uint32_t maxNumUePerThread = MAX_NUM_ODHO_UE_PER_THREAD;

    // VCCB_PRINT_CMD("[ODF_HO] %s \n", __func__); // odfho_dbg
    onDemandLoadDistInfo_type *pCtrl = &ENV->onDemandLoadDistCtrl;

    // Init targetUeList
    for (threadId = 0; threadId < maxCallThreadId; threadId++)
    {
        pCtrl->targetUeList[threadId].numUe = 0;
    }

    VccbCellInfo_type *const pCellBase = CELLINFO;

    // find UE from pCtrl->startUeIndex
    for (callId = pCtrl->startUeIndex;
         (callId < maxCallNum && numCheckUePerPeriod <= maxNumUePerPeriod); callId++)
    {
        // Get Call Info
        ptCi = FnVCCB_GetCallInUse(callId);
        if (NULL == ptCi) continue;  // Too much log from VALID_E_POINT_CHECK_CONTINUE MACRO

        // existing calls basis
        numCheckUePerPeriod++;

        // Cell Number
        const uint16_t cellNum = ptCi->servCellNum;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(cellNum, maxCellNum);

        // Thread
        const uint8_t myThreadId = ptCi->myThreadId;
        VCCB_CHECK_E_RANGE_AND_CONTINUE(myThreadId, maxCallThreadId);

        // The number of selected UEs in the UE Served Cell is over than threshold
        if (numSelectedUePerCell[cellNum] >= maxNumUePerCell)
        {
            continue;
        }

        // The number of selected UEs in current thread is over than threshold
        if (pCtrl->targetUeList[myThreadId].numUe >= maxNumUePerThread)
        {
            continue;
        }

        // Check UE is allowed to on-demand mobility
        if (FnVCCB_IsAllowedUeForOnDemandHo(ptCi) == false)
        {
            continue;
        }

        releaseFlag = false;
        if(E_CALLTYPE_NSA == ptCi->callType)
        {
            // FGR-CC5000 FR3310
            releaseFlag = true;
            endcRelCnt++;
        }
        else if (IS_NRDC_SN(ptCi))
        {
            // FGR-CC5200:FR290
            releaseFlag = true;
            snRelCnt++;
        }
        else
        {
            // Operation Mode
            opMode = pCellBase[cellNum].onDemandHoInfo.operationMode;
            expiredFlag = pCtrl->shutdownCellInfo[cellNum].expiredFlag;

            // Check if the UE is for timer based call release or meas. config
            // If timer based call release, set releaseFlag true.
            // If On-Demand Meas configuration, set releaseFlag false.
            // If not all, check the next UE.
            if (FnVCCB_CheckNeedToCallRelease(opMode, expiredFlag) == false)
            {
                if (FnVCCB_CheckNeedToMeasConfForOndemandHO(ptCi, opMode, expiredFlag) == false)
                {
                    continue;
                }

                ho_cnt++;
            }
            else
            {
                releaseFlag = true;
                redirect_cnt++;
            }
        }

        // Update UE Information
        ueIndex = pCtrl->targetUeList[myThreadId].numUe++;
        pCtrl->targetUeList[myThreadId].callId[ueIndex] = callId;
        pCtrl->targetUeList[myThreadId].releaseFlag[ueIndex] = releaseFlag;
        numSelectedUePerCell[cellNum]++;
    }

    /* Update startUeIndex */
    pCtrl->startUeIndex = (callId >= maxCallNum) ? 0 : callId;

    if (ho_cnt || redirect_cnt || snRelCnt || endcRelCnt)
    {
        VCCB_PRINT_SA_ON_DEMAND_HO("[ODF_HO] UE Count: HO(%u) Rd(%u) SNRelCnt(%u) endc(%u) numCheckUe(%u) startUeIndex(%u)\n",
            ho_cnt, redirect_cnt, snRelCnt, endcRelCnt, numCheckUePerPeriod, pCtrl->startUeIndex);
    }

    VIIL_sendInternalTriggerOnDemandHoCall();

    return;
}

void FnVCCB_MainHandleOnDemandMobility(void)
{
    AUTO_TRACE_FUNC;

    /* Current Time */
    struct timespec currTime = tickGetMono();

    if (!IS_TIMER_VALID(VCCB_ODHO_LOAD_DIST_TIMER))  // If the timer is not attached
    {
        FnVCCB_MainInitOnDemandMobilityControl();
    }
    else
    {
        /* Check ldTimerInMain timer is not abnormal */
        if (FnVCCB_MainCheckValidationForLdTimer(currTime) == false)
        {
            return;
        }
    }

    // Update the shutdown status of all cells.
    if (FnVCCB_MainUpdateOnDemandMobilityControl(currTime) == BREAK)
    {
        return;
    }

    /* UE Selection for On-Demand Mobility */
    FnVCCB_MainSelectUeForOnDemandMobility();

    return;
}

bool FnVCCB_IsOnDemandIntraNrRedirectionApplicable(callInfo_type *ptCi, const measurementObjectNRBaseDb_type *pMeasObjNr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pMeasObjNr, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, false);

    // If not used
    if (CI_use != pMeasObjNr->usage)
    {
        return false;
    }

    // exclude freq which is same with serving cell's
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    // Check OnDemandHo is allowed, if not
    if (TRUE != pMeasObjNr->supportOnDemandMobility)
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(
            ptCi, "%s ssbFrequency(%u) Not supportOnDemandMobility\n", __func__, pMeasObjNr->ssbFrequency);
        return false;
    }

    if (pCell->ssbArfcn == pMeasObjNr->ssbFrequency)
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(
            ptCi, "%s ssbFrequency(%u) same to serving cell freq \n", __func__, pMeasObjNr->ssbFrequency);
        return false;
    }

    // Check SaCapable, if not
    if (TRUE != fnVCCB_IsSaCapableMO(ptCi, pMeasObjNr))
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(
            ptCi, "%s Not SaCapable ssbFrequency(%u) saCapable(%d) redcapAccessAllowed(%d)\n", __func__,
            pMeasObjNr->ssbFrequency, pMeasObjNr->saCapable, pMeasObjNr->redcapAccessAllowed);
        return false;
    }

    // Check not allowed frequency (n77 extended band on 24A) in restricted-ssb-frequencies
    if (!FnVCCB_IsSsbAllowed(*ptCi, pMeasObjNr->ssbFrequency))
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(
            ptCi, "%s Restricted ssbFrequency(%u) restricted-ssb-frequencies!\n", __func__, pMeasObjNr->ssbFrequency);
        return false;
    }

    // Check UE Supported band(+MFBI), if not
    if (0 == VCCB_GetMoNrBandForUe(ptCi, pMeasObjNr))
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(
            ptCi, "%s pMeasObjNr->ssbFrequency(%u) Not Supported band \n", __func__, pMeasObjNr->ssbFrequency);
        return false;
    }

    return true;
}

bool FnVCCB_IsOnDemandInterRatRdApplicable(callInfo_type *ptCi, const measurementObjectEUTRABaseDb_type *pMeasObjEutra, uint32_t *pEarfcn)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pMeasObjEutra, false);
    VALID_E_POINT_CHECK_RET_VAL(pEarfcn, false);

    // if not used
    if (CI_use != pMeasObjEutra->usage)
    {
        return false;
    }

    // Check UE Supported band(+MFBI), if not
    if (!VCCB_GetMoEutraBandForUe(ptCi, pMeasObjEutra, pEarfcn))
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(
                ptCi, "[ODF_HO] pMeasObjEutra->carrierFreq(%u) Not Supported band \n", pMeasObjEutra->carrierFreq);
        return false;
    }

    // Check OnDemandHo is allowed, if not
    if (TRUE != pMeasObjEutra->supportOnDemandMobility)
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi, "[ODF_HO] pMeasObjEutra->carrierFreq(%u) Not support OnDemand \n",
                pMeasObjEutra->carrierFreq);
        return false;
    }

    return true;
}


enumRatForOnDemandMobility_type FnVCCB_GetPreferRatTypeForOnDemandMobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, ODHO_PREFER_NR);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, ODHO_PREFER_NR);

    uint16_t qosIdx;
    enumRatForOnDemandMobility_type type = ODHO_PREFER_NR;

    for (qosIdx = 0; qosIdx < MAX_QOS_FLOW_PER_CALL; ++qosIdx)
    {
        if (CI_use == ptCi->qosFlow[qosIdx].usage &&
                VONR_5QI == ptCi->qosFlow[qosIdx].qosParam.nonDyna.fiveQi)
        {
            VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi, "[ODF_HO] Voice UE !! \n");
            break;
        }
    }

    if (qosIdx < MAX_QOS_FLOW_PER_CALL)
    {  // Voice Type
        type = ODHO_CELL_PREFER_RAT_FOR_VOICECALL(ptCi->servCellNum);
    }
    else
    {  // Data Type
        type = ODHO_CELL_PREFER_RAT_FOR_DATACALL(ptCi->servCellNum);
    }

    return type;
}

int16_t FnVCCB_SelectTargetCarrierForOnDemandRedirection(callInfo_type *ptCi, uint32_t *moIdx, enumMeasRatType *ratType, uint32_t *overlappedCarrierFreq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    const uint32_t maxCandidateBuffSize = MAX(MAX_NR_OF_OBJECT_ID_DB, MAX_NR_OF_OBJECTEUTRA_ID_DB);

    uint16_t idx;
    uint8_t numCandidate = 0, selectedIdx = 0;
    const measurementObjectNRBaseDb_type *pMeasObjNr = NULL;
    const measurementObjectEUTRABaseDb_type *pMeasObjEutra = NULL;
    uint32_t candidateListIdx[maxCandidateBuffSize];
    uint32_t mappedEarfcnCandidateList[maxCandidateBuffSize];
    uint32_t earfcn = 0;
    enumMeasRatType selectedRat = measRatUnknown;

    memset(candidateListIdx, 0x00, sizeof(candidateListIdx));
    memset(mappedEarfcnCandidateList, 0x00, sizeof(mappedEarfcnCandidateList));

    // Select Target Carrier by Preferred RAT
    enumRatForOnDemandMobility_type preferRat = FnVCCB_GetPreferRatTypeForOnDemandMobility(ptCi);

    VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi, "[ODF_HO] %s preferRat(%d NR:0) \n", __func__, preferRat);

    // NR Only or BOTH(High NR priority)
    if (preferRat == ODHO_PREFER_NR || preferRat == ODHO_PREFER_BOTH)
    {
        // Find on-demand mobility allowed NR carrier from CELL MeasObjectNR DB, not call DB
        for (idx = 0; idx < MAX_NR_OF_OBJECT_ID_DB; idx++)
        {
            pMeasObjNr = &pCell->measurementsData.measurementObjectsNRDb[idx].base;

            if (false == FnVCCB_IsOnDemandIntraNrRedirectionApplicable(ptCi, pMeasObjNr))
            {
                continue;
            }

            // Find supportable NR carrier, add candidateList, store measObjIndex
            candidateListIdx[numCandidate++] = idx;
        }

        if (numCandidate > 0)
        {
            selectedRat = measRatNr;
        }
    }

    // EUTRA Only or BOTH(Add if not selected in NR)
    if (selectedRat == measRatUnknown && (preferRat == ODHO_PREFER_EUTRA || preferRat == ODHO_PREFER_BOTH))
    {
        // Protection Code
        numCandidate = 0;

        // Find on-demand mobility allowed EUTRA from CELL MeasObjectNR DB, not call DB
        for (idx = 0; idx < MAX_NR_OF_OBJECTEUTRA_ID_DB; idx++)
        {
            pMeasObjEutra = &pCell->measurementsData.measurementObjectsEUTRADb[idx].base;

            if (false == FnVCCB_IsOnDemandInterRatRdApplicable(ptCi, pMeasObjEutra, &earfcn))
            {
                continue;
            }

            // Find supportable EUTRA carrier, add candidateList, store measObjIndex
            candidateListIdx[numCandidate] = idx;

            // Store overrapping earfcn
            mappedEarfcnCandidateList[numCandidate] = earfcn;

            numCandidate++;
        }

        if (numCandidate > 0)
        {
            selectedRat = measRatEutra;
        }
    }

    if (measRatUnknown == selectedRat)
    {
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi, "[ODF_HO] call release required : no target for redirection \n");
        return ERROR;
    }

    selectedIdx = 0;
    if (numCandidate > 1)
    {
        // If multiple redirected carriers to be selected, random selection
        selectedIdx = (uint8_t)FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, numCandidate);
        VCCB_CHECK_E_RANGE_AND_RETURN(selectedIdx, maxCandidateBuffSize);
    }

    // get measobjIdx & frequency
    *moIdx = candidateListIdx[selectedIdx];
    *overlappedCarrierFreq = mappedEarfcnCandidateList[selectedIdx];
    *ratType = selectedRat;

    return GOOD;
}

int16_t FnVCCB_ReleaseCallForOnDemandRedirection(callInfo_type *ptCi, uint32_t moIdx, enumMeasRatType selectedRat, uint32_t overlappedCarrierFreq)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    int16_t status = ERROR;
    const measurementObjectNRBaseDb_type *pMeasObjNr = NULL;
    const measurementObjectEUTRABaseDb_type *pMeasObjEutra = NULL;

    // Set Redirection Info by selected target carrier
    ptCi->redirectionInfo.actualRedirectionMethod = BLIND_REDIR_ONLY;

    if (measRatNr == selectedRat)
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(moIdx, MAX_NR_OF_OBJECT_ID_DB);

        ptCi->redirectionInfo.redirType = INTRA_RAT_REDIRECTION;
        pMeasObjNr = &pCell->measurementsData.measurementObjectsNRDb[moIdx].base;
        VLIB_CreateRedirectionInfoNrFromMeasObjectDb(&ptCi->redirectionInfo.rat.nr, pMeasObjNr);

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "NR Redirection Triggered ssbFrequency:%u moIdx:%d by On-Demand HO \n",
                ptCi->redirectionInfo.rat.nr.ssbFrequency, moIdx);
    }
    else
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(moIdx, MAX_NR_OF_OBJECTEUTRA_ID_DB);

        ptCi->redirectionInfo.redirType = INTER_RAT_REDIRECTION;
        pMeasObjEutra = &pCell->measurementsData.measurementObjectsEUTRADb[moIdx].base;
        VLIB_CreateRedirectionInfoEutraFromMeasObjectDb(
            &ptCi->redirectionInfo.rat.eutra, pMeasObjEutra, overlappedCarrierFreq);

        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "EUTRA Redirection Triggered carrierFreq:%u moIdx:%d  by On-Demand HO \n",
                ptCi->redirectionInfo.rat.eutra.overlappedCarrierFreq, moIdx);
    }

    // Release with redirection info
    status = VCCM_RedirectionByRRCReleaseTrigger(ptCi, InternalTriggerOnDemandHo_id);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "ERROR! VCCM_RedirectionByRRCReleaseTrigger OnDemand Rat:%d moIdx:%d\n",
            selectedRat, moIdx);

    ptCi->redirectionInfo.onDemandRedirect = TRUE;  // RETAIN_STAT_HO_21C

    return status;

}

int16_t FnVCCB_TriggerRedirectionForOnDemandMobility(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = ERROR;
    enumMeasRatType selectedRat = measRatUnknown;
    uint32_t moIdx = 0, overlappedCarrierFreq;

    status = FnVCCB_SelectTargetCarrierForOnDemandRedirection(ptCi, &moIdx, &selectedRat, &overlappedCarrierFreq);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "[ODF_HO] No target frequency for redirection\n");

    status = FnVCCB_ReleaseCallForOnDemandRedirection(ptCi, moIdx, selectedRat, overlappedCarrierFreq);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "[ODF_HO] ERROR! Redirection moIdx:%d rat:%d freq:%d \n",
                        moIdx, selectedRat, overlappedCarrierFreq);

    return status;
}

void FnVCCB_HandleOnDemandMobility(message_type *ptAll, uint8_t threadId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptAll);
    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    callInfo_type *ptCi = NULL;
    onDemandLoadDistInfo_type *pCtrl = &ENV->onDemandLoadDistCtrl;
    uint32_t callId, numUe;
    uint16_t idx;
    int16_t status = GOOD;

    //    msgInternalTriggerOnDemandHoMainToCall_type *ptMsg = (msgInternalTriggerOnDemandHoMainToCall_type *)ptAll;
    //    logShmNonUeIntMsg(RX_MSG, BLK_VCCB, InternalTriggerOnDemandHoMainToCall_id,
    //    sizeof(msgInternalTriggerOnDemandHoMainToCall_type),
    //            (uint8_t *)ptMsg, (SHMLOG_INVALID_APID | SHMLOG_INVALID_APUEID));

    // Copy UE list to local buffer
    onDemandTargetUeListInfo_type ueList, *pUeList = &ueList;
    *pUeList = pCtrl->targetUeList[threadId];

    numUe = MIN(pCtrl->targetUeList[threadId].numUe, MAX_NUM_ODHO_UE_PER_THREAD);
    VCCB_PRINT_SA_ON_DEMAND_HO("[ODF_HO] %s threadId(%d) number of UEs(%d)!! \n", __func__, threadId, numUe);

    for (idx = 0; idx < numUe; idx++)
    {
        // Get callId from callIdList and range check
        callId = pUeList->callId[idx];

        // Check range
        if (callId >= MAX_CALL_NUM_VCCB)
        {
            VCCB_PRINT_SA_ON_DEMAND_HO("[ODF_HO] %s callId:%d ERROR!! \n", __func__, callId);
            continue;
        }

        // Get ptCi
        ptCi = FnVCCB_GetCallInUse(callId);
        if (ptCi == NULL)
        {
            VCCB_PRINT_SA_ON_DEMAND_HO("[ODF_HO] %s callId:%d Not CI_use !! \n", __func__, callId);
            continue;
        }

        // Check myThreadId :: exceptional case
        if (ptCi->myThreadId != threadId)
        {
            VCCB_PRINT_SA_ON_DEMAND_HO("[ODF_HO] %s callId:%d ptCi->myThreadId:%d threadId:%d ERROR !! \n", __func__,
                callId, ptCi->myThreadId, threadId);
            continue;
        }

        // Range check :: ue served cell num
        if (ptCi->servCellNum >= MAX_CELL_NUM_VCCB)
        {
            VCCB_PRINT_SA_ON_DEMAND_HO(
                "[ODF_HO] %s callId:%d wrong Cell:%d !! \n", __func__, callId, ptCi->servCellNum);
            continue;
        }

        // Check allowed UE
        if (FnVCCB_IsAllowedUeForOnDemandHo(ptCi) == false)
        {
            continue;
        }

        // When selecting the UE, Main Task specifies the trigger type(release or measReconfig). Call task operates as
        // specified trigger type
        if (pUeList->releaseFlag[idx] == true)
        {
            if(E_CALLTYPE_NSA == ptCi->callType) //SgNB-initiated SN release
            {   // FGR-CC5000 FR3310
                status = VLIB_SgNBInitiatedSnReleaseDueToSwitchOff(ptCi, InternalTriggerOnDemandHoMainToCall_id);
                if(GOOD != status)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_SgNBInitiatedSnReleaseDueToSwitchOff failure\n");
                }
                continue;
            }
            else if (IS_NRDC_SN(ptCi)) // SN-initiated SN release procedure
            {  // FGR-CC5200:FR290
                MACRO_CALL_FAULT_SAVE(InternalTriggerOnDemandHoMainToCall_id, CauseCpInternalOMIntervention);
                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerSwitchOffOngoing;
                if (GOOD != VCCB_CALL_RELEASE_TRIGGER(ptCi))
                {
                    VCCB_PRINT_CALL_ERROR(
                        ptCi, "%s VCCB_CALL_RELEASE_TRIGGER by On-Demand Offloading Error!!\n", __func__);
                }
                continue;
            }
            else  // SA(MN) release procedure
            {
                // Trigger Redirection or Call Release
                status = FnVCCB_TriggerRedirectionForOnDemandMobility(ptCi);
                if (status != GOOD)
                {
                    // VCCB_PRINT_CALL_INFORMATIVE(ptCi, "triggerRedirectionForOnDemandMobility ERROR !! \n");
                    INCREASE_LOCAL_HO_STAT(threadId, triggerOnDemandRedirectionFail);
                }
                else
                {
                    // VCCB_PRINT_CALL_INFORMATIVE(ptCi, "triggerRedirectionForOnDemandMobility SUCCESS !! \n");
                    INCREASE_LOCAL_HO_STAT(threadId, triggerOnDemandRedirection);
                }
            }
        }
        else
        {
            // Trigger MeasReconfig
            if (ptCi->onDemandInfo.targetUe == FALSE)  // Not triggered ever
            {
                // Set onDemandTargetUe Flag
                ptCi->onDemandInfo.targetUe = TRUE;
                ptCi->onDemandInfo.prevTargetUe = TRUE;

                // Trigger MeasReconfig to add on-demand measurement configuration
                status = VCCM_TriggerMeasReconfig(ptCi);
                if (status != GOOD)
                {
                    VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi, "%s VCCM_TriggerMeasReconfig ERROR !! \n", __func__);
                    INCREASE_LOCAL_HO_STAT(threadId, triggerOnDemandMeasReconfigFail);
                }
                else  // odfho_dbg
                {
                    VCCB_PRINT_CALL_SA_ON_DEMAND_HO(ptCi, "%s VCCM_TriggerMeasReconfig SUCCESS !! \n", __func__);
                    INCREASE_LOCAL_HO_STAT(threadId, triggerOnDemandMeasReconfig);
                }
            }
        }

        if (status != GOOD)
        {
            ptCi->onDemandInfo.release = TRUE;  // RETAIN_STAT_HO_21C

            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Call Release in On-Demand HO \n");

            // Call Release
            if (VCCB_CALL_RELEASE_TRIGGER(ptCi) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "%s VCCB_CALL_RELEASE_TRIGGER by On-Demand HO Error!!\n", __func__);
            }
        }
    }

    return;
}

bool VCCM_Is_DrbStatusAddCondition(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, false);

    if (ptDi->drbStatus == S_Setup)
    {
        if (IS_MRDC_MN(ptCi))
        {
            if (FnVCCB_IsSnTermScgPerDRB(ptCi, ptDi, request_bearerType))
            {
                return false;
            }
        }

        return true;
    }

    if ((ptDi->drbStatus == S_Idle) && ((ptCi->stateCmd == IntraRatHO_cmd) || (ptCi->stateCmd == RRCResume_cmd)))
    {
        return true;
    }
    else if ((RrcReestablish_cmd == ptCi->stateCmd) && (GOOD == VLIB_IsCommonValidStateOfPduQosDrb(ptDi->drbStatus)))
    {
        if(IS_SUPPORT_DRB_PARTIAL_FOR_RRE_DURING_HO(ptCi, ptDi))
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Skip FnVCCB_FillF1_DrbToBeSetupList drb:%d isPartialDrbForRreDuringHo(%llu)i F1Partial:%u, RelAmf:%u !\n",
                ptDi->dRBId, 1ULL * ptCi->bitFlag.isPartialDrbForRreDuringHo, ptDi->needToSendTxStopByF1Partial_intraGnbOnlyUsed, ptDi->needToReleaseAmfByF1Partial_intraGnbOnlyUsed);

            return false;
        }

        return true;
    }

    // in partial InterGNB RRE Case drbStatus is S_Release
    // if (ptDi->drbStatus == S_Release && ptCi->stateCmd == RrcReestablish_cmd)
    // {
    //     return false;
    // }

    return false;
}

// void VLIB_EplmnsFromCompressedHoRestrictInfo(hoRestrictInfo_type *pTgt, hoRestrictInfoCompressed_type *pSrc)
// {
//     AUTO_TRACE_FUNC;
//
//     uint16_t loop = 0;
//
//     VALID_E_POINT_CHECK_VOID(pTgt);
//     VALID_E_POINT_CHECK_VOID(pSrc);
//
//     pTgt->numEplmn = pSrc->numEplmn;
//
//     for (loop = 0; loop < MIN(pSrc->numEplmn, X2_maxnoofEPLMNs); loop++)
//     {
//         // VCCB_PRINT_CMD("[5GC_MRL] %s ePlmn[%d]:%02X/%02X \n", __func__, loop, pSrc->ePlmn[loop].s2.mcc,
//         // pSrc->ePlmn[loop].s2.mnc);
//         pTgt->ePlmn[loop] = pSrc->ePlmn[loop];
//     }
// }

void FnVCCB_UpdateOnDemandHoFlag(callInfo_type *ptCi)  
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t reportType = ptCi->saHoMrQueueInfo.reportType;
    uint8_t reportPurpose = ptCi->saHoMrQueueInfo.reportPurpose;

    if (IS_REPORT_CGI_FOR_HANDOVER(ptCi))
    {
        reportType = ptCi->anrInfo.reportType;
        reportPurpose = ptCi->anrInfo.reportPurpose;
    }

    if ((reportType == measReport_A5 && reportPurpose == a5Purpose_intraNrOnDemandHandover) ||
        (reportType == measReport_B2Eutra && reportPurpose == b2Purpose_eutraOnDemandHandover))
    {
        ptCi->onDemandInfo.hoTriggered = true;
        VCCB_PRINT_CALL_SA_ON_DEMAND_HO(
            ptCi, "[ODF_HO] On-Demand HO Triggered. %s\n", (IS_REPORT_CGI_FOR_HANDOVER(ptCi) ? "ReportCgi" : ""));
    }
}

void FnVCCB_UpdateUstmHoFlag(callInfo_type *ptCi, StartSaHandoverDb& hoInputDb)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    const auto reportType = hoInputDb.getReportType();
    const auto reportPurpose = hoInputDb.getReportPurpose();

    if (FnVCCB_USTM_IsUstmNrReportTypePurpose(reportType, reportPurpose))
    {
        ptCi->ustmInfo.intraNrHandoverTriggered = true;
        VCCB_PRINT_LOG_USTM(ptCi, "USTM NR HO Triggered. %s\n", (IS_REPORT_CGI_FOR_HANDOVER(ptCi) ? "ReportCgi" : ""));
    }
    else if (FnVCCB_USTM_IsUstmEutraReportTypePurpose(reportType, reportPurpose))
    {
        ptCi->ustmInfo.interRatHandoverTriggered = true;
        VCCB_PRINT_LOG_USTM(ptCi, "USTM EUTRA HO Triggered. %s\n", (IS_REPORT_CGI_FOR_HANDOVER(ptCi) ? "ReportCgi" : ""));
    }
}

void FnVCCB_UpdateForcedMobilityHoFlag(callInfo_type *ptCi, StartSaHandoverDb& hoInputDb)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    FnVCCB_UpdateOnDemandHoFlag(ptCi);
    FnVCCB_UpdateUstmHoFlag(ptCi, hoInputDb);
}

void FnVCCB_InitOnDemandHoLoadParam(void)
{
    AUTO_TRACE_FUNC;

    MAX_NUM_ODHO_UE_PER_CELL = DEFAULT_NUM_ODHO_UE_PER_CELL;
    MAX_NUM_ODHO_UE_PER_THREAD = DEFAULT_NUM_ODHO_UE_PER_THREAD;
    VCCB_ODHO_CHECK_UE_RATIO = DEFAULT_VCCB_ODHO_CHECK_UE_RATIO;
    VCCB_ODHO_LOAD_DIST_TIMER_VAL = DEFAULT_VCCB_ODHO_LOAD_DIST_TIMER_VAL;
}

unsigned int FnVCCB_GetRandomValue(const char *ptFunc, const uint16_t gnbNum, const int maxRangeCount)
{
    AUTO_TRACE_FUNC;

    unsigned int rtValue = UINT_MAX;

    VALID_E_POINT_CHECK_RET_VAL(ptFunc, UINT_MAX);
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, UINT_MAX);

    VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];

    // rand_r() returns a pseudo-random integer in the range [0, RAND_MAX(INT_MAX)].
    int value = rand_r(&pGnb->randSeed);
    if (value < 0)
    {
        VCCB_PRINT_ERROR(
            "[Warning][%s] A negative number was returned from the rand_r API. Change it to an absolute value. (%d)\n",
            ptFunc, value);
        value = abs(value);  // This code does not run, but is written for protection. Example: -50 -> 50.
    }

    switch (maxRangeCount)
    {
        case INT_MIN ... 0:  // -2147483648 ~ 0
            VCCB_PRINT_ERROR(
                "[Error][%s] In order to perform Modular operation, MaxRange value greater than 0 must be requested. "
                "(%d)\n",
                ptFunc, maxRangeCount);
            break;

        case 1 ... RAND_MAX:
            value = value % maxRangeCount;
            if (value >= maxRangeCount)
            {
                rtValue = (unsigned int)(maxRangeCount - 1);  // '1 .. RAND_MAX' -> '0 .. (RAND_MAX - 1)'
                VCCB_PRINT_ERROR(
                    "[Warning][%s] Modular operation behaved differently than intended. Use the largest value. (%d -> "
                    "%u)\n",
                    ptFunc, value, rtValue);
            }
            else
            {
                rtValue = (unsigned int)value;
            }
            break;
        default:
            VCCB_PRINT_ERROR(
                "[Warning][%s] The maximum range of Random Value has been exceeded. VCCB can only select from 0 to "
                "%d. (%d)\n", ptFunc, RAND_MAX, maxRangeCount);
            break;
    }

    return rtValue;
}

int16_t FnVCCB_FindActionQueueIndex(callInfo_type *ptCi, uint64_t actionBitFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t loop = 0;
    uint64_t bitFlag = 0;

    for (loop = 0; loop < ACTION_QUEUE_SIZE; loop++)
    {
        bitFlag = (uint64_t)1 << ptCi->actionQueue[loop];

        if (bitFlag & actionBitFlag)
        {
            return loop;
        }
    }

    return ERROR;
}

int16_t FnVCCB_InterGnbRanPaging_GetMessage(
    callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack, enqueuedAction actionInQueue)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINTER_CHECK_FOR_STATE_FUNC_ERROR(ptCi, ptAll, ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status = GOOD;

    /* check message id before DEQUEUE */
    status = MsgQueueManager::getInstance().getEnqueuedMsgWithAction(*ptCi, *ptAll, actionInQueue);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "getEnqueuedMsgWithAction ERROR!!\n");  // there's no message queue map
    VCCB_RETURN_ON_CALL_NBREAK(
        ptCi, status, "getEnqueuedMsgWithAction BREAK!!\n");  // there's no message with actionInQueue

    status = VCCB_GetMsgUnpack_checkMsgId(ptAll, ptUnpack, ptCi->myThreadId);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCB_GetMsgUnpack_checkMsgId ERROR!!\n");

    if (NG_PDUSessionResourceSetupRequest_id != ptUnpack->msgId &&
        NG_PDUSessionResourceModifyRequest_id != ptUnpack->msgId &&
        NG_PDUSessionResourceReleaseCommand_id != ptUnpack->msgId &&
        NG_UEContextModificationRequestAmfAll_id != ptUnpack->msgId &&
        NG_DownlinkNASTransportAmfAll_id != ptUnpack->msgId)
    {
        return ERROR;
    }

    /* DEQUEUE from message queue */
    status = MsgQueueManager::getInstance().dequeueMsgQueueMap(ptCi, ptAll, actionInQueue);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "dequeueMsgQueueMap ERROR!!\n");

    return GOOD;
}

// [FGR-MC1016] If inter-gNB RAN paging (triggered by UE associated signaling from AMF) occurs,
// source gNB would be released after resume procedure is completed,
// so enqueued messages should be replied to AMF as failure in advance.
int16_t FnVCCB_InterGnbRanPaging_HandleMessageQueue(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

#define BACKUP_PDU_QOS_CONFIG_DATA()                                                               \
    {                                                                                              \
        memcpy(localPduSess, ptCi->pduSess, sizeof(callPDUSessInfo_type) * MAX_PDU_SESS_PER_CALL); \
        memcpy(localQosFlow, ptCi->qosFlow, sizeof(qosFlowInfo_type) * MAX_QOS_FLOW_PER_CALL);     \
    }
#define RESTORE_PDU_QOS_CONFIG_DATA()                                                              \
    {                                                                                              \
        memcpy(ptCi->pduSess, localPduSess, sizeof(callPDUSessInfo_type) * MAX_PDU_SESS_PER_CALL); \
        memcpy(ptCi->qosFlow, localQosFlow, sizeof(qosFlowInfo_type) * MAX_QOS_FLOW_PER_CALL);     \
    }

    int16_t status = GOOD;
    uint64_t actionBitFlag = 0;
    int16_t actionIndex = 0;

    message_type *ptAll = reinterpret_cast<message_type*>(&THREAD_INFO->call[ptCi->myThreadId].buf.rx);
    msgUnpack_type *ptUnpack = &THREAD_INFO->call[ptCi->myThreadId].buf.unpack.call.buff;

    uint16_t index = 0;
    uint16_t loop = 0;  // exit while
    //uint8_t pduStoreState = GOOD;
    //uint16_t numModifiedPdu = 0;

    //callPDUSessInfo_type localPduSess[MAX_PDU_SESS_PER_CALL];
    //qosFlowInfo_type localQosFlow[MAX_QOS_FLOW_PER_CALL];

    if (VCCB_FLAG_ON != ptCi->ranPagingInfo.dlDataFlag)
    {
        return GOOD;
    }

    actionBitFlag |= 1 << ENQUEUE_ACTION_PDU_SESSION;
    actionBitFlag |= 1 << ENQUEUE_ACTION_NGUECTX_MOD_REQ;
    actionBitFlag |= 1 << ENQUEUE_ACTION_DOWNLINK_NAS_TRANSPORT;

    while ((actionIndex = FnVCCB_FindActionQueueIndex(ptCi, actionBitFlag)) >= 0 && loop++ < ACTION_QUEUE_SIZE)
    {
        /* get message queue */
        status = FnVCCB_InterGnbRanPaging_GetMessage(ptCi, ptAll, ptUnpack, ptCi->actionQueue[actionIndex]);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_InterGnbRanPaging_GetMessage ERROR!!\n");
        VCCB_RETURN_ON_CALL_NBREAK(ptCi, status, "FnVCCB_InterGnbRanPaging_GetMessage BREAK!!\n");

        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerXnHandoverTriggered;

        /* DEQUEUE from action queue */
        for (index = (uint16_t)actionIndex; index < ACTION_QUEUE_SIZE - 1; index++)
        {
            ptCi->actionQueue[index] = ptCi->actionQueue[index + 1];
        }
        ptCi->actionQueue[ACTION_QUEUE_SIZE - 1] = ENQUEUE_NO_ACTION;

        switch (ptUnpack->msgId)
        {
            case NG_DownlinkNASTransportAmfAll_id:
            {
                status = VNIL_StoreNGAP_DownlinkNASTransport(ptCi, ptAll, ptUnpack);
                VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VNIL_StoreNGAP_DownlinkNASTransport ERROR!\n");
                break;
            }
            case NG_PDUSessionResourceSetupRequest_id:
            {
                FnVCCB_CollectPduQosFlowStat_ForRejectAll(ptCi, ptUnpack, PDU_MSG_COLLECT_STAT);
                int8_t isRejectAll = true;
                auto ngapSender = MsgNgapSender::createMessageSender(
                    ptCi, NG_PDUSessionResourceSetupResponse_id, &isRejectAll, ptUnpack, &ptCi->cause.ngCause);
                VALID_E_POINT_CHECK_ERROR(ngapSender);
                VCCB_RETURN_ON_CALL_ERROR(
                    ptCi, ngapSender->sendMsg(), "sendMsg(NG_PDUSessionResourceSetupResponse) ERROR!\n");
                break;
            }
            case NG_PDUSessionResourceModifyRequest_id:
            {
                FnVCCB_CollectPduQosFlowStat_ForRejectAll(ptCi, ptUnpack, PDU_MSG_COLLECT_STAT);
                int8_t isRejectAll = true;
                uint8_t forcelySuccessFlag = VCCB_FLAG_OFF;
                auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_PDUSessionResourceModifyResponse_id,
                    &isRejectAll, ptUnpack, &ptCi->cause.ngCause, &forcelySuccessFlag);
                VALID_E_POINT_CHECK_ERROR(ngapSender);
                VCCB_RETURN_ON_CALL_ERROR(
                    ptCi, ngapSender->sendMsg(), "sendMsg(NG_PDUSessionResourceModifyResponse) ERROR!\n");
                break;
            }
            case NG_UEContextModificationRequestAmfAll_id:
            {
                auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_UEContextModificationFailureAllAmf_id);
                VALID_E_POINT_CHECK_ERROR(ngapSender);
                VCCB_RETURN_ON_CALL_ERROR(
                    ptCi, ngapSender->sendMsg(), "sendMsg(NG_UEContextModificationFailureAllAmf) ERROR!\n");
                break;
            }
            default:  // NG_PDUSessionResourceReleaseCommand_id
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Msg(%s) is dequeued and dropped\n", strMsgId(ptUnpack->msgId));
                break;
            }
        }
    }

    return GOOD;
}

int16_t FnVCCB_NeedSgNBAddBlock_ByOverheating(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint16_t sCellIdx = 0, sCellCount = 0;
    OverheatingAssistance_type *pOverheating = &ptCi->overheatingAssistance;

    if (!ptCi->overheatingAssistance.overheating_m.overheatingAssistance)
    {
        return FALSE;
    }

    // Count SCell
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (sCellIdx = 0; sCellIdx < MAX_SCELL_PER_CALL; sCellIdx++)
    {
        if (SCELL_STATE_ADDED != scells[sCellIdx].state) continue;
        sCellCount++;
    }
    ptCi->sCellCountForOverheating = sCellCount;

    // Compare reducedCCsDL_r16 and SCell count
    if (pOverheating->m.reducedMaxCCs && (pOverheating->reducedMaxCCs.reducedCCsDL_r16 <= sCellCount))
    {
        // [FGR-CC0104 FR320] If reducedCCsDL-r16 <= SCell in MCG, SgNB Addition is not available.
        return TRUE;
    }

    if (pOverheating->m.reducedMaxBW_FR2 &&
        ((pOverheating->reducedMaxBW_FR2.reducedBW_DL_r16 == NRRRC_mhz0) ||
         (pOverheating->reducedMaxBW_FR2.reducedBW_UL_r16 == NRRRC_mhz0)))
    {
        // [FGR-CC0104 FR316]
        return TRUE;
    }

    return FALSE;
}

int FnVCCB_get_nrArfcn(callInfo_type *ptCi, uint32_t *ptNrArfcn)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNrArfcn);

    const uint16_t cellNum = FnVCCB_GetCellSelectionForConfig(ptCi).cellNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    *ptNrArfcn = pCell->nrArfcnDl;

    return GOOD;
}

int16_t FnVCCB_get_ssbArfcn(callInfo_type *ptCi, uint32_t *ptSsbArfcn)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptSsbArfcn);

    const uint16_t cellNum = FnVCCB_GetCellSelectionForConfig(ptCi).cellNum;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    *ptSsbArfcn = pCell->ssbArfcn;

    return GOOD;
}

void FnVCCB_UlSrbIntegrityFail_PrintLog_PdcpCtx(
    const callInfo_type *ptCi, const PdcpCallContext_type *pPdcpCtx, enumPdcpCtx_type pdcpCtxType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pPdcpCtx);
    const securityInformation_type *pSecurityInfo = &pPdcpCtx->securityInfo;

    switch (pdcpCtxType)
    {
        case PDCP_CTX:
            VCCB_PRINT_CALL_ERROR(ptCi,
                "1) ptCi->security.pdcpCtx : callId(%u) dbgFlag(%u) mode(%u) integrityAlgo(%u) cipherAlgo(%u)\n",
                pPdcpCtx->callId, pPdcpCtx->dbgFlag, pSecurityInfo->mode, pSecurityInfo->integrityAlgo,
                pSecurityInfo->cipherAlgo);
            break;
        case PDCP_CTX_NEW:
            VCCB_PRINT_CALL_ERROR(ptCi,
                "2) ptCi->security.newPdcpCtx : callId(%u) dbgFlag(%u) mode(%u) integrityAlgo(%u) cipherAlgo(%u)\n",
                pPdcpCtx->callId, pPdcpCtx->dbgFlag, pSecurityInfo->mode, pSecurityInfo->integrityAlgo,
                pSecurityInfo->cipherAlgo);
            break;
        default:
            break;
    }

    VCCB_PRINT_CALL_ERROR(ptCi,
        " - keyRrcIntCurr : %02X%02X%02X%02X %02X%02X%02X%02X %02X%02X%02X%02X %02X%02X%02X%02X\n",
        pSecurityInfo->keyRrcIntCurr[0], pSecurityInfo->keyRrcIntCurr[1], pSecurityInfo->keyRrcIntCurr[2],
        pSecurityInfo->keyRrcIntCurr[3], pSecurityInfo->keyRrcIntCurr[4], pSecurityInfo->keyRrcIntCurr[5],
        pSecurityInfo->keyRrcIntCurr[6], pSecurityInfo->keyRrcIntCurr[7], pSecurityInfo->keyRrcIntCurr[8],
        pSecurityInfo->keyRrcIntCurr[9], pSecurityInfo->keyRrcIntCurr[10], pSecurityInfo->keyRrcIntCurr[11],
        pSecurityInfo->keyRrcIntCurr[12], pSecurityInfo->keyRrcIntCurr[13], pSecurityInfo->keyRrcIntCurr[14],
        pSecurityInfo->keyRrcIntCurr[15]);

    VCCB_PRINT_CALL_ERROR(ptCi,
        " - keyRrcEncCurr : %02X%02X%02X%02X %02X%02X%02X%02X %02X%02X%02X%02X %02X%02X%02X%02X\n",
        pSecurityInfo->keyRrcEncCurr[0], pSecurityInfo->keyRrcEncCurr[1], pSecurityInfo->keyRrcEncCurr[2],
        pSecurityInfo->keyRrcEncCurr[3], pSecurityInfo->keyRrcEncCurr[4], pSecurityInfo->keyRrcEncCurr[5],
        pSecurityInfo->keyRrcEncCurr[6], pSecurityInfo->keyRrcEncCurr[7], pSecurityInfo->keyRrcEncCurr[8],
        pSecurityInfo->keyRrcEncCurr[9], pSecurityInfo->keyRrcEncCurr[10], pSecurityInfo->keyRrcEncCurr[11],
        pSecurityInfo->keyRrcEncCurr[12], pSecurityInfo->keyRrcEncCurr[13], pSecurityInfo->keyRrcEncCurr[14],
        pSecurityInfo->keyRrcEncCurr[15]);

    VCCB_PRINT_CALL_ERROR(ptCi, " - keyUpInt : %02X%02X%02X%02X %02X%02X%02X%02X %02X%02X%02X%02X %02X%02X%02X%02X\n",
        pSecurityInfo->keyUpInt[0], pSecurityInfo->keyUpInt[1], pSecurityInfo->keyUpInt[2], pSecurityInfo->keyUpInt[3],
        pSecurityInfo->keyUpInt[4], pSecurityInfo->keyUpInt[5], pSecurityInfo->keyUpInt[6], pSecurityInfo->keyUpInt[7],
        pSecurityInfo->keyUpInt[8], pSecurityInfo->keyUpInt[9], pSecurityInfo->keyUpInt[10],
        pSecurityInfo->keyUpInt[11], pSecurityInfo->keyUpInt[12], pSecurityInfo->keyUpInt[13],
        pSecurityInfo->keyUpInt[14], pSecurityInfo->keyUpInt[15]);

    VCCB_PRINT_CALL_ERROR(ptCi, " - keyUpEnc : %02X%02X%02X%02X %02X%02X%02X%02X %02X%02X%02X%02X %02X%02X%02X%02X\n",
        pSecurityInfo->keyUpEnc[0], pSecurityInfo->keyUpEnc[1], pSecurityInfo->keyUpEnc[2], pSecurityInfo->keyUpEnc[3],
        pSecurityInfo->keyUpEnc[4], pSecurityInfo->keyUpEnc[5], pSecurityInfo->keyUpEnc[6], pSecurityInfo->keyUpEnc[7],
        pSecurityInfo->keyUpEnc[8], pSecurityInfo->keyUpEnc[9], pSecurityInfo->keyUpEnc[10],
        pSecurityInfo->keyUpEnc[11], pSecurityInfo->keyUpEnc[12], pSecurityInfo->keyUpEnc[13],
        pSecurityInfo->keyUpEnc[14], pSecurityInfo->keyUpEnc[15]);

    return;
}

void FnVCCB_UlSrbIntegrityFail_PrintLog(
    const callInfo_type *ptCi, const F1_RRCContainer *pRRCContainer, const callSRBInfo_type *ptSi, const F1_SRBID sRBID)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pRRCContainer);
    VALID_E_POINT_CHECK_VOID(ptSi);

    uint32_t i = 0;
    uint32_t strLen = 0;
    uint32_t tempStrLen = 0;

    char rrcPrintBuf[MAX_RRC_CTXT_SIZE];
    uint32_t rrcBuffSize = sizeof(rrcPrintBuf);

    VCCB_PRINT_CALL_ERROR(ptCi, "[RET_INTEGRITY_FAIL]\n");

    FnVCCB_UlSrbIntegrityFail_PrintLog_PdcpCtx(ptCi, &ptCi->security.pdcpCtx, PDCP_CTX);
    FnVCCB_UlSrbIntegrityFail_PrintLog_PdcpCtx(ptCi, &ptCi->security.newPdcpCtx, PDCP_CTX_NEW);

    VCCB_PRINT_CALL_ERROR(ptCi, "3) ptCi->srbInfo(%ld).pdcpRbContext : pdcpSnSize(%u) rbId(%u) dummy(%u)\n", sRBID,
        ptSi->pdcpRbContext.pdcpSnSize, ptSi->pdcpRbContext.rbId, ptSi->pdcpRbContext.dummy);

    VCCB_PRINT_CALL_ERROR(ptCi, "   rxNextSn(%u) rxDelivSn(%u) rxHfn(%u) txNextSn(%u) txHfn(%u)\n",
        ptSi->pdcpRbContext.rxNextSn, ptSi->pdcpRbContext.rxDelivSn, ptSi->pdcpRbContext.rxHfn,
        ptSi->pdcpRbContext.txNextSn, ptSi->pdcpRbContext.txHfn);

    VCCB_PRINT_CALL_ERROR(ptCi, "4) pRRCContainer->length(%u) pRRCContainer->value:\n", pRRCContainer->length);

    rrcPrintBuf[0] = '\0';
    for (i = 0; i < MIN(rrcBuffSize, pRRCContainer->length); i++)
    {
        strLen += (uint32_t)snprintf(rrcPrintBuf + strLen, rrcBuffSize - strLen, "%02X", pRRCContainer->value[i]);
        ++tempStrLen;

        if (tempStrLen > 50)
        {
            tempStrLen = 0;
            VCCB_PRINT_CALL_ERROR(ptCi, "   %s\n", rrcPrintBuf);
            rrcPrintBuf[0] = '\0';
            strLen = 0;
        }
    }
    if (tempStrLen != 0) VCCB_PRINT_CALL_ERROR(ptCi, "   %s\n", rrcPrintBuf);

    return;
}

/*
 * @brief   Get cellNum based on CGI for current gNB
 *
 * @param[in]       ptCi : pointer to call info
 * @param[in]       cgi : cell cgi information
 * @param[in]       gnbIdLength : length of gnb ID
 * @return          cellNum, MAX_CELL_NUM_VCCB - in case of failure or inter-gNB
 */
uint16_t VLIB_GetCellNumBasedOnCgi(const callInfo_type *ptCi, cgi_type cgi, uint8_t gnbIdLength)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, MAX_CELL_NUM_VCCB);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    const uint32_t gnbId = VLIB_NrCellId2GnbId(gnbIdLength, cgi.ci);
    if (false == VCCB_IS_SAME_GNB(gnbId, cgi.plmn.longId, ptCi->gnbNum))
    {
        return MAX_CELL_NUM_VCCB;
    }

    const uint16_t cellIdentity = VLIB_NrCellId2CellId(gnbIdLength, cgi.ci);
    VCCB_CHECK_E_RANGE_AND_VAL(cellIdentity, MAX_CELL_IDENTITY, MAX_CELL_NUM_VCCB);

    return pGnb->env.cellNum[cellIdentity];
}

/*
 * @brief   Get cellNum based on nbrGnbCellInfo_type for current gNB
 *
 * @param[in]       rCi : reference to call info
 * @param[in]       rCell : reference to nbrGnbCellInfo
 * @return          cellNum, MAX_CELL_NUM_VCCB - in case of failure or inter-gNB
 */
uint16_t VLIB_GetCellNumBasedOnNbrGnbCellInfo(const callInfo_type &rCi, const nbrGnbCellInfo_type &rCell)
{
    AUTO_TRACE_FUNC;

    cgi_type cgi;
    cgi.ci = VLIB_GnbIdCellId2NrCellId(&rCell.globalGnbId.gnbId, rCell.cellId);
    cgi.plmn = rCell.globalGnbId.plmn;

    return VLIB_GetCellNumBasedOnCgi(&rCi, cgi, rCell.globalGnbId.gnbId.idLength);
}

/*
 * @brief   Get nbrIdx in pCell Nbr[] based on CGI
 *
 * @param[in]       pCell : pointer to cell info
 * @param[in]       cgi : cell cgi information
 * @return          nbrIdx, MAX_NBR_PER_CELL - in case matching neighbour not found
 */
uint16_t VLIB_GetNbrIdxBasedOnCgi(const VccbCellInfo_type *pCell, cgi_type cgi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(pCell, MAX_NBR_PER_CELL);

    uint16_t nbrIdx = 0;
    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; ++nbrIdx)
    {
        const nbrCellInfo_type *pNbr = &pCell->Nbr[nbrIdx];
        if ((EQUIP == pNbr->status) &&
            (cgi.plmn.longId == pNbr->targetGnbId.plmn.longId) &&
            (cgi.ci == VLIB_GnbIdCellId2NrCellId(&pNbr->targetGnbId.gnbId, pNbr->targetCellId)))
        {
            break;
        }
    }

    return nbrIdx;
}

/*
 * @brief   Get nbrGnbCellInfo_type based on CGI for current gNB
 *
 * @param[in]       ptCi : pointer to call info
 * @param[in]       cgi : cell cgi information
 * @param[in]       gnbIdLength : length of gnb ID
 * @return          pointer to nbrGnbCellInfo_type/NULL
 */
nbrGnbCellInfo_type *VLIB_GetNbrGnbCellInfoBasedOnCgi(const callInfo_type *ptCi, cgi_type cgi, uint8_t gnbIdLength)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);
    VCCB_CHECK_E_RANGE_AND_NULL(ptCi->gnbNum, MAX_GNB_PER_SYS);

    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    nbrGnbCellInfo_type *pnbrGnbCellInfo = NULL;

    const uint32_t gnbId = VLIB_NrCellId2GnbId(gnbIdLength, cgi.ci);
    if (VCCB_IS_SAME_GNB(gnbId, cgi.plmn.longId, ptCi->gnbNum))
    {
        const uint16_t cellIdentity = VLIB_NrCellId2CellId(gnbIdLength, cgi.ci);
        VCCB_CHECK_E_RANGE_AND_NULL(cellIdentity, MAX_CELL_IDENTITY);
        const uint16_t cellNum = pGnb->env.cellNum[cellIdentity];
        VCCB_CHECK_E_RANGE_AND_NULL(cellNum, MAX_CELL_NUM_VCCB);

        VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
        pnbrGnbCellInfo = &pCell->intraGnbNbrInfo;
    }
    else
    {
        pnbrGnbCellInfo = getNbrGnbCell(ptCi->gnbNum, pGnb, cgi);
    }
    if (NULL == pnbrGnbCellInfo)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "Unable to find nbrGnbCellInfo_type for cgi.ci(%lu)!!!\n", cgi.ci);
    }

    return pnbrGnbCellInfo;
}

uint8_t FnVCCB_NrdcCellInfo_RfspBasedEntries_FindEntry(
    uint8_t usage, uint16_t rfsp, nrdcRfspBasedUlPathSwitchCtrl_type entries[])
{
    uint8_t rfspIndex = 0;
    for (rfspIndex = 0; rfspIndex < MAX_RFSP_INDEX_TIMES_TWO; rfspIndex++)
    {
        if (usage == entries[rfspIndex].usage)
        {
            if ((usage == CI_no_use)                   // find first unused entry
                || (entries[rfspIndex].rfsp == rfsp))  // find existing specific entry
            {
                return rfspIndex;
            }
        }
    }
    return MAX_RFSP_INDEX_TIMES_TWO;
}

int16_t FnVCCB_CheckAndMarkForChangeOfUeReleasePreference(callInfo_type *ptCi, uint8_t onlyCheckFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    ueReleasePreferenceConfig_type *ptCurrent, *ptNew;

    ptCurrent = &ptCi->ueNrRrcOtherConfig.currConfig.ueRelPrefConfig;
    ptNew = &ptCi->ueNrRrcOtherConfig.newConfig.ueRelPrefConfig;

    // Initialize
    if (onlyCheckFlag != VCCB_FLAG_ON)
    {
        ptNew->releasePreferenceChangeFlag = NR_RRC_TYPE_NO_ACTION;
    }

    if (IS_NRDC_SN(ptCi))
    {
        return FALSE;
    }

    // Get New Config Info.
    FnVCCB_GetNewUeReleasePreferenceInfo(ptCi);

    // check UE full configuration condition
    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        if (ptNew->configured == VCCB_FLAG_ON)
        {
            if (onlyCheckFlag != VCCB_FLAG_ON)
            {
                ptNew->releasePreferenceChangeFlag = NR_RRC_TYPE_SETUP_OR_MODI;
            }
            return TRUE;
        }

        // UE releases the current config, bcz of ue full config..
        return FALSE;
    }

    // Check Difference ( currConfig vs newConfig )
    if (ptCurrent->configured != ptNew->configured)
    {
        if (onlyCheckFlag != VCCB_FLAG_ON)
        {
            if (ptCurrent->configured == VCCB_FLAG_ON)
                ptNew->releasePreferenceChangeFlag = NR_RRC_TYPE_RELEASE;
            else
                ptNew->releasePreferenceChangeFlag = NR_RRC_TYPE_SETUP_OR_MODI;
        }

        return TRUE;
    }

    if (ptCurrent->configured == VCCB_FLAG_ON)
    {
        // Compare ProhibitTimer value , connectedReporting
        if ((ptCurrent->connectedReporting != ptNew->connectedReporting) ||
            (ptCurrent->releasePreferenceProhibitTimer_r16 != ptNew->releasePreferenceProhibitTimer_r16))
        {
            if (onlyCheckFlag != VCCB_FLAG_ON)
            {
                ptNew->releasePreferenceChangeFlag = NR_RRC_TYPE_SETUP_OR_MODI;
            }

            return TRUE;
        }
    }

    return FALSE;
}

void FnVCCB_GetNewUeReleasePreferenceInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    ueReleasePreferenceConfig_type *ptNew;
    ptNew = &ptCi->ueNrRrcOtherConfig.newConfig.ueRelPrefConfig;

    ptNew->configured = VCCB_FLAG_OFF;
    ptNew->connectedReporting = VCCB_FLAG_OFF;
    ptNew->releasePreferenceProhibitTimer_r16 = 0xFF;

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if ((ptCi->ueInfo.ueCapa.nr.powerSav.releasePreference_r16_support == VCCB_FLAG_ON) &&
        (pGnb->ueRelPrefGnbConfig.releasePreferenceOnOff == VCCB_FLAG_ON))
    {
        ptNew->configured = VCCB_FLAG_ON;
        ptNew->connectedReporting = (uint8_t)(pGnb->ueRelPrefGnbConfig.connectedReportingUsage & e_BitMask_1bit);
        ptNew->releasePreferenceProhibitTimer_r16 = pGnb->ueRelPrefGnbConfig.releasePreferenceProhibitTimer;
    }

    return;
}

void FnVCCB_CommitUeNrRrcOtherConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (NR_RRC_TYPE_NO_ACTION != ptCi->ueNrRrcOtherConfig.newConfig.ueRelPrefConfig.releasePreferenceChangeFlag)
    {
        /* Clear ChangeFlag */
        ptCi->ueNrRrcOtherConfig.newConfig.ueRelPrefConfig.releasePreferenceChangeFlag = NR_RRC_TYPE_NO_ACTION;

        /* Copy NewConfig to CurrentConfig */
        ptCi->ueNrRrcOtherConfig.currConfig.ueRelPrefConfig = ptCi->ueNrRrcOtherConfig.newConfig.ueRelPrefConfig;
    }

    if (NR_RRC_TYPE_NO_ACTION != ptCi->ueNrRrcOtherConfig.newConfig.ueOverheatAssiConfig.changeFlag)
    {
        ptCi->ueNrRrcOtherConfig.newConfig.ueOverheatAssiConfig.changeFlag = NR_RRC_TYPE_NO_ACTION;
        ptCi->ueNrRrcOtherConfig.currConfig.ueOverheatAssiConfig =
            ptCi->ueNrRrcOtherConfig.newConfig.ueOverheatAssiConfig;
    }

    if (NR_RRC_TYPE_NO_ACTION != ptCi->ueNrRrcOtherConfig.newConfig.ueMaxBWPrefConfig.changeFlag)
    {
        ptCi->ueNrRrcOtherConfig.newConfig.ueMaxBWPrefConfig.changeFlag = NR_RRC_TYPE_NO_ACTION;
        ptCi->ueNrRrcOtherConfig.currConfig.ueMaxBWPrefConfig = ptCi->ueNrRrcOtherConfig.newConfig.ueMaxBWPrefConfig;
    }

    if (NR_RRC_TYPE_NO_ACTION != ptCi->ueNrRrcOtherConfig.newConfig.ueMaxCCPrefConfig.changeFlag)
    {
        ptCi->ueNrRrcOtherConfig.newConfig.ueMaxCCPrefConfig.changeFlag = NR_RRC_TYPE_NO_ACTION;
        ptCi->ueNrRrcOtherConfig.currConfig.ueMaxCCPrefConfig = ptCi->ueNrRrcOtherConfig.newConfig.ueMaxCCPrefConfig;
    }

    if (NR_RRC_TYPE_NO_ACTION != ptCi->ueNrRrcOtherConfig.newConfig.ueMaxMIMOLayerPrefConfig.changeFlag)
    {
        ptCi->ueNrRrcOtherConfig.newConfig.ueMaxMIMOLayerPrefConfig.changeFlag = NR_RRC_TYPE_NO_ACTION;
        ptCi->ueNrRrcOtherConfig.currConfig.ueMaxMIMOLayerPrefConfig =
            ptCi->ueNrRrcOtherConfig.newConfig.ueMaxMIMOLayerPrefConfig;
    }
}

int16_t FnVCCB_CheckNeedActionForUePreferredRrcState(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    if ((ptCi->callType != E_CALLTYPE_SA) || (IS_NRDC_SN(ptCi)))
    {
        return FALSE;
    }

    if (ptCi->ueNrRrcOtherConfig.newConfig.ueRelPrefConfig.releaseCallFlagByRxUeAssistInfo == VCCB_FLAG_ON)
    {
        // If already ue context release process is going, then ignore it.
        if (ptCi->ueNrRrcOtherConfig.currConfig.ueRelPrefConfig.releaseCallFlagByRxUeAssistInfo == VCCB_FLAG_ON)
        {
            return FALSE;
        }

        ptCi->ueNrRrcOtherConfig.currConfig.ueRelPrefConfig.releaseCallFlagByRxUeAssistInfo = VCCB_FLAG_ON;
        return TRUE;
    }

    return FALSE;
}

void FnVCCB_GetNewUeOverheatingAssistanceInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    ueNrRrcOtherConfigInfoIE_type *ptNew;

    ptNew = &ptCi->ueNrRrcOtherConfig.newConfig.ueOverheatAssiConfig;
    ptNew->configured = VCCB_FLAG_OFF;
    ptNew->prohibitTimer = 0xFF;

    if (!pGnb->UEOverheatingControl.overheatingControlSwitch || !ptCi->ueInfo.ueCapa.nr.overheatingInd)
    {
        return;
    }

    ptNew->configured = VCCB_FLAG_ON;
    ptNew->prohibitTimer = pGnb->UEOverheatingControl.t345;

    return;
}

bool FnVCCB_IsSetupFlag_UeMaxBWPref(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    uint32_t ssbArfcn = 0;
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // check gnb config
    if (!pGnb->UEPowersavingControl.bwPreferenceControlSwitch)
    {
        return false;
    }

    if (GOOD != FnVCCB_get_ssbArfcn(ptCi, &ssbArfcn))
    {
        VCCB_PRINT_CALL_DATA(ptCi, "FnVCCB_get_ssbArfcn ERROR in %s!!\n", __func__);
        return false;
    }

    // check ue capa
    if (ptCi->ueInfo.ueCapa.nr.powerSav.maxBWPreferenceInd ||
        (ssbArfcn < MIN_A6_NR_ARFCN && ptCi->ueInfo.ueCapa.nr.powerSav.fr1_maxBWPreferenceInd) ||
        (ssbArfcn >= MIN_A6_NR_ARFCN && ptCi->ueInfo.ueCapa.nr.powerSav.fr2_maxBWPreferenceInd))
    {
        return true;
    }

    return false;
}

void FnVCCB_GetNewUeMaxBW_PreferenceInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    ueNrRrcOtherConfigInfoIE_type *ptNew;

    ptNew = &ptCi->ueNrRrcOtherConfig.newConfig.ueMaxBWPrefConfig;
    ptNew->configured = VCCB_FLAG_OFF;
    ptNew->prohibitTimer = 0xFF;

    if (FnVCCB_IsSetupFlag_UeMaxBWPref(ptCi))
    {
        ptNew->configured = VCCB_FLAG_ON;
        ptNew->prohibitTimer = pGnb->UEPowersavingControl.t346b;
    }

    return;
}

void FnVCCB_GetNewUeMaxCC_PreferenceInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    ueNrRrcOtherConfigInfoIE_type *ptNew;

    ptNew = &ptCi->ueNrRrcOtherConfig.newConfig.ueMaxCCPrefConfig;
    ptNew->configured = VCCB_FLAG_OFF;
    ptNew->prohibitTimer = 0xFF;

    if (!pGnb->UEPowersavingControl.ccPreferenceControlSwitch || !ptCi->ueInfo.ueCapa.nr.powerSav.maxCCPreferenceInd)
    {
        return;
    }

    ptNew->configured = VCCB_FLAG_ON;
    ptNew->prohibitTimer = pGnb->UEPowersavingControl.t346c;

    return;
}

bool FnVCCB_IsSetupFlag_UeMaxMIMOLayer_Pref(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    uint32_t ssbArfcn = 0;
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // check gnb config
    if (!pGnb->UEPowersavingControl.mimoLayerPreferenceControlSwitch)
    {
        return false;
    }

    if (GOOD != FnVCCB_get_ssbArfcn(ptCi, &ssbArfcn))
    {
        VCCB_PRINT_CALL_DATA(ptCi, "FnVCCB_get_ssbArfcn ERROR in %s!!\n", __func__);
        return false;
    }

    // check ue capa
    if (ptCi->ueInfo.ueCapa.nr.powerSav.maxMIMOLayerPreferenceInd ||
        (ssbArfcn < MIN_A6_NR_ARFCN && ptCi->ueInfo.ueCapa.nr.powerSav.fr1_maxMIMOLayerPreferenceInd) ||
        (ssbArfcn >= MIN_A6_NR_ARFCN && ptCi->ueInfo.ueCapa.nr.powerSav.fr2_maxMIMOLayerPreferenceInd))
    {
        return true;
    }

    return false;
}

void FnVCCB_GetNewUeMaxMIMOLayer_PreferenceInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    ueNrRrcOtherConfigInfoIE_type *ptNew;

    ptNew = &ptCi->ueNrRrcOtherConfig.newConfig.ueMaxMIMOLayerPrefConfig;
    ptNew->configured = VCCB_FLAG_OFF;
    ptNew->prohibitTimer = 0xFF;

    if (FnVCCB_IsSetupFlag_UeMaxMIMOLayer_Pref(ptCi))
    {
        ptNew->configured = VCCB_FLAG_ON;
        ptNew->prohibitTimer = pGnb->UEPowersavingControl.t346d;
    }

    return;
}

int16_t FnVCCB_GetNewUeNrRrcOtherConfigIE(callInfo_type *ptCi, enumUeNrRrcOtherConfig_type configType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    switch (configType)
    {
        case UE_OVERHEAT_ASSI_CONFIG:
            FnVCCB_GetNewUeOverheatingAssistanceInfo(ptCi);
            break;
        case UE_MAXBW_PREF_CONFIG:
            FnVCCB_GetNewUeMaxBW_PreferenceInfo(ptCi);
            break;
        case UE_MAXCC_PREF_CONFIG:
            FnVCCB_GetNewUeMaxCC_PreferenceInfo(ptCi);
            break;
        case UE_MAXMIMO_LAYER_PREF_CONFIG:
            FnVCCB_GetNewUeMaxMIMOLayer_PreferenceInfo(ptCi);
            break;
        default:
            return ERROR;
    }

    return GOOD;
}

void FnVCCB_CheckAndMarkForChangeOfUeNrRrcOtherConfigIE(
    callInfo_type *ptCi, enumUeNrRrcOtherConfig_type configType, int16_t *pRetVal, uint8_t onlyCheckFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pRetVal);

    ueNrRrcOtherConfigInfoIE_type *ptCurr, *ptNew;

    switch (configType)
    {
        case UE_OVERHEAT_ASSI_CONFIG:
            ptCurr = &ptCi->ueNrRrcOtherConfig.currConfig.ueOverheatAssiConfig;
            ptNew = &ptCi->ueNrRrcOtherConfig.newConfig.ueOverheatAssiConfig;
            break;
        case UE_MAXBW_PREF_CONFIG:
            ptCurr = &ptCi->ueNrRrcOtherConfig.currConfig.ueMaxBWPrefConfig;
            ptNew = &ptCi->ueNrRrcOtherConfig.newConfig.ueMaxBWPrefConfig;
            break;
        case UE_MAXCC_PREF_CONFIG:
            ptCurr = &ptCi->ueNrRrcOtherConfig.currConfig.ueMaxCCPrefConfig;
            ptNew = &ptCi->ueNrRrcOtherConfig.newConfig.ueMaxCCPrefConfig;
            break;
        case UE_MAXMIMO_LAYER_PREF_CONFIG:
            ptCurr = &ptCi->ueNrRrcOtherConfig.currConfig.ueMaxMIMOLayerPrefConfig;
            ptNew = &ptCi->ueNrRrcOtherConfig.newConfig.ueMaxMIMOLayerPrefConfig;
            break;
        default:
            return;
    }

    // Initialize
    if (VCCB_FLAG_ON != onlyCheckFlag)
    {
        ptNew->changeFlag = NR_RRC_TYPE_NO_ACTION;
    }

    // Overheating : MN configures and receives report then indicates to SN
    // Power saving : MN and SN configures and receives report independently
    if (UE_OVERHEAT_ASSI_CONFIG == configType && (IS_NRDC_SN(ptCi) || IS_ENDC_SN(ptCi)))
    {
        return;
    }

    // Get New Config Info.
    if (GOOD != FnVCCB_GetNewUeNrRrcOtherConfigIE(ptCi, configType))
    {
        return;
    }

    // check UE full configuration condition
    if (IS_FULLCONFIGURATION_IN_PROCESS(ptCi))
    {
        if (VCCB_FLAG_ON == ptNew->changeFlag)
        {
            if (VCCB_FLAG_ON != onlyCheckFlag)
            {
                ptNew->changeFlag = NR_RRC_TYPE_SETUP_OR_MODI;
            }
            *pRetVal = TRUE;
            return;
        }
        // UE releases the current config, bcz of ue full config
        return;
    }

    // Check Difference ( currConfig vs newConfig )
    if (ptCurr->configured != ptNew->configured)
    {
        if (VCCB_FLAG_ON != onlyCheckFlag)
        {
            if (VCCB_FLAG_ON == ptCurr->configured)
            {
                ptNew->changeFlag = NR_RRC_TYPE_RELEASE;
            }
            else
            {
                ptNew->changeFlag = NR_RRC_TYPE_SETUP_OR_MODI;
            }
        }
        *pRetVal = TRUE;
        return;
    }
    else if (VCCB_FLAG_ON == ptCurr->configured)
    {
        // Compare ProhibitTimer value
        if (ptCurr->prohibitTimer != ptNew->prohibitTimer)
        {
            if (VCCB_FLAG_ON != onlyCheckFlag)
            {
                ptNew->changeFlag = NR_RRC_TYPE_SETUP_OR_MODI;
            }
            *pRetVal = TRUE;
            return;
        }
    }
}

int16_t FnVCCB_CheckAndMarkForChangeOfUeNrRrcOtherConfig(callInfo_type *ptCi, uint8_t onlyCheckFlag)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    int16_t returnValue = FALSE;

    FnVCCB_CheckAndMarkForChangeOfUeNrRrcOtherConfigIE(ptCi, UE_OVERHEAT_ASSI_CONFIG, &returnValue, onlyCheckFlag);

    FnVCCB_CheckAndMarkForChangeOfUeNrRrcOtherConfigIE(ptCi, UE_MAXBW_PREF_CONFIG, &returnValue, onlyCheckFlag);

    FnVCCB_CheckAndMarkForChangeOfUeNrRrcOtherConfigIE(ptCi, UE_MAXCC_PREF_CONFIG, &returnValue, onlyCheckFlag);

    FnVCCB_CheckAndMarkForChangeOfUeNrRrcOtherConfigIE(ptCi, UE_MAXMIMO_LAYER_PREF_CONFIG, &returnValue, onlyCheckFlag);

    // TS38.331
    // Requests the UE to attempt to have detailed location information available using GNSS.
    // NR configures the field if includeCommonLocationInfo is configured for one or more measurements.
    if (ptCi->fullConfiguration.interwork.obtainCommonLocation_r16)
    {
        returnValue = TRUE;
    }

    // SVR25A FGR-MC1020 FR133 (currently impossible to happen from a child IE: So, it's only for test)
    if (CFG->fullConfig.dbg.forcedTriggerScenario.EventScenario_SA_InterGnbResume_CuInit == Allowed)
    {
        returnValue = TRUE;
    }

    // SVR25B FGR-MC1020 FR133 (currently impossible to happen from a child IE: So, it's only for test)
    if (CFG->fullConfig.dbg.forcedTriggerScenario.EventScenario_SA_InterGnbRRE == Allowed)
    {
        returnValue = TRUE;
    }

    return returnValue;
}

// SVR22B: send RRC Inactive Transition Report Request
void FnVCCB_Proc_RRCInactiveTransitionReport(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->state != STATE_Conn && ptCi->state != STATE_Inact_Suspend)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "FnVCCB_Proc_RRCInactiveTransitionReport @ptCi->state(%d) is INVALIED!!\n", ptCi->state);

        return;
    }

    switch (ptCi->ueInfo.RrcInactiveInfo.transitionReportedBy)
    {
        case NG_InitialContextSetupRequestAmfAll_id:  // SVR22B FGR-CC0103 FR30
        case NG_HandoverRequestAmfgnb_id:             // SVR22B FGR-CC0103 FR32
        {
            if (ptCi->ueInfo.RrcInactiveInfo.newInactReportType == NGAP_subsequent_state_transition_report)
            {
                auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_RRCInactiveTransitionReportAllAmf_id);
                VALID_E_POINT_CHECK_VOID(ngapSender);
                if (ERROR == ngapSender->sendMsg())
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_RRCInactiveTransitionReportAllAmf) ERROR !!\n");

                    // initialize
                    INIT_RRC_INACTIVE_TRANSITION_REPORT(ptCi);
                    return;
                }
            }
            else
            {
                VCCB_PRINT_CALL_MSG(ptCi, "RrcInactiveTransitionReportRequest(%d)(ptCi->state(%d)) is ignored !!\n",
                    ptCi->ueInfo.RrcInactiveInfo.newInactReportType, ptCi->state);

                // initialize
                INIT_RRC_INACTIVE_TRANSITION_REPORT(ptCi);
            }
        }
        break;

        case NG_UEContextModificationRequestAmfAll_id:  // SVR22B FGR-CC0103 FR31, FR34
        {
            if (ptCi->ueInfo.RrcInactiveInfo.newInactReportType == NGAP_subsequent_state_transition_report ||
                ptCi->ueInfo.RrcInactiveInfo.newInactReportType == NGAP_single_rrc_connected_state_report)
            {
                auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_RRCInactiveTransitionReportAllAmf_id);
                VALID_E_POINT_CHECK_VOID(ngapSender);
                if (ERROR == ngapSender->sendMsg())
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_RRCInactiveTransitionReportAllAmf) ERROR !!\n");

                    // initialize
                    INIT_RRC_INACTIVE_TRANSITION_REPORT(ptCi);
                    return;
                }
            }

            if (ptCi->ueInfo.RrcInactiveInfo.newInactReportType == NGAP_subsequent_state_transition_report)
            {
                // update the old value with new one
                ptCi->ueInfo.RrcInactiveInfo.oldInactReportType = ptCi->ueInfo.RrcInactiveInfo.newInactReportType;
            }
            else
            {
                // initialize
                INIT_RRC_INACTIVE_TRANSITION_REPORT(ptCi);
            }
        }
        break;

        case NG_PathSwitchRequestAcknowledgeAmfGnb_id:  // SVR22B FGR-CC0103 FR33
        {
            if ((ptCi->ueInfo.RrcInactiveInfo.newInactReportType == NGAP_subsequent_state_transition_report ||
                    ptCi->ueInfo.RrcInactiveInfo.newInactReportType == NGAP_single_rrc_connected_state_report) &&
                ptCi->ueInfo.RrcInactiveInfo.singleReportByPathSwitch < RRC_INACTIVE_REPORT_SENT_TWICE)
            {
                auto ngapSender = MsgNgapSender::createMessageSender(ptCi, NG_RRCInactiveTransitionReportAllAmf_id);
                VALID_E_POINT_CHECK_VOID(ngapSender);
                if (ERROR == ngapSender->sendMsg())
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_RRCInactiveTransitionReportAllAmf) ERROR !!\n");

                    // initialize
                    INIT_RRC_INACTIVE_TRANSITION_REPORT(ptCi);
                    return;
                }

                if (ptCi->ueInfo.RrcInactiveInfo.newInactReportType == NGAP_subsequent_state_transition_report)
                {
                    // update the old value with new one
                    ptCi->ueInfo.RrcInactiveInfo.oldInactReportType = ptCi->ueInfo.RrcInactiveInfo.newInactReportType;
                }
                else if (ptCi->ueInfo.RrcInactiveInfo.newInactReportType == NGAP_single_rrc_connected_state_report)
                {
                    if (ptCi->state == STATE_Inact_Suspend)
                    {
                        if (ptCi->ueInfo.RrcInactiveInfo.singleReportByPathSwitch == RRC_INACTIVE_REPORT_SENT_NONE)
                        {
                            ptCi->ueInfo.RrcInactiveInfo.singleReportByPathSwitch = RRC_INACTIVE_REPORT_SENT_ONCE;
                        }
                    }
                    else  // STATE_Conn
                    {
                        if (ptCi->ueInfo.RrcInactiveInfo.singleReportByPathSwitch == RRC_INACTIVE_REPORT_SENT_ONCE)
                        {
                            ptCi->ueInfo.RrcInactiveInfo.singleReportByPathSwitch = RRC_INACTIVE_REPORT_SENT_TWICE;
                        }
                        else
                        {
                            // initialize
                            INIT_RRC_INACTIVE_TRANSITION_REPORT(ptCi);
                        }
                    }
                }
                else if (ptCi->ueInfo.RrcInactiveInfo.newInactReportType == NGAP_cancel_report)
                {
                    // initialize
                    INIT_RRC_INACTIVE_TRANSITION_REPORT(ptCi);
                }
            }
            break;
        }

        default:
            break;
    }
}

/***************************************************************************
 * octetString Cotntol
 **************************************************************************/
bool FnVCCB_CheckValid_octetString(const octetStringType *ptOct)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptOct, false);

    if (ptOct->length > 0 && ptOct->value)
    {
        return true;
    }

    return false;
}

int FnVCCB_QsortAvailableResourceDescendingOrder(const void *arg1, const void *arg2)
{
    AUTO_TRACE_FUNC;

    availResourcePerMeasResultCellReport_type *a = NULL;
    availResourcePerMeasResultCellReport_type *b = NULL;

    VALID_E_POINT_CHECK_ERROR(arg1);
    VALID_E_POINT_CHECK_ERROR(arg2);

    a = (availResourcePerMeasResultCellReport_type *)arg1;
    b = (availResourcePerMeasResultCellReport_type *)arg2;

    // b-a for descending order
    if (a->availableResource > b->availableResource)
    {
        return -1;
    }
    if (a->availableResource < b->availableResource)
    {
        return 1;
    }
    if (!a->availableResource && !a->ssbArfcn && b->ssbArfcn)
    {
        return 1;
    }

    return 0;
}

void FnVCCB_CheckBearerAndUpdateSignalingUserInactivity(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    if (IS_NRDC_SN(ptCi))
    {
        return;
    }

    // Check StateCmd
    if ((ptCi->stateCmd != PDUSetup_cmd) && (ptCi->stateCmd != PDUModify_cmd) && (ptCi->stateCmd != PDURelease_cmd))
    {
        return;
    }

    // Restart Signaling Timer
    FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_SIG_RESTART);

    return;
}

void FnVCCB_CheckBearerAndUpdateDataUserInactivity(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    int16_t status;

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "ptCi->callType is not E_CALLTYPE_SA ERROR!(%d) in %s\n", ptCi->callType, __FUNCTION__);
        return;
    }

    if (IS_NRDC_SN(ptCi))
    {
        return;
    }

    if (!IS_SUPPORT_RRC_INACTIVE(ptCi) && IS_NRDC_MN(ptCi) &&
        !FnVCCB_IsAnyMnTermPerUE(ptCi, request_bearerType))
    {
        FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_DATA_EXPIRY);
        return;
    }

    const auto dataActivityStatus = RscCall::getDataActivityStatus(*ptCi);
    if (dataActivityStatus == ActivityStatus_ACTIVE)
    {
        if (IS_SUPPORT_RRC_INACTIVE(ptCi))
        {
            status = FnVCCB_UpdateRRCInactStateAndDoActionIfExpiry(ptCi, RRCInactiveEvent_DATA_RESTART);
            VCCB_RETURN_ON_CALL_VOID(ptCi, status, "FnVCCB_UpdateRRCInactStateAndDoActionIfExpiry ERROR\n");
        }
        else
        {
            FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_DATA_RESTART);
        }
    }
    else
    {
        // For DATA_EXPIRY, check StateCmd because it can trigger inactivity actions
        // RRE during PDU Session Reconfiguration would be accepted by FGR-CC0102::FR250
        const uint8_t stateCmd = (ptCi->stateCmd == RrcReestablish_cmd) ? ptCi->prevStateCmd : ptCi->stateCmd;
        if ((PDUSetup_cmd != stateCmd) && (PDUModify_cmd != stateCmd) && (PDURelease_cmd != stateCmd))
        {
            return;
        }

        if (IS_SUPPORT_RRC_INACTIVE(ptCi))
        {
            status = FnVCCB_UpdateRRCInactStateAndDoActionIfExpiry(ptCi, RRCInactiveEvent_DATA_EXPIRY);
            VCCB_RETURN_ON_CALL_VOID(ptCi, status, "FnVCCB_UpdateRRCInactStateAndDoActionIfExpiry ERROR\n");
        }
        else
        {
            FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_DATA_EXPIRY);
        }
    }

    return;
}

bool FnVCCB_IsMultiUpHandlingCase(unsigned short msgId)
{
    AUTO_TRACE_FUNC;

    switch (msgId)
    {
        case E1_BearerContextModificationResponse_id:
        case E1_BearerContextModificationFailure_id:
        case E1_BearerContextSetupResponse_id:
        case E1_BearerContextSetupFailure_id:
            return true;

        default:
            return false;
    }
}

int16_t FnVCCB_MultiUpProcessing(callInfo_type *ptCi, msgUnpack_type *ptUnpack, const int16_t multiUpStatus,
    const multiUpFunctionParameter_type *pParm, const char *funcName)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;

    VALID_E_POINT_CHECK_ERROR_PARAM3(ptCi, ptUnpack, pParm);
    VALID_E_POINT_CHECK_ERROR_PARAM3(pParm->successFunction, pParm->unSuccessFunction, pParm->strSuccessFunction);
    VALID_E_POINT_CHECK_ERROR(funcName);

    switch (multiUpStatus)
    {
        case GOOD:
        case RESPONSE_WITH_PARTIAL_SUCCESS: // SVR25A FGR-MC1009 FR200
            status = pParm->successFunction(ptCi);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "%s ERROR! in %s\n", pParm->strSuccessFunction, funcName);
            return GOOD;

        case MULTI_UP_ERROR:
            status = pParm->unSuccessFunction(ptCi, ptUnpack);
            if (RESPONSE_WITH_PARTIAL_SUCCESS == status)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "MultiUp Continue with partial success\n");
                return GOOD;
            }
            return ERROR;

        default:
            return ERROR;
    }
}

// If it is impossible to decide whether nbr is SDL or not, the nbr will be regarded as normal cell.
bool FnVCCB_IsNbrSDLCell(const callInfo_type *ptCi, const nbrGnbCellInfo_type *ptNbrGnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(ptNbrGnbCell, false);

    if (VCCB_CELLDIR_DLONLY == ptNbrGnbCell->cellDirection)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "NBR is SDL Cell (ssbArfcn:%u, pci:%d, CellId:%d cellDir:%u nrArfcnUl:%u)!!\n",
                ptNbrGnbCell->ssbArfcn, ptNbrGnbCell->nrPci, ptNbrGnbCell->cellId, ptNbrGnbCell->cellDirection,
                ptNbrGnbCell->nrArfcnUl);
        return true;
    }

    return false;
}

bool FnVCCB_CheckIfOtherVendorGnbByGlobalGnbId(callInfo_type *ptCi, uint16_t gnbNum, vccbGlobalGnbId_type *pTgtGnbId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pTgtGnbId, false);
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, false);

    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];
    uint16_t xnIdx = MAX_XN_NBR_PER_GNB;  // == MAX_GNB_PER_GNB_CU_CP

    if (pGnb->globalGnbId.gnbId.id == pTgtGnbId->gnbId.id && pGnb->globalGnbId.plmn.longId == pTgtGnbId->plmn.longId)
    {
        return false;
    }
    else
    {
        xnIdx = fnVLIB_FindXnEndPointIndexByGnbId(gnbNum, pTgtGnbId);
        if (xnIdx >= MAX_XN_NBR_PER_GNB)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Fail, fnVLIB_FindXnEndPointIndexByGnbId(gnbNum:%u, gnb:%X/%u) in %s!\n",
                gnbNum, pTgtGnbId->plmn.longId, pTgtGnbId->gnbId.id, __func__);
            return false;
        }
    }

    return FnVCCB_CheckIfOtherVendorGnbByEpIdx(ptCi, gnbNum, xnIdx);
}

bool FnVCCB_CheckIfOtherVendorGnbByEpIdx(callInfo_type *ptCi, uint16_t gnbNum, uint16_t xnEpIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, false);
    VCCB_CHECK_E_RANGE_AND_VAL(xnEpIdx, MAX_GNB_PER_GNB_CU_CP, false);

    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];

    if ((pGnb->xnGnbInfo[xnEpIdx].status == EQUIP) && !pGnb->xnGnbInfo[xnEpIdx].samsungVendorInd)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Other vendor is confirmed in %s (gnbNum:%u, xnEpIdx:%u)!\n", __FUNCTION__, gnbNum, xnEpIdx);
        return true;
    }

    return false;
}

bool FnVCCB_IsPeerGnbOtherVendor(
    callInfo_type *ptCi, uint16_t gnbNum, uint8_t isEndPointKeyFlag, uint16_t xnEpIdx, vccbGlobalGnbId_type *pTgtGnbId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, false);

    if (isEndPointKeyFlag)
    {
        VCCB_CHECK_E_RANGE_AND_VAL(xnEpIdx, MAX_GNB_PER_GNB_CU_CP, false);

        return FnVCCB_CheckIfOtherVendorGnbByEpIdx(ptCi, gnbNum, xnEpIdx);
    }

    return FnVCCB_CheckIfOtherVendorGnbByGlobalGnbId(ptCi, gnbNum, pTgtGnbId);
}

void FnVCCB_getServingCellMeasInitialInfo(callInfo_type *ptCi, servingCellMeasInitialInfo_type *measResult)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(measResult);

    measResult->rsrpFlag = ptCi->servingCellMeasInitialInfo.rsrpFlag;
    measResult->rsrp = ptCi->servingCellMeasInitialInfo.rsrp;

    measResult->rsrqFlag = ptCi->servingCellMeasInitialInfo.rsrqFlag;
    measResult->rsrq = ptCi->servingCellMeasInitialInfo.rsrq;

    return;
}

/****************************************************************************
 * @brief           Get CellNum and band to be used in Configuration.
 *
 * @param[in,out]   ptCi :          call information
 * @return          cellSelection : struct containing cellNum and bandNr for Configuration
 ****************************************************************************/
cellSelection_type FnVCCB_GetCellSelectionForConfig(const callInfo_type *const ptCi)
{
    AUTO_TRACE_FUNC;
    cellSelection_type cellSelection = { MAX_CELL_NUM_VCCB, BAND_NOT_FOUND };
    VALID_E_POINT_CHECK_RET_VAL(ptCi, cellSelection);

    if (FnVCCB_IsLtmCandPrepForMeas(*ptCi))
    {
        const ltmCellInfo_type *pLtmCell = FnVCCB_GetLtmCellInfoForIndex(const_cast<callInfo_type*>(ptCi), ptCi->ltmUeInfo.currCandidateCellIdx);
        if (nullptr == pLtmCell)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetLtmCellInfoForIndex fail for currCandidateCellIdx(%u)!\n",
                ptCi->ltmUeInfo.currCandidateCellIdx);
            return cellSelection;
        }
        return pLtmCell->data.cellSelection;
    }

    if (((IntraRatHO_cmd == ptCi->stateCmd) || (IntraCellHO_cmd == ptCi->stateCmd)) &&
        (e_HoTrigger_LtmHandoverPrep != ptCi->hoInfo.cause))
    {
        if (ptCi->hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
        {
            cellSelection.cellNum = ptCi->hoInfo.targetCellNum;
            cellSelection.bandNr = ptCi->hoInfo.targetCellBand;
            return cellSelection;
        }
    }

    cellSelection.cellNum = ptCi->servCellNum;
    cellSelection.bandNr = ptCi->servCellBand;
    return cellSelection;
}

/* VCCB_ARCH_MCD START */
/**
 * @brief           Update cell status history
 *                  itscp_vccb get dbg log cellStatusHist [cellNum]
 * @return          void
 */
void VLIB_UpdateCellStatusHistory(uint16_t cellNum, uint16_t cause)
{
    AUTO_TRACE_FUNC;
    VRRM_VALID_CHECK_CELL_RET_VOID(cellNum);

    VccbDbgCellStatusHistory_type *pHist = &DBG->statusHist[cellNum];
    VccbDbgUpdateCellStatusHistory_type *pUpdate = NULL;
    gnbDuInfo_type *pGnbDu = NULL;
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    long currentTime;
    int16_t curIdx;
    uint16_t loop;

    uint8_t pldState = pCell->pldState;
    uint16_t gnbNum = pCell->gnbNum;
    uint16_t endPointF1Index = pCell->endPointF1Index;

    VCCB_CHECK_E_RANGE_AND_VOID(gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *pGnb = &GNBINFO[gnbNum];

    /* MUTEX_LOCK */
    VRRM_MUTEX_LOCK(&gCellHistUpdateMtx[cellNum]);
    curIdx = pHist->curIdx;

    if (curIdx >= 0 && curIdx < MAX_HISTORY_NUM)
    {
        pUpdate = &DBG->statusHist[cellNum].update[curIdx];
        switch (cause)
        {
            // if cause is CONFD_* or PLD_*, save  history when at least one of the below parameters is changed
            case CONFD_CELL_READ...CONFD_GNB_DELETE:
            case PLD_READ_NEQUIP...PLD_NOTI_EQUIP:
            case PLD_GNBSTATE_CHANGED:
                if (pUpdate->pldState == pldState && pUpdate->status == pCell->status &&
                    pUpdate->pldCellIdx == pCell->pldCellIdx && pUpdate->gnbNum == gnbNum &&
                    pUpdate->endPointF1Index == endPointF1Index && pUpdate->pldCellSrvState == pCell->serviceState &&
                    pUpdate->pldGnbSrvState == pGnb->pldActivationState)
                {
                    /* MUTEX UNLOCK */
                    VRRM_MUTEX_UNLOCK(&gCellHistUpdateMtx[cellNum]);
                    return;
                }
                break;

                // for the other causes, always save history
            default:
                break;
        }
    }

    if (curIdx == -1 || curIdx >= MAX_HISTORY_NUM)  // 1st case or curIdx was corrupted case
    {
        curIdx = 0;
        pHist->cycleFlag = VCCB_FLAG_OFF;
    }
    else if (curIdx == MAX_HISTORY_NUM - 1)
    {
        curIdx = 0;
        pHist->cycleFlag = VCCB_FLAG_ON;
    }
    else
    {
        curIdx++;
    }

    /* MUTEX_UNLOCK */
    pHist->curIdx = curIdx;
    VRRM_MUTEX_UNLOCK(&gCellHistUpdateMtx[cellNum]);
    pUpdate = &DBG->statusHist[cellNum].update[curIdx];

    pUpdate->pldState = pldState;
    pUpdate->status = pCell->status;
    pUpdate->pldCellIdx = pCell->pldCellIdx;
    pUpdate->cause = cause;
    pUpdate->gNBId = (gnbNum < MAX_GNB_PER_SYS) ? pGnb->globalGnbId.gnbId.id : MAX_GNB_PER_SYS;
    pUpdate->gnbNum = gnbNum;
    pUpdate->cellId = (uint16_t)pCell->cellIdentity;
    pUpdate->endPointF1Index = endPointF1Index;
    pUpdate->pldCellSrvState = pCell->serviceState;
    pUpdate->pldGnbSrvState = (gnbNum < MAX_GNB_PER_SYS) ? pGnb->pldActivationState : (uint8_t)N_EQUIP;

    if (pldState == EQUIP && gnbNum < MAX_GNB_PER_SYS && endPointF1Index < MAX_GNB_DU_PER_GNB_CU_CP)
    {
        pGnbDu = &pGnb->gnbDu[endPointF1Index];
        for (loop = 0; loop < MIN(MAX_CELL_PER_DU, pGnbDu->nrofCells); loop++)
        {
            if (pGnbDu->cellInDu[loop].cellNum == cellNum)
            {
                pUpdate->cellInDuStatus = pGnbDu->cellInDu[loop].status;
            }
        }
    }
    else  // in case accessing cellInDuStatus is impossible
    {
        pUpdate->cellInDuStatus = N_EQUIP;
    }

    if (time(&currentTime) > 0)
    {
        pUpdate->updateTime = currentTime;
    }
}

int16_t FnVCCB_CheckUeCapa_RedCapSupport (callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->redCapUeInfo.redCapUeFlag != ptCi->redCapUeInfo.supportOfRedCap_r17)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "redCapUeFlag(%d) is different from supportOfRedCap_r17(%d)\n",
            ptCi->redCapUeInfo.redCapUeFlag, ptCi->redCapUeInfo.supportOfRedCap_r17);
        return ERROR;
    }

    return GOOD;
}

bool FnVCCB_IsSupportDrbPartial_PreCondition(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    /* Check SA Call */
    if (ptCi->callType != E_CALLTYPE_SA) return false;
    //if(IS_NRDC_SN(ptCi)) return false;

    /* Check Multi-UP Status */
    if (IS_MULTI_UP(ptCi))
    {
        if (DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: not supported in MULTI-UP case\n");
        }
        return false;
    }

    /* Emergency Call */
    if (IS_EMERGENCY_FALLBACK_CASE(ptCi))
    {
        if (DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: not supported in emergency fallback case\n");
        }
        return false;
    }

    // SVR25B FGR-CC5200 FR1050
    if (IS_NRDC_SN(ptCi))
    {
        if(FnVCCB_IsNrdcAllowedPartialSuccess(ptCi))
        {
            return true;
        }
  
        if (DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: not supported in NR-DC SN (S:%d/Y:%d)\n", 
                                ptCi->stateCmd, GNBINFO[ptCi->gnbNum].cfg.nrdc.supportPartialSuccess);
        }
        return false;
    }   

    /* supported stateCmd */
    // SVR25A FGR-MC1009 FR200
    if ((true != IS_STATECMD_SUPPORT_DRB_PARTIAL(ptCi)))
    {
        if (DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: not supported in state cmd(%d)\n", ptCi->stateCmd);
        }
        return false;
    }

    // Function Off by Debug
    if (DBG->flag.drbPartialFunctionDisable == VCCB_FLAG_ON)
    {
        if (DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: not supported by debug command [drbPartialFunctionDisable]\n");
        }
        return false;
    }

    return true;
}

void FnVCCB_InitE1f1InfoAndSetDrbPartialReqOption(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    /* Clear */
    memset(&ptCi->drbPartialInfo.e1f1Info[interfaceType], 0, sizeof(ptCi->drbPartialInfo.e1f1Info[interfaceType]));

    /* Set Requested Option */
    FnVCCB_SetPartialOptionBeforeSendingE1F1(ptCi, interfaceType);

    /* Set preConditionSupport */
    ptCi->drbPartialInfo.e1f1Info[interfaceType].preConditionSupport = FnVCCB_IsSupportDrbPartial_PreCondition(ptCi);

    if (DBG->flag.logDrbPartial)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: interfaceType(%d) preConditionSupport(%d) requestedOption(%d)\n",
            interfaceType, ptCi->drbPartialInfo.e1f1Info[interfaceType].preConditionSupport,
            ptCi->drbPartialInfo.e1f1Info[interfaceType].requestedOption);
    }
}

void FnVCCB_SetPartialOptionBeforeSendingE1F1(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    /* Check SA Call */
    if (ptCi->callType != E_CALLTYPE_SA) return;

    switch (ptCi->stateCmd)
    {
        case RRCConnection_cmd:
        case PDUSetup_cmd:
        case PDUModify_cmd:
            ptCi->drbPartialInfo.e1f1Info[interfaceType].requestedOption = PARTIAL_OPT_ALL_SUPPORT_DRB_PARTIAL;
            return;
        case IntraRatHO_cmd: // SVR25A FGR-MC1009 FR200
        case InterRatHO_cmd: // SVR25A FGR-MC3002 FR300
            if (FnVCCB_NeedToSetPartialOptionBeforeSendingE1F1_ForHandover(*ptCi, interfaceType))
            {
                ptCi->drbPartialInfo.e1f1Info[interfaceType].requestedOption = PARTIAL_OPT_ALL_SUPPORT_DRB_PARTIAL;
            }
            return;
        case MrdcXnSNAdd_cmd: // SVR25B FGR-CC5200 FR1050
            if(IS_NRDC_SN(ptCi) && FnVCCB_IsNrdcAllowedPartialSuccess(ptCi))
            {
                ptCi->drbPartialInfo.e1f1Info[interfaceType].requestedOption = PARTIAL_OPT_ALL_SUPPORT_DRB_PARTIAL;
            }
            return;

        default:
            // PDURelease_cmd:
            // UeCtxModByNG_cmd:
            // ReconfigComplete_cmd:
            /* Using Default Action: Return Error with CallFaultSave */
            break;
    }

    return;
}

bool FnVCCB_IsModifyOrReleaseInAllDrb(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    uint8_t drbIdxInCall;
    callDRBInfo_type *ptDi = NULL;

    for (drbIdxInCall = 0; drbIdxInCall < MAX_DRB_PER_SA_CALL; drbIdxInCall++)
    {
        ptDi = &ptCi->drb[drbIdxInCall];
        if (ptDi->usage != CI_use) continue;

        if ((ptDi->drbStatus == S_Modify) || (ptDi->drbStatus == S_Release))
        {
            return true;
        }
    }

    return false;
}

// This function is called for recalulating resource and keeping going next step in that procedure when VCCB received
// E1/F1 Partial Success Response
int16_t FnVCCB_RecalculateResourceByE1F1PartialAccept(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    /* NOTE: For features that requires to rollback/recover its resources, please add an action here */
    // Common Part

    // Recalculate UE AMBR
    VCCM_DetermineSA_UE_AMBR(ptCi);
    FnVCCB_ReproduceUeAMBRforMRDC(ptCi);

    // Recalculate UE Slice MBR
    FnVCCB_DetermineSA_UE_SliceMBR(*ptCi);
    FnVCCB_ReproduceUeSliceMBRforMRDC(*ptCi, true);

    // Per Interface
    if (interfaceType == PARTIAL_INTERFACE_E1)
    {
        // TODO: All Features affected by Partial Response
        // Add Action if need
    }
    else  // PARTIAL_INTERFACE_F1
    {
        // queueing is needed as it is not possible to override measConfig which is already sent to DU
        VCCB_RETURN_ON_CALL_ERROR(ptCi, VCCM_EnqueueActionMeasReconfig(ptCi, MeasReconfigPriorAction_Full),
            "Queuing MeasReconfig in %s failed!\n", __FUNCTION__);
        // TODO: All Features affected by Partial Response
        // Add Action if need
    }
    return status;
}

int16_t FnVCCB_RollbackResourceByE1F1AllFailure(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    /* NOTE: For features that requires to rollback/recover its resources, please add an action here */
    // Common Part

    // Recalculate UE AMBR
    VCCM_DetermineSA_UE_AMBR(ptCi);
    FnVCCB_ReproduceUeAMBRforMRDC(ptCi);

    // Recalculate UE Slice MBR
    FnVCCB_DetermineSA_UE_SliceMBR(*ptCi);
    FnVCCB_ReproduceUeSliceMBRforMRDC(*ptCi, true);

    // Per Interface
    if (interfaceType == PARTIAL_INTERFACE_E1)
    {
    }
    else // PARTIAL_INTERFACE_F1
    {
        // it is assumed that new measConfig has been prepared so clear is needed
        VCCB_ClearNewMeasConfig(*ptCi, VCCB_FLAG_ON);
    }
    return status;
}

// This function is called in VLIB_setBearerStatusToIdle() after procedure is done.(Actually After Receiving RRC Reconfig Complete)
void FnVCCB_FinalizeAfterDrbPartial(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    uint8_t callPduIdx = 0;
    uint8_t callQosFlowIdx = 0;
    uint8_t callDrbIdx = 0;
    uint8_t rxPartialOrFailureMessage = VCCB_FLAG_OFF;

    if( TRUE == ptCi->drbPartialInfo.rxPartialOrFailureMessage )
    {
        rxPartialOrFailureMessage = VCCB_FLAG_ON;
    }

    /* Clear UE Drb Partial Info */
    VCCB_INIT_UE_DRB_PARTIAL_INFO(ptCi);

    /* Clear PDU/QosFow/Drb Partial Info */
    for (callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
    {
        if (ptCi->pduSess[callPduIdx].usage != CI_use) continue;

        ptCi->pduSess[callPduIdx].isBackedup = FALSE;
        ptCi->pduSess[callPduIdx].needToReconfigE1ByF1Fail = FALSE;
        ptCi->pduSess[callPduIdx].needToGetBackup = FALSE;
        ptCi->pduSess[callPduIdx].rxNotSupportSlice = VCCB_FLAG_OFF;
        ptCi->pduSess[callPduIdx].isLteFallbackTriggered = VCCB_FLAG_OFF;
    }

    for (callQosFlowIdx = 0; callQosFlowIdx < MAX_QOS_FLOW_PER_CALL; callQosFlowIdx++)
    {
        if (ptCi->qosFlow[callDrbIdx].usage != CI_use) continue;
        ptCi->qosFlow[callDrbIdx].needToReconfigE1ByF1Fail = FALSE;
        ptCi->qosFlow[callDrbIdx].rxNotSupportSlice = VCCB_FLAG_OFF;
        ptCi->qosFlow[callDrbIdx].isLteFallbackTriggered = VCCB_FLAG_OFF;
    }

    for (callDrbIdx = 0; callDrbIdx < MAX_DRB_PER_CALL; callDrbIdx++)
    {
        if (ptCi->drb[callDrbIdx].usage != CI_use) continue;
        ptCi->drb[callDrbIdx].needToReconfigE1ByF1Fail = FALSE;
        ptCi->drb[callDrbIdx].needToReconfigE1BySnFail = FALSE;
        ptCi->drb[callDrbIdx].rxNotSupportSlice = VCCB_FLAG_OFF;
        ptCi->drb[callDrbIdx].rxDuNotSupportVoNr5qi = VCCB_FLAG_OFF;
        ptCi->drb[callDrbIdx].isLteFallbackTriggered = VCCB_FLAG_OFF;
    }

    // Check Post Action if stateCmd supported DRB Partial and has rxPartial or rxFailureMessage
    if( (IS_STATECMD_SUPPORT_DRB_PARTIAL(ptCi)) && (rxPartialOrFailureMessage))
    {
        // Add Action if need
    }

    return;
}

void FnVCCB_FindModifyOrRelDrbInPduAndSetFlag(
    callInfo_type *ptCi, callPDUSessInfo_type *ptPi, VccbE1F1PartialInterface_type interfaceType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPi);

    callDRBInfo_type *ptDi = NULL;
    uint8_t pduDrbIdx = 0, callDrbIdx = 0;

    for (pduDrbIdx = 0; pduDrbIdx < MAX_DRB_PER_PDU_SESS; pduDrbIdx++)
    {
        callDrbIdx = (uint8_t)ptPi->drbIndex[pduDrbIdx];
        if (callDrbIdx >= MAX_DRB_PER_SA_CALL) continue;
        if (!IS_VALID_NODE(DRB_NODE, ptCi, &(ptCi->drb[callDrbIdx]))) continue;

        ptDi = &ptCi->drb[callDrbIdx];

        /* Check Modify */
        if ((ptDi->drbStatus == S_Modify) || (ptDi->drbStatus == S_FailToModify))
        {
            if (ptDi->firstReqStatusInThisProcedure != S_Setup)
            {
                ptCi->drbPartialInfo.e1f1Info[interfaceType].rxDrbModifyOrRelFail = TRUE;
                break;
            }
        }

        /* Check Release */
        else if ((ptDi->drbStatus == S_Release) || (ptDi->drbStatus == S_FailToRelease))
        {
            ptCi->drbPartialInfo.e1f1Info[interfaceType].rxDrbModifyOrRelFail = TRUE;
            break;
        }
    }
}

VccbExtBackup_type *FnVCCB_GetPtrOfBackupFromExtCallDB(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_NULL(ptCi);

    const uint32_t callId = ptCi->callId;

    if (IS_VALID_PTCI(ptCi) == FALSE)  // CALL DB JOB
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Call Info!! (%p, %p~%p)\n", ptCi, &ENV->callInfo[0],
            &ENV->callInfo[MAX_CALL_NUM_VCCB]);
        return NULL;
    }

    if (IS_VALID_CALLID_VCCB(callId) == false)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid Call Id(%u, 0~%u)!!\n", callId, VCCB_MAX_CALL_COUNT_PER_CPC);
        return NULL;
    }

    return &EXTERNAL_INFO.call[callId].extBackup;
}

void FnVCCB_BackupPduInfoForRollback(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VccbExtBackup_type *ptExtBackup = FnVCCB_GetPtrOfBackupFromExtCallDB(ptCi);

    for (uint8_t callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
    {
        if (ptExtBackup == NULL)
        {
            ptCi->pduSess[callPduIdx].isBackedup = FALSE;
            continue;
        }
        else
        {
            ptCi->pduSess[callPduIdx].isBackedup = TRUE;
            if (ptCi->pduSess[callPduIdx].usage == CI_use)
            {
                memcpy(&ptExtBackup->pduSess[callPduIdx], &ptCi->pduSess[callPduIdx], sizeof(callPDUSessInfo_type));
            }
            else
            {
                ptExtBackup->pduSess[callPduIdx].usage = CI_no_use;
                ptExtBackup->pduSess[callPduIdx].isBackedup = TRUE;
            }
        }
    }

    return;
}

int16_t FnVCCB_GetPduBackupForPduModifyFail(
    callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;

    VccbExtBackup_type *ptExtBackup = NULL;
    callPDUSessInfo_type *ptPi = NULL;
    callPDUSessInfo_type *ptBackupPdu = NULL;

    ptExtBackup = FnVCCB_GetPtrOfBackupFromExtCallDB(ptCi);
    if (ptExtBackup == NULL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetPtrOfBackupFromExtCallDB is NULL\n");
        return ERROR;
    }

    // Rollback Only PDU Modify Fail and needToGetBackup == TRUE
    for (uint8_t callPduIdx = 0; callPduIdx < MAX_PDU_SESS_PER_CALL; callPduIdx++)
    {
        ptPi = &ptCi->pduSess[callPduIdx];
        if (ptPi->usage != CI_use) continue;
        if (ptPi->pduSessStatus != S_FailToModify) continue;
        if (ptPi->firstReqStatusInThisProcedure == S_Setup) continue;
        if (ptPi->needToGetBackup != TRUE) continue; // Backup is done already
        if (ptPi->isBackedup != TRUE)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "PDU session not backed up. (callPduIdx=%d)\n", callPduIdx);
            return ERROR;
        }

        ptBackupPdu = &ptExtBackup->pduSess[callPduIdx];

        // Following items should be used as a current value.
        // 1. Status
        ptBackupPdu->firstReqStatusInThisProcedure = ptPi->firstReqStatusInThisProcedure;
        ptBackupPdu->prevPduSessStatus             = ptPi->prevPduSessStatus;
        ptBackupPdu->pduSessStatus                 = ptPi->pduSessStatus;

        ptBackupPdu->isSpecificSlice               = ptPi->isSpecificSlice;
        ptBackupPdu->specificSliceHasFailInNgStore = ptPi->specificSliceHasFailInNgStore;

        // 2. QosFlow/DRB Info
        ptBackupPdu->numQoSFlowPerPDUSess = ptPi->numQoSFlowPerPDUSess;
        memcpy(&ptBackupPdu->qosFlowIndex[0], &ptPi->qosFlowIndex[0], sizeof(ptPi->qosFlowIndex));
        ptBackupPdu->numDRBPerPDUSess = ptPi->numDRBPerPDUSess;
        memcpy(&ptBackupPdu->drbIndex[0], &ptPi->drbIndex[0], sizeof(ptPi->drbIndex));

        // 3. FailCause, statistics
        ptBackupPdu->pduStatistic = ptPi->pduStatistic;
        ptBackupPdu->failCause = ptPi->failCause;
        ptBackupPdu->isSavedRequestedPduParam = ptPi->isSavedRequestedPduParam;
        ptBackupPdu->requestedPduParam = ptPi->requestedPduParam;
        ptBackupPdu->rxNotSupportSlice = ptPi->rxNotSupportSlice;
        ptBackupPdu->isLteFallbackTriggered = ptPi->isLteFallbackTriggered;

        // 4. needToReconfigE1ByF1Fail, activityStatus(for Inactivity), needToResponseToAmf
        ptBackupPdu->needToReconfigE1ByF1Fail = ptPi->needToReconfigE1ByF1Fail;
        ptBackupPdu->activityStatus = ptPi->activityStatus;
        ptBackupPdu->activityStatusPrev = ptPi->activityStatusPrev;
        ptBackupPdu->needToResponseToAmf = ptPi->needToResponseToAmf;

        // 5. If it is E1 interface, use backup data,
        //    but if it is F1 interface, then use current value for E1 Modify.
        //    If pduSessAmbrPresent is False in backup, do not send E1.
        if (interfaceType == PARTIAL_INTERFACE_F1)
        {
            if (ptBackupPdu->pduSessAmbrPresent)
            {
                ptBackupPdu->fNeedModify_pduSessAmbrDL = TRUE;
                //ptBackupPdu->fNeedModify_pduSessAmbrUL = TRUE;
            }

            // UL TNL(UP Side)
            ptBackupPdu->nGuUlInfo.fNeedModify = TRUE;

            // Slice Info
            ptBackupPdu->sNssai.fNeedModify = TRUE;
        }

        // Using Old Data.
        // NR-DC snNGuDlInfo, snNGuUlInfo
        // Fowrwarding Info (Currently Not Case in InitialContextSetup/PduSessionSetup/Modify)

        // Copy Old Data to Current PDU Session Data.
        memcpy(ptPi, ptBackupPdu, sizeof(callPDUSessInfo_type));

        // Clear Flag
        ptPi->needToGetBackup = FALSE;
        ptPi->isBackedup = FALSE;
    }

    return status;
}

int16_t FnVCCB_IsSupportDrbPartial_PostCondition(
    callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, FALSE);

    // refer to FnVCCB_IsSupportDrbPartialPreCondition()
    if (ptCi->drbPartialInfo.e1f1Info[interfaceType].preConditionSupport != TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: pre condition not supported\n");
        return FALSE;
    }

    // Check NR-DC SN Modify in PDU Modification Request
    if (ptCi->drbPartialInfo.isMnNeedToModifySnBearerInPduModifyCmd == TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: SN modify not supported\n");
        return FALSE;
    }

    /* Check NR-DC add new E1 Setup, after receiving F1 Modify Failure */
    if( (interfaceType == PARTIAL_INTERFACE_F1) &&
        (ptCi->drbPartialInfo.e1f1Info[PARTIAL_INTERFACE_F1].rxFailureMessage == TRUE) &&
        (ptCi->drbPartialInfo.isNrDcMnE1Setup == TRUE))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: Nrdc MN set up new E1 while Partial Response(Not Supported)\n");
        return FALSE;
    }

    // It's for Only F1 Interface
    if (ptCi->drbPartialInfo.e1f1Info[interfaceType].rxSrbFail == TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: srb failure not supported\n");
        return FALSE;
    }

    // Check Version
    if(ptCi->drbPartialInfo.e1f1Info[interfaceType].isNotSupportSwVersion == TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: version not supported\n");
        return FALSE;
    }

    // Check Rx DRB Fail or Release Fail
    if(ptCi->drbPartialInfo.e1f1Info[interfaceType].rxDrbModifyOrRelFail == TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: drb modify or rel fail not supported\n");
        return FALSE;
    }

    // It's for Only All Failure case.
    if((ptCi->drbPartialInfo.e1f1Info[interfaceType].rxFailureMessage == TRUE) &&
       (ptCi->drbPartialInfo.reqDrbModiOrRelExist == TRUE))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: all failure case not supported\n");
        return FALSE;
    }

    // Save rxPartialOrFailureMessage.
    if((ptCi->drbPartialInfo.e1f1Info[interfaceType].rxFailureMessage == TRUE) ||
       (ptCi->drbPartialInfo.e1f1Info[interfaceType].rxPartialResponse == TRUE))
    {
        ptCi->drbPartialInfo.rxPartialOrFailureMessage = TRUE;
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: default case caused by other reason (not by partial)\n");
        return FALSE;
    }

    return TRUE;
}

#define SET_PDU_FAILCAUSE(__ptPi, __cause)     \
do                                             \
{                                              \
    if(__ptPi->failCause == CAUSE_NO_FAULT)    \
    {                                          \
        __ptPi->failCause = __cause;           \
    }                                          \
} while(0)

#define SET_DRB_FAILCAUSE(__ptDi, __cause)     \
do                                             \
{                                              \
    if(__ptDi->failCause == CAUSE_NO_FAULT)    \
    {                                          \
        __ptDi->failCause = __cause;           \
    }                                          \
} while(0)

#define SET_QOSFLOW_FAILCAUSE(__ptQi, __cause) \
do                                             \
{                                              \
    if(__ptQi->failCause == CAUSE_NO_FAULT)    \
    {                                          \
        __ptQi->failCause = __cause;           \
    }                                          \
} while(0)

void FnVCCB_SetRequestedQosDrbStatusToFailWithCause(
    callInfo_type *ptCi, callPDUSessInfo_type *ptPi, VccbE1F1PartialInterface_type interfaceType,
    uint16_t cause, uint8_t includeDRB)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPi);

    qosFlowInfo_type *ptQi = NULL;
    callDRBInfo_type *ptDi = NULL;
    uint16_t drbIdxInCall = 0;
    uint16_t qosFlowIdxInCall = 0;

    for (uint16_t qosFlowIdxInPdu = 0; qosFlowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosFlowIdxInPdu++)
    {
        qosFlowIdxInCall = ptPi->qosFlowIndex[qosFlowIdxInPdu];
        if (qosFlowIdxInCall >= MAX_QOS_FLOW_PER_CALL) continue;

        ptQi = &ptCi->qosFlow[qosFlowIdxInCall];
        if (ptQi->usage != CI_use) continue;
        if (ptQi->qosFlowStatus == S_Idle) continue;

        // Set Qos Flow Status & Cause
        switch (ptQi->qosFlowStatus)
        {
            case S_Setup:
                SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToSetup);
                SET_QOSFLOW_FAILCAUSE(ptQi, cause);
                if (interfaceType == PARTIAL_INTERFACE_F1)
                {
                    ptQi->needToReconfigE1ByF1Fail = TRUE;
                }
                break;

            case S_Modify:
                if (ptQi->firstReqStatusInThisProcedure == S_Setup)
                {
                    SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToSetup);
                }
                else
                {
                    SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToModify);
                }
                SET_QOSFLOW_FAILCAUSE(ptQi, cause);
                if (interfaceType == PARTIAL_INTERFACE_F1)
                {
                    ptQi->needToReconfigE1ByF1Fail = TRUE;
                }
                break;

            case S_Release:
                SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToRelease);
                SET_QOSFLOW_FAILCAUSE(ptQi, cause);
                break;

            default:
                break;
        }
    }

    if (includeDRB)
    {
        for (uint16_t drbIndexInPdu = 0; drbIndexInPdu < MAX_DRB_PER_PDU_SESS; drbIndexInPdu++)
        {
            drbIdxInCall = ptPi->drbIndex[drbIndexInPdu];
            if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

            ptDi = &ptCi->drb[drbIdxInCall];
            if (ptDi->usage != CI_use) continue;
            if (ptDi->drbStatus == S_Idle) continue;

            // Set DRB Status & Cause
            switch (ptDi->drbStatus)
            {
                case S_Setup:
                    SET_DRB_STATUS(ptCi, drbIdxInCall, S_FailToSetup);
                    SET_DRB_FAILCAUSE(ptDi, cause);
                    if (interfaceType == PARTIAL_INTERFACE_F1)
                    {
                        ptDi->needToReconfigE1ByF1Fail = TRUE;
                    }
                    break;

                case S_Modify:
                    if (ptDi->firstReqStatusInThisProcedure == S_Setup)
                    {
                        SET_DRB_STATUS(ptCi, drbIdxInCall, S_FailToSetup);
                    }
                    else
                    {
                        SET_DRB_STATUS(ptCi, drbIdxInCall, S_FailToModify);
                        ptCi->drbPartialInfo.e1f1Info[interfaceType].rxDrbModifyOrRelFail = TRUE;
                    }
                    SET_DRB_FAILCAUSE(ptDi, cause);
                    if (interfaceType == PARTIAL_INTERFACE_F1)
                    {
                        ptDi->needToReconfigE1ByF1Fail = TRUE;
                    }
                    break;

                case S_Release:
                    SET_DRB_STATUS(ptCi, drbIdxInCall, S_FailToRelease);
                    ptCi->drbPartialInfo.e1f1Info[interfaceType].rxDrbModifyOrRelFail = TRUE;
                    SET_DRB_FAILCAUSE(ptDi, cause);
                    break;

                default:
                    break;
            }
        }
    }

    return;
}

void FnVCCB_SetRequestedPduQosDrbStatusToFailWithCause(
    callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType, uint16_t cause, uint8_t includeDRB)
{
    AUTO_TRACE_FUNC;

    callPDUSessInfo_type *ptPi = NULL;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (uint8_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];
        if (ptPi->usage != CI_use) continue;
        if (ptPi->pduSessStatus == S_Idle) continue;

        // Set PDU Session Status & Cause
        switch (ptPi->pduSessStatus)
        {
            case S_Setup:
                SET_PDU_STATUS(ptCi, pduIdx, S_FailToSetup);
                SET_PDU_FAILCAUSE(ptPi, cause);
                if (interfaceType == PARTIAL_INTERFACE_F1)
                {
                    ptPi->needToReconfigE1ByF1Fail = TRUE;
                }
                break;

            case S_Modify:
                if (ptPi->firstReqStatusInThisProcedure == S_Setup)
                {
                    SET_PDU_STATUS(ptCi, pduIdx, S_FailToSetup);
                }
                else
                {
                    SET_PDU_STATUS(ptCi, pduIdx, S_FailToModify);
                }
                SET_PDU_FAILCAUSE(ptPi, cause);
                if (interfaceType == PARTIAL_INTERFACE_F1)
                {
                    ptPi->needToReconfigE1ByF1Fail = TRUE;
                }
                break;

            case S_Release: // actually there's no S_Release case in Partial DRB
                SET_PDU_STATUS(ptCi, pduIdx, S_FailToRelease);
                SET_PDU_FAILCAUSE(ptPi, cause);
                break;

            default:
                break;
        }

        FnVCCB_SetRequestedQosDrbStatusToFailWithCause(ptCi, ptPi, interfaceType, cause, includeDRB);
    }

    return;
}

void FnVCCB_GetFailStatusOfDrb(callInfo_type *ptCi, qosFlowInfo_type *ptQi, bool &isDrbFailed, uint16_t &drbFailCause)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptQi);

    callDRBInfo_type *ptDi = NULL;

    uint16_t drbIdxInCall = ptQi->drbIdxInCall;
    VCCB_CHECK_E_RANGE_AND_VOID(drbIdxInCall, MAX_DRB_PER_SA_CALL);

    ptDi = &ptCi->drb[drbIdxInCall];

    if (ptDi->usage != CI_use) return;

    if ((ptDi->drbStatus == S_FailToSetup) || (ptDi->drbStatus == S_FailToModify) || (ptDi->drbStatus == S_FailToRelease))
    {
        drbFailCause = ptDi->failCause;
        isDrbFailed = true;
    }

    return;
}

void FnVCCB_GetQosFailStatusAndSetStatusIfDrbFail(
    callInfo_type *ptCi, callPDUSessInfo_type *ptPi, VccbE1F1PartialInterface_type interfaceType,
    uint16_t &qosFlowReqCnt, uint16_t &qosFlowFailCnt, uint16_t &qosFlowFirstFailCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPi);

    qosFlowInfo_type *ptQi = NULL;
    bool isDrbFailed = false;
    uint16_t drbFailCause = CAUSE_NO_FAULT;
    uint16_t qosFlowIdxInCall = 0;

    for (uint8_t pduQosFlowIdx = 0; pduQosFlowIdx < MAX_QOS_FLOW_PER_PDU_SESS; pduQosFlowIdx++)
    {
        qosFlowIdxInCall = ptPi->qosFlowIndex[pduQosFlowIdx];
        if (qosFlowIdxInCall >= MAX_QOS_FLOW_PER_CALL) continue;

        ptQi = &ptCi->qosFlow[qosFlowIdxInCall];

        if ((ptQi->usage != CI_use) || (ptQi->qosFlowStatus == S_Idle)) continue;

        qosFlowReqCnt++;
        isDrbFailed = false;
        drbFailCause = CAUSE_NO_FAULT;

        switch (ptQi->qosFlowStatus)
        {
            case S_Setup:
            case S_Modify:
                {
                    FnVCCB_GetFailStatusOfDrb(ptCi, ptQi, isDrbFailed, drbFailCause);
                    if (isDrbFailed)
                    {
                        qosFlowFailCnt++;

                        if (ptQi->firstReqStatusInThisProcedure == S_Setup)
                        {
                            SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToSetup);
                            if (interfaceType == PARTIAL_INTERFACE_F1)
                            {
                                ptQi->needToReconfigE1ByF1Fail = TRUE;
                                ptPi->needToReconfigE1ByF1Fail = TRUE;
                            }
                        }
                        else
                        {
                            SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToModify);
                            if (interfaceType == PARTIAL_INTERFACE_F1)
                            {
                                ptQi->needToReconfigE1ByF1Fail = TRUE;
                                ptPi->needToReconfigE1ByF1Fail = TRUE;
                            }
                        }

                        ptQi->failCause = drbFailCause;
                        if ((qosFlowFirstFailCause == CAUSE_NO_FAULT) && (ptQi->failCause != CAUSE_NO_FAULT))
                        {
                            qosFlowFirstFailCause = ptQi->failCause;
                        }
                    }
                }
                break;

            case S_Release:
                {
                    FnVCCB_GetFailStatusOfDrb(ptCi, ptQi, isDrbFailed, drbFailCause);
                    if (isDrbFailed)
                    {
                        qosFlowFailCnt++;

                        SET_QOSFLOW_STATUS(ptCi, qosFlowIdxInCall, S_FailToRelease);
                        if(interfaceType == PARTIAL_INTERFACE_F1)
                        {
                            ptQi->needToReconfigE1ByF1Fail = TRUE;
                            ptPi->needToReconfigE1ByF1Fail = TRUE;
                        }

                        ptQi->failCause = drbFailCause;
                        if ((qosFlowFirstFailCause == CAUSE_NO_FAULT) && (ptQi->failCause != CAUSE_NO_FAULT))
                        {
                            qosFlowFirstFailCause = ptQi->failCause;
                        }
                    }
                }
                break;

            case S_FailToSetup:
            case S_FailToModify:
            case S_FailToRelease:
                qosFlowFailCnt++;

                if ((qosFlowFirstFailCause == CAUSE_NO_FAULT) && (ptQi->failCause != CAUSE_NO_FAULT))
                {
                    qosFlowFirstFailCause = ptQi->failCause;
                }
                break;

            default:
                break;
        }
    }

    return;
}

int16_t FnVCCB_RearrangePduQosDrbStatusByPartialResponse(
    callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    callPDUSessInfo_type *ptPi = NULL;

    uint16_t pduSessionCntReq = 0;
    uint16_t pduSessionCntFail = 0;

    uint16_t qosFlowReqCnt = 0;
    uint16_t qosFlowFailCnt = 0;
    uint16_t qosFlowFirstFailCause = CAUSE_NO_FAULT;

    for (uint8_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];

        if ((ptPi->usage != CI_use) || (ptPi->pduSessStatus == S_Idle)) continue;

        pduSessionCntReq++;

        qosFlowReqCnt = 0;
        qosFlowFailCnt = 0;
        qosFlowFirstFailCause = CAUSE_NO_FAULT;

        switch (ptPi->pduSessStatus)
        {
            case S_Setup:
            case S_Modify:
            {
                FnVCCB_GetQosFailStatusAndSetStatusIfDrbFail(ptCi, ptPi, interfaceType, qosFlowReqCnt, qosFlowFailCnt, qosFlowFirstFailCause);

                // If All Failure of QosFlow, then change PDU Status.
                if ((qosFlowReqCnt > 0) && (qosFlowReqCnt <= qosFlowFailCnt))
                {
                    pduSessionCntFail++;

                    if (ptPi->firstReqStatusInThisProcedure == S_Setup)
                    {
                        SET_PDU_STATUS(ptCi, pduIdx, S_FailToSetup);
                        if (interfaceType == PARTIAL_INTERFACE_F1)
                        {
                            ptPi->needToReconfigE1ByF1Fail = TRUE;
                        }
                    }
                    else
                    {
                        SET_PDU_STATUS(ptCi, pduIdx, S_FailToModify);
                        ptPi->needToGetBackup = TRUE; // Need to Rollback from backup PDU.
                        if (interfaceType == PARTIAL_INTERFACE_F1)
                        {
                            ptPi->needToReconfigE1ByF1Fail = TRUE;
                        }
                    }

                    ptPi->failCause = qosFlowFirstFailCause;
                }
            }
            break;

            case S_FailToSetup:
            case S_FailToModify:
                pduSessionCntFail++;
                FnVCCB_SetRequestedQosDrbStatusToFailWithCause(ptCi, ptPi, interfaceType, ptPi->failCause, VCCB_FLAG_ON);
                break;

            case S_FailToRelease:
                pduSessionCntFail++;

            default: // No action for S_Release
                break;
        }
    }

    if ((pduSessionCntReq > 0) && (pduSessionCntReq <= pduSessionCntFail))
    {
        if (DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: all E1/F1 requests are failed\n");
        }
        return BREAK;
    }
    return GOOD;
}

int16_t FnVCCB_DecideRollbackAndRearrangeDbForDrbPartial(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t status = GOOD;
    uint16_t cause = ptCi->drbPartialInfo.e1f1Info[interfaceType].finalFailCause;
    bool doMoreOperation = true;

    // Stage_1.
    // 1. Check Post Condition.
    if (FnVCCB_IsSupportDrbPartial_PostCondition(ptCi, interfaceType) != TRUE)
    {
        if (DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: post condition not supported\n");
        }
        return ERROR;
    }

    // 2. ReArrange PDU/QosFlow/DRB (Also check remain operation)
    if (ptCi->drbPartialInfo.e1f1Info[interfaceType].rxFailureMessage == TRUE) // receive failure message
    {
        // Set all PDU/QosFlow/DRB fail
        FnVCCB_SetRequestedPduQosDrbStatusToFailWithCause(ptCi, interfaceType, cause, VCCB_FLAG_ON);
        doMoreOperation = false;
    }
    else // receive response(partial) message
    {
        status = FnVCCB_RearrangePduQosDrbStatusByPartialResponse(ptCi, interfaceType);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RearrangePduQosDrbStatusByPartialResponse ERROR!\n");
        if (status == BREAK)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "All E1/F1 requests are failed.. Should be sent as failure in %s!\n", __FUNCTION__);
            return ERROR;
        }
    }

    // 3. Check Again Modify or Rel Fail after rearrange DRB.
    if (ptCi->drbPartialInfo.e1f1Info[interfaceType].rxDrbModifyOrRelFail == TRUE)
    {
        if (DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: drb modify or rel fail not supported\n");
        }
        return ERROR;
    }

    // 4. Check (VoNR, SpecificSlice) Fail Conditionin // It should be after Rearrange QosFlow
    status = FnVCCB_CheckFailCond_InterRatHoOrRedirection(ptCi, ptCi->recentMsgId, CheckHoOrRedirect_OnPartialState);
    if (status == STATE_NEED_REDIRECTION)
    {
        if (DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: satisfy fallback condition and do redirection instead\n");
        }
        return ERROR;
    }

    // Stage_2.
    // If PDU status is S_FailToSetup or S_FailToModify, remove NAS message
    VLIB_CancelNasPduByFailedPDU(ptCi);

    // If PDU status is S_FailToModify and needRollback is ON, then recover PDU with backup Data.
    status = FnVCCB_GetPduBackupForPduModifyFail(ptCi, interfaceType);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_GetPduBackupForPduModifyFail ERROR in %s!\n", __func__);

    MACRO_RESET_CALL_FAULT_CAUSES;

    // If F1 Interface, Recover value of ptCi->dssCauseRelease.
    if ((interfaceType == PARTIAL_INTERFACE_F1) &&
        (ptCi->drbPartialInfo.e1f1Info[interfaceType].rxFailureMessage == TRUE))
    {
        ptCi->dssCauseRelease = ptCi->drbPartialInfo.e1f1Info[interfaceType].oldDssCauseRelease;
    }

    if (doMoreOperation)
    {
        status = FnVCCB_RecalculateResourceByE1F1PartialAccept(ptCi, interfaceType);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RecalculateResourceByE1F1PartialAccept ERROR(interface=%d)\n", interfaceType);
        return GOOD;
    }
    else
    {
        status = FnVCCB_RollbackResourceByE1F1AllFailure(ptCi, interfaceType);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_RollbackResourceByE1F1AllFailure ERROR(interface=%d)\n", interfaceType);
        return STOP_AND_ROLLBACK;
    }
}

int16_t FnVCCB_DecideRollbackAndRearrangeDbForDrbPartialForNrdcSn(callInfo_type *ptCi, VccbE1F1PartialInterface_type interfaceType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    // refer to FnVCCB_IsSupportDrbPartial_PreCondition()
    if (ptCi->drbPartialInfo.e1f1Info[interfaceType].preConditionSupport != TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: pre condition not supported\n");
        return ERROR;
    }

    // It's for Only F1 Interface
    if (ptCi->drbPartialInfo.e1f1Info[interfaceType].rxSrbFail == TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Partial DRB: srb3 failure is not supported\n");
        return ERROR;
    }

    ptCi->drbPartialInfo.rxPartialOrFailureMessage = TRUE;

    int16_t status = FnVCCB_RearrangePduQosDrbStatusByPartialResponse(ptCi, interfaceType);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_RearrangePduQosDrbStatusByPartialResponse Error!\n");
        return ERROR;
    }
    else if (status == BREAK)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "All E1/F1 requests are failed.. Should be sent as failure in %s!\n", __FUNCTION__);
        return ERROR;
    }

    /** 
     * T.B.D.
     * Need to review resources, DB in NRDC SN requiring recalculation due to DRB Partial failure
     * (e.g., MeasConfig, CA...)
    **/

    MACRO_RESET_CALL_FAULT_CAUSES;

    return GOOD;
}

/**
 * @brief     Triggers SgNB Initiated SN Release of UE due to Cell/gNB/ACPF/CPC switch off
 *            or MIB cellBarred case for UEs that were conditionally attached after switch off.
 * @param     ptCi  : temporary call context
 * @return    GOOD/ERROR
 */
int16_t VLIB_SgNBInitiatedSnReleaseDueToSwitchOff(callInfo_type *ptCi, const uint32_t msgId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    MACRO_CALL_FAULT_SAVE(msgId, CauseCpInternalOMIntervention);
    ptCi->cause.x2Cause = CauseX2apRadioNetworkLayerSwitchOffOngoing;

    int16_t status = VXIL_sendX2_SgNBReleaseRequired(ptCi, STAT_SGNB_INIT_SGNB_REL_PER_GNB, FALSE);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "send VXIL_sendX2_SgNBReleaseRequired ERROR!\n");
        return ERROR;
    }
    VLIB_SetCurStateAll(ptCi, STATE_DCSNRelRqrd);
    VLIB_AttachTimer(&ptCi->timer, ptCi, timX2_SgNBReleaseConfirm_id);

    return GOOD;
}

bool FnVCCB_IsRfspBasedBlindInterRatRedirection(callInfo_type *ptCi, uint16_t cellNum, enumInterRatRedirectionForcedOption_type &redirectionMethod)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    rfspBasedCtrl_type *pRfsp = NULL;

    // 1. Check if the UE served PLMN and RFSP are registered in the rfsp list.
    if (GOOD != VCCB_GetRfspControlInfo(ptCi, cellNum, ptCi->ueInfo.servedPlmn, ptCi->ueInfo.rfsp.indexToRFSP, &pRfsp))
    {
        return false;
    }

    if (NULL == pRfsp) return false;

    // 2. Check whether Blind Inter-RAT Redirection is supported for the RFSP.
    // supportMeasInterRatRedirection has higher priority than supportBlindInterRatRedirection.
    if ((TRUE == pRfsp->controlOptionExt.supportMeasInterRatRedirection) ||
        (TRUE == pRfsp->controlOptionExt.supportBlindInterRatRedirection))
    {
        // Check Firstly supportMeasInterRatRedirection (higher priority than supportBlindInterRatRedirection)
        if(TRUE == pRfsp->controlOptionExt.supportMeasInterRatRedirection)
        {
            redirectionMethod = Redirection_Forced_MrBased; // MrBased
        }
        else
        {
            redirectionMethod = Redirection_Forced_Blind; // Blind
        }


        if(pGnb->yangTimer.internalIratRedirectTimeForAccessControl == 0)
        {
            redirectionMethod = Redirection_Forced_Blind; // Blind
            ptCi->bitFlag.rfspBlindRedirectionWithOutTimer = VCCB_FLAG_ON;
        }
        return true;
    }

    return false;
}

bool FnVCCB_IsNeedToReconfigE1ByF1Partial(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    for (const auto &pduSession : ptCi->pduSess)
    {
        if (pduSession.usage != CI_use) continue;
        if (pduSession.needToReconfigE1ByF1Fail == TRUE) return true;
    }
    return false;
}

void FnVCCB_SortNrCaControlIndex(VccbGnbInfo_type &rGnb)
{
    AUTO_TRACE_FUNC;

    struct CaControlSort_type
    {
        uint8_t priority;
        uint8_t index;
    };

    CaControlSort_type caControlSortList[MAX_NR_CA_CONTROL_ENTRIES];

    for(uint8_t index = 0; index < MAX_NR_CA_CONTROL_ENTRIES; ++index)
    {
        const auto &rNrCaControlEntry = rGnb.carrierAggregationInfo.nrCaControlEntries[index];
        caControlSortList[index].priority = rNrCaControlEntry.caIndexPriority;
        caControlSortList[index].index = index;
    }

    // 1. Priority: decending order
    // 2. Index: ascending order
    std::sort(caControlSortList, caControlSortList+MAX_NR_CA_CONTROL_ENTRIES,
            [](const CaControlSort_type &lhs, const CaControlSort_type &rhs)
            {
                if((lhs.priority > rhs.priority) || ((lhs.priority == rhs.priority) && (lhs.index < rhs.index)))
                {
                    return true;
                }

                return false;
            });

    for(uint8_t index = 0; index < MAX_NR_CA_CONTROL_ENTRIES; ++index)
    {
        auto &rSortIdx = rGnb.carrierAggregationInfo.nrCaControlSortIdx[index];
        rSortIdx = caControlSortList[index].index;
    }
}

// SVR25A FGR-MC1009 FR200
bool FnVCCB_IsVoNRFailedByPartialDRB(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    uint8_t fiveQi;
    uint16_t qosFlowIdx;

    qosFlowInfo_type *ptQi = NULL;
    callDRBInfo_type *ptDi = NULL;
    callPDUSessInfo_type *ptPi = NULL;

    for (qosFlowIdx = 0; qosFlowIdx < MAX_QOS_FLOW_PER_CALL; qosFlowIdx++)
    {
        ptQi = &rCall.qosFlow[qosFlowIdx];
        if (ptQi->usage != CI_use) continue;

        VLIB_getFiveQi(ptQi, &fiveQi);
        if (fiveQi == VONR_5QI) break;
    }

    if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL)
    {
        return false;
    }

    ptQi = &rCall.qosFlow[qosFlowIdx];
    if (ptQi->drbIdxInCall >= MAX_DRB_PER_SA_CALL)
    {
        return false;
    }

    ptDi = &rCall.drb[ptQi->drbIdxInCall];

    if (ptDi->usage == CI_use && ptDi->drbStatus == S_FailToSetup)
    {
        if(DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(&rCall, "Partial DRB: 5QI#1 Info (stateCmd:%d, qosIdx:%d, drbIdx:%d, drbStatus:%d)\n",
                rCall.stateCmd, qosFlowIdx, ptQi->drbIdxInCall, ptDi->drbStatus);
        }

        return true;
    }

    if (ptDi->pduIdxInCall >= MAX_PDU_SESS_PER_CALL)
    {
        return false;
    }

    ptPi = &rCall.pduSess[ptDi->pduIdxInCall];

    if (ptPi->usage == CI_use && ptPi->pduSessStatus == S_FailToSetup)
    {
        if(DBG->flag.logDrbPartial)
        {
            VCCB_PRINT_CALL_INFORMATIVE(&rCall, "Partial DRB: 5QI#1 Info (stateCmd:%d, qosIdx:%d, drbIdx:%d, pduIdx:%d, drbStatus:%d, pduSessStatus:%d)\n",
                rCall.stateCmd, qosFlowIdx, ptQi->drbIdxInCall, ptDi->pduIdxInCall, ptDi->drbStatus, ptPi->pduSessStatus);
        }

        return true;
    }

    return false;
}

int16_t FnVCCB_Decide_QosMonitoringInfo_ForDrbQos(callInfo_type *ptCi, callDRBInfo_type *ptDi, enumQosMonitoringRequest_type* output)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDi);
    VALID_E_POINT_CHECK_ERROR(output);

    // Initialize temp to QOS_MONITORING_REQUEST_STOP
    enumQosMonitoringRequest_type val = QOS_MONITORING_REQUEST_STOP;
    bool EnableDrbQosMonitoring = false;

    for (uint8_t i = 0; i < MAX_QOS_FLOW_PER_DRB; i++)
    {
        uint16_t qosFlowIdx = ptDi->qosFlowIndex[i];
        if(qosFlowIdx >= MAX_QOS_FLOW_PER_CALL) continue;
        
        qosFlowInfo_type *qosFlowInfo = &ptCi->qosFlow[qosFlowIdx];
        if(qosFlowInfo->usage != CI_use) continue;
        if (VLIB_IsCommonValidStateOfPduQosDrbForQosMonitoring(qosFlowInfo->qosFlowStatus) == ERROR) continue;
        if(qosFlowInfo->qosParam.qosMonitoringRequestPresent)
        {
            EnableDrbQosMonitoring = true;
            switch (qosFlowInfo->qosParam.qosMonitoringRequest)
            {
                case QOS_MONITORING_REQUEST_BOTH:
                    val = QOS_MONITORING_REQUEST_BOTH;
                    goto DECIDE_AND_RETURN;
                case QOS_MONITORING_REQUEST_DL:
                    if (val == QOS_MONITORING_REQUEST_UL)
                    {
                        val = QOS_MONITORING_REQUEST_BOTH;
                        goto DECIDE_AND_RETURN;
                    }
                    else
                    {
                        val = QOS_MONITORING_REQUEST_DL;
                    }
                    break;
                case QOS_MONITORING_REQUEST_UL:
                    if (val == QOS_MONITORING_REQUEST_DL)
                    {                    
                        val = QOS_MONITORING_REQUEST_BOTH;
                        goto DECIDE_AND_RETURN;
                    }
                    else
                    {
                        val = QOS_MONITORING_REQUEST_UL;
                    }                        
                    break;
                case QOS_MONITORING_REQUEST_STOP:
                    // Do nothing, as we only care about the first non-stop value
                    break;
                default:
                    VCCB_PRINT_CALL_ERROR(ptCi, "Fail to set DrbQos::Invalid QosMonitoring(%d)\n", qosFlowInfo->qosParam.qosMonitoringRequest);
                    return ERROR;
            }
        }
    }

    DECIDE_AND_RETURN:
    // No qosMonitoringRequestPresent Qosflows
    if((EnableDrbQosMonitoring == false) && (ptDi->qosMonitorActivated == false))
    {
        *output = QOS_MONITORING_REQUEST_NOT_PRESENT;
        return GOOD;
    }

    *output = val;
    return GOOD;
}

/**
 * @brief    Determine the QoS monitoring request for a QosFlow based on its QoS monitoring parameters.
 * @param    rCall - A constant reference to a callInfo_type structure representing the call information.
 * @param    rQos - A constant reference to a qosFlowLevelQoSParam_type structure representing the QoS flow information.
 * @return   Returns an enumQosMonitoringRequest_type value indicating the QoS monitoring request for the QoS flow.
 */
enumQosMonitoringRequest_type FnVCCB_Determine_QosMonitoringRequest_For_QosFlow(
    const callInfo_type &rCall, const qosFlowLevelQoSParam_type &rQos)
{
    AUTO_TRACE_FUNC;
    if (rQos.qosMonitoringRequestPresent == OPT_PRESENT)
    {
        if (rQos.qosMonitoringRequest < QOS_MONITORING_REQUEST_STOP)  // UL, DL, Both
        {
            if (IS_GNB_SUPPORT_QOS_MONITORING(rCall.gnbNum))
            {
                return rQos.qosMonitoringRequest;
            }
        }
        else if (rQos.qosMonitoringRequest == QOS_MONITORING_REQUEST_STOP)
        {
            return QOS_MONITORING_REQUEST_STOP;
        }
    }

    return QOS_MONITORING_REQUEST_NOT_PRESENT;
}

/**
 * @brief    Determine the QoS monitoring request for a DRB based on its QoS monitoring parameters.
 * @param    rCall - A constant reference to a callInfo_type structure representing the call information.
 * @param    rDrb - A constant reference to a callDRBInfo_type structure representing the DRB information.
 * @return   Returns an enumQosMonitoringRequest_type value indicating the QoS monitoring request for the DRB.
 */
enumQosMonitoringRequest_type FnVCCB_Determine_QosMonitoringRequest_For_DRB(
    const callInfo_type &rCall, const callDRBInfo_type &rDrb)
{
    AUTO_TRACE_FUNC;
    if (rDrb.drbQosMonitoring < QOS_MONITORING_REQUEST_STOP)  // ul,dl,both && YANG On
    {
        if (IS_GNB_SUPPORT_QOS_MONITORING(rCall.gnbNum))
        {
            return rDrb.drbQosMonitoring;
        }
    }
    else if (rDrb.drbQosMonitoring == QOS_MONITORING_REQUEST_STOP)  // when stop is requested, Yang is not considered.
    {
        return QOS_MONITORING_REQUEST_STOP;
    }

    return QOS_MONITORING_REQUEST_NOT_PRESENT;
}

/**
 * @brief Determine the QoS monitoring request for a DRB based on its term point-based QoS parameters.
 * @param    rCall - A constant reference to a callInfo_type structure representing the call information.
 * @param    rDrb - A constant reference to a callDRBInfo_type structure representing the DRB information.
 * @return   Returns an enumQosMonitoringRequest_type value indicating the QoS monitoring request for the term
 * point-based DRB.
 */
enumQosMonitoringRequest_type FnVCCB_Determine_QosMonitoringRequest_For_TermPointBasedDRB(
    const callInfo_type &rCall, const callDRBInfo_type &rDrb)
{
    AUTO_TRACE_FUNC;
    const qosFlowLevelQoSParam_type &rQos = rDrb.termPointBasedDrbQos;

    if (rQos.qosMonitoringRequestPresent == OPT_PRESENT)
    {
        if (rQos.qosMonitoringRequest == QOS_MONITORING_REQUEST_STOP)
        {
            return QOS_MONITORING_REQUEST_STOP;
        }
        else
        {
            // Even if the peer node sends a request to enable QoS monitoring, it will not be enabled if the Yang
            // configuration is turned off.
            if (IS_GNB_SUPPORT_QOS_MONITORING(rCall.gnbNum))
            {
                return rQos.qosMonitoringRequest;
            }
        }
    }
    else
    {
        if (rDrb.isInSetupList == TRUE && rDrb.qosMonitorActivated == TRUE)
        {
            // If the current node is in the process of setting up a split leg(isInSetupList == TRUE), and
            // qosMonitoring was activated(qosMonitorActivated == TRUE), then the QoS monitoring should be stopped, so
            // QOS_MONITORING_REQUEST_STOP should be sent to DU.
            return QOS_MONITORING_REQUEST_STOP;
        }
    }
    return QOS_MONITORING_REQUEST_NOT_PRESENT;
}

/**
 * @brief    This function checks whether QoS monitoring is activated for a given DRB.
 * @param[in] ptCi Pointer to the call information structure.
 * @param[in] ptDi Pointer to the DRB information structure.
 * @return   Returns true if QoS monitoring is activated for the DRB, otherwise returns false.
 */
bool FnVCCB_IsDrbQosMonitoringActivated(const callInfo_type *ptCi, const callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptDi);

    if (IS_TERM_POINT_ON_PEER_NODE(ptCi, ptDi))
    {
        if (ptDi->termPointBasedDrbQos.qosMonitoringRequestPresent == OPT_PRESENT &&
            ptDi->termPointBasedDrbQos.qosMonitoringRequest < QOS_MONITORING_REQUEST_STOP)
        {
            return true;
        }
    }
    else  // In Basic SA or in NR-DC when term point is current node
    {
        if (ptDi->drbQosMonitoring < QOS_MONITORING_REQUEST_STOP)
        {
            return true;
        }
    }
    return false;
}

int16_t FnVCCB_HasVoiceRequest_InPduSessionSetupReq(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_CollectPduQosFlow_ForPduSessionSetupRejectAll(ptCi, ptUnpack, PDU_MSG_CHECK_VOICE);

    return status;
}

int16_t FnVCCB_HasVoiceRequest_InPduSessionModifyReq(callInfo_type *ptCi, msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    int16_t status = GOOD;

    status = FnVCCB_CollectPduQosFlow_ForPduSessionModifyRejectAll(ptCi, ptUnpack, PDU_MSG_CHECK_VOICE);

    return status;
}

int16_t FnVCCB_HasVoiceRequestInMsg(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptAll);
    VALID_E_POINT_CHECK_FALSE(ptUnpack);

    // Set Off
    ptCi->bitFlag.hasVoiceInRequestMsg = VCCB_FLAG_OFF;

    // Find 5QI=1 in Msg.
    switch (ptUnpack->msgId)
    {
        case NG_PDUSessionResourceSetupRequest_id:
            if (FnVCCB_HasVoiceRequest_InPduSessionSetupReq(ptCi, ptUnpack) != GOOD)
            {
                return FALSE;
            }
            break;
        case NG_PDUSessionResourceModifyRequest_id:
            if (FnVCCB_HasVoiceRequest_InPduSessionModifyReq(ptCi, ptUnpack) != GOOD)
            {
                return FALSE;
            }
            break;

        default:
            break;
    }

    if (ptCi->bitFlag.hasVoiceInRequestMsg == VCCB_FLAG_ON)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/**
 * @brief Checks if Partial HO Allow is enabled for a given call.
 * 
 * @param rCall Reference to the call information structure.
 * @return bool Returns true if Partial HO Allow is enabled, otherwise false.
 */
bool FnVCCB_IsPartialHoAllowEnabled(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, false);
    const gnbConfig_type &rGnbConfig = GNBINFO[rCall.gnbNum].cfg;

    if (IS_NRDC(&rCall))
    {
        if (rGnbConfig.nrdc.supportPartialSuccess == disabled) return false;
    }

    return (rGnbConfig.gnbMobilityConfig.partialSuccessForMultipleDrbEnabled == TRUE);
}

/**
 * @brief Determines whether partial response option should be set before sending E1/F1 messages during handover.
 * 
 * This function is called every time an E1/F1 message is sent to decide whether to allow partial responses.
 *
 * @param rCall Reference to the call information structure.
 * @param interfaceType Type of interface (E1, F1, etc.).
 * @return true if partial response option should be set, false otherwise.
 */
bool FnVCCB_NeedToSetPartialOptionBeforeSendingE1F1_ForHandover(callInfo_type &rCall, uint8_t interfaceType)
{
    AUTO_TRACE_FUNC;

    if (rCall.stateCmd != IntraRatHO_cmd && rCall.stateCmd != InterRatHO_cmd) return false;

    // Check Yang parameter
    if (not FnVCCB_IsPartialHoAllowEnabled(rCall)) return false;

    // Check based on scenario; It can be changed to FALSE during HO
    if (rCall.hoInfo.currentlyAllowPartial != TRUE) return false;

    // Check based on interface
    switch (interfaceType)
    {
        case PARTIAL_INTERFACE_E1:
            if (!GET_E1_RESOURCE_FLAG(rCall.flag.setupFlag)) // UP setup -> allow
            {
                return true;
            }
            break;

        case PARTIAL_INTERFACE_F1:
            if (rCall.hoInfo.hoType.nb == HO_TYPE_INTER_NB)
            {
                if (!GET_F1_RESOURCE_FLAG(rCall.flag.setupFlag)) // DU setup -> allow
                {
                    return true;
                }
            }
            else
            {
                if (rCall.hoInfo.hoType.du == HO_TYPE_INTER_DU && rCall.state == STATE_INTER_DU_Prepare)
                {
                    return true;    //  Inter-DU Handover, DU setup -> allow
                }
                
                if (rCall.hoInfo.hoType.du == HO_TYPE_INTRA_DU && rCall.state == STATE_INTRA_DU_Prepare)
                {
                    return true;    // Intra-DU Handover, DU modify -> allow
                }
            }
            break;
        
        default:
            break;
}

    return false;
}

bool FnVCCB_IsSecurityProcedureDone(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    VccbDbgInfo_type *pDbg = DBG;

    // isNeedSecurityFlow
    // When Sending RRCSetup, set it as TRUE
    // When Sending SecurityModeCommand, set is as FALSE
    if(ptCi->bitFlag.isNeedSecurityFlow != FALSE)
    {
        return false;
    }

    if(GET_SECURITY_MODE_CMD_FLAG(ptCi->flag.respFlag))
    {
        if((pDbg->flag.sendSecuModeCmdInF1CtxtSetupReq == VCCB_FLAG_OFF) &&
           (pDbg->flag.needSecurityModeCompleteForRedirection == VCCB_FLAG_OFF))
        {
            // It is handled as OK since 25B. So No Action here.
            // It can be handled by Debug Command.
        }
        else
        {
            return false;
        }
    }

#ifdef IPC_TEST
    // No Check SECURITY_IDLE in IPC_TEST (GTEST only)
    if(ptCi->checker.rxSecurityFailure) return FALSE;
#else
    if(ptCi->security.pdcpCtx.securityInfo.mode == SECURITY_IDLE)
    {
        return false;
    }
#endif

    return true;
}

enumSpecificSliceAwareOption_type FnVCCB_GetSpecificSliceAwareOption(uint16_t gnbNum)
{
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, specificSliceAwareOption_lteOnly);
    specificSliceConfig_type *pSpecificSlice = &GNBINFO[gnbNum].cfg.gnbMobilityConfig.sliceAware.specificSliceConfig;
    
    if (pSpecificSlice->modeOption > specificSliceAwareOption_nrFirst)
        return specificSliceAwareOption_lteOnly;

    return static_cast<enumSpecificSliceAwareOption_type>(pSpecificSlice->modeOption);
}

/**
 * @brief Checks if a specific slice with the given SST/SD is configured and active for the call's gNB.
 * 
 * @param rCall Reference to call information containing the gNB index.
 * @param sstSd Combined SST and SD value identifying the target slice.
 * @return true If an active slice with the matching SST/SD is found.
 * @return false If no such slice exists or configurations are inactive.
 */
bool FnVCCB_IsSpecificSlice(callInfo_type &rCall, uint32_t sstSd) //FGR-CC3101, FGR-CC0102, FGR-CC0103, FGR-MC1021
{
    AUTO_TRACE_FUNC;
    
    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, false);
    VccbGnbInfo_type *pGnb = &GNBINFO[rCall.gnbNum];
    specificSliceConfig_type *pSliceConfig = &pGnb->cfg.gnbMobilityConfig.sliceAware.specificSliceConfig;

    if (pSliceConfig->usage != CI_use) return false;

    for (auto index = 0; index < MAX_SPECIFIC_SLICE_INFO_ENTRIES; index++)
    {
        auto rSlice = pSliceConfig->sliceInfo[index];
        
        if (rSlice.usage != CI_use) continue;

        if (rSlice.sstSd == sstSd) return true;
    }

    return false;    
}

/**
 * @brief Handles specific slice border mobility blind redirection for inter-RAT calls.
 * 
 * This function processes inter-RAT redirection by selecting an EARFCN and determining
 * the redirection status. If successful, it updates redirection info and triggers RRC release.
 * Otherwise, it initiates call release. Contains TODO for handling measurement report cases.
 * 
 * @param ptCi Pointer to call information structure
 * @param msgId Message identifier for tracking
 * @return int16_t Redirection status (GOOD or error code)
 */
int16_t FnVCCB_SpecificSliceForcedMobilityBlindRedirection(callInfo_type *ptCi, uint16_t msgId) //FGR-CC3101, FGR-CC0102, FGR-CC0103, FGR-MC1021
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    auto processInterRATRedirection = [ptCi, msgId]()
    {
        if (SelectEARFCN_ForInterRATRedirection(ptCi, Redirection_Forced_Blind) == GOOD) 
        {
            ptCi->redirectionInfo.isSpecificSliceRejected = TRUE;
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Blind Redir to EUTRA procedure has begun by specific slice rejection!!\n");

            return VCCM_RedirectionByRRCReleaseTrigger(ptCi, msgId);
        }
        else
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Call Release procedure has started!!\n");

            return VCCB_CALL_RELEASE_TRIGGER(ptCi);
        }
    };

    // MR based redirection (26A~)
    if (ptCi->redirectionInfo.redirType == INTER_RAT_REDIRECTION)
    {
        ptCi->redirectionInfo.isSpecificSliceRejected = TRUE;
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "MR based Redir(%d/%d) to EUTRA procedure has begun by specific slice rejection!!\n",
            ptCi->redirectionInfo.rat.eutra.carrierFreq, ptCi->redirectionInfo.rat.eutra.overlappedCarrierFreq);

        return VCCM_RedirectionByRRCReleaseTrigger(ptCi, msgId);
    }

    // blind redirection (25B~)
    return processInterRATRedirection();
}

/**
 * @brief     Set the rxNotSupportSlice flag for all PDU sessions in the call.
 * @param     ptCi : Pointer to the callInfo structure
 * @details   This function iterates through all PDU sessions associated with the call and calls 
 *            FnVCCB_SetRxNotSupportSlicePerPDU for each session to set the rxNotSupportSlice flag.
 */
void FnVCCB_SetRxNotSupportSliceForAllSetupPDU(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t pduIdx;

    // Check 5QI(==1) which is set/modified
    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        FnVCCB_SetRxNotSupportSlicePerPDU(ptCi, pduIdx);
    } // for PDU
}

/**
 * @brief     Set the rxNotSupportSlice flag for a specific PDU session.
 * @param     ptCi : Pointer to the callInfo structure
 * @param     pduIdx : Index of the PDU session within the call.
 * @details   This function checks the status of the PDU session, its associated QoS flows, and DRBs. 
 *            If any of them are in Setup or Modify status and their first request status is Setup, 
 *            it sets the rxNotSupportSlice flag for the PDU session, QoS flow, or DRB.
 */
void FnVCCB_SetRxNotSupportSlicePerPDU(callInfo_type *ptCi, uint16_t pduIdx)
{
    VCCB_CALL_CHECK_RANGE_AND_RETURN_VOID(ptCi, pduIdx, MAX_PDU_SESS_PER_CALL, "pduIdxInCall");

    callPDUSessInfo_type *ptPi = &ptCi->pduSess[pduIdx];
    qosFlowInfo_type *ptQi = NULL;
    callDRBInfo_type *ptDi = NULL;

    uint16_t qosFlowIdxInPdu;
    uint16_t qosFlowIdxInCall;
    uint16_t drbIndexInPdu;
    uint16_t drbIdxInCall;


    if (ptPi->usage != CI_use) return;

    // Check PDU Session status :  Setup, Modify
    if ((ptPi->pduSessStatus != S_Setup) && (ptPi->pduSessStatus != S_Modify) ) return;

    if ((ptPi->firstReqStatusInThisProcedure == S_Setup) ||
        (ptPi->firstReqStatusInThisProcedure == S_Modify))
    {
        // Set rxNotSupportSlice
        ptPi->rxNotSupportSlice = VCCB_FLAG_ON;
    }

    // QosFlow
    for (qosFlowIdxInPdu = 0; qosFlowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosFlowIdxInPdu++)
    {
        qosFlowIdxInCall = ptPi->qosFlowIndex[qosFlowIdxInPdu];
        if (qosFlowIdxInCall >= MAX_QOS_FLOW_PER_CALL) continue;

        ptQi = &ptCi->qosFlow[qosFlowIdxInCall];
        if (ptQi->usage != CI_use) continue;

        if((ptQi->qosFlowStatus != S_Setup) && (ptQi->qosFlowStatus != S_Modify) ) continue;
        if(ptQi->firstReqStatusInThisProcedure != S_Setup) continue;

        // Set rxNotSupportSlice
        ptQi->rxNotSupportSlice = VCCB_FLAG_ON;
    }// for QosFlow

    // DRB
    for (drbIndexInPdu = 0; drbIndexInPdu < MAX_DRB_PER_PDU_SESS; drbIndexInPdu++)
    {
        drbIdxInCall = ptPi->drbIndex[drbIndexInPdu];
        if (drbIdxInCall >= MAX_DRB_PER_SA_CALL) continue;

        ptDi = &ptCi->drb[drbIdxInCall];
        if (ptDi->usage != CI_use) continue;

        if((ptDi->drbStatus != S_Setup) && (ptDi->drbStatus != S_Modify) ) continue;
        if(ptDi->firstReqStatusInThisProcedure != S_Setup) continue;

        // Set rxNotSupportSlice
        ptDi->rxNotSupportSlice = VCCB_FLAG_ON;
    }
}

/**
 * @brief     Set the rxNotSupportSlice flag for QoS flows associated with a specific DRB.
 * @param     ptCi : Pointer to the callInfo structure
 * @param     ptDi : Pointer to the callDRBInfo structure
 * @details   This function iterates through all QoS flows associated with the given DRB. 
 *            If a QoS flow is in Setup or Modify status and its first request status is Setup, 
 *            it sets the rxNotSupportSlice flag for the QoS flow.
 */
void FnVCCB_SetQosFlowAsNotSupportSliceByDrb(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);

    qosFlowInfo_type *ptQi = NULL;
    uint8_t drbQosIdx = 0;
    uint16_t qosFlowIdxInCall;
    for (drbQosIdx = 0; drbQosIdx < MAX_QOS_FLOW_PER_DRB; drbQosIdx++)
    {
        qosFlowIdxInCall = ptDi->qosFlowIndex[drbQosIdx];
        if (qosFlowIdxInCall >= MAX_QOS_FLOW_PER_CALL) continue;

        ptQi = &ptCi->qosFlow[qosFlowIdxInCall];

        if (ptQi->usage != CI_use) continue;

        switch (ptQi->qosFlowStatus)
        {
            case S_Setup:
            case S_Modify:
                if (ptQi->firstReqStatusInThisProcedure == S_Setup)
                {
                    ptQi->rxNotSupportSlice = VCCB_FLAG_ON;
                }
                break;
            default:
                break;
        }
    } // for
    return;
}

/**
 * @brief     Set the rxNotSupportSlice flag for a PDU session associated with a specific DRB.
 * @param     ptCi : Pointer to the callInfo structure
 * @param     ptDi : Pointer to the callDRBInfo structure
 * @details   This function checks the status of the PDU session associated with the given DRB. 
 *            If the PDU session is in Setup or Modify status and its first request status is Setup, 
 *            it sets the rxNotSupportSlice flag for the PDU session. Note that this flag may not 
 *            necessarily indicate a setup failure, so it should be checked with other fail conditions 
 *            when collecting statistics for the PDU session.
 */
void FnVCCB_SetPduAsNotSupportSliceByDrb(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptDi);

    uint8_t pduIdxInCall = ptDi->pduIdxInCall;
    if (pduIdxInCall >= MAX_PDU_SESS_PER_CALL) return;

    callPDUSessInfo_type *ptPi = &ptCi->pduSess[ptDi->pduIdxInCall];
    if (ptPi->usage != CI_use) return;

    switch (ptPi->pduSessStatus)
    {
        case S_Setup:
        case S_Modify:
            if ((ptPi->firstReqStatusInThisProcedure == S_Setup ) ||
                (ptPi->firstReqStatusInThisProcedure == S_Modify))
            {
                // Set PDU as rxNotSupportSlice .
                // But It may not be setup fail. 
                // So When Collect Stat Of PDU, Should be check it with Fail Condition.
                ptPi->rxNotSupportSlice = VCCB_FLAG_ON;
            }
            break;
        default:
            break;
    }
}

/**
 * @brief Determines if a UE is capable of L1/L2 triggered mobility control(LTM) for a specified band.
 *
 * This function checks the UE's capability to perform LTM on the given band by validating
 * necessary configuration flags in the band's settings. It retrieves the band information
 * using FnVCCB_GetBandNrUeCapa and verifies the required conditions for LTM support.
 *
 * @param rCall Reference to call information structure containing UE capabilities.
 * @param bandNr Band number to check LTM capability for.
 * @return bool True if the UE is LTM-capable on the specified band, False otherwise.
 *
 * @example
 * bool isCapable = FnVCCB_CheckLtmUeCapability(callInfo, 5); // Checks band 5 for LTM capability
 *
 * @note The function relies on accurate data from FnVCCB_GetBandNrUeCapa. Returns false immediately
 * if the band data is unavailable or the band doesn't support below IEs.
 * - ltm-MCG-IntraFreq-r18
 * - ltm-BeamIndicationJointTCI-r18  
 * - ltm-MAC-CE-JointTCI-r18
 * @warning Does not throw exceptions; returns false on invalid inputs or unmet conditions.
 */
bool FnVCCB_CheckLtmUeCapability(const callInfo_type &rCall, const uint16_t bandNr)
{
    if (rCall.ueInfo.ueCapa.nr.rf.nrOfBands == 0)
    {
        VCCB_PRINT_DATA("ueCapa.nr.rf.nrOfBands == 0\n");
        return false;
    }

    auto *ptBand = FnVCCB_GetBandNrUeCapa(const_cast<callInfo_type *>(&rCall), bandNr);
    VALID_E_POINT_CHECK_RET_VAL(ptBand, false);
 
    /*
        ref) FGR-MC1034:FR100
        ~26A : ltm-MCG-IntraFreq-r18 + rach-eralyTA-Measurement-r18
        26B~ : ltm-MCG-IntraFreq-r18 + ltm-BeamIndicationJointTCI-r18 + ltm-MAC-CE-JointTCI-r18
    */
    
    auto ltmUeCapaSupport = [ptBand]()
    {
        if (ptBand->ltmMCGIntraFreq_r18 == FLAG_OFF) return false;
        if (ptBand->ltmBeamIndicationJointTCI_r18_present == OPT_NOT_PRESENT) return false;
        if (ptBand->ltmMacCeJointTCI_r18_present == OPT_NOT_PRESENT) return false;

        return true;
    };

    if (ltmUeCapaSupport() == false)
    {
        if (DBG->flag.logLtm)
        {
            VCCB_PRINT_CALL_COMMENT(
                &rCall, "[LTM:DB] LTM Ue Capa not support MCGIntraFreq(%d) BeamIndicationJointTCI(%d) macCeJointTCI(%d) Not supported\n",
                ptBand->ltmMCGIntraFreq_r18, ptBand->ltmBeamIndicationJointTCI_r18_present, ptBand->ltmMacCeJointTCI_r18_present);
        }
        return false;
    }

    return true;
}

/**
 * @brief Get the maximum number of LTM candidate cells per service group
 * @param gnbNum gNB number
 * @param svcGrpId service group ID
 * @return Maximum number of LTM candidate cells, or 0 if not configured
 */
uint8_t FnVCCB_GetMaxNumOfLtmCellPerSvgGrp(uint16_t gnbNum, uint8_t svcGrpId)
{
    VCCB_CHECK_E_RANGE_AND_VAL(svcGrpId, MAX_SVC_GRP_DB_NUM, 0);
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, 0);

    const SvcGrpBasedCfg_type &rSvcGrpBasedCfg = GNBINFO[gnbNum].cfg.svcGrpBasedCfg[svcGrpId];    
    return (rSvcGrpBasedCfg.usage == CI_use ? rSvcGrpBasedCfg.numOfLtmCandidateCell : 0);
}

void FnVCCB_SetRxDuNotSupportVonr5qiForAllSetupDrb(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint8_t callDrbIdx = 0;
    for (callDrbIdx = 0; callDrbIdx < MAX_DRB_PER_CALL; callDrbIdx++)
    {
        callDRBInfo_type *ptDi = &ptCi->drb[callDrbIdx];
        if (ptDi->usage != CI_use) continue;

        // If 5QI DRB and DrbSetup Operation, then set rxDuNotSupportVoNr5qi = ON
        VCCB_SET_RX_DU_NOT_SUPPORT_VONR_5QI_ON_SETUP_DRB(ptCi, ptDi);
    }
}

void FnVCCB_GetSliceValWithReqVal(callPDUSessInfo_type *ptPi, callSNSSAI_type *ptSnssai)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptPi);
    VALID_E_POINT_CHECK_VOID(ptSnssai);

    if(ptPi->isSavedRequestedPduParam) // Saved Value for Modify
    {
        *ptSnssai = ptPi->requestedPduParam.sNssai;
    }
    else
    {
        *ptSnssai = ptPi->sNssai;
    }
}


/* EOF */
