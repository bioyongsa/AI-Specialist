/**
 * @file        FeatMobility.cpp
 * @brief       This function provides a function for controlling the operation of the Mobility Feature(RRC Resume, RRE) for the SA UE.
 */
#include "FeatMobility.h"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "FeatCa.hpp"
#include "FeatCallInfo.h"
#include "FeatCallProc.h"
#include "FeatCommon.h"
#include "FeatRrcInactive.h"
#include "FeatRre.h"
#include "FeatSecurity.h"
#include "StateHandleAll.h"
#include "StateCommon.h"
#include "StateSaHo.h"
#include "FeatFullConfig.h"

int16_t FnVCCB_CheckFallbackCondition(callInfo_type *ptCi, const MobilityType mobilityType)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type &cell = CELLINFO[ptCi->servCellNum];

    if (MobilityType::RRE == mobilityType)
    {
        if ((!IS_FULLCONFIGURATION_IN_PROCESS(ptCi)) && (!GET_NRRRC_CELLGROUPCONFIG_FLAG(ptCi->flag.setupFlag)))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_StoreXNMessage(XNRetUERsp) ERROR : Cellgroupconfig is NULL !!\n");
            return ERROR;
        }
        OFF_NRRRC_CELLGROUPCONFIG_FLAG(ptCi->flag.setupFlag);

        // Decide whether to allow PLMN based on the cell from which RRE has been uploaded.
        plmnId_type selectedPlmn;
        int status = VCOM_GetSelectedPLMN_For_RRE(ptCi, ptCi->servCellNum, RRE_TYPE_INTER_GNB, &selectedPlmn);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Since it does not support PLMN, Execute RRC Setup!\n");
            return ERROR;
        }
        ptCi->ueInfo.servedPlmn.longId = selectedPlmn.longId;

        /* [FGR-CC5204] NR-DC RRE fallback to RRC Setup */
        if (ptCi->ueInfo.reestablishInfo.isNrdcCall == TRUE)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "RRE is Not available for NR-DC Call. Execute RRC Setup!\n");
            return ERROR;
        }
    }
    else if ((MobilityType::RRC_RESUME_INTRA_GNB == mobilityType) ||
             (MobilityType::RRC_RESUME_INTER_GNB == mobilityType))
    {
        const bool &isEmergencyCall = static_cast<bool>(VCCM_CheckEmergencyCall(ptCi));

        plmnId_type selectedPlmn;
        int status = FnVCCB_GetSelectedPLMNForRRCResume(*ptCi, mobilityType, isEmergencyCall, &selectedPlmn);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Since it does not support PLMN in %s\n", __func__);
            return ERROR;
        }
        ptCi->ueInfo.servedPlmn.longId = selectedPlmn.longId;

        //SVR25B
        if (ptCi->state == STATE_Conn_RelCmd)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Received RRCResumeRequest1 after sending NG_UEContextReleaseRequest!\n");
            return ERROR;
        }        
    }

    if ((MobilityType::RRE == mobilityType) ||
        ((MobilityType::RRC_RESUME_INTRA_GNB == mobilityType || MobilityType::RRC_RESUME_INTER_GNB == mobilityType) &&
         ptCi->ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update))
    {
        // Check UE's appliedFreqBandListFilter and System Configuration
        if (BAND_NOT_FOUND == VLIB_GetFreqBandIndForCell(ptCi, &cell))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_GetFreqBandIndForCell BAND_NOT_FOUND in %s\n", __func__);
            return ERROR;
        }
    }

    /* check the slice aware */
    /* CAUTION!! statusChange shall be set to FALSE always (deleted) in SVR26B for inter-gNB RRE case as well */
    uint8_t statusChange = mobilityType == MobilityType::RRE ? TRUE : FALSE;

    if (GOOD != FnVCCB_CheckSliceAwareForRREAndRRCResume(ptCi, statusChange))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CheckSliceAwareForRREAndRRCResume ERROR in %s\n", __func__);
        return ERROR;
    }

    if ((MobilityType::RRE == mobilityType) || (MobilityType::RRC_RESUME_INTER_GNB == mobilityType))
    {
        int16_t status = FnVCCB_CheckFallbackConditionInterGnb(*ptCi, mobilityType);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_CheckFallbackConditionInterGnb ERROR in %s\n", __func__);
            return ERROR;
        }
    }

    return GOOD;
}

int16_t FnVCCB_CheckFallbackConditionInterGnb(callInfo_type &call, const MobilityType mobilityType)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_RETURN(call.servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type &cell = CELLINFO[call.servCellNum];
    VCCB_CHECK_E_RANGE_AND_RETURN(call.gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type &gnb = GNBINFO[call.gnbNum];

    /* Check 5qi support and Rearrange PDU/QosFlow. */
    if (mobilityType == MobilityType::RRE ||
       (mobilityType == MobilityType::RRC_RESUME_INTER_GNB && (call.ueInfo.RrcInactiveInfo.resumeCause != NRRRC_rna_Update)))
    {
        if (GOOD != VCCM_CheckSupportQosFlowAndRearrange(&call, XN_RetrieveUEContextResponse_id))
        {
            VCCB_PRINT_CALL_ERROR(&call, "VCCM_CheckSupportQosFlowAndRearrange ERROR in %s\n", __func__);
            call.cause.xnCause = CauseXnapRadioNetworkLayerNotSupported5qiValue;
            return ERROR;  // RRC Setup
        }
    }

    if (MobilityType::RRC_RESUME_INTER_GNB == mobilityType)
    {
        // Not supported as of SVR21D in RRE
        /* Check for DRB Integrity Protection Support */
        if (GOOD != FnVCCB_DecideSourceSecurityCapabilities(&call))
        {
            VCCB_PRINT_CALL_ERROR(&call, "FnVCCB_DecideSourceSecurityCapabilities ERROR in %s\n", __func__);
            return ERROR;
        }

        // FGR-BC0323 FR410
        // VCCM_CheckUpIntegrityProtectionForRRE replace
        if ((call.ueInfo.rrcResumeInfo.isDRBIntegrityProtectionEnabled) &&
            (gnb.security.isUpDrbIntegrityProtectionSupported == FALSE))
        {
            VCCB_PRINT_CALL_ERROR(&call,
                "gNB does not support DRBIntegrityProtection, there is DRB with Protection enabled in %s\n", __func__);
            return ERROR;
        }
    }

    if (MobilityType::RRE == mobilityType)
    {
        if (GOOD != VCCM_CheckVoiceOverNR(&call, call.servCellNum))
        {
            VCCB_PRINT_CALL_ERROR(&call, "VCCM_CheckVoiceOverNR ERROR in %s\n", __func__);
            call.cause.xnCause = CauseXnapRadioNetworkLayerNotSupported5qiValue;
            return ERROR;
        }
    }

    if (ERROR == VLIB_checkDssAllowed(&call, BAND_NOT_SET, false, &cell))
    {
        VCCB_PRINT_CALL_ERROR(&call, "VLIB_checkDssAllowed ERROR in %s\n", __func__);
        MACRO_CALL_FAULT_SAVE_REF(call, XN_RetrieveUEContextResponse_id, CauseCpInternalResourceAllocFail);
        return ERROR;
    }

    return GOOD;
}

int16_t FnVCCB_ConfigureUeContextForRREandRRCResume(callInfo_type *ptCi, const MobilityType mobilityType)
{
    AUTO_TRACE_FUNC;

    /* allocate SRB */
    int status = VHCM_AllocCallSrbInfoForInterNode(ptCi);
    if (ERROR == status)
    {
        MACRO_CALL_FAULT_SAVE(XN_RetrieveUEContextResponse_id, CauseCpInternalResourceAllocFail);
        VCCB_PRINT_CALL_ERROR(ptCi, "VHCM_AllocCallSrbInfoForInterNode ERROR!\n");
        return ERROR;
    }

    ptCi->srbInfo[ID_SRB1 - 1].srbStatus = S_Idle;  // SRB1 is already setup as default value.

    /* Update PduSession and QosFlow Status for Partial DRB */
    if (mobilityType == MobilityType::RRE)
    {
        VCOM_ChangeStatus_PduSessionAndQosFlow_FailToSetup_ForPartialDRB(ptCi);
    }

    /* allocates the DRB for SDAP layer */
    status = VCCM_SDAP_AllocationAndUpdate_DRBStatus(ptCi);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_SDAP_AllocationAndUpdate_DRBStatus ERROR!\n");
        MACRO_CALL_FAULT_SAVE(XN_RetrieveUEContextResponse_id, CauseCpInternalResourceAllocFail);
        return ERROR;
    }

    if (mobilityType == MobilityType::RRC_RESUME_INTER_GNB)
    {
        if (GOOD != VLIB_getAmfFromGuami(ptCi))
        {
            // MACRO_CALL_FAULT_SAVE fill VRRM_AMFSelection.
            if (AMF_ASSIGN_FAIL_UNKNOWN_GUAMI_ID == GET_XN_AMF_CALL_FAULT_CAUSE(ptCi))
            {
                MACRO_CALL_FAULT_SAVE(XN_RetrieveUEContextResponse_id, CauseXnapRadioNetworkLayerUnknownGuamiId);
                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerUnknownGuamiId;
            }
            else  //(AMF_ASSIGN_FAIL_INVALID_SET_ID== GET_XN_AMF_CALL_FAULT_CAUSE(ptCi))
            {
                MACRO_CALL_FAULT_SAVE(XN_RetrieveUEContextResponse_id, CauseXnapRadioNetworkLayerInvalidAmfSetId);
                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerInvalidAmfSetId;
            }
            VCCB_PRINT_CALL_ERROR(ptCi, "No available AMF !!\n");
            INIT_XN_RECEIVED_TNL_ADDR_INFO(ptCi);
            return ERROR;
        }
        INIT_XN_RECEIVED_TNL_ADDR_INFO(ptCi);

        if (FnVCCB_IsPLMNSupportedByAMF(ptCi) == FALSE)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Selected AMF(%u) doesn't support servedPLMN(%u)\n", ptCi->endPointInfo.ngIdx,
                ptCi->ueInfo.servedPlmn.longId);
            MACRO_CALL_FAULT_SAVE(XN_RetrieveUEContextResponse_id, CauseCpInternalInvalidPlmn);
            return ERROR;
        }
    }

    // Select handling gNB-CU-UP
    if (GOOD != VRRM_AUPFSelection(ptCi))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "No available AUPF !!\n");
        MACRO_CALL_FAULT_SAVE(XN_RetrieveUEContextResponse_id, CauseCpInternalUpAllocationFail);
        return ERROR;
    }

    // update the csl connectInfo
    ptCi->cslInfo.connectInfo.cellNum = ptCi->servCellNum;

    return GOOD;
}

// SVR25B FGR-CC0103: FR702
// When a call is released due to E1/F1 failure and Specified Slice is included, gNB shall trigger release with redirection.
int16_t FnVCCB_CheckSpecificSliceAndDoRrcRedirection_ForRREAndRRCResume(callInfo_type *ptCi, uint16_t msgId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->stateCmd == RRCResume_cmd)
    {
        if (ptCi->ueInfo.rrcResumeInfo.resumeType != RESUME_TYPE_INTRA_GNB &&
            ptCi->ueInfo.rrcResumeInfo.resumeType != RESUME_TYPE_INTER_GNB_TARGET) return ERROR;

        for (callPDUSessInfo_type &rPdu : ptCi->pduSess)
        {
            if (rPdu.usage != CI_use) continue;

            if (FnVCCB_IsSpecificSlice(*ptCi, rPdu.sNssai.sstSd) == true)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "[RRCInactive] Failed with the specific slice (SSTSD:%u sst:%u sd:%u) sessId:%d, so trigger redirection!\n",
                    rPdu.sNssai.sstSd, rPdu.sNssai.sst, rPdu.sNssai.sd, rPdu.pduSessId);

                return FnVCCB_SpecificSliceForcedMobilityBlindRedirection(ptCi, msgId);
            }
        }
    }
    else if (ptCi->stateCmd == RrcReestablish_cmd)
    {
        for (callPDUSessInfo_type &rPdu : ptCi->pduSess)
        {
            if (rPdu.usage != CI_use) continue;

            if (FnVCCB_IsSpecificSlice(*ptCi, rPdu.sNssai.sstSd) == true)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "[RRE] Failed with the specific slice (SSTSD:%u sst:%u sd:%u) sessId:%d, so trigger redirection!\n", 
                    rPdu.sNssai.sstSd, rPdu.sNssai.sst, rPdu.sNssai.sd, rPdu.pduSessId);

                return FnVCCB_SpecificSliceForcedMobilityBlindRedirection(ptCi, msgId);
            }
        }
    }

    return BREAK;
}

// SVR26A FGR-CC0103, FGR-CC0107
// FR710.CACP.SR1.HD1 - Voice Requested and Emergency Requested indicators
// FR1070.CACP.SR1.HD1 - Voice Requested and Emergency Requested indicators
void FnVCCB_CheckAndUpdate_VoNREmergencyIndicator_CSL(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    const bool &isEmergencyCall = static_cast<bool>(VCCM_CheckEmergencyCall(ptCi));

    if (isEmergencyCall)
    {
        // set the emergency call indicator in CSL structure
        ptCi->emergencyRequestedForCsl = VCCB_FLAG_ON;
    }

    if (FnVCCB_IsVoNRCall(ptCi))
    {
        // set VoNR call indicator in CSL structure
        ptCi->vonrRequestedForCsl = VCCB_FLAG_ON;
    }
}
