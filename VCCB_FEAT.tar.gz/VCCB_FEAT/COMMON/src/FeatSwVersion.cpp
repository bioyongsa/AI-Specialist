#include "FeatSwVersion.h"
#include "ComAutoNtrace.hpp"
#include "ComGlobalData.h"
#include "ComLibIpcApi.h"

namespace
{
const uint32_t INVALID_FORMAT = 0u;

uint32_t VLIB_ConvertXYZOfSwVersionToUInt(swVersionRaw_type *ptVerRaw)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptVerRaw, INVALID_FORMAT);

    if ('\0' == ptVerRaw->text[0])
    {
        VCCB_PRINT_COMMENT("SW version string is empty.\n");
        return INVALID_FORMAT;
    }

    int majorPkgDigit = 0;
    char minorPkgDigit = 0;
    int tempPkgDigit = 0;
    char dash;
    int minorPkgDigitInt = 0;

    int howManyMatched = sscanf(ptVerRaw->text, "%2d.%1c.%1d%1c", &majorPkgDigit, &minorPkgDigit, &tempPkgDigit, &dash);

    if (howManyMatched < 3)
    {
        VCCB_PRINT_ERROR("Not all required fields are matched in %s.\n", ptVerRaw->text);
        return INVALID_FORMAT;
    }

    if (4 == howManyMatched && dash != '-')
    {
        VCCB_PRINT_ERROR(
            "Invalid format because the expected character was '-' and we get %c in %s.\n", dash, ptVerRaw->text);
        return INVALID_FORMAT;
    }

    if (minorPkgDigit < 'A' || minorPkgDigit > 'Z')
    {
        VCCB_PRINT_ERROR("y is out of the range in %s.\n", ptVerRaw->text);
        return INVALID_FORMAT;
    }

    minorPkgDigitInt = minorPkgDigit - 'A';

    return (uint32_t)((majorPkgDigit << 16) + (minorPkgDigitInt << 8) + tempPkgDigit);
}
}  // namespace

void VLIB_CreateSwVersionFromPld(const char *ptPldSwVersion, swVersion_type *ptSwVersion)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptPldSwVersion);
    VALID_E_POINT_CHECK_VOID(ptSwVersion);

    memcpy(ptSwVersion->raw.text, ptPldSwVersion, VCCB_ARRAY_COUNT(ptSwVersion->raw.text));
    ptSwVersion->raw.text[VCCB_ARRAY_COUNT(ptSwVersion->raw.text) - 1] =
        '\0';  // make sure we have null terminated C-string
    ptSwVersion->xyz = VLIB_ConvertXYZOfSwVersionToUInt(&ptSwVersion->raw);
}

/****************************************************************************
 * @brief      Check if DU, to which cell belongs, version is equal or higher than required Version

 * @param[in]  cellNum: index to CELLINFO's cell which belongs to DU for which query is run
 * @return     bool : true/false
 ****************************************************************************/
bool VLIB_IsCellDuRequiredVersion(uint16_t cellNum, uint32_t requiredDuSwVersion)
{
    AUTO_TRACE_FUNC;

#ifdef __NVGNB__
    UNUSED2(cellNum, requiredDuSwVersion);
    return true;
#else
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, false);

    const VccbCellInfo_type& cell = CELLINFO[cellNum];
    VCCB_CHECK_E_RANGE_AND_VAL(cell.gnbNum, MAX_GNB_PER_SYS, false);
    VCCB_CHECK_E_RANGE_AND_VAL(cell.endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP, false);
    const gnbDuInfo_type& gnbDu = GNBINFO[cell.gnbNum].gnbDu[cell.endPointF1Index];

    return gnbDu.swVersion.xyz >= requiredDuSwVersion;
#endif // __NVGNB__
}

bool FnVCCB_IsPartialDrbRequiredVersion(
    callInfo_type* ptCi, VccbE1F1PartialInterface_type interfaceType, uint16_t endPointIndex)
{
    AUTO_TRACE_FUNC;

#ifdef __NVGNB__
    UNUSED3(ptCi, interfaceType, endPointIndex);
    return true;
#else
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    const uint32_t requiredSwVersion = SW_VERSION_XYZ(24, 'A', 0);

    switch (interfaceType)
    {
        case PARTIAL_INTERFACE_E1:
        {
            VCCB_CHECK_E_RANGE_AND_VAL(endPointIndex, MAX_GNB_CU_UP_PER_GNB_CU_CP, false);
            const swVersion_type *pSwVersion = &GNBINFO[ptCi->gnbNum].aupf.gnbCuUp[endPointIndex].swVersion;
            return pSwVersion->xyz >= requiredSwVersion;
        }

        case PARTIAL_INTERFACE_F1:
        {
            VCCB_CHECK_E_RANGE_AND_VAL(endPointIndex, MAX_GNB_DU_PER_GNB_CU_CP, false);
            const gnbDuInfo_type *pGnbDu = &GNBINFO[ptCi->gnbNum].gnbDu[endPointIndex];
            return pGnbDu->swVersion.xyz >= requiredSwVersion;
        }

        default:
            return false;
    }
#endif
}

bool FnVCCB_IsSupportMSG4TaskOnF1SwVer(callInfo_type *ptCi, uint16_t endPointF1Index)
{
    AUTO_TRACE_FUNC;
#ifdef __NVGNB__
    // Since 24B
    UNUSED2(ptCi, endPointF1Index);
    return true;
#else
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);
    VCCB_CHECK_E_RANGE_AND_VAL(endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP, false);

    const gnbDuInfo_type *pGnbDu = &GNBINFO[ptCi->gnbNum].gnbDu[endPointF1Index];

    const uint32_t requiredDuSwVersion = SW_VERSION_XYZ(24, 'B', 0);
    return pGnbDu->swVersion.xyz >= requiredDuSwVersion;
#endif // __NVGNB__
}

