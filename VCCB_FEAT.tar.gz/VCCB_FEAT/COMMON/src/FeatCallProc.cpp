/****************************************************************
 * System      : 5G vNB
 * Subsystem   : CALL
 * Module      : VCCB
 * File        : MainCallUtility.c
 * Description :
 * Author      :
 * Dept.       : NG Access Lab.
 * Created     : 2016.08.01
 * Procedures defined :
 * Procedures called  :
 * Version     :
 * Revision history   :
 *          date      :
 *       revised by   :
 * revised information:
 ****************************************************************/

#include "FeatCallProc.h"
#include "ComMacro.h"
#include "FeatCommon.h"
#include "FeatCallInfo.h"
#include "FeatMeasurements.hpp"
#include "FeatMrdc.h"
#include "FeatMfbi.h"
#include "FeatCa.hpp"
#include "FeatMco.h"
#include "FeatHoCommon.h"
#include "FeatSon.h"
#include "FeatLb.hpp"
#include "FeatRrcSegment.h"
#include "FeatFullConfig.h"
#include "FeatInterference.h"
#include "FeatRbInfo.h"
#include "FeatRrcInactive.h"
#include "FeatMrl.h"
#include "FeatNonNeighborHo.h"
#include "FeatCellReselection.h"
#include "FeatUeHistory.h"
#include "FeatSpeedState.hpp"

#include "ComInclude.h"
#include "ComLibUtility.h"
#include "ComTimeUtil.h"

#include "CdbUtil.h"
#include "CdbDalNotification.h"

#include "MsgNmbSend.h"
#include "MsgF1apSend.h"
#include "MsgX2apSend.h"
#include "MsgXnapSend.h"
#include "MsgNrRrcMake.h"
#include "MsgNrRrcStore.h"
#include "MsgNrRrcMake.h"
#include "MsgE1apSend.h"
#include "MsgNgapSend.h"

#include "StateCommon.h"
#include "StateSaRre.h"
#include "StateSaHo.h"
#include "StateCa.h"
#include "StateMco.h"
#include "StateMeasurements.h"
#include "StateHandleAll.h"
#include "StateHandleSaMrdc.h"

#include "access_common_yang.h"

#include "nrrrcUnpack.h"
#include "f1apUnpack.h"
#include "e1apUnpack.h"
#include "ngapUnpackMsg.h"
#include "xnapUnpackMsg.h"
#include "x2apUnpackMsg.h"

#include "FeatUlPathControlENDC.h"
#include "FeatUeHistory.h"
#include "UplinkStatusTriggeredMobility.hpp"

#ifdef VCCB_IPC_TEST
bool isRunTxMsgApprovalTest();
bool isRunShmMsgApprovalTest();
#endif

/****************************************************************************
 * Function      : VCCM_StoreSuccess_PreviousResource
 * Description   :
 * Proc called   :
 * Proc calling  :
 * Input         :
 * Output        :
 * Update History:
 ****************************************************************************/
void VCCM_StoreSuccess_PreviousResource(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    uint8_t eRab;

    VALID_E_POINT_CHECK_VOID(ptCi);

    /* QoS,RBInfo */
    for (eRab = 0; eRab < MAX_ERAB_PER_CALL; eRab++)
    {
        if (!IS_VALID_NODE(ERAB_NODE, ptCi, &(ptCi->erabInfo[eRab])))
        {
            continue;
        }
        ptCi->erabInfo[eRab].erabQosPrev = ptCi->erabInfo[eRab].erabQos;
        ptCi->erabInfo[eRab].rbInfo.pdcpInfoPrev = ptCi->erabInfo[eRab].rbInfo.pdcpInfo;
        ptCi->erabInfo[eRab].prevDataSplitThreshold = ptCi->erabInfo[eRab].dataSplitThreshold;
    }

    /* qciGrpId */
    ptCi->qciGrpIdPrev = ptCi->qciGrpId;
}

#define CHECK_TIMER_INVALID(_ptCi, _timer) \
    do { \
        if (-1 != (_timer).id) { \
            VCCB_PRINT_CALL_INFORMATIVE((_ptCi), "Timer '%s' is not canceled after previous procedure.\n", #_timer); \
        } \
    } while (0)

/**
 * @brief Verify that all link timers are canceled when switching to state idle.
 * 
 * @param rCi call info
 */
void VCCB_CheckLinksTimersCanceled(const callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    CHECK_TIMER_INVALID(&rCi, rCi.timer);
    CHECK_TIMER_INVALID(&rCi, rCi.callMultiTimer.x2);
    CHECK_TIMER_INVALID(&rCi, rCi.callMultiTimer.e1);
    CHECK_TIMER_INVALID(&rCi, rCi.callMultiTimer.f1);
    CHECK_TIMER_INVALID(&rCi, rCi.callMultiTimer.rrc);
    CHECK_TIMER_INVALID(&rCi, rCi.callMultiTimer.ng);
    CHECK_TIMER_INVALID(&rCi, rCi.callMultiTimer.xn);
    CHECK_TIMER_INVALID(&rCi, rCi.callMultiTimer.spec);
}

/****************************************************************************
 * Function      : VCCM_SetStableState_CallSetup
 * Description   :
 * Proc called   :
 * Proc calling  :
 * Input         :
 * Output        :
 * Update History:
 ****************************************************************************/
void VCCM_SetStableState_CallSetup(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->cslInfo.cslEvent = csl_event_undefined;

    if (GETBIT(ptCi->flag.respFlag, X2_SN_STATUS_FLAG))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "X2_SNStatusTransfer not received ERROR \n");
        OFF_X2_SN_STATUS_FLAG(ptCi->flag.respFlag);
    }

    VLIB_ClearAllReleaseFlags(ptCi);

    VLIB_ClearAllRespFlags(ptCi);

    VLIB_setBearerStatusToIdle(ptCi);
    if(ptCi->callType == E_CALLTYPE_SA)
    {
        CLEAR_RETAIN_STAT_EVENT(ptCi->retainStatOfVonrEmer);
    }

    VCCM_UpdateCaControlIndexAndQueueCaModIfNeeded(ptCi);

        
    MACRO_RESET_CALL_FAULT_CAUSES;
    SET_STATE_CMD(Idle_cmd);  // ptCi->stateCmd = Idle_cmd;
    SET_PROC_FOR_STAT(ptCi, MAX_PROC_FOR_STAT);

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        // Store Previous Resource...
        ptCi->ulPathControl.prev.qci128SwitchFlag = ptCi->ulPathControl.curr.qci128SwitchFlag;
        ptCi->ulPathControl.revertUlPathChange = false;
        VCCM_StoreSuccess_PreviousResource(ptCi);
        VLIB_SetCurStateAll(ptCi, STATE_DB);
    }
    else
    {
        // TODO for SA
        // VCCM_StoreSuccess_PreviousResource(ptCi);
        VLIB_SetCurStateAll(ptCi, STATE_Conn);

        // Initialize Nas Information...
        INIT_NAS_INFORMATION(ptCi->nasInfo);

        if (IS_SUPPORT_UE_CAPA_INFO(ptCi) && (!IS_NRDC_SN(ptCi)) &&
            GET_VCCB_UE_INFO_REQ_FLAG(ptCi) != VCCB_FLAG_ON)  // 21D: NR RACH Optimization
        {
            if (ERROR == VCOM_SendNRRRC_UEInformationRequest(ptCi))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VCOM_SendNRRRC_UEInformationRequest ERROR !!\n");
            }
        }
    }

    // init current value
    VLIB_InitFullConfigurationInfo(ptCi);

    // Print diagnostic messages if any timer is not canceled after previous procedure.
    VCCB_CheckLinksTimersCanceled(*ptCi);

    return;
}

void VCCM_UpdateNRRRCMsgStat(callInfo_type *ptCi, uint16_t msgId, uint32_t gnbIdOrNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    enumCallType_type callType = ptCi->callType;
    uint8_t threadId = ptCi->myThreadId;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // In NVGNB, gnbIdOrNum must be gnbNum.
    // In ACPF,  gnbIdOrNum must be gnbId.

    switch (msgId)
    {
        case NRRRC_RrcSetup_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcSetup);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Tx_RRCSetup, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_RrcReconfiguration_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcReconfiguration);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Tx_RRCReconfiguration, gnbIdOrNum, 0, threadId);
                MACRO_STAT_PMCC(STAT_RRC_RECONFIG, ConnReconfigAtt, ptCi, 0, 0, 0, 0, 0);
            }
            break;
        case NRRRC_RrcReject_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcReject);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Tx_RRCReject, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_RrcRelease_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcRelease);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Tx_RRCRelease, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_SecurityModeCommand_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_SecurityModeCommand);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Tx_RRCSecurityModeCommand, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_UECapabilityEnquiry_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_UECapabilityEnquiry);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Tx_RRCUECapabilityEnquiry, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_RrcSetupRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcSetupRequest);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Rx_RRCSetupRequest, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_RrcSetupComplete_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcSetupComplete);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Rx_RRCSetupComplete, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_RrcReconfigurationComplete_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcReconfigurationComplete);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Rx_RRCReconfigurationComplete, gnbIdOrNum, 0, threadId);
                MACRO_STAT_PMCC(STAT_RRC_RECONFIG, ConnReconfigSucc, ptCi, 0, 0, 0, 0, 0);
            }
            break;
        case NRRRC_SecurityModeComplete_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_SecurityModeComplete);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Rx_RRCSecurityModeComplete, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_SecurityModeFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_SecurityModeFailure);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Rx_RRCSecurityModeFailure, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_UECapabilityInformation_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_UECapabilityInformation);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Rx_RRCUECapabilityInformation, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_MeasurementReport_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_MeasurementReport);
            break;
        case NRRRC_SCGFailureInformationEUTRA_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_SCGFailureInformationEUTRA);
            break;
        case NRRRC_RrcReestablishmentRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcReestablishmentRequest);
            break;
        case NRRRC_RrcReestablishment_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcReestablishment);
            break;
        case NRRRC_RrcReestablishmentComplete_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcReestablishmentComplete);
            break;
        case NRRRC_RrcResumeRequest1_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcResumeRequest1);
            break;
        case NRRRC_RrcResume_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcResume);
            break;
        case NRRRC_RrcResumeComplete_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_RrcResumeComplete);
            break;
        case NRRRC_SCGFailureInformation_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_SCGFailureInformation);
            break;
        case NRRRC_MobilityFromNRCommand_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_MobilityFromNRCommand);
            break;
        case NRRRC_ULDedicatedMessageSegment_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_ULDedicatedMessageSegment);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Rx_RRCULDedicatedMessageSegment, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_UEInformationRequestR16_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_UEInformationRequest);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Tx_RRCUeInformationRequest, gnbIdOrNum, 0, threadId);
            }
            break;
        case NRRRC_UEInformationResponseR16_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_UEInformationResponse);
            if (callType == E_CALLTYPE_SA)
            {
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_RRC_MSG, Rx_RRCUeInformationResponse, gnbIdOrNum, 0, threadId);
            }
            break;
        default:
            INCREASE_LOCAL_MSG_STAT(threadId, NRRRC_Others);
            break;
    }
}

static void VCCM_UpdateE1APMsgStat(uint8_t threadId, uint16_t msgId, uint32_t gnbIdOrNum, uint16_t endPointIdx, enumDirection direction)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // In NVGNB, gnbIdOrNum must be gnbNum.
    // In ACPF,  gnbIdOrNum must be gnbId.

    switch (msgId)
    {
        case E1_BearerContextSetupRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextSetupRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Tx_E1apBearerContextSetupRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextSetupResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextSetupResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Rx_E1apBearerContextSetupResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextSetupFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextSetupFailure);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Rx_E1apBearerContextSetupFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextModificationRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextModificationRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(
                STAT_E1AP_CUCP_MSG_UE, Tx_E1apBearerContextModificationRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextModificationResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextModificationResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(
                STAT_E1AP_CUCP_MSG_UE, Rx_E1apBearerContextModificationResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextModificationFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextModificationFailure);
            MACRO_STAT_PMCC_MSG_PERIODIC(
                STAT_E1AP_CUCP_MSG_UE, Rx_E1apBearerContextModificationFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextModificationRequired_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextModificationRequired);
            MACRO_STAT_PMCC_MSG_PERIODIC(
                STAT_E1AP_CUCP_MSG_UE, Rx_E1apBearerContextModificationRequired, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextModificationConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextModificationConfirm);
            MACRO_STAT_PMCC_MSG_PERIODIC(
                STAT_E1AP_CUCP_MSG_UE, Tx_E1apBearerContextModificationConfirm, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextReleaseCommand_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextReleaseCommand);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Tx_E1apBearerContextReleaseCommand, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextReleaseComplete_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextReleaseComplete);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Rx_E1apBearerContextReleaseComplete, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextReleaseRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextReleaseRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Rx_E1apBearerContextReleaseRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_BearerContextInactivityNotification_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_BearerContextInactivityNotification);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Rx_E1apBearerContextInactivityNotification, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_DLDataNotification_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_DLDataNotification);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Rx_E1apDlDataNotification, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_DataUsageReport_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_DataUsageReport);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Rx_E1apDataUsageReport, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_TraceStart_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_TraceStart);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Tx_E1apTraceStart, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_DeactivateTrace_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_DeactivateTrace);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Tx_E1apDeactivateTrace, gnbIdOrNum, endPointIdx, threadId);
            break;
        case E1_GNB_CU_UP_CounterCheckRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_UP_StatusIndication);
            break;
        case E1_ULDataNotification_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_ULDataNotification);
            break;

        // interface (NON-UE Message)
        case E1_Reset_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_Reset);
            break;
        case E1_ResetAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_ResetAcknowledge);
            break;
        case E1_ErrorIndication_id:
            if (TX_MSG == direction)
            {
                INCREASE_LOCAL_MSG_STAT(threadId, E1_TxErrorIndication);
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Tx_E1apErrorIndicationUe, gnbIdOrNum, endPointIdx, threadId);
            }
            else
            {
                INCREASE_LOCAL_MSG_STAT(threadId, E1_RxErrorIndication);
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_E1AP_CUCP_MSG_UE, Rx_E1apErrorIndicationUe, gnbIdOrNum, endPointIdx, threadId);
            }
            break;
        case E1_GNB_CU_UP_E1SetupRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_UP_E1SetupRequest);
            break;
        case E1_GNB_CU_UP_E1SetupResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_UP_E1SetupResponse);
            break;
        case E1_GNB_CU_UP_E1SetupFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_UP_E1SetupFailure);
            break;
        case E1_GNB_CU_CP_E1SetupRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_CP_E1SetupRequest);
            break;
        case E1_GNB_CU_CP_E1SetupResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_CP_E1SetupResponse);
            break;
        case E1_GNB_CU_CP_E1SetupFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_CP_E1SetupFailure);
            break;
        case E1_GNB_CU_UP_ConfigurationUpdate_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_UP_ConfigurationUpdate);
            break;
        case E1_GNB_CU_UP_ConfigurationUpdateAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_UP_ConfigurationUpdateAcknowledge);
            break;
        case E1_GNB_CU_UP_ConfigurationUpdateFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_UP_ConfigurationUpdateFailure);
            break;
        case E1_GNB_CU_CP_ConfigurationUpdate_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_CP_ConfigurationUpdate);
            break;
        case E1_GNB_CU_CP_ConfigurationUpdateAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_CP_ConfigurationUpdateAcknowledge);
            break;
        case E1_GNB_CU_CP_ConfigurationUpdateFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_CP_ConfigurationUpdateFailure);
            break;
        case E1_E1ReleaseRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_E1ReleaseRequest);
            break;
        case E1_E1ReleaseResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_E1ReleaseResponse);
            break;
        case E1_GNB_CU_UP_StatusIndication_id:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_GNB_CU_UP_StatusIndication);
            break;
        default:
            INCREASE_LOCAL_MSG_STAT(threadId, E1_Others);
            break;
    }
}

static void VCCM_UpdateF1APMsgStat(uint8_t threadId, uint16_t msgId, uint32_t gnbIdOrNum, uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // In NVGNB, gnbIdOrNum must be gnbNum.
    // In ACPF,  gnbIdOrNum must be gnbId.

    switch (msgId)
    {
        case F1_ErrorIndication_id:  // Currently, ErrorIndication is collected in VNMB only
            INCREASE_LOCAL_MSG_STAT(threadId, F1_ErrorIndication);
            break;
        case F1_UEContextSetupRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextSetupRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apUeContextSetupRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEContextSetupResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextSetupResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apUeContextSetupResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEContextSetupFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextSetupFailure);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apUeContextSetupFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEContextReleaseCommand_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextReleaseCommand);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apUeContextReleaseCommand, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEContextReleaseComplete_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextReleaseComplete);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apUeContextReleaseComplete, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEContextModificationRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextModificationRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apUeContextModificationRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEContextModificationResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextModificationResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(
                STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apUeContextModificationResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEContextModificationFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextModificationFailure);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apUeContextModificationFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEContextModificationRequired_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextModificationRequired);
            MACRO_STAT_PMCC_MSG_PERIODIC(
                STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apUeContextModificationRequired, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEContextModificationConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextModificationConfirm);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apUeContextModificationConfirm, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEContextModificationRefuse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextModificationRefuse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apUeContextModificationRefuse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_UEMobilityCommand_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEMobilityCommand);
            break;
        case F1_UEContextReleaseRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_UEContextReleaseRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apUeContextReleaseRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_InitialULRRCMessageTransfer_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_InitialULRRCMessageTransfer);
            // Because VCCB receives F1_InitialULRRCMessageTransfer_id through CallSetupRequest from VNMB,
            // this stat is collected in VCCM_SA_ALL_CallSetupRequest function.
            break;
        case F1_DLRRCMessageTransfer_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_DLRRCMessageTransfer);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apDlRrcMessageTransfer, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_ULRRCMessageTransfer_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_ULRRCMessageTransfer);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apUlRrcMessageTransfer, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_PrivateMessage_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_PrivateMessage);
            break;
        case F1_AccessAndMobilityIndication_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_AccessAndMobilityIndication);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apAccessAndMobilityIndication, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_AccessSuccess_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_AccessSuccess);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apAccessSuccess, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_RRCDeliveryReport_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_RRCDeliveryReport);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apRrcDeliveryReport, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_TraceStart_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_TraceStart);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apTraceStart, gnbIdOrNum, endPointIdx, threadId);
            break;  
        case F1_DeactivateTrace_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_DeactivateTrace);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apDeactivateTrace, gnbIdOrNum, endPointIdx, threadId);
            break;  
        case F1_PositioningInformationRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_PositioningInformationRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apPositioningInformationRequest, gnbIdOrNum, endPointIdx, threadId);
            break;        
        case F1_PositioningInformationResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_PositioningInformationResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apPositioningInformationResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_PositioningInformationFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_PositioningInformationFailure);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apPositioningInformationFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_E_CIDMeasurementInitiationRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_E_CIDMeasurementInitiationRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apEcidMeasurementInitiationRequest, gnbIdOrNum, endPointIdx, threadId);
            break; 
        case F1_E_CIDMeasurementInitiationResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_E_CIDMeasurementInitiationResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apEcidMeasurementInitiationResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_E_CIDMeasurementInitiationFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_E_CIDMeasurementInitiationFailure);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apEcidMeasurementInitiationFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_E_CIDMeasurementFailureIndication_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_E_CIDMeasurementFailureIndication);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apEcidMeasurementFailureIndication, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_E_CIDMeasurementReport_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_E_CIDMeasurementReport);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apEcidMeasurementReport, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_E_CIDMeasurementTerminationCommand_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_E_CIDMeasurementTerminationCommand);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apEcidMeasurementTerminationCommand, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_PositioningInformationUpdate_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_PositioningInformationUpdate);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apPositioningInformationUpdate, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_DUCUCellSwitchNotification_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_DUCUCellSwitchNotification);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Rx_F1apDuCuCellSwitchNotification, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_CUDUCellSwitchNotification_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_CUDUCellSwitchNotification);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apCuDuCellSwitchNotification, gnbIdOrNum, endPointIdx, threadId);
            break;
        case F1_CUDUMobilityInitiationRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_CUDUMobilityInitiationRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_F1AP_CU_MSG_UE, ACPF_Tx_F1apCuDuMobilityInitiationRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        default:
            INCREASE_LOCAL_MSG_STAT(threadId, F1_Others);
            break;
    }
}

static void VCCM_UpdateNGAPMsgStat(uint8_t threadId, uint16_t msgId, uint32_t gnbIdOrNum, uint16_t endPointIdx, enumDirection direction)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // In NVGNB, gnbIdOrNum must be gnbNum.
    // In ACPF,  gnbIdOrNum must be gnbId.

    switch (msgId)
    {
        case NG_InitialUEMessageAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_InitialUEMessage);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGInitialUEMessage, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_InitialContextSetupResponseAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_InitialContextSetupResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGInitialContextSetupResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_InitialContextSetupFailureAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_InitialContextSetupFailure);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGInitialContextSetupFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UplinkNASTransportAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UplinkNASTransport);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGUplinkNASTransport, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UECapabilityInfoIndicationAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UECapabilityInfoIndication);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGUECapabilityInfoIndication, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PDUSessionResourceSetupResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PDUSessionResourceSetupResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGPDUSessionResourceSetupResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PDUSessionResourceReleaseResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PDUSessionResourceReleaseResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGPDUSessionResourceReleaseResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PDUSessionResourceModifyResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PDUSessionResourceModifyResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGPDUSessionResourceModifyResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UEContextReleaseRequestAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextReleaseRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGUEContextReleaseRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UEContextReleaseCompleteAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextReleaseComplete);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGUEContextReleaseComplete, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UEContextModificationResponseAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextModificationResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGUEContextModificationResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UEContextModificationFailureAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextModificationFailure);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGUEContextModificationFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PDUSessionResourceModifyIndication_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PDUSessionResourceModifyIndication);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGPDUSessionResourceModifyIndication, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PDUSessionResourceModifyConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PDUSessionResourceModifyConfirm);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGPDUSessionResourceModifyConfirm, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UEContextModificationRequestAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextModificationRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGUEContextModificationRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_InitialContextSetupRequestAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_InitialContextSetupRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGInitialContextSetupRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_DownlinkNASTransportAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_DownlinkNASTransport);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGDownlinkNASTransport, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PDUSessionResourceSetupRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PDUSessionResourceSetupRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGPDUSessionResourceSetupRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PDUSessionResourceReleaseCommand_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PDUSessionResourceReleaseCommand);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGPDUSessionResourceReleaseCommand, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PDUSessionResourceModifyRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PDUSessionResourceModifyRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGPDUSessionResourceModifyRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UEContextReleaseCommandAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextReleaseCommand);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGUEContextReleaseCommand, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_NASNonDeliveryIndicationAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_NASNonDeliveryIndication);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGNASNonDeliveryIndication, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_HandoverRequiredGnbAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_HandoverRequiredGnbAmf);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGHandoverRequired, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_HandoverRequestAmfgnb_id:
            /* Refer to VCCM_ALL_SA_HO_CallSetupRequest() */
            break;
        case NG_HandoverRequestAcknowledgeGnbAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_HandoverRequestAcknowledgeGnbAmf);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGHandoverRequestAcknowledge, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_HandoverCommandAmfGnb_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_HandoverCommandAmfGnb);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGHandoverCommand, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_HandoverNotifyGnbAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_HandoverNotifyGnbAmf);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGHandoverNotify, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_HandoverPreparationFailureGnbAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_HandoverPreparationFailureGnbAmf);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGHandoverPreparationFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_HandoverFailureGnbAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_HandoverFailureGnbAmf);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGHandoverFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_HandoverCancelGnbAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_HandoverCancelGnbAmf);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGHandoverCancel, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_HandoverCancelAcknowledgeAmfGnb_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_HandoverCancelAcknowledgeAmfGnb);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGHandoverCancelAcknowledge, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PathSwitchRequestGnbAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PathSwitchRequestGnbAmf);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGPathSwitchRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PathSwitchRequestAcknowledgeAmfGnb_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PathSwitchRequestAcknowledgeAmfGnb);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGPathSwitchRequestAcknowledge, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_PathSwitchRequestFailureAmfGnb_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PathSwitchRequestFailureAmfGnb);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGPathSwitchRequestFailure, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UEContextResumeRequestAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextResumeRequestAllAmf);
            break;
        case NG_UEContextResumeResponseAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextResumeResponseAmfAll);
            break;
        case NG_UEContextResumeFailureAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextResumeFailureAmfAll);
            break;
        case NG_UEContextSuspendRequestAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextSuspendRequestAllAmf);
            break;
        case NG_UEContextSuspendResponseAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextSuspendResponseAmfAll);
            break;
        case NG_UEContextSuspendFailureAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UEContextSuspendFailureAmfAll);
            break;
        case NG_PDUSessionResourceNotify_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_PDUSessionResourceNotify);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGPDUSessionResourceNotify, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UERadioCapabilityCheckRequestAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UERadioCapabilityCheckRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGUERadioCapabilityCheckRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UERadioCapabilityCheckResponseAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UERadioCapabilityCheckResponse);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGUERadioCapabilityCheckResponse, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_RerouteNASRequestAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_RerouteNASRequest);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGRerouteNASRequest, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_RRCInactiveTransitionReportAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_RRCInactiveTransitionReport);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGRRCInactiveTransitionReport, gnbIdOrNum, endPointIdx, threadId);
            break;
        case NG_UETNLABindingRequestAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UETNLABindingRelease);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGUETNLABindingRelease, gnbIdOrNum, endPointIdx, threadId);
            break;            
        case NG_DownlinkRANStatusTransferAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_DownlinkRANStatusTransfer);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGDownlinkRANStatusTransfer, gnbIdOrNum, endPointIdx, threadId);
            break;            
        case NG_UplinkRANStatusTransferAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UplinkRANStatusTransfer);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGUplinkRANStatusTransfer, gnbIdOrNum, endPointIdx, threadId);
            break;            
        case NG_DownlinkUEAssociatedNRPPaTransportAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_DownlinkUEAssociatedNRPPATransport);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGDownlinkUEAssociatedNRPPATransport, gnbIdOrNum, endPointIdx, threadId);
            break;            
        case NG_UplinkUEAssociatedNRPPaTransportAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_UplinkUEAssociatedNRPPATransport);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGUplinkUEAssociatedNRPPATransport, gnbIdOrNum, endPointIdx, threadId);
            break;            
        case NG_TraceStartAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_TraceStart);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGTraceStart, gnbIdOrNum, endPointIdx, threadId);
            break;    
        case NG_TraceFailureIndicationAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_TraceFailureIndication);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGTraceFailureIndication, gnbIdOrNum, endPointIdx, threadId);
            break;        
        case NG_DeactivateTraceAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_DeactivateTrace);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGDeactivateTrace, gnbIdOrNum, endPointIdx, threadId);
            break;            
        case NG_CellTrafficTraceAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_CellTrafficTrace);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGCellTrafficTrace, gnbIdOrNum, endPointIdx, threadId);
            break;            
        case NG_LocationReportingControlAmfAll_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_LocationReportControl);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGLocationReportControl, gnbIdOrNum, endPointIdx, threadId);
            break;            
        case NG_LocationReportingFailureIndicationAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_LocationReportFailureIndication);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGLocationReportFailureIndication, gnbIdOrNum, endPointIdx, threadId);
            break;            
        case NG_LocationReportAllAmf_id:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_LocationReport);
            MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGLocationReport, gnbIdOrNum, endPointIdx, threadId);
            break;            
        case NG_ErrorIndicationAllAll_id:
            if (direction == TX_MSG)
            {
                INCREASE_LOCAL_MSG_STAT(threadId, NG_ErrorIndicationTX);
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Tx_NGErrorIndication, gnbIdOrNum, endPointIdx, threadId);
            }
            else
            {
                INCREASE_LOCAL_MSG_STAT(threadId, NG_ErrorIndicationRX);
                MACRO_STAT_PMCC_MSG_PERIODIC(STAT_NGAP_MSG_UE, Rx_NGErrorIndication, gnbIdOrNum, endPointIdx, threadId);
            }
            break;
        default:
            INCREASE_LOCAL_MSG_STAT(threadId, NG_Others);
            break;
    }
}

void VCCM_UpdateX2APMsgStat(uint8_t threadId, uint16_t msgId, uint32_t gnbIdOrNum, uint16_t endPointIdx)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // In NVGNB, gnbIdOrNum must be gnbNum.
    // In ACPF,  gnbIdOrNum must be gnbId.

    switch (msgId)
    {
        case X2_ErrorIndication_id:  // Currently, ErrorIndication is collected in VNMB only
            INCREASE_LOCAL_MSG_STAT(threadId, X2_ErrorIndication);
            break;
        case X2_SgNBAdditionRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBAdditionRequest);
            // Because VCCB receives X2_SgNBAdditionRequest through CallSetupRequest from VNMB,
            // this stat is collected in VCCB_ProcMsgX2apSgNBAdditionRequest function.
            break;
        case X2_SgNBAdditionRequestAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBAdditionRequestAcknowledge);
            MACRO_STAT_PMCC_MSG(
                STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSgNBAdditionRequestAcknowledge, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBAdditionRequestReject_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBAdditionRequestReject);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSgNBAdditionRequestReject, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBReconfigurationComplete_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBReconfigurationComplete);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Rx_X2apSgNBReconfigurationComplete, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBModificationRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBModificationRequest);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Rx_X2apSgNBModificationRequest, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBModificationRequestAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBModificationRequestAcknowledge);
            MACRO_STAT_PMCC_MSG(
                STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSgNBModificationRequestAcknowledge, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBModificationRequestReject_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBModificationRequestReject);
            MACRO_STAT_PMCC_MSG(
                STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSgNBModificationRequestReject, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBModificationRequired_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBModificationRequired);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSgNBModificationRequired, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBModificationConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBModificationConfirm);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Rx_X2apSgNBModificationConfirm, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBModificationRefuse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBModificationRefuse);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Rx_X2apSgNBModificationRefuse, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBReleaseRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBReleaseRequest);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Rx_X2apSgNBReleaseRequest, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBReleaseRequestAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBReleaseRequestAcknowledge);
            MACRO_STAT_PMCC_MSG(
                STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSgNBReleaseRequestAcknowlegde, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBReleaseRequestReject_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBReleaseRequestReject);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSgNBReleaseReject, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBReleaseRequired_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBReleaseRequired);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSgNBReleaseRequired, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBReleaseConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBReleaseConfirm);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Rx_X2apSgNBReleaseConfirm, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBCounterCheckRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBCounterCheckRequest);
            break;
        case X2_SgNBChangeRequired_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBChangeRequired);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSgNBChangeRequired, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBChangeConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBChangeConfirm);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Rx_X2apSgNBChangeConfirm, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBChangeRefuse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBChangeRefuse);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Rx_X2apSgNBChangeRefuse, gnbIdOrNum, endPointIdx);
            break;
        case X2_RRCTransfer_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_RRCTransfer);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Rx_X2apRRCTransfer, gnbIdOrNum, endPointIdx);
            break;
        case X2_SecondaryRATDataUsageReport_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SecondaryRATDataUsageReport);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSecondaryDataUsageReport, gnbIdOrNum, endPointIdx);
            break;
        case X2_SgNBActivityNotification_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_SgNBActivityNotification);
            MACRO_STAT_PMCC_MSG(STAT_X2AP_MSG_UE_PER_GNB, Tx_X2apSgNBActivityNotification, gnbIdOrNum, endPointIdx);
            break;
        case X2_UEContextRelease_id:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_UEContextRelease);
            break;
        default:
            INCREASE_LOCAL_MSG_STAT(threadId, X2_Others);
            break;
    }
}

void VCCM_UpdateXNAPMsgStat(uint8_t threadId, uint16_t msgId, uint32_t gnbIdOrNum, uint16_t endPointIdx, enumDirection direction)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // In NVGNB, gnbIdOrNum must be gnbNum.
    // In ACPF,  gnbIdOrNum must be gnbId.

    switch (msgId)
    {
        case XN_HandoverRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_HandoverRequest);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnHandoverRequest, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_HandoverRequestAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_HandoverRequestAcknowledge);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnHandoverRequestAcknowledge, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_HandoverPreparationFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_HandoverPreparationFailure);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnHandoverPreparationFailure, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_HandoverCancel_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_HandoverCancel);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnHandoverCancel, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_UEContextRelease_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_UEContextRelease);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnUEContextRelease, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeReleaseConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeReleaseConfirm);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE, Tx_XnSnodeReleaseConfirm, gnbIdOrNum, endPointIdx);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeReleaseConfirm, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeReleaseReject_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeReleaseReject);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE, Rx_XnSnodeReleaseReject, gnbIdOrNum, endPointIdx);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeReleaseReject, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeReleaseRequestAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeReleaseRequestAcknowledge);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE, Rx_XnSnodeReleaseRequestAcknowledge, gnbIdOrNum, endPointIdx);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeReleaseRequestAcknowledge, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeReleaseRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeReleaseRequest);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE, Tx_XnSnodeReleaseRequest, gnbIdOrNum, endPointIdx);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeReleaseRequest, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeReleaseRequired_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeReleaseRequired);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE, Rx_XnSnodeReleaseRequired, gnbIdOrNum, endPointIdx);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeReleaseRequired, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_RRCTransfer_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_RRCTransfer);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnRRCTransfer, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_ActivityNotification_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_ActivityNotification);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnActivityNotification, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_RetrieveUEContextRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_RetrieveUEContextRequest);
            if(direction == TX_MSG)
            {
                MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnRetrieveUEContextRequest, direction, gnbIdOrNum, endPointIdx); // RX is handled during RRE and Resume procedures to avoid mulitple Rx from VNMB
            }
            break;
        case XN_RetrieveUEContextResponse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_RetrieveUEContextResponse);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnRetrieveUEContextResponse, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_RetrieveUEContextFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_RetrieveUEContextFailure);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnRetrieveUEContextFailure, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeAdditionRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeAdditionRequest);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeAdditionRequest, direction, gnbIdOrNum, endPointIdx);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE, Tx_XnSnodeAdditionRequest, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeAdditionRequestAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeAdditionRequestAcknowledge);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeAdditionRequestAcknowledge, direction, gnbIdOrNum, endPointIdx);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE,Rx_XnSnodeAdditionRequestAcknowledge, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeAdditionRequestReject_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeAdditionRequestReject);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeAdditionRequestReject, direction, gnbIdOrNum, endPointIdx);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE,Rx_XnSnodeAdditionRequestReject, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeChangeRequired_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeChangeRequired);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeChangeRequired, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeChangeConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeChangeConfirm);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeChangeConfirm, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeChangeRefuse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeChangeRefuse);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeChangeRefuse, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeModificationRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeModificationRequest);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeModificationRequest, direction, gnbIdOrNum, endPointIdx);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE,Tx_XnSnodeModificationRequest, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeModificationRequestAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeModificationRequestAcknowledge);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeModificationRequestAcknowledge, direction, gnbIdOrNum, endPointIdx);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE,Rx_XnSnodeModificationRequestAcknowledge, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeModificationRequestReject_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeModificationRequestReject);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeModificationRequestReject, direction, gnbIdOrNum, endPointIdx);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE,Rx_XnSnodeModificationRequestReject, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeModificationRequired_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeModificationRequired);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeModificationRequired, direction, gnbIdOrNum, endPointIdx);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE,Rx_XnSnodeModificationRequired, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeModificationConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeModificationConfirm);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeModificationConfirm, direction, gnbIdOrNum, endPointIdx);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE,Tx_XnSnodeModificationConfirm, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeModificationRefuse_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeModificationRefuse);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeModificationRefuse, direction, gnbIdOrNum, endPointIdx);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE,Tx_XnSnodeModificationRefuse, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeReconfigurationComplete_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeReconfigurationComplete);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeReconfigurationComplete, direction, gnbIdOrNum, endPointIdx);
            MACRO_STAT_PMCC_MSG(STAT_XNAP_MSG_UE,Tx_XnSnodeReconfigurationComplete, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNStatusTransfer_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNStatusTransfer);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNStatusTransfer, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_XnUAddressIndication_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_XnUAddressIndication);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnXNUAddressIndication, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_HandoverSuccess_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_HandoverSuccess);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnHandoverSuccess, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_ConditionalHandoverCancel_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_ConditionalHandoverCancel);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnConditionalHandoverCancel, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_EarlyStatusTransfer_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_EarlyStatusTransfer);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnEarlyStatusTransfer, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_RetrieveUEContextConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_RetrieveUEContextConfirm);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnRetrieveUEContextConfirm, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_PartialUEContextTransfer_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_PartialUEContextTransfer);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnPartialUEContextTransfer, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_PartialUEContextTransferAcknowledge_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_PartialUEContextTransferAcknowledge);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnPartialUEContextTransferAcknowledge, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_PartialUEContextTransferFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_PartialUEContextTransferFailure);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnPartialUEContextTransferFailure, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SNodeCounterCheckRequest_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SNodeCounterCheckRequest);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSNodeCounterCheckRequest, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_NotificationControlIndication_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_NotificationControlIndication);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnNotificationControlIndication, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_SecondaryRATDataUsageReport_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_SecondaryRATDataUsageReport);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnSecondaryRATDataUsageReport, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_TraceStart_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_TraceStart);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnTraceStart, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_DeactivateTrace_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_DeactivateTrace);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnDeactivateTrace, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_CellTrafficTrace_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_CellTrafficTrace);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnCellTrafficTrace, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_ScgFailureInformationReport_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_ScgFailureInformationReport);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnScgFailureInformationReport, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_ScgFailureTransfer_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_ScgFailureTransfer);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnScgFailureTransfer, direction, gnbIdOrNum, endPointIdx);
            break;
        case XN_ConditionalPScellChangeCancel_id:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_ConditionalPScellChangeCancel);
            MACRO_STAT_XNAP_MSG_UE_PER_GNB(XnConditionalPScellChangeCancel, direction, gnbIdOrNum, endPointIdx);
            break;
        default:
            INCREASE_LOCAL_MSG_STAT(threadId, XN_Others);
            break;
    }
}

void VCCM_UpdateTimerMsgStat(uint8_t threadId, uint16_t msgId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    switch (msgId)
    {
        case timE1_BearerContextSetup_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_E1_BearerContextSetup);
            break;
        case timE1_BearerContextModification_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_E1_BearerContextModification);
            break;
        case timE1_BearerContextRelease_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_E1_BearerContextRelease);
            break;

        case timF1_UeContextSetup_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_F1_UeContextSetup);
            break;
        case timF1_UeContextRelease_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_F1_UeContextRelease);
            break;
        case timF1_UeContextModification_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_F1_UeContextModification);
            break;
        case timF1_RrcDeliveryReportForDlNas_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_F1_RrcDeliveryReport);
            break;

        case timX2_DcOverall_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_X2_DcOverall);
            break;
        case timX2_SnStatusTransfer_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_X2_SnStatusTransfer);
            break;
        case timX2_UeContextRelease_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_X2_UeContextRelease);
            break;
        case timX2_SgNBReleaseConfirm_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_X2_SgNBReleaseConfirm);
            break;
        case timX2_SgNBReleaseRequired_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_X2_SgNBReleaseRequired);
            break;

        case timXN_SNodeRelease_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_XN_SnNodeReleaseAcknowledgment);
            break;

        case timInternalUserInactivitySig_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_INT_UserInactivitySig);
            break;
        case timInternalCallForcedRelease_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_INT_CallForcedRelease);
            break;
        case InternalULSrbIntegrityFailure_id:
            INCREASE_LOCAL_MSG_STAT(threadId, TIM_INT_ULSrbIntegrityFailure);
            break;

        default:
            break;
    }
}

void VCCM_UpdateInternalMsgStat(uint8_t threadId, uint16_t msgId, uint8_t dstThreadId)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    switch (msgId)
    {
        case msgCallSetupReq_VnmbVccb_id:
            INCREASE_LOCAL_MSG_STAT(threadId, INT_CallSetupReq);
            break;
        case msgCallSetupRsp_VccbVnmb_id:
            VCCB_CHECK_E_RANGE_AND_VOID(dstThreadId, VNMB_CALL_THREAD_NUM);
            INCREASE_LOCAL_MSG_STAT_DST(threadId, INT_CallSetupRsp, dstThreadId);
            break;
        case msgCallReleaseInd_VccbVnmb_id:
            VCCB_CHECK_E_RANGE_AND_VOID(dstThreadId, VNMB_CALL_THREAD_NUM);
            INCREASE_LOCAL_MSG_STAT_DST(threadId, INT_CallReleaseInd, dstThreadId);
            break;
        /* Handled in Main Task
        case msgCallReleaseCommand_VnmbVccb_id:
            INCREASE_LOCAL_MSG_STAT(threadId, INT_CallReleaseCommand);
            break;
        */
        case msgCallResourceChangeInd_VccbVnmb_id:
            VCCB_CHECK_E_RANGE_AND_VOID(dstThreadId, VNMB_CALL_THREAD_NUM);
            INCREASE_LOCAL_MSG_STAT_DST(threadId, INT_CallResourceChangeInd, dstThreadId);
            break;

        default:
            break;
    }
}

/****************************************************************************
 * Function      : VCCM_UpdateNgMsgStat
 * Description   :
 * Proc called   :
 * Proc calling  :
 * Input         :
 * Output        :
 * Update History:
 ****************************************************************************/
void VCCM_UpdateNrMsgStat(
    uint8_t threadId, uint8_t dstThreadId, uint16_t msgId, uint32_t gnbIdOrNum, uint16_t endPointIdx, enumDirection direction)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    // In NVGNB, gnbIdOrNum must be gnbNum.
    // In ACPF,  gnbIdOrNum must be gnbId.

    switch (msgId)
    {
            // RRC messages are collected through VCCM_UpdateNRRRCMsgStat function

        case MSGBASE_F1AP ... F1_MAX_id:
            VCCM_UpdateF1APMsgStat(threadId, msgId, gnbIdOrNum, endPointIdx);
            break;

        case MSGBASE_E1AP_new ... E1_MAX_id_new:
            VCCM_UpdateE1APMsgStat(threadId, msgId, gnbIdOrNum, endPointIdx, direction);
            break;

        case MSGBASE_NGAP ... NG_MAX_id:
            VCCM_UpdateNGAPMsgStat(threadId, msgId, gnbIdOrNum, endPointIdx, direction);
            break;

        case MSGBASE_X2AP ... X2_MAX_id:
            VCCM_UpdateX2APMsgStat(threadId, msgId, gnbIdOrNum, endPointIdx);
            break;

        case MSGBASE_XNAP ... XN_MAX_id:
            VCCM_UpdateXNAPMsgStat(threadId, msgId, gnbIdOrNum, endPointIdx, direction);
            break;

        case MSGBASE_TIMER ... TIMER_END_ID:
            VCCM_UpdateTimerMsgStat(threadId, msgId);
            break;

        default:
            VCCM_UpdateInternalMsgStat(threadId, msgId, dstThreadId);
            break;
    }
    return;
}

void FnVCCB_HandleSigDataInactivityExpiredBothForSA(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    uint8_t isReleaseRequired = FALSE;
    uint8_t isAttachTimerRequired = FALSE;

    if (IS_NRDC(ptCi))
    {
        if (IS_NRDC_MN(ptCi))
        {
            // SN Term Bearer Exist
            if (FnVCCB_IsAnySnTermBearer(ptCi))
            {
                // NR-DC SN Inactivity is expired also.
                if (ptCi->CallUserInactivity.nrdcSN_UELevel_InactivityStatus == ActivityStatus_INACTIVE)
                {
                    isReleaseRequired = TRUE;
                }
            }
            else  // SN Term Bearer is not Exist
            {
                // Call Release regardless of SgNB Inactivity
                isReleaseRequired = TRUE;
            }
        }
        else  // IS_NRDC_SN(ptCi)
        {
            if ((pGnb->UserInactivityNrdcSN.xnReleaseTimer != 0) &&  // !0: xnReleaseTimer used
                (FALSE == FnVCCB_ExistMNTermBearerInNrdcSN(ptCi)))   // MNTerm Bearer is not exist
            {
                isAttachTimerRequired = TRUE;
            }

            if (isAttachTimerRequired == TRUE)
            {
                if (ptCi->CallUserInactivity.isReleaseTimerTimeout == TRUE)  // Timer Timeout happened already
                {
                    isReleaseRequired = TRUE;
                }
                else if (ptCi->CallUserInactivity.releaseTimer.id <= 0)
                {
                    VLIB_AttachTimer(&ptCi->CallUserInactivity.releaseTimer, ptCi, timXN_SNodeReleaseRequired_id);
                    ptCi->CallUserInactivity.isReleaseTimerTimeout = FALSE;
                }
            }
            else
            {
                if (ptCi->CallUserInactivity.releaseTimer.id > 0)
                {
                    VCCB_CLEAR_TIMER(&ptCi->CallUserInactivity.releaseTimer, CANCEL_TIMER);
                }
                ptCi->CallUserInactivity.isReleaseTimerTimeout = FALSE;
            }
        }
    }
    else  // Basic
    {
        isReleaseRequired = TRUE;
    }

    if (isReleaseRequired == TRUE)
    {
        FnVCCB_TriggerCallReleaseByUserInactivityForSA(ptCi);
    }

    return;
}

/**
 *  @brief   Function to update User Inactivity state and do action if expiry
 *  @details After both timers expiration: Signaling (VCCB timer - sigInactivityTimer) and Data (provided from CU-UP on
 * E1 link) And if there are no ongoing Basic or Mobility procedures then SgNB Release procedure is triggered. Feature
 * On/Off takes effect on Signaling timer, Data Inactivity needs to be watched anyways.
 *  @param [IN] ptCi  : pointer to CallInfo structure
 *  @param [IN] event : User Inactivity Event
 */
void FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(callInfo_type *ptCi, enumUserInactivityEvent_type event)
{
    AUTO_TRACE_FUNC;
    int16_t status = GOOD;

    if (ptCi == NULL)
    {
        VCCB_PRINT_ERROR("ptCi(=NULL) in FnVCCB_UpdateUserInactStateAndDoActionIfExpiry\n");
        return;
    }
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    // Signaling User Inactivity timer re(start)
    if (event == UserInactivityEvent_SIG_RESTART)
    {
        const bool isNsaCall = ptCi->callType == E_CALLTYPE_NSA;

        bool isEnabled = false;  // 22B_UserInactivity_FR214

        uint16_t signalingTimer = pGnb->UserInactivitySA.signalingTimer;
        if(isNsaCall)
        {
            signalingTimer = pGnb->UserInactivity.signalingTimer;
        }
        else if(IS_NRDC_SN(ptCi))
        {
            signalingTimer = pGnb->UserInactivityNrdcSN.signalingTimer;
        }
        else if(IS_REDCAP_UE(ptCi))
        {
            signalingTimer = pGnb->UserInactivitySA.redCap.signalingTimer;
        }

        // 22B_UserInactivity_FR214 Start
        //  SA.NRDC.SN
        if ((ptCi->callType == E_CALLTYPE_SA) && (IS_NRDC_SN(ptCi)))
        {
            if (pGnb->UserInactivityNrdcSN.featureEnabled == EQUIP) isEnabled = true;
        }
        else  // SA, NSA
        {
            if (ptCi->CallUserInactivity.featureEnabled == EQUIP) isEnabled = true;
        }
        // 22B_UserInactivity_FR214 End

        if (!isEnabled)
        {
            VCCB_PRINT_CALL_DATA(ptCi, "[UserInactivity] Feature is OFF\n");
        }
        else if (signalingTimer == 0)
        {
            if (ptCi->CallUserInactivity.sigInactivityTimer.id > 0)
            {
                VCCB_CLEAR_TIMER(&ptCi->CallUserInactivity.sigInactivityTimer, CANCEL_TIMER);
            }
            event = UserInactivityEvent_SIG_EXPIRY;
        }
        else
        {
            if (ptCi->CallUserInactivity.releaseTimer.id > 0)
            {
                VCCB_CLEAR_TIMER(&ptCi->CallUserInactivity.releaseTimer, CANCEL_TIMER);
            }

            if (ptCi->CallUserInactivity.sigInactivityTimer.id > 0)
            {
                VCCB_CLEAR_TIMER(&ptCi->CallUserInactivity.sigInactivityTimer, CANCEL_TIMER);
            }            
            
            if (ptCi->bitFlag.stopUserInactivityByScgSuspend == TRUE)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "[UserInactivity] Suspended due to SCG Failure Handling\n");
            }
            else
            {
                VLIB_AttachTimer(&ptCi->CallUserInactivity.sigInactivityTimer, ptCi, timInternalUserInactivitySig_id);
            }
            ptCi->CallUserInactivity.isReleaseTimerTimeout = FALSE;
        }
    }
    else if (event == UserInactivityEvent_DATA_RESTART)
    {
        if (ptCi->CallUserInactivity.releaseTimer.id > 0)
        {
            VCCB_CLEAR_TIMER(&ptCi->CallUserInactivity.releaseTimer, CANCEL_TIMER);
        }
        ptCi->CallUserInactivity.isReleaseTimerTimeout = FALSE;
    }

    enumUserInactivityState_type newState = UserInactivityState_DATA_SIG_EXPIRED;
    enumUserInactivityState_type currentState = ptCi->CallUserInactivity.ueInactivityState;

    switch (currentState)
    {
        case UserInactivityState_ACTIVE:
            if (event == UserInactivityEvent_SIG_EXPIRY)
            {
                newState = UserInactivityState_SIG_EXPIRED;
            }
            else if (event == UserInactivityEvent_DATA_EXPIRY)
            {
                newState = UserInactivityState_DATA_EXPIRED;
            }
            else
            {
                // VCCB_PRINT_CALL_DATA(ptCi, "[UserInactivity] Ignore UserInactivityEvent = %d In
                // UserInactivityState_ACTIVE state\n", event);
                return;
            }
            break;

        case UserInactivityState_DATA_EXPIRED:
            if (event == UserInactivityEvent_SIG_EXPIRY)
            {
                newState = UserInactivityState_DATA_SIG_EXPIRED;
            }
            else if (event == UserInactivityEvent_DATA_RESTART)
            {
                newState = UserInactivityState_ACTIVE;
            }
            else
            {
                // VCCB_PRINT_CALL_DATA(ptCi, "[UserInactivity] Ignore UserInactivityEvent = %d In
                // UserInactivityState_DATA_EXPIRED state\n", event);
                return;
            }
            break;

        case UserInactivityState_SIG_EXPIRED:
            if (event == UserInactivityEvent_DATA_EXPIRY)
            {
                newState = UserInactivityState_DATA_SIG_EXPIRED;
            }
            else if (event == UserInactivityEvent_SIG_RESTART)
            {
                newState = UserInactivityState_ACTIVE;
            }
            else
            {
                // VCCB_PRINT_CALL_DATA(ptCi, "[UserInactivity] Ignore UserInactivityEvent = %d In
                // UserInactivityState_SIG_EXPIRED state\n", event);
                return;
            }
            break;

        case UserInactivityState_DATA_SIG_EXPIRED:
            if (event == UserInactivityEvent_SIG_RESTART)
            {
                newState = UserInactivityState_DATA_EXPIRED;
            }
            else if (event == UserInactivityEvent_DATA_RESTART)
            {
                newState = UserInactivityState_SIG_EXPIRED;
            }
            break;

        // All cases verified. default not needed.
        default:
            break;
    }

    ptCi->CallUserInactivity.ueInactivityState = newState;

    if (currentState != newState)
    {
        VCCB_PRINT_CALL_DATA(
                ptCi, "[UserInactivity] State change [%d -> %d] due to event[%d]\n", currentState, newState, event);
    }

    if (newState == UserInactivityState_DATA_SIG_EXPIRED)
    {
        if (ptCi->state != STATE_DB && ptCi->state != STATE_Conn)
        // Ongoning Basic    EN-DC procedures: SgNB Addition, SgNB Modification, SgNb Rel
        // Ongoning Mobility EN-DC procedures: SgNB Change,   Intra-gNB-DU HO,   Inter-gNB-DU HO
        {
            VCCB_PRINT_CALL_DATA(ptCi,
                "[UserInactivity] Enqueue UserInactivityState_DATA_SIG_EXPIRED set during ongoing "
                "procedure ptCi->state=%d\n",
                ptCi->state);
            if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_E1_INACTIVITY_NOTI))
            {
                VCCB_PRINT_CALL_INFORMATIVE(
                    ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_E1_INACTIVITY_NOTI) in %s fail\n", __FUNCTION__);
            }
            return;
        }

        status = FnVCCB_DoInactivityActionInIdleState(ptCi);
        if (status != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_DoInactivityActionInIdleState ERROR(%d)\n", status);
        }
    }
    return;
}


/**
 *  @brief   Function to update User Inactivity state and do action when recv/send NRPPA-PDU
 *  @param [IN] ptCi  : pointer to CallInfo structure
 */
void FnVCCB_CheckAndRestartSignalingTimerForNRPPa(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (pGnb->UserInactivitySA.nrPpaSignalingTimerEnabled == enabled)
    {
        FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_SIG_RESTART);
    }
}

/**
 *  @brief   Function to do InactivityAction in idle states
 *  @param [IN] ptCi   : pointer to CallInfo structure
 *  @return     status : GOOD/ERROR (int16_t)
 */
int16_t FnVCCB_DoInactivityActionInIdleState(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    int16_t status = GOOD;
    uint8_t x2Reporting = 0;
    uint8_t sendReleaseRequiredFlag = 0;
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (IS_SUPPORT_RRC_INACTIVE(ptCi))
    {
        switch (ptCi->state)
        {
            case STATE_Conn:
                if (ERROR == FnVCCB_CheckRRCInactive(ptCi))
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "FnVCCB_CheckRRCInactive in %s fail!\n", __FUNCTION__);
                    return ERROR;
                }
                break;

            case STATE_Inact_Suspend:
                {
                    VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, CANCEL_TIMER);

                    MACRO_RESET_CALL_FAULT_CAUSES;
                    MACRO_CALL_FAULT_SAVE(InternalUserInactivityUpdate_id, CauseCpInternalSaRrcInactiveRelease);

                    if (GETBIT(ptCi->flag.setupFlag, NGC_CONNECTION_FLAG))
                    {
                        ptCi->bitFlag.sentRelRequestToAmfByUserInact = VCCB_FLAG_ON;    // for statistics on NR retainability

                        status = FnVCCB_SendNGAP_UeContextReleaseRequest(ptCi);
                        if (status != GOOD)
                        {
                            ptCi->bitFlag.sentRelRequestToAmfByUserInact = VCCB_FLAG_OFF;
                            MACRO_RESET_CALL_FAULT_CAUSES;
                            MACRO_CALL_FAULT_SAVE(InternalUserInactivityUpdate_id, CauseCpInternalSaSendNgMessageError);
                            status = VCCB_CALL_RELEASE_TRIGGER(ptCi);
                            return status;
                        }

                        MACRO_RESET_CALL_FAULT_CAUSES;
                        VLIB_AttachTimer(&ptCi->timer, ptCi, timNG_UEContextRelease_id);
                        VLIB_SetCurStateAll(ptCi, STATE_Inact_RelCmd);  // New State

                        ptCi->ueInfo.rrcResumeInfo.goingToRRCIdleFlag = VCCB_FLAG_ON;
                    }
                    else
                    {
                        status = VCCB_CALL_RELEASE_TRIGGER(ptCi);
                        return status;
                    }
                }
                break;

            default:
                VCCB_PRINT_CALL_ERROR(ptCi, "Invalid ptCi->state(%d) in %s\n", ptCi->state, __FUNCTION__);
                break;
        }
        return GOOD;
    }
    else
    {
        if (ptCi->CallUserInactivity.ueInactivityState == UserInactivityState_DATA_SIG_EXPIRED)
        {
            if (ptCi->callType == E_CALLTYPE_NSA)
            {
                if (CHECK_STATECMD_RELEASE(ptCi))
                {
                    VCCB_PRINT_CALL_ERROR(
                        ptCi, "[UserInactivity] Inactivity occurred in release stateCmd(%d)\n", ptCi->stateCmd);
                    return GOOD;
                }

                VCCB_PRINT_CALL_MSG(
                    ptCi, "[UserInactivity] Trigger SgNB Release procedure in Call state %d\n", ptCi->state);

                if (VCCM_IsPossibleFreqBaseControl_InUserInact(ptCi) ==
                    GOOD)  // 1-1. FreqBased Control feature FOO & switch is ON.
                {
                    // (1) No Need to Check Samsung eNB

                    if ((ptCi->CallUserInactivity.desiredActivityNotificationLevel ==
                                desiredActivityNotifLvl_NA ||  // (2) No Desired level from MeNB Req
                            ptCi->CallUserInactivity.desiredActivityNotificationLevel == desiredActivityNotifLvl_NONE))
                    {
                        VCCM_GetFreqBasedControl_InUserInact(
                            ptCi, &x2Reporting);  //(3) Determine x2Reporting type with FreqBased Control.
                        if (x2Reporting == x2Reporting_RELEASE_REQUIRED)
                        {
                            sendReleaseRequiredFlag++;
                        }
                    }
                }
                else  // 1-2. FreqBased Control feature FOO & switch is OFF.
                {
                    if (getInactivityVendor(ptCi) == ActivityNotification_SamsungEnb)  // (1). Check Samsung MeNB.
                    {
                        if ((ptCi->CallUserInactivity.desiredActivityNotificationLevel == desiredActivityNotifLvl_NA ||
                                // (2) No Desired level from MeNB Req
                                ptCi->CallUserInactivity.desiredActivityNotificationLevel ==
                                    desiredActivityNotifLvl_NONE))
                        {
                            if (pGnb->UserInactivity.x2Reporting == x2Reporting_RELEASE_REQUIRED)
                            // (3) SgNB Config with x2Reporting
                            {
                                VCCB_PRINT_CALL_COMMENT(ptCi, " x2Reporting_RELEASE_REQUIRED \n");
                                sendReleaseRequiredFlag++;
                            }
                        }
                    }
                }

                if (sendReleaseRequiredFlag)
                {
                    MACRO_RESET_CALL_FAULT_CAUSES;
                    MACRO_CALL_FAULT_SAVE(InternalUserInactivityUpdate_id, CauseCpInternalUserInactivity);

                    status = VXIL_sendX2_SgNBReleaseRequired(ptCi, STAT_SGNB_INIT_SGNB_REL_PER_GNB, FALSE);
                    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VXIL_sendX2_SgNBReleaseRequired error!\n");

                    VLIB_SetCurStateAll(ptCi, STATE_DCSNRelRqrd);
                    VLIB_AttachTimer(&ptCi->timer, ptCi, timX2_SgNBReleaseConfirm_id);
                }
                else
                {
                    VCCB_PRINT_COMMENT(
                        "[UserInactivity CallId=%d] Sending X2 RELEASE REQUIRED is disabled.\n", ptCi->callId);
                }

                if ((pGnb->UserInactivity.x2ReleaseTimer != 0) && (ptCi->CallUserInactivity.releaseTimer.id <= 0) &&
                    (VCCM_NeedToSendX2SgNBActivityNotification(ptCi) == GOOD))
                {
                    // State : DB
                    // To prevent Zombi Call on MeNB, SgNB sends SgNBReleaseRequired to MeNB after 30 min
                    VLIB_AttachTimer(&ptCi->CallUserInactivity.releaseTimer, ptCi, timX2_SgNBReleaseRequired_id);
                }
            }
            else  // SA CALL
            {
                FnVCCB_HandleSigDataInactivityExpiredBothForSA(ptCi);
            }
        }
        else  // ptCi->CallUserInactivity.ueInactivityState != UserInactivityState_DATA_SIG_EXPIRED
        {
            // For NE-DC User Inactivity
            // If all MN_Term_SPLIT_Bearer are in Inactive, then trigger SN Release.
            if ((ptCi->callType == E_CALLTYPE_SA) &&
                ((ptCi->CallUserInactivity.activityNotificationLevel == activityNotifLvl_DRB) ||
                    (ptCi->CallUserInactivity.activityNotificationLevel == activityNotifLvl_PDUSession)))
            {
                if (IsSupport_NEDC_InActivity() && IsAvailable_MrdcInfo())
                {
                    if (VCCM_checkForSplitBearerSnNodeRelease(ptCi))
                    {
                        ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_InactivityRelease;
                        status = VCCM_TriggerMgNBInitSNReleaseProcedure(ptCi);
                        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_TriggerMgNBInitSNReleaseProcedure ERROR !!\n");
                    }
                }
            }
        }
    }
    return GOOD;
}

int16_t VCCM_IsPossibleFreqBaseControl_InUserInact(callInfo_type *ptCi)
{
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (FOO.VF_UserInactivityTimer_FrequencyBasedControl != TRUE)
    {
        return BREAK;
    }

    if (pGnb->UserInactivity.freqControlInfo.featureSwitch != enabled)
    {
        return BREAK;
    }

    return GOOD;
}

int16_t VCCM_NeedToSendX2SgNBActivityNotification(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint8_t x2Reporting = 0;

    if ((ptCi->CallUserInactivity.featureEnabled))  // 22B_UserInactivity_FR214
    {
        if (ptCi->CallUserInactivity.desiredActivityNotificationLevel == desiredActivityNotifLvl_UE ||
            ptCi->CallUserInactivity.desiredActivityNotificationLevel == desiredActivityNotifLvl_ERAB)
        {
            VCCB_PRINT_COMMENT("Using X2 ACTIVITY NOTIFICATION by MeNB Req.\n");
            return GOOD;
        }

        if (VCCM_IsPossibleFreqBaseControl_InUserInact(ptCi) == GOOD)
        {
            //(1) No Checking X2 Vendor.

            //(2) MeNB Not requested(desiredActivityNotifLvl_NA), So get x2Reporting from SgNB Freqbased Control.
            if (VCCM_GetFreqBasedControl_InUserInact(ptCi, &x2Reporting) == GOOD)
            {
                if (x2Reporting == x2Reporting_ACTIVITY_NOTIFICATION)
                {
                    VCCB_PRINT_COMMENT("Using X2 ACTIVITY NOTIFICATION by SgNB FreqGroup.\n");
                    return GOOD;
                }
            }
        }

        else
        {
            //(1) for E. and others, send even if it is not requested.
            if (getInactivityVendor(ptCi) != ActivityNotification_SamsungEnb)
            {
                VCCB_PRINT_COMMENT("Using X2 ACTIVITY NOTIFICATION by Other Vendor.\n");
                return GOOD;
            }

            //(2) MeNB(Samsung) Not requested(desiredActivityNotifLvl_NA), So get x2Reporting from SgNB yang.
            if (pGnb->UserInactivity.x2Reporting == x2Reporting_ACTIVITY_NOTIFICATION)
            {
                VCCB_PRINT_COMMENT("Using X2 ACTIVITY NOTIFICATION by SgNB Config.\n");
                return GOOD;
            }
        }
    }

    return BREAK;
}

void VCCM_GetGroupIdxbyFreqInFreqList(callInfo_type *ptCi, uint32_t reqFreq, uint8_t *matchedGroupIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t loop = 0;
    uint8_t grpIdx = 0;

    FreqBasedUserInactivityList_type *pFreqList = NULL;

    // Find same frequency in FreqList of User Inactivity.
    for (loop = 0; loop < VCCB_MAX_USER_INACT_FREQLIST; loop++)
    {
        pFreqList = &pGnb->UserInactivity.freqControlInfo.freqList[loop];
        if (pFreqList->usage != CI_use) continue;

        // If same freq, then return group Idx.
        if (pFreqList->ssbArfcn == reqFreq)
        {
            grpIdx = pFreqList->frequencyGroupIndex;
            if ((grpIdx < VCCB_MAX_USER_INACT_FREQGROUP) &&
                (pGnb->UserInactivity.freqControlInfo.freqGroup[grpIdx].usage == CI_use))
            {
                *matchedGroupIdx = grpIdx;
                return;
            }
        }
    }
    return;
}

typedef struct
{
    uint32_t freq;  // ssbArfcn
    int32_t sCellIdx;
} FreqBasedTempList_type;

int16_t VCCM_GetFreqBasedControl_InUserInact(callInfo_type *ptCi, uint8_t *getX2Reporting)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t cellIdx = 0;
    uint16_t tmpFreqCount = 0;
    uint16_t maxFreqList = (MAX_SCELL_PER_CALL) + 1;
    FreqBasedTempList_type tmpFreqList[maxFreqList];
    FreqBasedUserInactivityControl_type *pFreqControlInfo = &pGnb->UserInactivity.freqControlInfo;

    uint8_t highestPriority = 0;      // Higher is high priority. so initial value is lowest value.
    int32_t lowestSCellIdx = 0xFFFF;  // Lower is high priority. so initial value is highest value.
    uint8_t finalX2Reporting =
        pFreqControlInfo->freqGroup[VCCB_USER_INACT_DEFAULT_GROUP_IDX].x2Reporting;  // default Group(0)
    uint8_t matchedGroupIdx = VCCB_MAX_USER_INACT_FREQGROUP;

    // ------------------------------------------------------------------------------
    // 1. Make FreqList from Pcell & Scell
    // ------------------------------------------------------------------------------
    // Get PCell
    tmpFreqList[tmpFreqCount].freq = pCell->ssbArfcn;
    tmpFreqList[tmpFreqCount].sCellIdx = -1;  // PCell has lowest Scell Idx.
    tmpFreqCount++;                           // tmpFreqCount = 1

    // Get SCell
    scellList_type &scells = FnVCCB_GetScellInfoList(*ptCi);
    for (cellIdx = 0; cellIdx < MAX_SCELL_PER_CALL; cellIdx++)
    {
        if ((scells[cellIdx].state != SCELL_STATE_ADDED) ||
            (scells[cellIdx].action != SCELL_ACTION_KEEP))  // It means committed.
        {
            continue;
        }

        if (tmpFreqCount < maxFreqList)
        {
            tmpFreqList[tmpFreqCount].freq = scells[cellIdx].ssbArfcn;
            tmpFreqList[tmpFreqCount].sCellIdx = static_cast<int32_t>(
                scells[cellIdx].sCellIndex);  // When state is SCELL_STATE_ADDED, scellIndex is valid.
            tmpFreqCount++;
        }
    }

    // ------------------------------------------------------------------------------
    // 2. Get GroupIdx and x2Reporting from tmpFreqList.
    // ------------------------------------------------------------------------------
    uint8_t finalMatchedGroupIdx = VCCB_MAX_USER_INACT_FREQGROUP;  // for debug print
    for (cellIdx = 0; cellIdx < tmpFreqCount; cellIdx++)
    {
        // (2-1) Get Group Index.
        matchedGroupIdx = VCCB_MAX_USER_INACT_FREQGROUP;
        VCCM_GetGroupIdxbyFreqInFreqList(ptCi, tmpFreqList[cellIdx].freq, &matchedGroupIdx);

        if (matchedGroupIdx >= VCCB_MAX_USER_INACT_FREQGROUP)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "(sCellIdx : %d) There is no matched group. Set on default group.\n",
                tmpFreqList[cellIdx].sCellIdx);
            matchedGroupIdx = VCCB_USER_INACT_DEFAULT_GROUP_IDX;  // default Group(0)
        }
        else
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "(sCellIdx : %d) match group idx : %d..\n", tmpFreqList[cellIdx].sCellIdx, matchedGroupIdx);
        }

        // (2-2)  Compare priority and Get x2Reporting.
        //  Priority : Higher is high priority.
        //  sCellIdx : Lower is high priority. (Pcell:-1, Scell Idx:1 ~ MAX_SCELL_INDEX)
        if (pFreqControlInfo->freqGroup[matchedGroupIdx].priority > highestPriority)
        {
            highestPriority = pFreqControlInfo->freqGroup[matchedGroupIdx].priority;
            finalX2Reporting = pFreqControlInfo->freqGroup[matchedGroupIdx].x2Reporting;
            lowestSCellIdx = tmpFreqList[cellIdx].sCellIdx;
            finalMatchedGroupIdx = matchedGroupIdx;  // for debug print
        }
        else if ((pFreqControlInfo->freqGroup[matchedGroupIdx].priority == highestPriority) &&  // same priority
                 (tmpFreqList[cellIdx].sCellIdx < lowestSCellIdx))  // lower sCellIdx  (PCell has lowest value)
        {
            finalX2Reporting = pFreqControlInfo->freqGroup[matchedGroupIdx].x2Reporting;
            lowestSCellIdx = tmpFreqList[cellIdx].sCellIdx;
            finalMatchedGroupIdx = matchedGroupIdx;  // for debug print
            VCCB_PRINT_CALL_COMMENT(ptCi, "Same Priority, compare sCellIdx. (PCell has lowest sCellIdx)\n");
        }
    }

    VCCB_PRINT_CALL_COMMENT(
        ptCi, "Determine Frequency Group : %d (selected sCellIdx : %d)\n", finalMatchedGroupIdx, lowestSCellIdx);
    *getX2Reporting = finalX2Reporting;

    return GOOD;
}

// 22C2
void FnVCCB_CheckErabAndUpdateDataUserInactivity(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ptCi->callType != E_CALLTYPE_NSA)
    {
        return;
    }

    if (ptCi->CallUserInactivity.featureEnabled != EQUIP)
    {
        return;
    }

    const auto selectedLevel = FnVCCB_Get_UserInactivity_NotiLevel(ptCi);
    if (selectedLevel == activityNotifLvl_UE)
    {
        if (RscCall::isRequiredActivityNotification(*ptCi))
        {
            if ((ptCi->CallUserInactivity.desiredActivityNotificationLevel != desiredActivityNotifLvl_NONE) &&
                (GOOD == VCCM_NeedToSendX2SgNBActivityNotification(ptCi)))
            {
                if (ERROR == VXIL_sendX2_SgNBActivityNotification(ptCi))
                {
                    VCCB_PRINT_ERROR("VXIL_sendX2_SgNBActivityNotification ERROR!!\n");
                }
            }
            RscCall::updateUeActivityStatusReported(*ptCi);
        }
    }

    // Do Action
    const auto dataActivityStatus = RscCall::getDataActivityStatus(*ptCi);
    if (dataActivityStatus == ActivityStatus_ACTIVE)
    {
        FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_DATA_RESTART);
    }
    else
    {
        FnVCCB_UpdateUserInactStateAndDoActionIfExpiry(ptCi, UserInactivityEvent_DATA_EXPIRY);
    }

    return;
}

/****************************************************************************
 * @brief     Stop SgNB change on source VCCB
 *
 * @param[in,out]   ptCi : call information / callInfo_type
 * @return          void
 ****************************************************************************/
void VHCM_StopSgNBChange(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    if (ERROR == VLIB_FreeCallGnbInfo(ptCi, ptCi->hoInfo.hoGnbIdx))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_FreeCallGnbInfo ERROR!\n");
    }

    VLIB_SetNoAttemptFlag(ptCi, STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB);
    VLIB_SetNoAttemptFlag(ptCi, STAT_INTER_SN_PSCELL_CHANGE_SRC_PER_GNB_DU_ID_CELL_SPID);

    SET_STATE_CMD(Idle_cmd);
    VLIB_setBearerStatusToIdle(ptCi);
    VLIB_SetCurStateAll(ptCi, STATE_DB);
    ptCi->cslInfo.cslEvent = csl_event_undefined;

    MACRO_RESET_CALL_FAULT_CAUSES;

    VCCB_ENDC_OnHoRollback(*ptCi);
}

/****************************************************************************
 * @brief  Check if bandNR is satisfying allowed band combination.
 * @param  ptCi          : pointer to UE Context
 * @param  bandNR        : band value
 ****************************************************************************/
int16_t VCCB_checkAllowedBCListMRDC(callInfo_type *ptCi, uint16_t bandNR)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    uint16_t ueCapaIdx = 0;

    if (IS_NRDC_SN(ptCi) && ((VCCB_FLAG_OFF == ptCi->cgConfigInfo.configRestrictInfoFlag) ||
                                (VCCB_FLAG_OFF == ptCi->cgConfigInfo.configRestrictInfo.allowedBC_ListMRDC_Flag)))
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "allowedBC_ListMRDC is not included!! Just skip VCCB_checkAllowedBCListMRDC\n");

        // Samsung MN will include allowedBC_ListMRDC always during SNodeAdditionRequest procedure.
        // TODO: This is temporal code for 21C IODT for testing with simulator.
        return GOOD;
    }

    for (ueCapaIdx = 0; ueCapaIdx < MIN(ptCi->ueInfo.ueCapa.nr.rf.nrOfBands, MAX_NUM_UECAPA_NR_BANDS); ueCapaIdx++)
    {
        if (bandNR == ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[ueCapaIdx].bandNR)
        {
            if (VCCB_FLAG_ON ==
                ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[ueCapaIdx].isBandAllowedByBandCombinations)
            {
                return GOOD;
            }
            break;
        }
    }

    return BREAK;
}

/****************************************************************************
 * @brief  Check if bandNR is supported as pcell band (if UE has DL+UL for bandNR in any BC)
 * @param  ptCi          : pointer to UE Context
 * @param  bandNR        : band value
 ****************************************************************************/
int16_t VCCB_isBandSupportedAsPcellBand(const callInfo_type *ptCi, uint16_t bandNR)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    uint16_t ueCapaIdx = 0;
    for (ueCapaIdx = 0; ueCapaIdx < MIN(ptCi->ueInfo.ueCapa.nr.rf.nrOfBands, MAX_NUM_UECAPA_NR_BANDS); ueCapaIdx++)
    {
        if (bandNR == ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[ueCapaIdx].bandNR)
        {
            if (VCCB_FLAG_ON == ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[ueCapaIdx].isBandSupportedAsPcellBand)
            {
                return GOOD;
            }
            break;
        }
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "Band %u is not supported as Pcell band\n", bandNR);

    return BREAK;
}

/****************************************************************************
 * @brief  Check if bandNR is NR CA capable (if UE has DL+UL for bandNR and at least one more NR band in this BC).
 * @param  ptCi          : pointer to UE Context
 * @param  bandNR        : band value
 ****************************************************************************/
int16_t VCCB_isBandNrCaCapable(const callInfo_type *ptCi, uint16_t bandNR)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    uint16_t ueCapaIdx = 0;
    for (ueCapaIdx = 0; ueCapaIdx < MIN(ptCi->ueInfo.ueCapa.nr.rf.nrOfBands, MAX_NUM_UECAPA_NR_BANDS); ueCapaIdx++)
    {
        if (bandNR == ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[ueCapaIdx].bandNR)
        {
            if (VCCB_FLAG_ON == ptCi->ueInfo.ueCapa.nr.rf.supportedBandListNR[ueCapaIdx].isBandNrCaCapable)
            {
                return GOOD;
            }
            break;
        }
    }

    return BREAK;
}

/********************************************************************************************
 * @brief           Check if the TAC exists in Forbidden the TAC list.
 *
 * @param[in]       tac    : tracking area code to check
 * @param[in]       ptHrl  : Handover Restriction List / hoRestrictInfo_type
 * @return          status : GOOD - is not restricted, ERROR - is restricted / int16_t
 ********************************************************************************************/
int16_t VCCM_CheckForbiddenFiveGTAC(const hoRestrictInfo_type *ptHrl, uint32_t tac, uint32_t longId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptHrl);

    uint16_t fPlmnIdx = 0;

    for (fPlmnIdx = 0; fPlmnIdx < ptHrl->numForbidTaPlmn; fPlmnIdx++)
    {
        if (longId == ptHrl->forbiddenTA[fPlmnIdx].plmn.longId)
        {
            if (NULL != bsearch(&tac, ptHrl->forbiddenTA[fPlmnIdx].fiveGTac,
                            MIN(ptHrl->forbiddenTA[fPlmnIdx].numTac, NG_MaxnoofForbTACs), sizeof(uint32_t),
                            VLIB_QsortUint32AscendingOrder))
            {
                VCCB_PRINT_COMMENT("VCCM_CheckForbiddenFiveGTA found forbiddenTA(0x%x, longId:%d)\n", tac, longId);
                return ERROR;
            }
        }
    }

    return GOOD;
}

/********************************************************************************************
 * @brief           Check if the TAC exists in not allowed the TAC list.
 *
 * @param[in]       tac    : tracking area code to check
 * @param[in]       ptHrl  : Handover Restriction List / hoRestrictInfo_type
 * @return          status : GOOD - is not restricted, ERROR - is restricted / int16_t
 ********************************************************************************************/
int16_t VCCM_CheckNotAllowedTA(const hoRestrictInfo_type *ptHrl, uint32_t tac, uint32_t longId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptHrl);

    uint16_t serviceAreadIdx = 0, loop = 0;
    uint32_t notAllowedTac = 0;
    uint16_t tacIdx;

    for (serviceAreadIdx = 0; serviceAreadIdx < ptHrl->numServiceArea; serviceAreadIdx++)
    {
        if (longId != ptHrl->serviceArea[serviceAreadIdx].plmn.longId) continue;

        const allowedTac_type *pAllowedTac = &ptHrl->serviceArea[serviceAreadIdx].not_allowed;

        for (tacIdx = 0; tacIdx < pAllowedTac->numTac; tacIdx++)
        {
            notAllowedTac = 0;
            for (loop = 0; loop < FIVEGS_TAC_OCT_LEN; loop++)
            {
                notAllowedTac |= static_cast<uint32_t>(pAllowedTac->tac[tacIdx][loop] << (8 * (2 - loop)));
            }
            if (tac == notAllowedTac)
            {
                VCCB_PRINT_COMMENT("VCCM_CheckNotAllowedTA found forbiddenTA(0x%x, longId:%x)\n", tac, longId);
                return ERROR;
            }
        }
    }

    return GOOD;
}

int16_t FnVCCB_NRDC_checkTAI_SN(
    callInfo_type *ptCi, hoRestrictInfo_type *ptMrl, uint32_t targetCellNum, uint8_t *pSelectedCellPlmnIndex)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMrl);
    VALID_E_POINT_CHECK_ERROR(pSelectedCellPlmnIndex);
    VCCB_CHECK_E_RANGE_AND_RETURN(targetCellNum, MAX_CELL_NUM_VCCB);

    if (!IS_NRDC_SN(ptCi))
    {
        return ERROR;
    }

    uint8_t cellPlmnIdx = 0;
    allowedPlmnList_Type allowedCellPlmnList, allowedPlmnList;
    allowedPlmnList.num_plmn = 0;
    uint16_t plmnIdx = 0, allowedIdx = 0;
    plmnId_type *ptPlmn = NULL, *ptMrlPlmn = NULL;

    // FGR-CC5200:FR173
    // SgNB shall determine serving PLMN of UE with consideration of MRL
    //  - If MRL is available,
    //    - If PSCell supports serving PLMN in MRL, serving PLMN of UE shall be serving PLMN in MRL
    //    - Otherwise, serving PLMN of UE shall be the first equivalent PLMN in MRL supported by PSCell
    // ******************** Checked below items during selecting PSCell ********************
    //    - For serving PLMN and equivalent PLMNs in MRL, SgNB shall exclude restricted PLMNs defined in FR172
    //      1) RAT Restrictions (PLMN with NR is forbidden)
    //      2) Service Area Information (PLMN with TAC is Not Allowed)
    //      3) Core Network Type Restriction for Equivalent PLMNs (PLMN with 5GC is forbidden)
    // *************************************************************************************
    //  - If MRL is not available, serving PLMN of UE shall be the first PLMN supported by PSCell

    allwedPlmnList_type *pAllowedPlmn = FnVCCB_GetAllowedPlmnListByMRL(ptCi, ptMrl, MyRATRestriction);
    if (pAllowedPlmn == NULL)
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "Not Allowed MRL Based PLMN Selection : Empty Allowed PLMN List By MRL (%s)\n", __FUNCTION__);
        return ERROR;
    }

    // 1. get cell PLMN
    if (GOOD != VLIB_getBPLMN(ptCi, targetCellNum, &allowedCellPlmnList))
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "Not Allowed MRL Based PLMN Selection : Extract Fail in %s\n", __FUNCTION__);
        return ERROR;
    }

    if(CELLINFO[targetCellNum].configuredTacIndication == CI_no_use)
    {
        if(GOOD != FnVCCB_GetNbrSaAvailablePlmnList_IntraGnbCell(*ptCi, allowedCellPlmnList))
        {
            VCCB_PRINT_CALL_TGT_SEL(
                ptCi, "check FnVCCB_GetNbrSaAvailablePlmnList_IntraGnbCell in %s\n", __FUNCTION__);
            return ERROR;
        }        
    }

    // for DEBUG
    if (allowedCellPlmnList.num_plmn == 0)
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "Not Allowed MRL Based PLMN Selection : Extract From BPLMN (%u)\n", allowedCellPlmnList.num_plmn);
        return ERROR;
    }

    // 2. Acquires the intersection of the neighbor broadcast PLMN and MRL PLMN. (MRL)

    if (TRUE == ptMrl->existFlag)
    {
        for (allowedIdx = 0; allowedIdx < pAllowedPlmn->numNrAllowedPlmn; allowedIdx++)
        {
            ptMrlPlmn = &pAllowedPlmn->nrAllowedPlmn[allowedIdx];
            for (plmnIdx = 0; plmnIdx < allowedCellPlmnList.num_plmn; plmnIdx++)
            {
                ptPlmn = &allowedCellPlmnList.plmn[plmnIdx];

                if (VCOM_CheckPlmnIdentical(ptPlmn, ptMrlPlmn) == FALSE) continue;

                const VccbCellInfo_type *const pCell = &CELLINFO[targetCellNum];
                if (ERROR == VCCM_CheckPlmnAndTacInMrlAllowedList(ptCi, ptMrl, pCell->tac, ptPlmn->longId)) continue;

                allowedPlmnList.plmn[allowedPlmnList.num_plmn++] = *ptPlmn;
            }
        }
    }
    else
    {
        // There is [5. O - PLMN Identity (9_2_2_4)] from MN
        if (ptCi->ueInfo.selectedPlmnfromMN.longId > 0)
        {
            for (plmnIdx = 0; plmnIdx < allowedCellPlmnList.num_plmn; plmnIdx++)
            {
                ptPlmn = &allowedCellPlmnList.plmn[plmnIdx];
                if (VCOM_CheckPlmnIdentical(ptPlmn, &ptCi->ueInfo.selectedPlmnfromMN) == TRUE)
                {
                    allowedPlmnList.plmn[allowedPlmnList.num_plmn++] = *ptPlmn;
                    break;
                }
            }
        }
        else
        {
            ptPlmn = &allowedCellPlmnList.plmn[0];
            allowedPlmnList.plmn[allowedPlmnList.num_plmn++] = *ptPlmn;
        }
    }

    // for DEBUG
    if (allowedPlmnList.num_plmn == 0)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "Not Allowed MRL Based PLMN Selection : Excluding Not Allowed TAC (%u/%u)\n", allowedPlmnList.num_plmn,
            pAllowedPlmn->numNrAllowedPlmn);
        return ERROR;
    }

    // Slice aware
    if (DBG->flag.sliceAwareforSN)
    {
        // if (allowedPlmnList.num_plmn > 0)
        {
            uint32_t before_num_plmn = allowedPlmnList.num_plmn;

            if (ERROR == VCCM_CheckSliceAwareForSn(ptCi, &allowedPlmnList, targetCellNum))
            {
                return ERROR;
            }

            if (allowedPlmnList.num_plmn == 0)
            {
                VCCB_PRINT_CALL_TGT_SEL(ptCi,
                    "Not Allowed MRL Based PLMN Selection : Excluding Slice Aware (%u/%u)\n", before_num_plmn,
                    allowedPlmnList.num_plmn);
                return ERROR;
            }
        }
    }

    if (allowedPlmnList.num_plmn > 0)
    {
        if (TRUE ==
            VLIB_GetCellPlmnIdx(allowedPlmnList.plmn[0].longId, static_cast<uint16_t>(targetCellNum), &cellPlmnIdx))
        {
            VCCB_PRINT_CALL_COMMENT(
                ptCi, "pSelectedCellPlmn is (longId=%x idx=%u)\n", allowedPlmnList.plmn[0].longId, cellPlmnIdx);
            *pSelectedCellPlmnIndex = cellPlmnIdx;
            return GOOD;
        }
    }
    return ERROR;
}

int16_t FnVCCB_CheckAgainstMRL_Wrapper(callInfo_type *ptCi, hoRestrictInfo_type *pMrl, uint16_t targetCellNum,
    uint8_t *pSelectedCellPlmnIndex, const char *pFuncName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMrl);
    VALID_E_POINT_CHECK_ERROR(pSelectedCellPlmnIndex);
    VALID_E_POINT_CHECK_ERROR(pFuncName);
    VCCB_CHECK_E_RANGE_AND_RETURN(targetCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[targetCellNum];

    int16_t status = GOOD;

    if (IS_NRDC_SN(ptCi))
    {
        status = FnVCCB_NRDC_checkTAI_SN(ptCi, pMrl, targetCellNum, pSelectedCellPlmnIndex);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "%s: [cellNum(%u), cellIdentity(%u)] FnVCCB_NRDC_checkTAI_SN ERROR!\n",
            pFuncName, targetCellNum, pCell->cellIdentity);
    }
    else
    {
        status = VCCM_CheckAgainstHRL(MAX_CELL_NUM_VCCB, pMrl, INTRA_NB, targetCellNum);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "%s: [cellNum(%u), cellIdentity(%u)] VCCM_CheckAgainstHRL ERROR!\n",
            pFuncName, targetCellNum, pCell->cellIdentity);
    }

    return GOOD;
}

int16_t VCCM_Check90MhzSupport(const callInfo_type *ptCi, const VccbCellInfo_type *ptCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptCell);

    // [FGR-CC5000] FR3120
    // * For EN-DC calls gNB-CU-CP shall exclude a candidate PSCell if:
    //      (1) 90MHz not supported on downlink by UE
    //      (2) 90MHz not supported on uplink by UE
    if (IS_ENDC(ptCi))
    {
        if (ci_nr_bandwidth_90MHz == ptCell->intraGnbNbrInfo.bandwidthDl)
        {
            if (TRUE != ptCi->ueInfo.ueCapa.nr.rf.bw90MHzSupportedDl)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "[CI(%u)] Cell not qualified for SpCell selection: 90MHz on DL/UL not supported by UE.\n",
                    ptCell->cellIdentity);
                return ERROR;
            }
        }

        if (ci_nr_bandwidth_90MHz == ptCell->intraGnbNbrInfo.bandwidthUl)
        {
            if (TRUE != ptCi->ueInfo.ueCapa.nr.rf.bw90MHzSupportedUl)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "[CI(%u)] Cell not qualified for SpCell selection: 90MHz on DL/UL not supported by UE.\n",
                    ptCell->cellIdentity);
                return ERROR;
            }
        }
    }

    return GOOD;
}


int16_t VCCM_CheckNRSDLCell(VccbCellInfo_type *ptCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCell);

    if (MAX_A6_NR_ARFCN == ptCell->nrArfcnUl)
    {
        return TRUE;
    }

    return FALSE;
}

int16_t VCCM_CheckMobilityPSCellSelectionThreshold(callInfo_type *ptCi, measResultNR_type *pMeasResultNR, uint16_t cellNum,
    uint32_t ssbFrequency)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMeasResultNR);
    VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");

    // Mobility for EN-DC FR198.
    // FGR-CC5201 FR110 (S-2)
    // [S-Node]
    // In MN mobility triggered target PSCell selection case, only cells which over PSCell selection threshold can be selected as target pscell
    // In a new S-Node addition case (i.e. MN mobility with SN change / SN initiated SN change) SgNB shall select PScell according to PScell selection mode (specified in FGR-CC5200:FR171)
    // - MR based
    // - Load-based selection within colocated cells
    // - Random selection within colocated cells

    if ((TRUE != pMeasResultNR->cellResults.resultsSSB_CellFlag) ||
        ((SgnbAddTrigInd_InterMnHo != ptCi->hoInfo.sgnbAddTrigInd) &&
         (SgnbAddTrigInd_IntraMnHo != ptCi->hoInfo.sgnbAddTrigInd)))
    {
        return GOOD;
    }

    if (ERROR == VCCM_IsMeasAboveThld(ptCi, &pMeasResultNR->cellResults.resultsSSB_Cell, ssbFrequency, ptCi->gnbNum, cellNum))
    {
        if (IS_ENDC(ptCi))
        {
            ptCi->bitFlag.isSgNBAddReqRejectTgtNotAllowed = TRUE;
        }

        return ERROR;
    }

    return GOOD;
}

int16_t VCCM_CheckPSCellCandidateConditions(callInfo_type *ptCi, measResultNR_type *pMeasResultNR, uint16_t cellNum,
    uint32_t ssbFrequency, uint16_t frequencyBand, enumStatSpCellSelectionFailCause_type *pCellRejectCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMeasResultNR);
    VALID_E_POINT_CHECK_ERROR(pCellRejectCause);
    VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, cellNum, MAX_CELL_NUM_VCCB, "cellNum");
    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    const bool isEndcUe = IS_ENDC(ptCi);

    if (GOOD != VCCM_Check90MhzSupport(ptCi, pCell))
    {
        ptCi->bitFlag.isSgNBAddReqRejectNoRadioResourcesAvailableInTargetCell = TRUE;
        *pCellRejectCause = StatEndcSpCellSelFail_UeNotSup90MhzBw;
        return ERROR;
    }

    if (FnVCCB_IsNonSsbCell(pCell))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "[cellNum(%u), CI(%u)] Not SSB cell. Not qualified for SpCell selection!\n",
            cellNum, pCell->cellIdentity);
        *pCellRejectCause = StatEndcSpCellSelFail_NotSsbCell;
        return ERROR;
    }

    if (IS_NRDC_SN(ptCi))
    {
        if (!FnVCCB_isNRDC_allowedCell(ptCi, &pCell->intraGnbNbrInfo))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[cellNum(%u), CI(%u)] Not qualified for SpCell selection: not allowed NRDC Cell\n", cellNum,
                pCell->cellIdentity);
            return ERROR;
        }
    }
    else
    {
        if ((E_CALLTYPE_NSA == ptCi->callType) &&
            (GOOD != VLIB_checkDssAllowed(ptCi, frequencyBand, true, pCell)))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                    "[cellNum(%u), CI(%u)] NR band(%u) not eligible for DSS!(Check "
                    "rateMatchingLTE_CRS is available in NR UE Capa.)\n",
                    cellNum, pCell->cellIdentity, frequencyBand);
            *pCellRejectCause = StatEndcSpCellSelFail_DssUeNotSupRateMatchingLteCrs;
            return ERROR;
        }
    }

    if (TRUE == VCCM_CheckNRSDLCell(pCell))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[cellNum(%u), CI(%u)] NR SDL Cell is not allowed!\n",
            cellNum, pCell->cellIdentity);
        ptCi->bitFlag.isSgNBAddReqRejectNoRadioResourcesAvailableInTargetCell = TRUE;
        *pCellRejectCause = StatEndcSpCellSelFail_NrSdlCell;
        return ERROR;
    }

    if ((VCCB_FLAG_ON == DBG->flag.noHoBtwSaAndNsaCell) && (VCCB_FLAG_ON == ptCi->cgConfigInfo.sourceConfigSCG_Flag) &&
        (((TRUE == ptCi->hoInfo.receivedCoresetId0) && (N_EQUIP == pCell->tacStatus)) ||
         ((FALSE == ptCi->hoInfo.receivedCoresetId0) && (EQUIP == pCell->tacStatus))))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "[cellNum(%u), CI(%u)] Inter gNB HO between only NSA and SA support cell is not allowed!\n",
            cellNum, pCell->cellIdentity);
        *pCellRejectCause = StatEndcSpCellSelFail_NoHoBtwSaAndNsaCell;
        return ERROR;
    }

    if (GOOD != VCCM_CheckMobilityPSCellSelectionThreshold(ptCi, pMeasResultNR, cellNum, ssbFrequency))
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "[cellNum(%u), CI(%u)] en/nrdc-pscell-selection-threshold requirement not satisfied!\n",
            cellNum, pCell->cellIdentity);
        return ERROR;
    }

    // need to check cell if DU is overloaded
    if (isEndcUe && FnVCCB_IsDuOverload(pGnb, pCell->endPointF1Index) == true)
    {
        ptCi->bitFlag.isSgNBAddReqRejectDuOverload = TRUE;
        VCCB_PRINT_CALL_ERROR(ptCi,
            "[cellNum(%u), CI(%u)] DU endPointF1Index(%u) overloaded!\n",
            cellNum, pCell->cellIdentity, pCell->endPointF1Index);
        *pCellRejectCause = StatEndcSpCellSelFail_DuOverload;
        return ERROR;
    }

    if (isEndcUe && !FnVCCB_IsSsbAllowed(*ptCi, ssbFrequency))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            "[cellNum(%u), CI(%u)] SsbArfcn(%u) Restricted for SpCell Selection!\n",
            cellNum, pCell->cellIdentity, ssbFrequency);
        *pCellRejectCause = StatEndcSpCellSelFail_SsbRestricted;
        ptCi->bitFlag.isSgNBAddReqRejectNoRadioResourcesAvailableInTargetCell = TRUE;
        return ERROR;
    }

    // FGR-CC5001 FR235 && FGR-CC5000 FR3620 & FR3622
    if (isEndcUe && VCCB_IsCellUlInterfered(*pCell) &&
        (false == VCCB_isUlInterferedCellAllowedBasedOnThresholds(*ptCi, pMeasResultNR->cellResults)))
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "[cellNum(%u), CI(%u)] cellNum is rejected due to Ul Interference!\n", cellNum, pCell->cellIdentity);
        *pCellRejectCause = StatEndcSpCellSelFail_ULInterfered;
        
        // FGR-CC5001 FR155
        if ((SgnbAddTrigInd_SnChange == ptCi->hoInfo.sgnbAddTrigInd) ||
            (SgnbAddTrigInd_InterMnHo == ptCi->hoInfo.sgnbAddTrigInd) ||
            (SgnbAddTrigInd_IntraMnHo == ptCi->hoInfo.sgnbAddTrigInd))
        {
            ptCi->bitFlag.isSgNBAddReqRejectedDueToDucting = TRUE;
        }
        else
        {
            ptCi->bitFlag.isSgNBAddReqRejectNoRadioResourcesAvailableInTargetCell = TRUE;
        }
        
        return ERROR;
    }

    return GOOD;
}

uint16_t VCCM_GetPSCellCandidateBand(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, BAND_NOT_FOUND);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, BAND_NOT_FOUND);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(ptCi->gnbNum, BAND_NOT_FOUND);

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t frequencyBand = BAND_NOT_FOUND;
    uint16_t bandList[MAX_FREQBAND_PER_CELL];
    uint8_t bandIdx = 0;
    int16_t status = ERROR;
    const uint8_t noOfBands = VLIB_GetFreqBandIndListForNeighborCellWithCustomSpCell(
        ptCi, &pCell->intraGnbNbrInfo, cellNum, true, bandList);
    enumStatSpCellSelectionFailCause_type failCause = StatEndcSpCellSelFail_UeNotSupChannelBw;

    if (0 == noOfBands)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "[cellNum(%u), CI(%u)] Frequency band not found in cell. Check supportedBandListNR in Ue Capa!\n",
            cellNum, pCell->cellIdentity);
        ptCi->bitFlag.isSgNBAddReqRejectNoRadioResourcesAvailableInTargetCell = TRUE;
        VLIB_SaveCauseOfRejectCandidateCell(ptCi, pCell->cellIdentity, pCell->ssbArfcn, StatEndcSpCellSelFail_UeNotSupCellFreqBand);
        return BAND_NOT_FOUND;
    }

    for (bandIdx = 0; bandIdx < noOfBands; ++bandIdx)
    {
        frequencyBand = bandList[bandIdx];

        status = VLIB_checkChannelBWs(ptCi, cellNum, frequencyBand);
        if (GOOD != status)
        {
            if(BREAK == status && false == IS_REDCAP_UE(ptCi) &&
               (ci_nr_bandwidth_90MHz == pCell->intraGnbNbrInfo.bandwidthDl ||
                ci_nr_bandwidth_90MHz == pCell->intraGnbNbrInfo.bandwidthUl ))
            {
                failCause = StatEndcSpCellSelFail_UeNotSup90MhzBw;
            }

            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[cellNum(%u), CI(%u), NR band(%u), cellScsDl(%u), cellScsUl(%u)] channelBWs not supported!\n",
                cellNum, pCell->cellIdentity, frequencyBand, pCell->intraGnbNbrInfo.nrScsDl,
                pCell->intraGnbNbrInfo.nrScsUl);
            continue;
        }

        if (VCCB_checkAllowedBCListMRDC(ptCi, frequencyBand) != GOOD)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "[cellNum(%u), CI(%u)] NR band(%u) not satisfying the allowed MR-DC band combination!\n",
                cellNum, pCell->cellIdentity, frequencyBand);
            failCause = StatEndcSpCellSelFail_UeNotSupBandCombination;
            continue;
        }

        // [FGR-CC5000] FR795
        // * For EN-DC calls gNB-CU-CP shall exclude a candidate PSCell if:
        //      (1) PScell selection method: MR based and
        //      (2) LTE PCell and a candidate PSCell are in intra-band relationship and
        //      (3) No EN-DC band combination reported by UE supports a given relationship (intra-band contiguous or
        //      intra-band non-contiguous)
        if (IS_ENDC(ptCi) &&
            FnVCCB_IsPsCellSelectionMeasurement(pGnb->cfg.pscellSelectionMethod) &&
            (GOOD != VCCB_CheckIntraBandRelationForNrAndLteBand(ptCi, frequencyBand)))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "[cellNum(%u), CI(%u) NR band(%u)] Cell not qualified for SpCell selection: intra-band relation with "
                "PCell and no BC\n",
                cellNum, pCell->cellIdentity, frequencyBand);
            failCause = StatEndcSpCellSelFail_MrBasedUeNotSupLteNrIntraBandRelation;
            continue;
        }

        return frequencyBand;  // eligible band found
    }

    VLIB_SaveCauseOfRejectCandidateCell(ptCi, pCell->cellIdentity, pCell->ssbArfcn, failCause);
    return BAND_NOT_FOUND;
}

/****************************************************************************
 * @brief  Check if candidate Cell to PsCell is NRCGI cell
 * @param[in]  pMeasResultNR: pointer to measResultNR_type RRC struct with cell info
 * @return                  : ERROR/TRUE/FALSE
 ****************************************************************************/
int8_t VCCM_isNrcgiCell(const measResultNR_type *pMeasResultNR)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(pMeasResultNR);
    if ((pMeasResultNR->cgiInfoFlag == VCCB_FLAG_ON) &&
        (pMeasResultNR->cgiInfo.plmn_IdentityInfoList_Flag == VCCB_FLAG_ON) &&
        (pMeasResultNR->cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo != 0))
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

uint16_t VCCM_GetPSCellCandidateCellNum(callInfo_type *ptCi, const measResultNR_type *pMeasResultNR,
    const uint32_t ssbFrequency, const enumNRCGICellPrior_type eNRCGICellPrior, uint8_t *pUnavailableCellIdentityFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_CELL_NUM_VCCB);
    VALID_E_POINT_CHECK_RET_VAL(pMeasResultNR, MAX_CELL_NUM_VCCB);
    VALID_E_POINT_CHECK_RET_VAL(pUnavailableCellIdentityFlag, MAX_CELL_NUM_VCCB);

    VCCB_CALL_CHECK_RANGE_AND_RETURN_COMMON(ptCi, ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum", return MAX_CELL_NUM_VCCB);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t cellNumCandidate = MAX_CELL_NUM_VCCB;
    enumCellTypeAsPsCellCandidate_type cellType = maxCellType;

    const int8_t nrcgiCell = VCCM_isNrcgiCell(pMeasResultNR);

    if (TRUE == nrcgiCell)
    {
        // NR-CGI Cell
        cellType = NRCGI_cell;
        if (nonNRCGI_cell_only == eNRCGICellPrior)
        {
            VCCB_PRINT_CALL_DATA(ptCi, "[CellIdentity(%25lu)] is NR CGI cell. Not qualified for SpCell selection.\n",
                pMeasResultNR->cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].cellIdentity);
            return MAX_CELL_NUM_VCCB;
        }
    }
    else if (FALSE == nrcgiCell)
    {
        // None NR-CGI Cell
        cellType = nonNRCGI_cell;
        if (NRCGI_cell_only == eNRCGICellPrior)
        {
            if (TRUE != pMeasResultNR->physCellIdFlag)
            {
                return MAX_CELL_NUM_VCCB;
            }

            VCCB_PRINT_CALL_DATA(
                ptCi, "[PCI(%u)] is not NR CGI cell. Not qualified for SpCell selection.\n", pMeasResultNR->physCellId);
            return MAX_CELL_NUM_VCCB;
        }
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Unavailable cell information.\n");
        return MAX_CELL_NUM_VCCB;
    }

    if (NRCGI_cell == cellType)
    {
        /* case1) received NCGI */
        const uint64_t nrCellId = pMeasResultNR->cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].cellIdentity;

        const uint32_t gnbId = VLIB_NrCellId2GnbId(pGnb->globalGnbId.gnbId.idLength, nrCellId);

        if (gnbId != pGnb->globalGnbId.gnbId.id)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "received gNB ID(%d) is not matched with gnbId(%d)\n", gnbId, pGnb->globalGnbId.gnbId.id);

            VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbFrequency, StatEndcSpCellSelFail_Nrcgi_GnbIdMismatch);

            return MAX_CELL_NUM_VCCB;
        }

        // Fill cellIdentity
        const uint16_t cellIdentity = VLIB_NrCellId2CellId(pGnb->globalGnbId.gnbId.idLength, nrCellId);

        if (cellIdentity >= MAX_CELL_IDENTITY)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR cellIdentity(%u) >= MAX_CELL_IDENTITY(%u)\n", cellIdentity, MAX_CELL_IDENTITY);

            VLIB_SaveCauseOfRejectCandidateCell(ptCi, cellIdentity, ssbFrequency, StatEndcSpCellSelFail_Nrcgi_CellNumNotFound);

            return MAX_CELL_NUM_VCCB;
        }
        cellNumCandidate = pGnb->env.cellNum[cellIdentity];

        // Validation Check for the Cell. PCID, SSB Freq and active state
        if (cellNumCandidate >= MAX_CELL_NUM_VCCB)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "ERROR Could not find cellNum for [cellIdentity(%u)]\n", cellIdentity);
            ptCi->unavailableCellIdAddReqFail = cellIdentity;
            *pUnavailableCellIdentityFlag = TRUE;

            // [FGR-CC5000] FR2830
            // * For EN-DC calls VCCB will response with SgNB Addition Request Reject
            //   and "No Radio Resource Available in Target Cell" cause if:
            //      (1) noneNrcgiCellsFoundDuringAddReq set to enabled
            //      (2) NR CGI cells are included and none exists in gNB
            if (IS_ENDC(ptCi) && (enabled == pGnb->cfg.noneNrcgiCellsFoundDuringAddReq))
            {
                ptCi->bitFlag.isSgNBAddReqRejectNoRadioResourcesAvailableInTargetCell = TRUE;
            }

            VLIB_SaveCauseOfRejectCandidateCell(ptCi, cellIdentity, ssbFrequency, StatEndcSpCellSelFail_Nrcgi_CellNumNotFound);

            return MAX_CELL_NUM_VCCB;
        }

        const VccbCellInfo_type *const pNrcgiCell = &CELLINFO[cellNumCandidate];
        // even though cells are equipped in user PLD(pCell->pldState) but not in ConfD(pCell->status),
        // the basic call processing should be enabled.
        if (ERROR == VCCM_CheckCellInService(ptCi, cellNumCandidate, FALSE, TRUE))
        {
            enumStatSpCellSelectionFailCause_type cause =
                (ptCi->bitFlag.spCellSelCellBarredWithSwitchOff && pGnb->cfg.endcAddWithSwitchingOffCells)
                    ? StatEndcSpCellSelFail_Nrcgi_MibCellBarred : StatEndcSpCellSelFail_Nrcgi_CellOosOrBarred;

            // FR3580. SwitchOffOngoing Rejection only when NRCGI included.
            if(ptCi->bitFlag.spCellSelCellBarredWithSwitchOff)
            {
                ptCi->bitFlag.isSgNBAddReqRejectSwitchOffOngoing = true;
            }

            VLIB_SaveCauseOfRejectCandidateCell(ptCi, pNrcgiCell->cellIdentity, ssbFrequency, cause);

            ptCi->bitFlag.spCellSelCellBarredWithSwitchOff = false;

            return MAX_CELL_NUM_VCCB;
        }

        if ((TRUE == pMeasResultNR->physCellIdFlag) && (pNrcgiCell->phyCellId != pMeasResultNR->physCellId))
        {
            // If there is physCellId, check if it is the same.
            VCCB_PRINT_CALL_ERROR(ptCi,
                "phyCellId is not matched!(MR:%d) gnbId(%u) cellNum(%u) cellIdentity(%u) phyCellId(%d)\n",
                pMeasResultNR->physCellId, gnbId, cellNumCandidate, cellIdentity, pNrcgiCell->phyCellId);

            VLIB_SaveCauseOfRejectCandidateCell(ptCi, pNrcgiCell->cellIdentity, ssbFrequency, StatEndcSpCellSelFail_Nrcgi_PciMismatch);

            return MAX_CELL_NUM_VCCB;
        }

        if ((UNKNOWN_ARFCN != ssbFrequency) && (pNrcgiCell->ssbArfcn != ssbFrequency))
        {
            // If there is ssbFrequency, check if it is the same.
            VCCB_PRINT_CALL_ERROR(ptCi,
                "ssbFreq is not matched!(MR:%u) gnbId(%u) cellNum(%u) cellIdentity(%u) ssbFreq(%u)\n", ssbFrequency,
                gnbId, cellNumCandidate, cellIdentity, pNrcgiCell->ssbArfcn);

            VLIB_SaveCauseOfRejectCandidateCell(ptCi, pNrcgiCell->cellIdentity, ssbFrequency, StatEndcSpCellSelFail_Nrcgi_ssbFreqMismatch);

            return MAX_CELL_NUM_VCCB;
        }
    }
    else
    {
        /* case2) not received NCGI */
        /* PCI duplicated cells are excluded from the candidates. */

        /* Update physCellId */
        if (TRUE != pMeasResultNR->physCellIdFlag)
        {
            VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, ssbFrequency, StatEndcSpCellSelFail_nonNrcgi_PciNotInCandidateListInfo);

            return MAX_CELL_NUM_VCCB;
        }

        if (VLIB_GetCellNumFromPhysCellId(ptCi, ptCi->gnbNum, pMeasResultNR->physCellId, ssbFrequency, &cellNumCandidate) !=
            GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_GetCellNumFromPhysCellId PCI(%u) ssbFreq(%u) ERROR!\n",
                pMeasResultNR->physCellId, ssbFrequency);
            return MAX_CELL_NUM_VCCB;
        }
    }

    return cellNumCandidate;
}

/****************************************************************************
 * @brief           Update Cell Sort listForSort
 *
 * @param[in,out]   pCellForSort  : cellForSort information / candidateCellForSort_type
 *                  pMeasResultNR : call information / measResultNR_type
 * @return          status        : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCM_UpdateCellForSort(callInfo_type *ptCi, candidateCellForSort_type *pCellForSort,
    measResultNR_type *pMeasResultNR, hoRestrictInfo_type *pHoRestrictInfo, uint32_t ssbFrequency,
    uint8_t *pUnavailableCellIdentityFlag, enumNRCGICellPrior_type eNRCGICellPrior)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pCellForSort);
    VALID_E_POINT_CHECK_ERROR(pMeasResultNR);
    VALID_E_POINT_CHECK_ERROR(pHoRestrictInfo);
    VALID_E_POINT_CHECK_ERROR(pUnavailableCellIdentityFlag);

    const uint16_t cellNumCandidate =
        VCCM_GetPSCellCandidateCellNum(ptCi, pMeasResultNR, ssbFrequency, eNRCGICellPrior, pUnavailableCellIdentityFlag);
    if (MAX_CELL_NUM_VCCB <= cellNumCandidate)
    {
        // log already provided
        return ERROR;
    }

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNumCandidate];

    // NRDC Overload Du check
    if (IS_NRDC_SN(ptCi) && VCOM_getSystemType() != e_VCCB_NVGNB)
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
        VccbCallThreadBufferInfo_type *pCallThreadBuf = &THREAD_INFO->call[ptCi->myThreadId].buf;
        pCallThreadBuf->totalOvldCandidatesCnt++;

        VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
        VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

        if (FnVCCB_IsDuOverload(pGnb, pCell->endPointF1Index) == true)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[cellNum(%u), CI(%u)] DU endPointF1Index(%u) overloaded!\n", cellNumCandidate,
                pCell->cellIdentity, pCell->endPointF1Index);
            pCallThreadBuf->ovldCandidatesCnt++;
            return ERROR;
        }
    }

    const uint16_t frequencyBand = VCCM_GetPSCellCandidateBand(ptCi, cellNumCandidate);
    if (BAND_NOT_FOUND == frequencyBand)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "[cellNum(%u), CI(%u)] BandNR which satisfy allowed MR-DC BC and cell channelBW not found!\n",
            cellNumCandidate, pCell->cellIdentity);
        ptCi->bitFlag.isSgNBAddReqRejectNoRadioResourcesAvailableInTargetCell = TRUE;
        return ERROR;
    }

    enumStatSpCellSelectionFailCause_type cellRejectCause = StatEndcSpCellSelFail_MAX_STAT;
    if (GOOD != VCCM_CheckPSCellCandidateConditions(ptCi, pMeasResultNR, cellNumCandidate, ssbFrequency, frequencyBand, &cellRejectCause))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[cellNum(%u), CI(%u)] PSCell Candidate conditions not satisfied!\n",
            cellNumCandidate, pCell->cellIdentity);
        VLIB_SaveCauseOfRejectCandidateCell(ptCi, pCell->cellIdentity, pCell->ssbArfcn, cellRejectCause);
        return ERROR;
    }

    // ptCi->servCellNum is not yet allocated
    if (FnVCCB_CheckAgainstMRL_Wrapper(
            ptCi, pHoRestrictInfo, cellNumCandidate, &pCellForSort->selectedCellPlmnIndex, __func__) == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[cellNum(%u), CI(%u)] FnVCCB_CheckAgainstMRL_Wrapper ERROR!\n",
            cellNumCandidate, pCell->cellIdentity);
        VLIB_SaveCauseOfRejectCandidateCell(ptCi, pCell->cellIdentity, pCell->ssbArfcn, StatEndcSpCellSelFail_MrlNotSatisfied);
        return ERROR;
    }

    pCellForSort->physCellId = (pMeasResultNR->physCellIdFlag ? pMeasResultNR->physCellId : UNKNOWN_PCI);
    pCellForSort->cellNum = cellNumCandidate;
    pCellForSort->bandNr = frequencyBand;
    pCellForSort->priority = pCell->priority;
    pCellForSort->rsrqFlag = FALSE;
    pCellForSort->rsrpFlag = FALSE;
    pCellForSort->ueCount = pCell->cfg.assignedCellCallCount;
    pCellForSort->nrcgiCell = (VCCM_isNrcgiCell(pMeasResultNR) ? TRUE : FALSE);

    if (TRUE == pMeasResultNR->cellResults.resultsSSB_CellFlag)
    {
        if (TRUE == pMeasResultNR->cellResults.resultsSSB_Cell.rsrpFlag)
        {
            pCellForSort->rsrpFlag = TRUE;
            pCellForSort->rsrp = pMeasResultNR->cellResults.resultsSSB_Cell.rsrp;
        }
        else
        {
            /*************************************************************
             * LTE not send resultsSSB_Cell in case of BlindAddition.
             * Do not sort based on rsrp.
             *************************************************************/
            VCCB_PRINT_CALL_DATA(ptCi, "resultsSSB_Cell is not exist. Do not consider rsrp to select PsCell!\n");
        }
        if (TRUE == pMeasResultNR->cellResults.resultsSSB_Cell.rsrqFlag)
        {
            pCellForSort->rsrqFlag = TRUE;
            pCellForSort->rsrq = pMeasResultNR->cellResults.resultsSSB_Cell.rsrq;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief       Go through candidateCellInfoListMN and check if NR CGI cell exists and count PCI Cells.
 *
 * @param[in]   ptCi                               : pointer to UE Context
 * @param[in]   pCandidateCellInfoListMN           : pointer to array containing list of candidate cells
 * @param[in]   pNumOfNrCGICellOnCandidatePSCellsList: counter determining number of NR CGI Cell exists
                                                     on PSCell candidate List
 * @param[in]   pNumOfRequestedCandidatePCICell    : number of PCI cells on CandidateCellInfoListMN
 * @return      status                             : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_CheckNrCGI_PCI_CellsOnCandidatePSCellsList(callInfo_type *ptCi,
    measResultList2NR_type *pCandidateCellInfoListMN, uint8_t *pNumOfNrCGICellOnCandidatePSCellsList,
    uint16_t *pNumOfRequestedCandidatePCICell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pCandidateCellInfoListMN);
    VALID_E_POINT_CHECK_ERROR(pNumOfRequestedCandidatePCICell);
    uint16_t loopFreq = 0;
    uint16_t loopNeighbourCell = 0;
    measResultListNR_type *ptMeasResultList = NULL;
    *pNumOfNrCGICellOnCandidatePSCellsList = 0;
    *pNumOfRequestedCandidatePCICell = 0;

    for (loopFreq = 0; loopFreq < UMIN(pCandidateCellInfoListMN->nrofFreq, MAX_NUM_FREQ); loopFreq++)
    {
        /* measResultServingCell */
        // In case of candidateCellInfoListSN, VCCB will not check measResultServingCell
        if (!ptCi->cgConfigInfo.candidateCellInfoListSN_Flag)
        {
            if (pCandidateCellInfoListMN->measResult2NR[loopFreq].measResultServingCell_Flag)
            {
                if (TRUE == pCandidateCellInfoListMN->measResult2NR[loopFreq].measResultServingCell.cgiInfoFlag)
                {
                    (*pNumOfNrCGICellOnCandidatePSCellsList)++;
                }

                if (TRUE == pCandidateCellInfoListMN->measResult2NR[loopFreq].measResultServingCell.physCellIdFlag)
                {
                    (*pNumOfRequestedCandidatePCICell)++;
                }
            }
        }
        /* measResultNeighCellListNR */
        ptMeasResultList = &pCandidateCellInfoListMN->measResult2NR[loopFreq].measResultNeighCellListNR;
        for (loopNeighbourCell = 0; loopNeighbourCell < UMIN(ptMeasResultList->nrofCellReport, MAX_NUM_CELL_REPORT);
             loopNeighbourCell++)
        {
            if (TRUE == ptMeasResultList->measResultNR[loopNeighbourCell].cgiInfoFlag)
            {
                (*pNumOfNrCGICellOnCandidatePSCellsList)++;

                // FGR-CC5200:FR481
                if (IS_NRDC_SN(ptCi) && MULTI_RECEIVE != ptCi->mrdcInfo.nrCgiReceivedFromMn.plmn.longId)
                {
                    FnVCCB_StoreNrcgiforMnSelectedPSCell(
                        ptCi, ptMeasResultList->measResultNR[loopNeighbourCell].cgiInfo);
                }
            }

            if (TRUE == ptMeasResultList->measResultNR[loopNeighbourCell].physCellIdFlag)
            {
                (*pNumOfRequestedCandidatePCICell)++;
            }
        }
    }

    return GOOD;
}

/**
 * @brief Save the cause of rejected candidate cell during SpCelSelection for SgNbAddition
 *        FGR-CC5000 Basic Operation for EN-DC
 *        FR: TBD
 * @param[in]   ptCi    : pointer to UE Context
 * @param[in]   cellId  : CellId of rejected candidate cell (or 0xFFFF if unknown)
 * @param[in]   arfcn: NR ARFCN of rejected candidate cell (or 0xFFFFFF if unknown)
 * @param[in]   cause   : the cause of candidate cell rejection
 */
void VLIB_SaveCauseOfRejectCandidateCell(callInfo_type *ptCi, uint16_t cellId, uint32_t arfcn, enumStatSpCellSelectionFailCause_type cause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->spCellSelFailStats.num, MAX_NUM_CELL_REPORT);

    if (cause <= StatEndcSpCellSelFail_Spid_PlmnSpidOutOfRange)
    {
        for (int loop=0; loop < ptCi->spCellSelFailStats.num; ++loop)
        {
            if (arfcn == ptCi->spCellSelFailStats.SpCellSelFailPerCandidateCell[loop].arfcn)
            {
                // Prevent from double collection of SPID causes. ENDC call SPID is verified twice:
                // STEP1: NRCGI_cell_only
                // STEP2: nonNRCGI_cell_only
                return;
            }
        }
    }

    ptCi->spCellSelFailStats.SpCellSelFailPerCandidateCell[ptCi->spCellSelFailStats.num].cellId = cellId;
    ptCi->spCellSelFailStats.SpCellSelFailPerCandidateCell[ptCi->spCellSelFailStats.num].arfcn = arfcn;
    ptCi->spCellSelFailStats.SpCellSelFailPerCandidateCell[ptCi->spCellSelFailStats.num].spCellSelFailure = cause;
    ptCi->spCellSelFailStats.num++;
}

/**
 * @brief Returns true if the given CGI refers to a cell served by call's gNB.
 *        It checks:
 *          - if gNB ID matches with call's gNB ID,
 *          - if cell ID from CGI is valid,
 *          - if cell ID exists in gNB's cell list.
 *
 * @param call info
 * @param cgi cell global identity
 * @return true
 * @return false
 */
bool VCCB_IsCgiServedByThisGnb(const callInfo_type &call, uint64_t cgi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(call.gnbNum, false);

    const auto &gnb = GNBINFO[call.gnbNum];
    // Check gNB-ID.
    const auto gnbId = VLIB_NrCellId2GnbId(gnb.globalGnbId.gnbId.idLength, cgi);
    if (gnbId != gnb.globalGnbId.gnbId.id)
    {
        VCCB_PRINT_CALL_COMMENT(&call, "%s: gNB ID mismatch (%u != %u).\n", __FUNCTION__, gnbId, gnb.globalGnbId.gnbId.id);
        return false;
    }
    // Check cell ID.
    const auto cellId = VLIB_NrCellId2CellId(gnb.globalGnbId.gnbId.idLength, cgi);
    if (MAX_CELL_IDENTITY <= cellId)
    {
        VCCB_PRINT_CALL_COMMENT(&call, "%s: cell ID (%u) out of range (%u).\n", __FUNCTION__, cellId, MAX_CELL_IDENTITY);
        return false;
    }
    // Check cell number.
    const auto cellNum = gnb.env.cellNum[cellId];
    if (MAX_CELL_NUM_VCCB <= cellNum)
    {
        VCCB_PRINT_CALL_COMMENT(&call, "%s: cell (ID %u) is not served by gNB (ID %u).\n", __FUNCTION__, cellId, gnbId);
        return false;
    }
    return true;
}

/**
 * @brief Returns true if FGR-CC5001 FR88 (inter-gNB SCell to PSCell switch) is applicable.
 *
 * @param call info
 * @param measResultList2NR measurement report from the source SgNB
 * @return true
 * @return false
 */
bool VCCB_ENDC_CanApplyInterGnbScellToPscellSwitch(
    const callInfo_type &call, const measResultList2NR_type &measResultList2NR)
{
    AUTO_TRACE_FUNC;

    if (VCCB_FLAG_OFF == call.cgConfigInfo.candidateCellInfoListSN_Flag)
    {
        VCCB_PRINT_CALL_COMMENT(&call, "%s: no, candidateCellInfoListSN not used.\n", __FUNCTION__);
        return false;
    }
    // this is optional.
    if ((SgnbAddTrigInd_Unknown != call.hoInfo.sgnbAddTrigInd) &&
        (SgnbAddTrigInd_SnChange != call.hoInfo.sgnbAddTrigInd))
    {
        VCCB_PRINT_CALL_COMMENT(&call, "%s: no, sgNBAdditionTriggerInd is not 'SN Change'.\n", __FUNCTION__);
        return false;
    }
    // Only one frequency reported.
    if (1 != measResultList2NR.nrofFreq)
    {
        VCCB_PRINT_CALL_COMMENT(
            &call, "%s: no, only one frequency allowed, got %u.\n", __FUNCTION__, measResultList2NR.nrofFreq);
        return false;
    }
    // No NBR measurement is present.
    if (0 < measResultList2NR.measResult2NR[0].measResultNeighCellListNR.nrofCellReport)
    {
        VCCB_PRINT_CALL_COMMENT(&call, "%s: no, NBR measurements present.\n", __FUNCTION__);
        return false;
    }
    // Serving cell measurement must be present.
    if (FALSE == measResultList2NR.measResult2NR[0].measResultServingCell_Flag)
    {
        VCCB_PRINT_CALL_COMMENT(&call, "%s: no, missing serving cell measurement.\n", __FUNCTION__);
        return false;
    }
    // Serving cell must have CGI.
    const auto &servCellMeas = measResultList2NR.measResult2NR[0].measResultServingCell;
    if ((FALSE == servCellMeas.cgiInfoFlag) || (VCCB_FLAG_OFF == servCellMeas.cgiInfo.plmn_IdentityInfoList_Flag) ||
        (0 == servCellMeas.cgiInfo.plmn_IdentityInfoList.nrofPLMN_IdentityInfo))
    {
        VCCB_PRINT_CALL_COMMENT(&call, "%s: no, serving cell has no CGI.\n", __FUNCTION__);
        return false;
    }
    // CGI is served by this gNB.
    if (not VCCB_IsCgiServedByThisGnb(call, servCellMeas.cgiInfo.plmn_IdentityInfoList.plmn_IdentityInfo[0].cellIdentity))
    {
        return false; // Cause logged by the checker.
    }
    // Here we are sure that there is only one measurement present.
    return true;
}

/****************************************************************************
 * @brief           Go through candidateCellInfoList MN or SN and build list of candidate cells
 *                  for PScell with NR-CGI Prioritize algorithm for EN-DC.
 *
 * @param[in,out]   ptCi                        : pointer to UE Context
 * @param[in,out]   ptCellListForSort           : pointer to array containing list of candidate cells
 * @param[in,out]   pCandidateCellInfoList      : pointer to MN or SN candidateCellInfoList
 * @param[in,out]   blindAdd                    : flag determining if addition is done without RSRP measurements
 * @param[in,out]   pUnavailableCellIdentityFlag: flag using for SGNB_ADD_REJECT_PER_GNB statistic
 * @param[in,out]   eNRCGICellPrior             : NRCGI_cell_only for 1 STEP of NR-CGI prioritize for EN-DC
                                                  nonNRCGI_cell_only for 2 STEP of NR-CGI prioritize for EN-DC
                                                  both_cells_type for other than EN-DC
 * @return          status                  : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_SelectSpCellBuildListOfCandidatesNRCGIprioritize(callInfo_type *ptCi,
    candidateCellListForSort_type *ptCellListForSort, measResultList2NR_type *ptCandidateCellInfoList,
    uint8_t *ptBlindAdd, uint8_t *pUnavailableCellIdentityFlag, enumNRCGICellPrior_type eNRCGICellPrior)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptCellListForSort);
    VALID_E_POINT_CHECK_ERROR(ptCandidateCellInfoList);
    VALID_E_POINT_CHECK_ERROR(ptBlindAdd);
    VALID_E_POINT_CHECK_ERROR(pUnavailableCellIdentityFlag);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    uint16_t loopCandidateCell = 0;
    uint16_t loopFreq = 0;
    uint16_t loopMRNeighbourCell = 0;
    uint32_t ssbFrequency = UNKNOWN_ARFCN;
    measResultNR_type *ptMeasResultNR = NULL;
    measResultListNR_type *ptMeasResultList = NULL;
    int16_t status = ERROR;

    VccbCallThreadBufferInfo_type *pCallThreadBuf = &THREAD_INFO->call[ptCi->myThreadId].buf;

    // NRDC Overload check
    if ((IS_NRDC_SN(ptCi) && VCOM_getSystemType() != e_VCCB_NVGNB))
    {
        // init ovld counter
        pCallThreadBuf->ovldCandidatesCnt = 0;
        pCallThreadBuf->totalOvldCandidatesCnt = 0;
    }

    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;
    candidateCellForSort_type *ptCellForSort = NULL;

    ptCellListForSort->nrofCells = 0;
    failedPCIInfo_type *pFailedPCIInfo = &THREAD_INFO->call[ptCi->myThreadId].failedPCIInfoForRecovery;

    // FGR-CC5001 FR88: inter-gNB FP based SCell to PSCell switch.
    const auto isInterGnbScellToPscellSwitch = VCCB_ENDC_CanApplyInterGnbScellToPscellSwitch(*ptCi, *ptCandidateCellInfoList);

    // Update localStruct list for sort.
    const auto freqCount = UMIN(ptCandidateCellInfoList->nrofFreq, MAX_NUM_FREQ);
    for (loopFreq = 0; loopFreq < freqCount; loopFreq++)
    {
        VCCB_CALL_CHECK_RANGE_AND_BREAK(
            ptCi, loopCandidateCell, MAX_NUM_CANDIDATE_CELL_FOR_PSCELL, "candidateCell loopCandidateCell #1");

        if ((DBG->flag.checkSsbFreqFlag == FLAG_ON) &&  // checkSsbFreqFlag: Default = FLAG_ON
            (ptCandidateCellInfoList->measResult2NR[loopFreq].ssbFrequency_Flag == TRUE))
        {
            ssbFrequency = ptCandidateCellInfoList->measResult2NR[loopFreq].ssbFrequency;
        }
        else
        {
            ssbFrequency = UNKNOWN_ARFCN;
        }

        if (GOOD != VLIB_IsPCellAvailableForUe(ptCi, ssbFrequency, ptHrl))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "[SpCell Selection] Frequency %d is not supported !\n", ssbFrequency);
            if (FALSE == ptCi->invalidCellSgNBAddReject.spidFlag)
            {
                ptCi->invalidCellSgNBAddReject.spidFlag = TRUE;
                ptCi->invalidCellSgNBAddReject.arfcn = ssbFrequency;
            }
            continue;
        }

        // TODO - add check for DSS

        // In case of candidateCellInfoListSN, VCCB will not check measResultServingCell.
        // FGR-CC5001 FR88: check candidateCellInfoListSN.
        if (!ptCi->cgConfigInfo.candidateCellInfoListSN_Flag || isInterGnbScellToPscellSwitch)
        {
            /* measResultServingCell */
            if (ptCandidateCellInfoList->measResult2NR[loopFreq].measResultServingCell_Flag)
            {
                ptMeasResultNR = &ptCandidateCellInfoList->measResult2NR[loopFreq].measResultServingCell;

                ptCellForSort = &ptCellListForSort->candidateCell[loopCandidateCell];
                pFailedPCIInfo->failedDueToRecoveryTargetParam = FALSE;
                status = VCCM_UpdateCellForSort(ptCi, ptCellForSort, ptMeasResultNR, ptHrl, ssbFrequency,
                    pUnavailableCellIdentityFlag, eNRCGICellPrior);
                if (status == GOOD)
                {
                    if (ptCellForSort->rsrpFlag == FALSE) *ptBlindAdd = TRUE;

                    loopCandidateCell++;
                }

                if ((TRUE == ptMeasResultNR->physCellIdFlag) &&
                    (pFailedPCIInfo->numOfFailed < MAX_NUM_CANDIDATE_CELL_FOR_PSCELL))
                {
                    if (TRUE == pFailedPCIInfo->failedDueToRecoveryTargetParam)
                    {
                        pFailedPCIInfo->pciList[pFailedPCIInfo->numOfFailed++] = ptMeasResultNR->physCellId;
                    }
                }
            }
            // FGR-CC5001 FR88: inter-gNB FP based SCell to PSCell switch - process only serving cell.
            if (isInterGnbScellToPscellSwitch)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[ENDC] Applied inter-gNB SCell to PSCell switch.\n");
                break;
            }
        }

        /* measResultNeighCellListNR */
        ptMeasResultList = &ptCandidateCellInfoList->measResult2NR[loopFreq].measResultNeighCellListNR;
        for (loopMRNeighbourCell = 0; loopMRNeighbourCell < UMIN(ptMeasResultList->nrofCellReport, MAX_NUM_CELL_REPORT);
             loopMRNeighbourCell++)
        {
            ptMeasResultNR = &ptMeasResultList->measResultNR[loopMRNeighbourCell];

            VCCB_CALL_CHECK_RANGE_AND_BREAK(
                ptCi, loopCandidateCell, MAX_NUM_CANDIDATE_CELL_FOR_PSCELL, "candidateCell loopCandidateCell #2");
            ptCellForSort = &ptCellListForSort->candidateCell[loopCandidateCell];
            pFailedPCIInfo->failedDueToRecoveryTargetParam = FALSE;
            status = VCCM_UpdateCellForSort(ptCi, ptCellForSort, ptMeasResultNR, ptHrl, ssbFrequency,
                pUnavailableCellIdentityFlag, eNRCGICellPrior);
            if (status == GOOD)
            {
                if (ptCellForSort->rsrpFlag == FALSE) *ptBlindAdd = TRUE;

                loopCandidateCell++;
            }

            if ((TRUE == ptMeasResultNR->physCellIdFlag) &&
                (pFailedPCIInfo->numOfFailed < MAX_NUM_CANDIDATE_CELL_FOR_PSCELL))
            {
                if (TRUE == pFailedPCIInfo->failedDueToRecoveryTargetParam)
                {
                    pFailedPCIInfo->pciList[pFailedPCIInfo->numOfFailed++] = ptMeasResultNR->physCellId;
                }
            }
        }
    }

    ptCellListForSort->nrofCells = static_cast<uint8_t>(loopCandidateCell);

    if (IS_NRDC_SN(ptCi) && VCOM_getSystemType() != e_VCCB_NVGNB)
    {
        // SVR23B FGR-CC5200 Basic Operation For NR-DC :: FR179 :: Restricted gNB by overload
        // If all candidate cell's DU are overloaded, SN have to reject
        // SNodeAdditionReq(CauseXnapMiscControlProcessingOverload).
        if (pCallThreadBuf->totalOvldCandidatesCnt != 0 && pCallThreadBuf->ovldCandidatesCnt != 0 &&
            pCallThreadBuf->ovldCandidatesCnt == pCallThreadBuf->totalOvldCandidatesCnt)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[NRDC] All Candidate DUs are overloaded. No available DU\n");
            ptCi->cause.xnCause = CauseXnapMiscControlProcessingOverload;
            MACRO_CALL_FAULT_SAVE(XN_SNodeAdditionRequest_id, ptCi->cause.xnCause);
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Go through candidateCellInfoList MN or SN and build list of candidate cells for PScell.
 *
 * @param[in,out]   ptCi                    : pointer to UE Context
 * @param[in,out]   ptCellListForSort       : pointer to array containing list of candidate cells
 * @param[in,out]   pCandidateCellInfoList  : pointer to MNR or SN candidateCellInfoList
 * @param[in,out]   blindAdd                : flag determining if addition is done without RSRP measurements
 * @return          status                  : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_SelectSpCellBuildListOfCandidates(callInfo_type *ptCi, candidateCellListForSort_type *ptCellListForSort,
    measResultList2NR_type *ptCandidateCellInfoList, uint8_t *ptBlindAdd)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptCellListForSort);
    VALID_E_POINT_CHECK_ERROR(ptCandidateCellInfoList);
    VALID_E_POINT_CHECK_ERROR(ptBlindAdd);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, ptCi->gnbNum, MAX_GNB_PER_SYS, "ptCi->gnbNum");
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint8_t numOfNrCGICellOnCandidatePSCellsList = 0;

    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;
    if (ERROR == VLIB_DecompressHoRestrictInfo(ptCi, ptHrl))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[SpCell Selection Fail!] VLIB_DecompressHoRestrictInfo ERROR!\n");
        return ERROR;
    }

    ptCellListForSort->nrofCells = 0;

    uint16_t numOfRequestedCandidatePCICell = 0;
    uint8_t unavailableCellIdentityFlag = FALSE;

    failedPCIInfo_type *pFailedPCIInfo = &THREAD_INFO->call[ptCi->myThreadId].failedPCIInfoForRecovery;
    pFailedPCIInfo->numOfFailed = 0;
    ptCi->bitFlag.needSendCallSetupRspWithFailedPCI = FALSE;

    if (ERROR == VCCM_CheckNrCGI_PCI_CellsOnCandidatePSCellsList(ptCi, ptCandidateCellInfoList,
                     &numOfNrCGICellOnCandidatePSCellsList, &numOfRequestedCandidatePCICell))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[SpCell Selection Fail!] VCCM_CheckNrCGICellOnCandidatePSCellsList ERROR !\n");
        return ERROR;
    }

    if (IS_ENDC(ptCi))
    {
        // [FGR-CC5000] Basic EN-DC FR2840 -> STEP 1
        // * If SgNB receives NRCGI cells on candidateCellInfoListMN, algorithm will exclude non-NRCGI cells for
        // choosing on PSCell.
        // * If none of the included candidate cells which has NR CGI cannot be found/are unavailable, then gNB consider
        // non-NRCGI cells
        // * and try to select one of them in STEP 2.
        VCCB_PRINT_CALL_DATA(ptCi, "------------------------------------\n");
        VCCB_PRINT_CALL_DATA(ptCi, "NR-CGI cells prioritize algorithm:\n");
        VCCB_PRINT_CALL_DATA(ptCi, "---------------STEP 1---------------\n");
        VCCB_PRINT_CALL_DATA(ptCi, " -> Try to find NR-CGI cells as candidate on PSCell:\n");
        VCCM_SelectSpCellBuildListOfCandidatesNRCGIprioritize(ptCi, ptCellListForSort, ptCandidateCellInfoList,
            ptBlindAdd, &unavailableCellIdentityFlag, NRCGI_cell_only);
    }
    else
    {
        // For non EN-DC calls NRCGI prioritize algorithm do not applicable
        VCCM_SelectSpCellBuildListOfCandidatesNRCGIprioritize(ptCi, ptCellListForSort, ptCandidateCellInfoList,
            ptBlindAdd, &unavailableCellIdentityFlag, both_cells_type);
    }

    // [FGR-CC5000] Basic EN-DC FR2840 -> STEP 2
    // * If noneNrcgiCellsFoundDuringAddReq (disable) or (enable and none NRCGI included in candidateCellInfoListMN)
    // then consider PCI Cells.
    if ((0 == ptCellListForSort->nrofCells) && (IS_ENDC(ptCi)))
    {
        if ((enabled == pGnb->cfg.noneNrcgiCellsFoundDuringAddReq) && (numOfNrCGICellOnCandidatePSCellsList > 0))
        {
            if (numOfRequestedCandidatePCICell > numOfNrCGICellOnCandidatePSCellsList)
            {
                const int spCellsWithPciNotAllowedCount { numOfRequestedCandidatePCICell - numOfNrCGICellOnCandidatePSCellsList};
                for(int loop=0; loop < spCellsWithPciNotAllowedCount; loop++)
                {
                    VLIB_SaveCauseOfRejectCandidateCell(ptCi, 0xFFFF, UNKNOWN_ARFCN, StatEndcSpCellSelFail_nonNrcgi_PciSelectionNotAllowed);
                }
            }
        }
        else
        {
            VCCB_PRINT_CALL_DATA(ptCi, "------------------------------------\n");
            VCCB_PRINT_CALL_DATA(ptCi, "NR-CGI cells prioritize algorithm:\n");
            VCCB_PRINT_CALL_DATA(ptCi, "---------------STEP 2---------------\n");
            VCCB_PRINT_CALL_DATA(ptCi, "Not any NR-CGI cell qualified to select on PSCell.\n");
            VCCB_PRINT_CALL_DATA(ptCi, " -> Try to find PCI cells as candidate on PSCell:\n");
            VCCM_SelectSpCellBuildListOfCandidatesNRCGIprioritize(ptCi, ptCellListForSort, ptCandidateCellInfoList,
                ptBlindAdd, &unavailableCellIdentityFlag, nonNRCGI_cell_only);
        }
    }

    if (0 == ptCellListForSort->nrofCells)
    {
        if (numOfRequestedCandidatePCICell == pFailedPCIInfo->numOfFailed)
        {
            ptCi->bitFlag.needSendCallSetupRspWithFailedPCI = TRUE;
        }

        FnVCCB_PrintCandidatesInfo(ptCi, ptCandidateCellInfoList);
        VCCB_PRINT_CALL_ERROR(ptCi, "[SpCell Selection Fail!] candidate listForSort.nrofCells==0 ERROR!\n");

        // [FGR-CC5000] FR2810
        // * Collecting EndcAddReject_SNCellUnavailable counter for LGU+ customer
        // * Only applicable when working with Samsung MeNB when only one PSCell candidate is received in CG-ConfigInfo
        if ((FOO.VF_BasicOperationforENDC_LGUOnlyCounterFamily) && (IS_ENDC(ptCi)) &&
            (VCCB_FLAG_ON == ptCi->eNBInfo.x2VendorInd) && (1 == ptCandidateCellInfoList->nrofFreq))
        {
            // Checking if one PSCell candidate was received
            if (((TRUE == ptCandidateCellInfoList->measResult2NR[0].measResultServingCell_Flag) &&
                    (0 == ptCandidateCellInfoList->measResult2NR[0].measResultNeighCellListNR.nrofCellReport)) ||
                ((FALSE == ptCandidateCellInfoList->measResult2NR[0].measResultServingCell_Flag) &&
                    (1 == ptCandidateCellInfoList->measResult2NR[0].measResultNeighCellListNR.nrofCellReport)))
            {
                if (TRUE == unavailableCellIdentityFlag)
                {
                    MACRO_STAT_PMCC(STAT_SGNB_ADD_REJECT_PER_GNB, EndcAddReject_SNCellUnavailable, ptCi, 0, 0, 0, 0, 0);
                }
            }
        }

        return ERROR;
    }

    return GOOD;
}

/****************************************************************************
 * @brief           select pscell by manual cellIdentity config
 *
 * @param[in]  ptCi      : call information / callInfo_type
 * @param[out] ptCellNum : selected pscell num / uint16_t*
 * @param[out] ptBandNr  : selected pscell band / uint16_t*
 * @return     status    : GOOD, BREAK, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_CheckManualCfgforCellIdentity(callInfo_type *ptCi, uint16_t* ptCellNum, uint16_t* ptBandNr)
{
    // This func is extracted from VCCM_SelectSpCell to improve SAM score without any logic changes.
    // In general, this func should return GOOD to continue the next routines if debug cfg is not set.

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptCellNum);
    VALID_E_POINT_CHECK_ERROR(ptBandNr);

    uint16_t loop = 0;
    uint16_t loop2 = 0;
    VccbCellInfo_type *pCell = NULL;

    if (DBG->flag.manualFlag == FLAG_ON)
    {
        for (loop = 0; loop < MAX_MANUAL_CONFIG; loop++)
        {
            if (CFG->manualInfo[loop].status != EQUIP) continue;

            if (static_cast<uint32_t>(ptCi->eCGI.ci) == CFG->manualInfo[loop].enbCI)
            {
                for (loop2 = 0; loop2 < MAX_CELL_NUM_VCCB; loop2++)
                {
                    pCell = &CELLINFO[loop2];

                    if (pCell->status != EQUIP) continue;

                    if (pCell->gnbNum != ptCi->gnbNum) continue;

                    if (pCell->cellIdentity == CFG->manualInfo[loop].gnbCellId)
                    {
                        *ptCellNum = loop2;
                        *ptBandNr = VLIB_GetFreqBandIndForCell(ptCi, &CELLINFO[*ptCellNum]);
                        return BREAK;
                    }
                }
            }
        }
    }

    return GOOD;  // not found
}

/****************************************************************************
 * @brief           select pscell by the manual mappingF1Idx config
 *
 * @param[in]  ptCi         : call information / callInfo_type
 * @param[in]  pCellForSort : cell candidate / const candidateCellForSort_type*
 * @param[out] ptCellNum    : selected pscell num / uint32_t*
 * @param[out] ptBandNr     : selected pscell band / uint32_t*
 * @return     status :    GOOD, BREAK, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_CheckManualCfgforMappingF1Idx(callInfo_type *ptCi, uint16_t *ptCellNum, uint16_t *ptBandNr)
{
    // This func is extracted from VCCM_SelectSpCell to improve SAM score without any logic changes.

    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptCellNum);
    VALID_E_POINT_CHECK_ERROR(ptBandNr);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t loop = 0;
    uint16_t mappingF1Idx = MAX_GNB_DU_PER_GNB_CU_CP;
    VccbCellInfo_type *pCell = NULL;

    // TODO: To be removed after SLSI/NI Test
    VCCB_PRINT_CALL_ERROR(ptCi, "candidateCellInfoListMN and candidateCellInfoListSN is not in cgConfigInfo\n");

    if (!(ptCi->endPointInfo.x2Idx < MAX_ENB_PER_GNB_CU_CP))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid input (ptCi->endPointInfo.x2Idx:%d, max:%d)\n", ptCi->endPointInfo.x2Idx,
            MAX_ENB_PER_GNB_CU_CP);
        return ERROR;
    }

    mappingF1Idx = pGnb->x2Nbr[ptCi->endPointInfo.x2Idx].mappingF1Idx;
    VCCB_CALL_CHECK_RANGE_AND_RETURN(ptCi, mappingF1Idx, MAX_GNB_DU_PER_GNB_CU_CP, "mappingF1Idx");
    if (!(mappingF1Idx < MAX_GNB_DU_PER_GNB_CU_CP))
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Invalid input (mappingF1Idx:%d, max:%d)\n", mappingF1Idx, MAX_GNB_DU_PER_GNB_CU_CP);
        return ERROR;
    }

    if (pGnb->gnbDu[mappingF1Idx].status)
    {
        for (loop = 0; loop < MAX_CELL_NUM_VCCB; loop++)
        {
            pCell = &CELLINFO[loop];
            if (!pCell->pldState)
            {
                continue;
            }

            if (pCell->gnbNum != ptCi->gnbNum) continue;

            if (pCell->endPointF1Index == mappingF1Idx)
            {
                *ptCellNum = loop;
                *ptBandNr = VLIB_GetFreqBandIndForCell(ptCi, &CELLINFO[*ptCellNum]);
                return BREAK;
            }
        }
    }

    return GOOD;
}

int16_t VCCM_SelectSpCellByMeasurement(callInfo_type *ptCi, candidateCellListForSort_type *pListForSort,
    gnbDuInfo_type **ppGnbDu, uint16_t* ptCellNum, uint16_t* ptBandNr, cellSelection_type *ptSpCellCandidate)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pListForSort);
    VALID_E_POINT_CHECK_ERROR(ppGnbDu);
    VALID_E_POINT_CHECK_ERROR(ptCellNum);
    VALID_E_POINT_CHECK_ERROR(ptBandNr);
    VALID_E_POINT_CHECK_ERROR(ptSpCellCandidate);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t loop = 0;
    uint16_t maxLoop = static_cast<uint16_t>(
        UMIN(pListForSort->nrofCells, sizeof(pListForSort->candidateCell) / sizeof(pListForSort->candidateCell[0])));
    uint8_t pscellSelectionMethod;
    VccbCellInfo_type *pCell = NULL;
    gnbDuInfo_type *pGnbDu = NULL;

    if (IS_NRDC_SN(ptCi))
    {
        pscellSelectionMethod = pGnb->cfg.nrdc.pscellSelectionMethod;
    }
    else
    {
        pscellSelectionMethod = pGnb->cfg.pscellSelectionMethod;
    }

    for (loop = 0; loop < maxLoop; loop++)
    {
        // [B6G][A6G] 4. select 1st cell from sorted list.
        pCell = &CELLINFO[pListForSort->candidateCell[loop].cellNum];
        ptSpCellCandidate->cellNum = pListForSort->candidateCell[loop].cellNum;
        ptSpCellCandidate->bandNr = pListForSort->candidateCell[loop].bandNr;
        // [A6G] 5. Select DU.
        VCCB_CALL_CHECK_RANGE_AND_CONTINUE(
            ptCi, pCell->endPointF1Index, MAX_GNB_DU_PER_GNB_CU_CP, "pCell->endPointF1Index");
        pGnbDu = &pGnb->gnbDu[pCell->endPointF1Index];

        if (FnVCCB_IsDuOverload(pGnb, pCell->endPointF1Index) == true)
        {
            continue;  // selected not overloaded du.
        }

        // select best cell measurement-based
        // if cfg.fixPscellSelection set as VCCB_FLAG_ON, Spcell selection algorithm will be disabled
        if (pCell->nrArfcnDl < MIN_A6_NR_ARFCN || pGnb->cfg.fixPscellSelection == VCCB_FLAG_ON ||
            FnVCCB_IsPsCellSelectionMeasurement(pscellSelectionMethod))
        {
            // [B6G][A6G] case. ----------------------------------------------------------------
            *ptCellNum = pListForSort->candidateCell[loop].cellNum;
            *ptBandNr = pListForSort->candidateCell[loop].bandNr;
            VCCB_PRINT_CALL_DATA(ptCi, "[B6G] cellNum : %d\n", *ptCellNum);  // TODO: For Debugging

            if (IS_NRDC_SN(ptCi))  // Determine serving PLMN of UE
            {
                if ((*ptCellNum >= MAX_CELL_NUM_VCCB) ||
                    (pListForSort->candidateCell[loop].selectedCellPlmnIndex >= MAX_PLMN_INDEX))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "[SpCell Selection Fail!] Invalid cellNum(%d)/cellPlmnIndex(%d) ERROR!\n",
                        *ptCellNum, pListForSort->candidateCell[loop].selectedCellPlmnIndex);
                    return ERROR;
                }

                ptCi->ueInfo.servedPlmn.longId =
                    CELLINFO[*ptCellNum]
                        .cellPlmn.servedPlmn[pListForSort->candidateCell[loop].selectedCellPlmnIndex];
            }

            // [FGR-CC5000] [24A] Basic EN-DC FR2230
            // * If SgNB chose NRCGI cell on PSCell (Measurement method) then if CAC failed SgNB send
            //   'Target Not Allowed' X2 cause in SgNB Addition Reject message.
            //   It is applicable only if PSCell selection success.
            if (TRUE == pListForSort->candidateCell[loop].nrcgiCell)
            {
                ptCi->bitFlag.endcAdditionToNrcgiCell = TRUE;
            }

            return BREAK;
        }
        break;
    }

    if (e_VCCB_NVGNB != VCOM_getSystemType() && loop == maxLoop)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[SpCell Selection Fail!] All DUs are overloaded. No available DU!!!\n");
        if (IS_NRDC_SN(ptCi))
        {
            // SVR23B FGR-CC5200 Basic Operation For NR-DC :: FR179 :: Restricted gNB by overload
            ptCi->cause.xnCause = CauseXnapMiscControlProcessingOverload;
            MACRO_CALL_FAULT_SAVE(msgCallSetupReq_VnmbVccb_id, ptCi->cause.xnCause);
        }
        else
        {
            ptCi->cause.x2Cause = CauseX2apMiscControlProcessingOverload;
            MACRO_CALL_FAULT_SAVE(msgCallSetupReq_VnmbVccb_id, ptCi->cause.x2Cause);
        }

        return ERROR;
    }

    *ppGnbDu = pGnbDu;

    // [A6G] case. ----------------------------------------------------------------
    VCCB_PRINT_CALL_DATA(ptCi, "[A6G] selected DU(%d), PsCell candidate num(%d) \n",
        pCell ? pCell->endPointF1Index : -1, ptSpCellCandidate->cellNum);  // TODO: For Debugging
    return GOOD;
}

void FnVCCB_PrepDuBandCandidateCellList(callInfo_type &rCall, const VccbGnbInfo_type &rGnb, gnbDuInfo_type &rGnbDu,
    const uint16_t bandNr, hoRestrictInfo_type &rHrl, const candidateCellListForSort_type &rBaseOfListForSort,
    candidateCellListForSort_type &rCellListOut, uint8_t &rCcPerBandCountOut)
{
    AUTO_TRACE_FUNC;

    uint16_t maxLoopCell = 0;
    uint16_t cellNum = 0;
    rCellListOut.nrofCells = 0;
    rCcPerBandCountOut = 0;

#ifdef __NSGNBAU__
    (void)rGnbDu;
    maxLoopCell = MAX_CELL_NUM_VCCB;
#else
    maxLoopCell = MAX_CELL_PER_DU;
    if (rCellListOut.nrofCells >= MIN(rGnbDu.nrofCells, MAX_NUM_CANDIDATE_CELL_FOR_PSCELL))
    {
        return;
    }
#endif

    for (uint16_t loopCell = 0; loopCell < maxLoopCell; loopCell++)
    {

#ifdef __NSGNBAU__
        cellNum = loopCell;
        if ((EQUIP != CELLINFO[cellNum].status) ||
            (rCall.gnbNum != CELLINFO[cellNum].gnbNum))
        {
            continue;
        }
#else
        cellNum = rGnbDu.cellInDu[loopCell].cellNum;
        if (EQUIP != rGnbDu.cellInDu[loopCell].status)
        {
            continue;
        }
#endif

        VccbCellInfo_type *const pDuCell = &CELLINFO[cellNum];

        if (ERROR == VCCM_CheckCellInService(&rCall, cellNum, TRUE, FALSE))
        {
            continue;
        }

        // Select PsCell candidate only from the same band as chosen cell from candidateCellInfoListMN
        const uint16_t cellNrFrBand = VLIB_GetFreqBandIndForNeighborCellWithCustomSpCell(&rCall, &pDuCell->intraGnbNbrInfo,
            cellNum, true);
        if (bandNr != cellNrFrBand)
        {
            continue;
        }
        rCcPerBandCountOut++;

        if (FnVCCB_IsNonSsbCell(pDuCell))
        {
            VCCB_PRINT_CALL_COMMENT(
                &rCall, "cellNum(%u) is not SSB cell. Not qualified for SpCell selection!\n", cellNum);
            continue;
        }

        if (VCCB_FLAG_ON == rGnb.cfg.spidBasedServingCellSelectionEnable)
        {
            if (GOOD != VLIB_IsPCellAvailableForUe(&rCall, pDuCell->ssbArfcn, &rHrl))
            {
                if (FALSE == rCall.invalidCellSgNBAddReject.spidFlag)
                {
                    rCall.invalidCellSgNBAddReject.spidFlag = TRUE;
                    rCall.invalidCellSgNBAddReject.arfcn = pDuCell->ssbArfcn;
                }
                continue;
            }
        }

        VCCB_PRINT_CALL_DATA(&rCall, "Candidate in DU Found cellNum(%u) nrFreqBand(%u) pci(%u) \n", cellNum,
            bandNr, pDuCell->phyCellId);

        if (IS_NRDC_SN(&rCall))
        {
#ifndef IPC_TEST  // #ifndef Will be removed after cell configuration maintenance for BT
            if (!FnVCCB_isNRDC_allowedCell(&rCall, &pDuCell->intraGnbNbrInfo))
            {
                VCCB_PRINT_CALL_COMMENT(&rCall,
                    "[%s] [cellNum(%u), CI(%u)] Not qualified for SpCell selection: not allowed NRDC Cell\n",
                    __FUNCTION__, cellNum, pDuCell->cellIdentity);
                continue;
            }
#endif
        }

        if (TRUE == VCCM_CheckNRSDLCell(pDuCell))
        {
            VCCB_PRINT_CALL_COMMENT(&rCall, "%s: [cellNum(%u), cellIdentity(%u)] NR SDL Cell is not allowed!\n",
                __FUNCTION__, cellNum, pDuCell->cellIdentity);
            rCall.bitFlag.isSgNBAddReqRejectNoRadioResourcesAvailableInTargetCell = TRUE;
            continue;
        }

        candidateCellForSort_type *pCellForSort = &rCellListOut.candidateCell[rCellListOut.nrofCells];
        pCellForSort->cellNum = cellNum;
        pCellForSort->rsrpFlag = FALSE;
        pCellForSort->rsrqFlag = FALSE;
        pCellForSort->selectedCellPlmnIndex = MAX_PLMN_INDEX;

        for (uint8_t candidateCellIdx = 0; candidateCellIdx < rBaseOfListForSort.nrofCells; candidateCellIdx++)
        {
            const candidateCellForSort_type *pBaseCandidate = &rBaseOfListForSort.candidateCell[candidateCellIdx];
            if (pBaseCandidate->cellNum == pCellForSort->cellNum)
            {
                pCellForSort->rsrpFlag = pBaseCandidate->rsrpFlag;
                pCellForSort->rsrp = pBaseCandidate->rsrp;
                pCellForSort->rsrqFlag = pBaseCandidate->rsrqFlag;
                pCellForSort->rsrq = pBaseCandidate->rsrq;
                break;
            }
        }
        pCellForSort->physCellId = pDuCell->phyCellId;
        pCellForSort->bandNr = cellNrFrBand;
        pCellForSort->priority = pDuCell->priority;
        pCellForSort->ueCount = pDuCell->cfg.assignedCellCallCount;

        if (IS_NRDC_SN(&rCall))
        {
            if (FnVCCB_CheckAgainstMRL_Wrapper(
                    &rCall, &rHrl, pCellForSort->cellNum, &pCellForSort->selectedCellPlmnIndex, __func__) == ERROR)
            {
                VCCB_PRINT_CALL_COMMENT(&rCall,
                    "%s: [cellNum(%u), cellIdentity(%u)] FnVCCB_CheckAgainstMRL_Wrapper ERROR!\n", __FUNCTION__,
                    pCellForSort->cellNum, CELLINFO[pCellForSort->cellNum].cellIdentity);
                continue;
            }
        }

        rCellListOut.nrofCells++;
    }
}

int16_t VCCM_SelectSpCellByOthers(callInfo_type *ptCi, candidateCellListForSort_type *pListForSort,
    const candidateCellListForSort_type *pBaseOfListForSort, gnbDuInfo_type *pGnbDu, uint16_t *ptCellNum,
    const cellSelection_type spCellCandidate)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pListForSort);
    VALID_E_POINT_CHECK_ERROR(pBaseOfListForSort);
    VALID_E_POINT_CHECK_ERROR(pGnbDu);
    VALID_E_POINT_CHECK_ERROR(ptCellNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    const VccbDbgInfo_type *const pDbg = DBG;

    unsigned int offset = 0;
    uint8_t pscellSelectionMethod;
    uint16_t candidateCellIdx = 0;

    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;
    VCCB_RETURN_ON_CALL_ERROR(ptCi, VLIB_DecompressHoRestrictInfo(ptCi, ptHrl),
        "VLIB_DecompressHoRestrictInfo ERROR!\n");

    // [A6G] For PsCell selection get band from candidateCellInfoListMN cell
    if (BAND_NOT_FOUND == spCellCandidate.bandNr)
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(spCellCandidate.cellNum, MAX_CELL_NUM_VCCB);
        VCCB_PRINT_CALL_ERROR(ptCi,
            "[SpCell Selection Fail!] cellNum(%u) cellIdentity(%u). Frequency band not found in candidate cell.\n",
            spCellCandidate.cellNum, CELLINFO[spCellCandidate.cellNum].cellIdentity);
        return ERROR;
    }

    pListForSort->nrofCells = 0;
    uint8_t ccPerBandCount = 0;

    FnVCCB_PrepDuBandCandidateCellList(*ptCi, *pGnb, *pGnbDu, spCellCandidate.bandNr, *ptHrl, *pBaseOfListForSort,
        *pListForSort, ccPerBandCount);

    if (0 == pListForSort->nrofCells)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[SpCell Selection Fail!] highest priority pListForSort->nrofCells==0 ERROR!\n");
        return ERROR;
    }

    if (IS_NRDC_SN(ptCi))
    {
        pscellSelectionMethod = pGnb->cfg.nrdc.pscellSelectionMethod;
    }
    else
    {
        pscellSelectionMethod = pGnb->cfg.pscellSelectionMethod;
    }

    if (FnVCCB_IsPsCellSelectionLB(pscellSelectionMethod))
    {
        // FGR-CC5500 FR90 - select spcell with:
        // 1. MAX UL BW
        // 2. Min UE count
        VCCB_CANDIDATE_CELL_PRINT("STEP3-- -", *pListForSort);
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] selectionMethod(%u) ccPerBandCount(%u)\n",
            pscellSelectionMethod, ccPerBandCount);

        qsort(pListForSort->candidateCell, pListForSort->nrofCells, sizeof(candidateCellForSort_type),
            VLIB_QsortCandidateCellUeCountAscendingOrder);
        offset = 0;
        // now list is sorted by UE counts - lowest UEs from beginning

        int bestIdx = -1;
        if ((pscellSelectionMethod == access_s5gtype_pscell_selection_load_balancing) &&
            (MAX_MCO_LB_CC_PER_BAND >= ccPerBandCount) &&
            (false == FnVCCB_McoCheckIfCpuIsOverloaded()))
        {
            if (VCCB_FLAG_ON == pDbg->flag.mcoLbOldAlgorithm)
            {
                bestIdx = VLIB_McoLbSelectBestSpcell(ptCi, pListForSort);
            }
            else
            {
                bestIdx = VLIB_McoLbSelectBestSpcell2(ptCi, pListForSort);
            }
        }
        else  // for access_s5gtype_pscell_selection_load_balancing_ue_count_based or CPU overload or CC number is over limit
        {
            bestIdx = 0;
        }
        if (bestIdx >= 0)
        {
            offset = static_cast<unsigned>(bestIdx);
            if (MAX_CELL_NUM_VCCB > pListForSort->candidateCell[bestIdx].cellNum)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi, "[MCO LB] Best candidate: [%d]%d, UE count: %d\n", bestIdx,
                    CELLINFO[pListForSort->candidateCell[bestIdx].cellNum].phyCellId,
                    pListForSort->candidateCell[bestIdx].ueCount);
            }
        }
    }
    else  // pscell_selection_method_random
    {
        VCCB_CANDIDATE_CELL_PRINT("STEP3-- -", *pListForSort);
        // 19A does not have cell priority in YANG, so select random cell from entire range
        offset = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, pListForSort->nrofCells);
        VCCB_CHECK_E_RANGE_AND_RETURN(offset, MAX_NUM_CANDIDATE_CELL_FOR_PSCELL);
    }

    *ptCellNum = pListForSort->candidateCell[offset].cellNum;

    if (IS_NRDC_SN(ptCi))  // Determine serving PLMN of UE
    {
        if ((*ptCellNum >= MAX_CELL_NUM_VCCB) ||
            (pListForSort->candidateCell[offset].selectedCellPlmnIndex >= MAX_PLMN_INDEX))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[SpCell Selection Fail!] Invalid cellNum(%d)/cellPlmnIndex(%d) ERROR!\n",
                *ptCellNum, pListForSort->candidateCell[offset].selectedCellPlmnIndex);
            return ERROR;
        }

        ptCi->ueInfo.servedPlmn.longId =
            CELLINFO[*ptCellNum]
                .cellPlmn.servedPlmn[pListForSort->candidateCell[offset].selectedCellPlmnIndex];
    }

    // [FGR-CC5000] [24A] Basic EN-DC FR2230
    // * If SgNB chose PSCell based on NRCGI cells (LB/Random method) then if CAC failed SgNB send
    //   'Target Not Allowed' X2 cause in SgNB Addition Reject message.
    //   It is applicable only if PSCell selection success.
    for (candidateCellIdx = 0; candidateCellIdx < pBaseOfListForSort->nrofCells; candidateCellIdx++)
    {
        const candidateCellForSort_type *pBaseCandidate = &pBaseOfListForSort->candidateCell[candidateCellIdx];
        if (pBaseCandidate->cellNum == spCellCandidate.cellNum)
        {
            if (TRUE == pBaseCandidate->nrcgiCell)
            {
                ptCi->bitFlag.endcAdditionToNrcgiCell = TRUE;
            }
            break;
        }
    }

    return GOOD;
}
/****************************************************************************
 * @brief           Select spCell and DU base on candidateCellInfoListMN
 *
 * @param[in,out]   ptCi      : call information / callInfo_type
 * @param[out]      ptCellNum : pointer to selected cellNum / uint16_t*
 * @param[out]      ptBandNr  : pointer to selected bandNr / uint16_t*
 * @return          status    : GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_SelectSpCell(callInfo_type *ptCi, uint16_t* ptCellNum, uint16_t* ptBandNr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptCellNum);
    VALID_E_POINT_CHECK_ERROR(ptBandNr);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    measResultList2NR_type *candidateCellInfoListMN =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListMN;
    measResultList2NR_type *candidateCellInfoListSN =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;
    measResultList2NR_type *candidateCellInfoList = NULL;

    gnbDuInfo_type *pGnbDu = NULL;
    cellSelection_type spCellCandidate = {};
    int16_t status = GOOD;
    uint8_t blindAdd = FALSE;
    candidateCellListForSort_type listForSort = {};
    // uint8_t numHighCell = 0, numMidCell = 0, numLowCell = 0;

    *ptCellNum = MAX_CELL_NUM_VCCB;
    *ptBandNr = BAND_NOT_FOUND;

    ptCi->servingCellMeasInitialInfo.rsrpFlag = FALSE;
    ptCi->servingCellMeasInitialInfo.rsrqFlag = FALSE;
    ptCi->spCellSelFailStats.num = 0;

    //FGR-CC5200:FR481
    ptCi->mrdcInfo.nrCgiReceivedFromMn.plmn.longId = NO_RECEIVE;

    // [FGR-CC5000] [24A] Basic EN-DC FR2230
    ptCi->bitFlag.endcAdditionToNrcgiCell = FALSE;

    // [FGR-CC5000] [25A] Basic EN-DC FR2206
    if (IS_ENDC(ptCi))
    {
        ptCi->bitFlag.isEndcSpCellSelectionProcedure = TRUE;
    }

    /*
        if Manual configuration is set. use it.
        case1) candidateCellInfoListMN - exist,     candidateCellInfoListSN - not exist. : use candidateCellInfoListMN.
        case2) candidateCellInfoListMN - exist,     candidateCellInfoListSN - exist.     : use candidateCellInfoListSN.
        case3) candidateCellInfoListMN - not exist, candidateCellInfoListSN - not exist. : use manual setting.
                                                                                           If not exist manual setting,
       return error.
    */

    if ((status = VCCM_CheckManualCfgforCellIdentity(ptCi, ptCellNum, ptBandNr)) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_CheckManualCfgforCellIdentity %s !\n", status == ERROR ? "ERROR" : "BREAK");
        return status == BREAK ? GOOD : ERROR;
    }
    // If manualFlag is ON but the mapping table is not exist, then VCCB search cell as like before.

    if (ptCi->cgConfigInfo.candidateCellInfoListSN_Flag)
    {
        candidateCellInfoList = candidateCellInfoListSN;
        ptCi->qInfo.measResult2NRType = CandidateCellInfoList_SN;
    }
    else if (ptCi->cgConfigInfo.candidateCellInfoListMN_Flag)
    {
        candidateCellInfoList = candidateCellInfoListMN;
        ptCi->qInfo.measResult2NRType = CandidateCellInfoList_MN;
    }
    else
    {
        if ((ptCi->callType == E_CALLTYPE_SA) && IS_NRDC_SN(ptCi))
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Cell Selection Failed because no MN/SN candidateCellInfoList in AdditionRequest!!!\n");
            return ERROR;
        }
        else
        {
#ifdef IPC_TEST
            // In general, this should not be happend!.
            // this logic will be kept to avoid the failure of GTEST.
            VCCB_PRINT_CALL_DATA(
                ptCi, "No MN/SN candidateCellInfoList => perform VCCM_CheckManualCfgforMappingF1Idx\n");

            if ((status = VCCM_CheckManualCfgforMappingF1Idx(ptCi, ptCellNum, ptBandNr)) != GOOD)
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "VCCM_CheckManualCfgforMappingF1Idx %s!\n", status == ERROR ? "ERROR" : "BREAK");
                return status == BREAK ? GOOD : ERROR;
            }
#endif
            MACRO_CALL_FAULT_SAVE(X2_SgNBAdditionRequest_id, CauseX2apRadioNetworkLayerNoRadioResourcesAvailableInTargetCell);
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Cell Selection Failed because no MN/SN candidateCellInfoList in AdditionRequest!!!\n");
            return ERROR;
        }
    }

    /*
        [B6G] (below 6 GHz)
        1. If ssbFrequency is exist in candidateCellInfoList, find cells which have same ssbFrequency
           (If not exist, then check only physCellId)
        2. find cells from measResult2NR[freqIdx].measResultNeighCellListNR.measResultNR[cellIdx].physCellId
           and measResult2NR[freqIdx].measResultServingCell.physCellId (if exist)
           (physCellId is optional field)
           + if NCGI is exist, use NCGI to find cell.
           + if {ssbFrequency, PCID} is unique, include cell to candidates.
           + if {ssbFrequency, PCID} is duplicated, exclude cell from the candidates.
        3. sort cells in below order.
            a. cell priority
            b. cellResults.resultsSSB_Cell -- not do in case blindAddition.
        4. select 1st cell from sorted list.

        [A6G] (above 6 GHz)
        1. If ssbFrequency is exist in candidateCellInfoList, find cells which have same ssbFrequency
           (If not exist, then check only physCellId)
        2. find cells from measResult2NR[freqIdx].measResultNeighCellListNR.measResultNR[cellIdx].physCellId
           and measResult2NR[freqIdx].measResultServingCell.physCellId (if exist)
           (physCellId is optional field)
           + if NCGI is exist, use NCGI to find cell.
           + if {ssbFrequency, PCID} is unique, include cell to candidates.
           + if {ssbFrequency, PCID} is duplicated, exclude cell from the candidates.
        3. sort cells in below order.
            a. cell priority
            b. cellResults.resultsSSB_Cell -- not do in case blindAddition..
        4. select best from sorted list.
        5. select DU.
        6.
        [18.3] randomly select SpCell from highest priority cells in selected DU.
        [19A] depending on ps-cell-selection-method, select SpCell in selected DU:
            - random: randomly (naive load balancing)
            - measurement: best cell, same as if GNBINFO.cfg.fixPscellSelection == VCCB_FLAG_ON
            - load-balancing: cell with the lowest number of calls.
        [22C] Selected SpCell in selected DU is from the same band as candidateCellInfoListMN cell from UEs CgInfo.
        [22C2] For EN-DC NRCGI prioritize algorithm was applied for B6G and A6G cells.
               -If NRCGI cells were included on candidateCellInfoListMN, algorithm will exclude non-NRCGI cells for
       choosing on PSCell. -If none of the included candidate cells which has NR CGI cannot be found/are unavailable,
       then gNB consider non-NRCGI cells and try to select one of them

    */

    VALID_E_POINT_CHECK_ERROR(candidateCellInfoList);

    if (ERROR == VCCM_SelectSpCellBuildListOfCandidates(ptCi, &listForSort, candidateCellInfoList, &blindAdd))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "[SpCell Selection Fail!] No cell is available to select from!!!\n");
        return ERROR;
    }

    // [B6G][A6G] 3. sort cells in below order of Priority
    //  a. cell priority
    //  b. cellResults.resultsSSB_Cell -- not do in case blindAddition.
    /* If there is no rsrp in MeasResultNR, do not sort based on rsrp. */
    if (blindAdd != TRUE)
    {
        qsort(listForSort.candidateCell, listForSort.nrofCells, sizeof(candidateCellForSort_type),
            VLIB_QsortCandidateCellRsrpDescendingOrder);
    }
    VCCB_CANDIDATE_CELL_PRINT("STEP1-- -", listForSort);
    qsort(listForSort.candidateCell, listForSort.nrofCells, sizeof(candidateCellForSort_type),
        VLIB_QsortCandidateCellPriorityDescendingOrder);
    VCCB_CANDIDATE_CELL_PRINT("STEP2-- -", listForSort);

    status = VCCM_SelectSpCellByMeasurement(ptCi, &listForSort, &pGnbDu, ptCellNum, ptBandNr, &spCellCandidate);
    if (GOOD != status)
    {
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[SpCell Selection Fail!] No cell is available to select from!!!\n");
            return ERROR;
        }
    }
    else  // [A6G] 6. random/LB select SpCell from highest priority cells in selected DU.
    {
#ifdef __NVGNB__ 
    #ifndef __NSGNBAU__
        if (IS_ENDC(ptCi))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "[SpCell Selection Fail!] LB and Random pscell selection are not supported for FR2 cell on NVGNB!\n");
            return ERROR;
        }
    #endif
#endif
        const candidateCellListForSort_type copyListForSort = listForSort;
        if (ERROR == VCCM_SelectSpCellByOthers(ptCi, &listForSort, &copyListForSort, pGnbDu, ptCellNum, spCellCandidate))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_SelectSpCellByOthers ERROR!\n");
            return ERROR;
        }
        *ptBandNr = spCellCandidate.bandNr;

        VCCB_PRINT_CALL_DATA(ptCi, "[A6G] cellNum : %d\n", *ptCellNum);  // TODO: For Debugging
    }

    uint16_t loop = 0;
    const uint16_t maxLoop = static_cast<uint16_t>(
        UMIN(listForSort.nrofCells, sizeof(listForSort.candidateCell) / sizeof(listForSort.candidateCell[0])));
    
    bool nrcgiCell = false;
    for (loop = 0; loop < maxLoop; loop++)
    {
        if (*ptCellNum == listForSort.candidateCell[loop].cellNum)
        {
            if (TRUE == listForSort.candidateCell[loop].rsrpFlag)
            {
                ptCi->servingCellMeasInitialInfo.rsrpFlag = TRUE;
                ptCi->servingCellMeasInitialInfo.rsrp =
                    static_cast<uint8_t>(listForSort.candidateCell[loop].rsrp & e_BitMask_7bit);
            }
            if (TRUE == listForSort.candidateCell[loop].rsrqFlag)
            {
                ptCi->servingCellMeasInitialInfo.rsrqFlag = TRUE;
                ptCi->servingCellMeasInitialInfo.rsrq =
                    static_cast<uint8_t>(listForSort.candidateCell[loop].rsrq & e_BitMask_7bit);
            }
            if (TRUE == listForSort.candidateCell[loop].nrcgiCell)
            {
                nrcgiCell = true;
            }
            break;
        }
    }

    FnVCCB_PrintSelectedCandidateInfo(ptCi, nrcgiCell);

    return GOOD;
}  // VCCM_SelectSpCell()

/**
 * @brief Check cell neighbors against MR to find the best target intra cell for HO
 *
 * @param[in/out]   ptTgtCellCxt : pointer to target cell neighbor context info / tgtCellSelectionContextInfo_type
 * @param[in]       tempIntraTgtCellSelection : temporary target intra cell selection / cellSelection_type
 * @param[in]       nbrCellIdx :  nbr cell index / uint16_t
 */
void VCCM_checkForBestIntraCellScg(tgtCellSelectionContextInfo_type *ptTgtCellCxt,
    const cellSelection_type tempIntraTgtCellSelection, uint16_t nbrCellIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(CELLINFO);
    VALID_E_POINT_CHECK_VOID(ptTgtCellCxt);
    VCCB_CHECK_E_RANGE_AND_VOID(ptTgtCellCxt->bestIntraIdx, MAX_NBR_PER_CELL);
    VCCB_CHECK_E_RANGE_AND_VOID(tempIntraTgtCellSelection.cellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[tempIntraTgtCellSelection.cellNum];

    if (FALSE == ptTgtCellCxt->tgtInterCellSelected_flag && FALSE == ptTgtCellCxt->tgtIntraCellSelected_flag)
    {
        // pick first matching intra cell as best cell and look further for better intra cell with higher rank
        ptTgtCellCxt->maxCellRank = ptTgtCellCxt->currentCellRank;
        ptTgtCellCxt->tgtIntraCellSelected_flag = TRUE;
        ptTgtCellCxt->pciMrIdx = nbrCellIdx;
        ptTgtCellCxt->bestIntraCells[(ptTgtCellCxt->bestIntraIdx)++] = tempIntraTgtCellSelection;
    }
    else if (ptTgtCellCxt->prevPciNr != pCell->phyCellId && TRUE == ptTgtCellCxt->tgtInterCellSelected_flag &&
             ptTgtCellCxt->pciMrIdx != nbrCellIdx)
    {
        memset(ptTgtCellCxt->bestIntraCells, 0, sizeof(ptTgtCellCxt->bestIntraCells));
        ptTgtCellCxt->bestIntraIdx = 0;

        // pick first found intra cell as best cell and iterate further in order to find better intra cell with higher
        // rank
        ptTgtCellCxt->maxCellRank = ptTgtCellCxt->currentCellRank;
        ptTgtCellCxt->tgtIntraCellSelected_flag = TRUE;
        ptTgtCellCxt->bestIntraCells[(ptTgtCellCxt->bestIntraIdx)++] = tempIntraTgtCellSelection;
    }
    else
    {
        // PCI duplication - rank based selection
        if (TRUE == ptTgtCellCxt->tgtIntraCellSelected_flag &&
            ptTgtCellCxt->maxCellRank == ptTgtCellCxt->currentCellRank)
        {
            ptTgtCellCxt->bestIntraCells[(ptTgtCellCxt->bestIntraIdx)++] = tempIntraTgtCellSelection;
        }
        else if (ptTgtCellCxt->maxCellRank >= ptTgtCellCxt->currentCellRank)
        {
            memset(ptTgtCellCxt->bestIntraCells, 0, sizeof(ptTgtCellCxt->bestIntraCells));
            ptTgtCellCxt->bestIntraIdx = 0;

            ptTgtCellCxt->maxCellRank = ptTgtCellCxt->currentCellRank;
            ptTgtCellCxt->tgtIntraCellSelected_flag = TRUE;
            ptTgtCellCxt->bestIntraCells[(ptTgtCellCxt->bestIntraIdx)++] = tempIntraTgtCellSelection;
        }
    }

    ptTgtCellCxt->prevPciNr = pCell->phyCellId;

    return;
}

/**
 * @brief  Check cell neighbors against MR to find the best target inter cell for HO
 *
 * @param[in]       ptCi : call information / callInfo_type
 * @param[in/out]   ptTgtCellCxt : pointer to target cell neighbor context / tgtCellSelectionContextInfo_type
 * @param[in]       tempTgtInterCellNum : temporary target inter cell number / uint32_t
 * @param[in]       nbrGnbCellNrPci : pci number for gnb cell / uint16_t
 * @param[in]       nbrCellIdx : neighbor cell index / uint16_t
 * @param[in]       nbrIdx : neighbor index / uint16_t
 */
void VCCM_checkForBestInterCellScg(callInfo_type *ptCi, tgtCellSelectionContextInfo_type *ptTgtCellCxt,
    uint16_t nbrGnbCellNrPci, uint16_t nbrCellIdx, uint16_t nbrIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(CELLINFO);
    VALID_E_POINT_CHECK_VOID(ptTgtCellCxt);

    VCCB_CHECK_E_RANGE_AND_VOID(ptTgtCellCxt->bestInterIdx, MAX_NBR_PER_CELL);
    VCCB_CHECK_E_RANGE_AND_VOID(nbrIdx, MAX_NBR_PER_CELL);

    if (FALSE == ptTgtCellCxt->tgtInterCellSelected_flag && FALSE == ptTgtCellCxt->tgtIntraCellSelected_flag)
    {
        // pick first matching inter cell as best cell and look further for the best intra cell or inter cell with
        // higher rank
        ptTgtCellCxt->maxCellRank = ptTgtCellCxt->currentCellRank;
        ptTgtCellCxt->tgtInterCellSelected_flag = TRUE;
        ptTgtCellCxt->pciMrIdx = nbrCellIdx;
        ptTgtCellCxt->bestInterCells[(ptTgtCellCxt->bestInterIdx)++] = nbrIdx;
    }
    else if (TRUE == ptTgtCellCxt->tgtInterCellSelected_flag && ptTgtCellCxt->pciMrIdx != nbrCellIdx)
    {
        if ((ptTgtCellCxt->prevPciNr != nbrGnbCellNrPci && FALSE == ptTgtCellCxt->tgtIntraCellSelected_flag) ||
            (ptTgtCellCxt->prevPciNr == nbrGnbCellNrPci && ptTgtCellCxt->maxCellRank > ptTgtCellCxt->currentCellRank))
        {
            // best inter cell already selected, iterate further to find best intra cell
            ptTgtCellCxt->tgtIntraCellSelected_flag = FALSE;
            ptTgtCellCxt->maxCellRank = ptTgtCellCxt->currentCellRank;
        }
        else
        {
            ptTgtCellCxt->prevPciNr = nbrGnbCellNrPci;
            return;
        }
    }
    else
    {
        // pci duplication and Inter cell previously selected so rank based selection should be performed
        // pci duplication - rank based selection (intra cell with duplicated pci selected but check if inter cell has
        // higher rank then intra)
        if (ptTgtCellCxt->maxCellRank > ptTgtCellCxt->currentCellRank)
        {
            memset(ptTgtCellCxt->bestInterCells, 0, sizeof(ptTgtCellCxt->bestInterCells));
            ptTgtCellCxt->bestInterIdx = 0;

            ptTgtCellCxt->maxCellRank = ptTgtCellCxt->currentCellRank;
            ptTgtCellCxt->tgtInterCellSelected_flag = TRUE;
            ptTgtCellCxt->tgtIntraCellSelected_flag = FALSE;
            ptTgtCellCxt->bestInterCells[(ptTgtCellCxt->bestInterIdx)++] = nbrIdx;
        }
        else if (ptTgtCellCxt->maxCellRank == ptTgtCellCxt->currentCellRank)
        {
            ptTgtCellCxt->bestInterCells[(ptTgtCellCxt->bestInterIdx)++] = nbrIdx;
        }
    }

    ptTgtCellCxt->prevPciNr = nbrGnbCellNrPci;
    return;
}

/****************************************************************************
 * @brief  Initialize target cell selection context structure with default values
 *
 * @param[in/out]   ptTgtCellNbrForHo :  call information / tgtCellSelectionContextInfo_type
 ****************************************************************************/
void VCCM_InitializeDefaultCellSelectionCtx(tgtCellSelectionContextInfo_type *ptTgtCellNbrForHo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptTgtCellNbrForHo);

    ptTgtCellNbrForHo->tgtIntraCellSelected_flag = FALSE;
    ptTgtCellNbrForHo->tgtInterCellSelected_flag = FALSE;
    ptTgtCellNbrForHo->bestIntraIdx = 0;
    ptTgtCellNbrForHo->bestInterIdx = 0;
    ptTgtCellNbrForHo->prevPciNr = 0;
    ptTgtCellNbrForHo->pciMrIdx = 0;
    ptTgtCellNbrForHo->targetIntraCell.cellNum = 0;
    ptTgtCellNbrForHo->targetIntraCell.bandNr = BAND_NOT_FOUND;
    ptTgtCellNbrForHo->targetInterCellNum = 0;
    ptTgtCellNbrForHo->maxCellRank = CANDIDATE_CELL_MAX_RANK;
    ptTgtCellNbrForHo->currentCellRank = CANDIDATE_CELL_MAX_RANK;
    memset(ptTgtCellNbrForHo->bestIntraCells, 0, sizeof(ptTgtCellNbrForHo->bestIntraCells));
    memset(ptTgtCellNbrForHo->bestInterCells, 0, sizeof(ptTgtCellNbrForHo->bestInterCells));

    return;
}

/****************************************************************************
 * @brief           Select PCell as Target for Handover triggered by SCG
 *
 * @param[in]       ptCi :          call information / callInfo_type
 * @return          status :        GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCM_SelectPCellAsTgtScgMob(callInfo_type *ptCi, uint16_t *ptRelationType, cellSelection_type *ptCellSelection,
    enumRSType rsType, measResultList2NR_type *ptMeasResultList2NR)
{
    AUTO_TRACE_FUNC;

    uint16_t idx = 0, nbrCellIdx = 0;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(CELLINFO);
    VALID_E_POINT_CHECK_ERROR(ptRelationType);
    VALID_E_POINT_CHECK_ERROR(ptCellSelection);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2NR);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    measResult2NR_type *measResult2NR = ptMeasResultList2NR->measResult2NR;
    measResultNR_type *ptMeasResultNR = NULL;

    for (idx = 0; idx < MIN(ptMeasResultList2NR->nrofFreq, MAX_NUM_FREQ); idx++)  // go through the measurement list
    {
        if (!(TRUE == measResult2NR[idx].ssbFrequency_Flag && RSType_SSB == rsType &&
                pCell->ssbArfcn == measResult2NR[idx].ssbFrequency))
        {
            continue;
        }

        if (TRUE == measResult2NR[idx].measResultServingCell_Flag)
        {
            ptMeasResultNR = &measResult2NR[idx].measResultServingCell;

            // Check as PSCell
            if ((TRUE != ptMeasResultNR->physCellIdFlag) || (pCell->phyCellId == ptMeasResultNR->physCellId))
            {
                ptCellSelection->cellNum = ptCi->servCellNum;
                ptCellSelection->bandNr = ptCi->servCellBand;
                *ptRelationType = INTRA_NB;

                return GOOD;
            }
        }

        for (nbrCellIdx = 0;
             nbrCellIdx < MIN(measResult2NR[idx].measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);
             nbrCellIdx++)
        {
            ptMeasResultNR = &measResult2NR[idx].measResultNeighCellListNR.measResultNR[nbrCellIdx];

            if ((FALSE == ptMeasResultNR->physCellIdFlag))
            {
                continue;
            }

            if (pCell->phyCellId == ptMeasResultNR->physCellId)
            {
                ptCellSelection->cellNum = ptCi->servCellNum;
                ptCellSelection->bandNr = ptCi->servCellBand;
                *ptRelationType = INTRA_NB;

                return GOOD;
            }
        }
    }

    return BREAK;
}

/**
 * @brief Returns true is a NBR cell is intra-SN.
 *
 * @param call info
 * @param nbr cell info
 * @return true
 * @return false
 */
inline bool VCCB_IsNbrIntraGnb(const callInfo_type &call, const nbrCellInfo_type &nbr)
{
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(call.gnbNum, false);
    return (nbr.targetGnbId == GNBINFO[call.gnbNum].globalGnbId);
}

/**
 * @brief State for MCG Mobility best NBR cell selection.
 *
 */
struct McgMob_FindBestRankNbrCell_state
{
    // Input params.
    const uint16_t pci;
    const uint32_t freq;
    const enumRSType rsType;
    // State.
    cellSelection_type bestCell;  // Best selected NBR cell.
    cellSelection_type currCell;  // Currently processed NBR cell info.
    //
    McgMob_FindBestRankNbrCell_state(uint16_t inPci, uint32_t inFreq, enumRSType inRsType) :
        pci(inPci),
        freq(inFreq),
        rsType(inRsType),
        bestCell{MAX_CELL_NUM_VCCB, BAND_NOT_FOUND},
        currCell{MAX_CELL_NUM_VCCB, BAND_NOT_FOUND}
    {
    }
};

/**
 * @brief Returns true if a intra-SN NBR cell meets PSCell selection criteria for MCG Mobility (common part for EN-DC
 * and NR-DC).
 *
 * @param call info
 * @param state algorithm state object
 * @return true
 * @return false
 */
bool VCCB_McgMob_CheckIntraSnPscellCandidateCell_COMMON(
    /*const*/ callInfo_type &call, McgMob_FindBestRankNbrCell_state &state)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(call.myThreadId, MAX_CALL_THREAD_NUM_VCCB, false);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(state.currCell.cellNum, false);
    VCCB_CHECK_VALID_GNBNUM_RET_VAL(call.gnbNum, false);

    uint8_t _unused = 0;

    if (GOOD != VCCM_CheckCellInService(&call, state.currCell.cellNum, TRUE, TRUE))
    {
        VCCB_PRINT_CALL_COMMENT(
            &call, "[MCG-MOB] %s: (cell-num %u) not in service.\n", __FUNCTION__, state.currCell.cellNum);
        return false;
    }
    // Mobility Restriction List.
    auto &hrl = THREAD_INFO->call[call.myThreadId].buf.hoRestrictInfo;
    if (GOOD != FnVCCB_CheckAgainstMRL_Wrapper(&call, &hrl, state.currCell.cellNum, &_unused, __FUNCTION__))
    {
        VCCB_PRINT_CALL_COMMENT(&call, "[MCG-MOB] %s: (cell-num %u) excluded by mobility restriction list.\n",
            __FUNCTION__, state.currCell.cellNum);
        return false;
    }
    const auto &cell = CELLINFO[state.currCell.cellNum];
    state.currCell.bandNr = VCCB_MRDC_SN_SelectPscellBandOfNbr(call, cell.intraGnbNbrInfo);
    if (BAND_NOT_FOUND == state.currCell.bandNr)
    {
        VCCB_PRINT_CALL_COMMENT(
            &call, "[MCG-MOB] %s: (cell-num %u) no PSCell-capable band.\n", __FUNCTION__, state.currCell.cellNum);
        return false;
    }
    // FGR-CC5001 FR199
    // FGR-CC5201 FR114
    // (S-Node) When Intra-SN Inter-PLMN Pscell change is not allowed,
    // gNB should exclude the intra-gNB cells which does not support the serving PLMN of the UE
    if ((VCCB_FLAG_OFF == GNBINFO[call.gnbNum].cfg.gnbMobilityConfig.allowIntraSnInterPlmnChange) &&
        (TRUE != VLIB_CheckCellPlmn(call.ueInfo.servedPlmn.longId, state.currCell.cellNum)))
    {
        VCCB_PRINT_CALL_COMMENT(
            &call, "[MCG-MOB] %s: (cell-num %u) is inter-PLMN.\n", __FUNCTION__, state.currCell.cellNum);
        return false;
    }
    // FGR-CC5001 FR224
    // FGR-CC5201 FR110
    // - [23A] Candidate PSCell is not SDL cell
    //   * Refer [FGR-CC3301 Call control for NR cell operation] for definition of SDL cell
    if (FnVCCB_IsNbrSDLCell(&call, &cell.intraGnbNbrInfo))
    {
        VCCB_PRINT_CALL_COMMENT(
            &call, "[MCG-MOB] %s: (cell-num %u) cell is SDL.\n", __FUNCTION__, state.currCell.cellNum);
        return false;
    }

    return true;
}

/**
 * @brief Returns true if a intra-SN NBR cell meets PSCell selection criteria for MCG Mobility (EN-DC specific).
 *
 * @param call info
 * @param nbr cell info
 * @param state algorithm state object
 * @return true
 * @return false
 */
bool VCCB_McgMob_CheckIntraSnPscellCandidateCell_ENDC(
    /*const*/ callInfo_type &call, const nbrCellInfo_type &nbr, McgMob_FindBestRankNbrCell_state &state)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(call.servCellNum, false);
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(state.currCell.cellNum, false);

    const auto *cellInfo = CELLINFO;
    const auto &psCell   = cellInfo[call.servCellNum];
    const auto &tgtCell  = cellInfo[state.currCell.cellNum];

    if (GOOD != VCCM_checkCellFrequencyOverlapWithLtePCell(&call, &tgtCell.intraGnbNbrInfo))
    {
        VCCB_PRINT_CALL_COMMENT(&call, "[MCG-MOB] %s: (cell-num %u) frequency overlap with LTE PCell.\n", __FUNCTION__,
            state.currCell.cellNum);
        return false;
    }

    if (psCell.imdInterferenceDetection)
    {
        if (GOOD != VCCM_checkImdInterferenceWithLtePCellAndNrCandidateCell(
                        &call, &tgtCell.intraGnbNbrInfo, &tgtCell.intraGnbNbrInfo))
        {
            VCCB_PRINT_CALL_COMMENT(&call, "[MCG-MOB] %s: (cell-num %u) IMD interference with LTE PCell.\n",
                __FUNCTION__, state.currCell.cellNum);
            return false;
        }
    }

    if (VCCB_FLAG_ON == DBG->flag.noHoBtwSaAndNsaCell)
    {
        if (psCell.tacStatus != tgtCell.tacStatus)
        {
            VCCB_PRINT_CALL_COMMENT(&call, "[MCG-MOB] %s: (cell-num %u) source and target TAC differs.\n", __FUNCTION__,
                state.currCell.cellNum);
            return false;
        }
    }
    // FGR-CC5001 FR235
    if (VCCB_IsCellUlInterfered(tgtCell))
    {
        call.bitFlag.isSgNBAddReqRejectedDueToDucting = TRUE;
        VCCB_PRINT_CALL_COMMENT(&call, "[MCG-MOB] %s: (cell-num %u) tgtCell is UL Interfered.\n",
                __FUNCTION__, state.currCell.cellNum);
        return false;
    }

    // FGR-CC5001 FR226, FGR-CC5001 FR243
    // VCCB_NSA_IsHoAllowed is not called, because in MCG mob there is no inter gnb HOs,
    // it is enough to check isEndcHoAllowed nbr value
    if (TRUE != nbr.isEndcHoAllowed)
    {
        VCCB_PRINT_CALL_COMMENT(&call, "%s:[MCG-MOB] HO not allowed to NBR(cell-num %u).\n",
                __FUNCTION__, state.currCell.cellNum);
        return false;
    }

    return true;
}

/**
 * @brief Returns true if a intra-SN NBR cell meets PSCell selection criteria for MCG Mobility (NR-DC specific).
 *
 * @param call info
 * @param state algorithm state object
 * @return true
 * @return false
 */
bool VCCB_McgMob_CheckIntraSnPscellCandidateCell_NRDC(
    /*const*/ callInfo_type &call, McgMob_FindBestRankNbrCell_state &state)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(state.currCell.cellNum, false);

    const auto &tgtCell = CELLINFO[state.currCell.cellNum];

    // FGR-CC5201 FR110
    // - Candidate PSCell is allowed for NR-DC PSCell
    //   * Refer [FGR-SF0001 NSA/SA Operation Scenario] for details
    if (FnVCCB_isNRDC_allowedCell(&call, &tgtCell.intraGnbNbrInfo) == false)
    {
        VCCB_PRINT_CALL_COMMENT(
            &call, "[MCG-MOB] %s: (cell-num %u) not allowed for NRDC.\n", __FUNCTION__, state.currCell.cellNum);
        return false;
    }

    // SVR23A FGR-CC5203
    // FR51. SN VCCB shall choose 'Intra SN & Intra DU Cell with existing PSCell' only as target PSCell for
    // Resume MR
    if (IS_SCG_RESUMING(&call))
    {
        if (tgtCell.endPointF1Index != call.endPointInfo.f1Idx)
        {
            return false;
        }
        if (state.currCell.cellNum == call.servCellNum)
        {
            if (DBG->flag.mrdcScgFailureSuspendResumeAcceptSameTargetPSCell == FALSE)
            {
                return false;
            }
        }
    }

    // FGR-CC5201 FR110
    // - Candidate PSCell is not non-SSB cell
    //   * Non-SSB cell is defined by SSB-ToMeasure with all zero value
    if (FnVCCB_IsNonSsbCell(&tgtCell))
    {
        VCCB_PRINT_CALL_COMMENT(&call, "[MCG-MOB] %s: (cell-num %u) not SSB.\n", __FUNCTION__, state.currCell.cellNum);
        return false;
    }

    VCCB_CHECK_E_RANGE_AND_VAL(tgtCell.gnbNum, MAX_GNB_PER_SYS, false);
    VccbGnbInfo_type *const pGnb = &GNBINFO[tgtCell.gnbNum];

    if (FnVCCB_IsDuOverload(pGnb, tgtCell.endPointF1Index) == true)
    {
        VCCB_PRINT_CALL_COMMENT((&call), "[MCG-MOB] %s: (cell-num %u) DU endPointF1Index(%u) overloaded!\n",
            __FUNCTION__, state.currCell.cellNum, tgtCell.endPointF1Index);
        return false;
    }

    return true;
}

/**
 * @brief Converts reference signal type value to c-string.
 *
 * @param rsType reference signal value
 * @return const char*
 */
const char *VCCB_RsTypeToString(enumRSType rsType)
{
    switch (rsType)
    {
        case RSType_SSB:
            return "SSB";
        case RSType_CSIRS:
            return "CSIRS";
        default:
            break;
    }

    return "<RSType unknown>";
}

/**
 * @brief Returns true if a NBR cell was found in intra-SN cells list.
 *
 * @param call info
 * @param nbr cell info
 * @param state algorithm state object
 * @return true
 * @return false
 */
bool VCCB_McgMob_FindIntraSnCellInfoByNbrInfo(
    const callInfo_type &call, const nbrCellInfo_type &nbr, McgMob_FindBestRankNbrCell_state &state)
{
    if (N_EQUIP == nbr.status)
    {
        return false;
    }
    if (not VCCB_IsNbrIntraGnb(call, nbr))
    {
        return false;
    }
    //
    state.currCell.cellNum = FnVCCB_GetCellNum(call.gnbNum, nbr.targetCellId);
    if (MAX_CELL_NUM_VCCB <= state.currCell.cellNum)
    {
        VCCB_PRINT_CALL_COMMENT(&call, "[MCG-MOB] %s: NBR (gnb-id %u cell-id %u) not found in intra-SN cells list.\n",
            __FUNCTION__, nbr.targetGnbId.gnbId.id, nbr.targetCellId);
        return false;
    }
    const auto &cell = CELLINFO[state.currCell.cellNum];
    if (EQUIP != cell.status)
    {
        VCCB_PRINT_CALL_COMMENT(
            &call, "[MCG-MOB] %s: NBR (cell-num %u) is not equipped.\n", __FUNCTION__, state.currCell.cellNum);
        return false;
    }
    // Match PCI and FREQ.
    if (cell.phyCellId != state.pci)
    {
        VCCB_PRINT_CALL_COMMENT(&call, "[MCG-MOB] %s: NBR (cell-num %u) PCI mismatch (%u != %u).\n", __FUNCTION__,
            state.currCell.cellNum, cell.phyCellId, state.pci);
        return false;
    }
    if (((RSType_SSB == state.rsType) && (cell.ssbArfcn != state.freq)) ||
        ((RSType_CSIRS == state.rsType) && (cell.nrArfcnDl != state.freq)))
    {
        VCCB_PRINT_CALL_COMMENT(&call, "[MCG-MOB] %s: NBR (cell-num %u) FREQ mismatch (%s %u != %u).\n", __FUNCTION__,
            state.currCell.cellNum, VCCB_RsTypeToString(state.rsType),
            (state.rsType == RSType_SSB ? cell.ssbArfcn : cell.nrArfcnDl), state.freq);
        return false;
    }

    // Intra-SN cell info found.
    return true;
}

/**
 * @brief Returns true if a intra-SN NBR cell meets PSCell selection criteria for MCG Mobility.
 *
 * @param call info
 * @param nbr cell info
 * @param state algorithm state object
 * @return true
 * @return false
 */
bool VCCB_McgMob_CheckIntraSnPscellCandidateCell(
    /*const*/ callInfo_type &call, const nbrCellInfo_type &nbr, McgMob_FindBestRankNbrCell_state &state)
{
    if (not VCCB_McgMob_FindIntraSnCellInfoByNbrInfo(call, nbr, state))
    {
        // Cause will be logged by the checker.
        return false;
    }

    if (not VCCB_McgMob_CheckIntraSnPscellCandidateCell_COMMON(call, state))
    {
        // Cause will be logged by the COMMON checker.
        return false;
    }
    // EN-DC.
    if (VCCB_IsEndcSn(call))
    {
        if (not VCCB_McgMob_CheckIntraSnPscellCandidateCell_ENDC(call, nbr, state))
        {
            // Cause will be logged by the ENDC checker.
            return false;
        }
    }
    // NR-DC.
    else if (FnVCCB_IsNrdcSn(&call))
    {
        if (not VCCB_McgMob_CheckIntraSnPscellCandidateCell_NRDC(call, state))
        {
            // Cause will be logged by the NRDC checker.
            return false;
        }
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(&call, "[MCG-MOB] %s: call is neither 'EN-DC SN' nor 'NR-DC SN'.\n", __FUNCTION__);
    }

    return true;
}

constexpr auto NBR_CELL_RANK_MAX = 10000;

/**
 * @brief Tries to find best intra-SN NBR cell for MCG Mobility based on candidate:
 *          - PCI,
 *          - FREQ
 *          - RANK.
 *        Returns true if a proper NBR cell was found.
 *
 * @param call info
 * @param state algorithm state object
 * @return true
 * @return false
 */
bool VCCB_McgMob_FindBestRankNbrCell(/*const*/ callInfo_type &call, McgMob_FindBestRankNbrCell_state &state)
{
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(call.servCellNum, false);

    // The lower the rank the better.
    int bestCellRank = NBR_CELL_RANK_MAX + 1;

    // Serving cell neighbors.
    const auto &nbrs = CELLINFO[call.servCellNum].Nbr;

    // All NBRs need to be checked due to possible PCI duplication.
    for (int nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; ++nbrIdx)
    {
        const auto &nbr = nbrs[nbrIdx];
        if (not VCCB_McgMob_CheckIntraSnPscellCandidateCell(call, nbr, state))
        {
            // Cause will be logged by the checker.
            continue;  // Check next NBR.
        }
        // Check best rank.
        if (nbr.rank < bestCellRank)
        {
            // Update current best cell.
            bestCellRank = nbr.rank;
            state.bestCell = state.currCell;
        }
    }

    // Return true if cell was selected.
    return (MAX_CELL_NUM_VCCB > state.bestCell.cellNum);
}

/****************************************************************************
 * @brief           Check if PCI for handover
 *                  PRECONDITION:
 *                      Before calling this function ensure that ptCi->hoRestrict
 *                      is decompressed into THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo.
 *
 * @return          status :        GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_CheckPciCellForHo(
    callInfo_type *ptCi, uint16_t pci, uint32_t usedFreq, enumRSType rsType, cellSelection_type *ptCellSelection)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptCellSelection);

    auto state = McgMob_FindBestRankNbrCell_state(pci, usedFreq, rsType);
    if (not VCCB_McgMob_FindBestRankNbrCell(*ptCi, state))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "[MCG-MOB] %s: no NBR cell selected for (PCI %u FREQ %s/%u).\n", __FUNCTION__,
            pci, VCCB_RsTypeToString(rsType), usedFreq);
        return BREAK;
    }

    // Best NBR cell was selected.
    *ptCellSelection = state.bestCell;
    return GOOD;
}

int16_t FnVCCB_CompareRankOfHoNbrCell(callInfo_type *ptCi, candidateNbrList_type *candidateCellList)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint8_t idx = 0;
    const uint16_t maxNumNbr = static_cast<uint16_t>(UMIN(ptCi->reportCgiHoInfo.qNumNbr, MAX_DUPL_PCI_NBR_PER_CELL));
    const uint16_t maxNumCandiNbr =
        (ptCi->anrInfo.ratType == nrType) ? MAX_NBR_PER_CELL : MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL;
    int32_t currentCellRank = CANDIDATE_CELL_MAX_RANK;

    /* Init candidateCellList */
    candidateCellList->numNbr = 0;
    candidateCellList->maxRank = CANDIDATE_CELL_MAX_RANK;

    for (idx = 0; idx < maxNumNbr; idx++)
    {
        currentCellRank = ptCi->reportCgiHoInfo.qRank[idx];

        if (candidateCellList->maxRank < currentCellRank)
        {
            // The lower the value, the higher the priority.
            VCCB_PRINT_CALL_COMMENT(ptCi, "current rank is less than already selected - maxRank:%d, currentRank:%d\n",
                candidateCellList->maxRank, currentCellRank);
            continue;
        }

        if (candidateCellList->maxRank > currentCellRank)
        {
            candidateCellList->numNbr = 0;
            candidateCellList->maxRank = currentCellRank;
        }
        // candidateCellList->numNbr should not be changed When currentCellRank is the same as the already selected rank.

        if (candidateCellList->numNbr >= maxNumCandiNbr)
        {
            continue;
        }

        candidateCellList->nbrList[candidateCellList->numNbr].nbrIdx = ptCi->reportCgiHoInfo.qTargetNbrIdx[idx];
        candidateCellList->nbrList[candidateCellList->numNbr].selectedTAI = ptCi->reportCgiHoInfo.selectedTAI[idx];
        candidateCellList->nbrList[candidateCellList->numNbr].freqIdx = ptCi->reportCgiHoInfo.freqIdx;
        candidateCellList->nbrList[candidateCellList->numNbr].pciIdx = ptCi->reportCgiHoInfo.pciIdx;
        candidateCellList->numNbr++;
    }

    return GOOD;
}

/************************************************************************************************************
 * @brief           Compare phyCellId and Frequency from measResult and cell info of neighbour from other gnb
 *
 * @param[in]       ptMeasResultNR    : meas result information
 * @param[in]       usedFreq          : frequency from measResult to compare
 * @param[in]       rsType            : RSType_CSIRS / RSType_SSB
 * @param[in]       ptNbrGnbCell      : cell to check
 * @param[in]       ptCi              : call information / callInfo_type
 * @return          status            : GOOD, ERROR, BREAK / int16_t
 ************************************************************************************************************/
int16_t VCCM_ComparePcisAndFreqsOfNbrCell(
    const measResultNR_type *ptMeasResultNR, uint32_t usedFreq, enumRSType rsType, nbrGnbCellInfo_type *ptNbrGnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCell);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultNR);

    if (ptNbrGnbCell->nrPci != ptMeasResultNR->physCellId)
    {
        VCCB_PRINT_COMMENT("Compared cells have different pci: nbr(cellId=%d)(%d), meas(%d)\n", ptNbrGnbCell->cellId,
            ptNbrGnbCell->nrPci, ptMeasResultNR->physCellId);
        return BREAK;
    }

    if (RSType_SSB == rsType)
    {
        if (ptNbrGnbCell->ssbArfcn != usedFreq)
        {
            VCCB_PRINT_COMMENT("Compared cells have different freq: nbr(cellId=%d)(%d), meas(%d), SSB\n",
                ptNbrGnbCell->cellId, ptNbrGnbCell->ssbArfcn, usedFreq);
            return BREAK;
        }
    }
    else  // if(RSType_CSIRS == rsType)
    {
        if (ptNbrGnbCell->nrArfcnDl != usedFreq)
        {
            VCCB_PRINT_COMMENT("Compared cells have different freq: nbr(cellId=%d)(%d), meas(%d), Not SSB\n",
                ptNbrGnbCell->cellId, ptNbrGnbCell->nrArfcnDl, usedFreq);
            return BREAK;
        }
    }

    return GOOD;
}

/********************************************************************************************
 * @brief           This function checks whether the TAI is a TAI allowed by the MRL.
 *
 * @param[in]       nbrLongId  : PLMN of TAI to check
 * @param[in]       nbrTac     : TAC of TAI to check
 * @param[in]       ptHrl      : Handover Restriction List / hoRestrictInfo_type
 * @return          status : TRUE - Allowed TAI, FALSE - Not Allowed TAI
 ********************************************************************************************/
int16_t FnVCCB_CheckAllowedTAIwithMRL(const hoRestrictInfo_type *ptHrl, uint32_t nbrTac, uint32_t nbrLongId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptHrl);

    // TAI = PLMN + TAC

    if (FALSE == ptHrl->existFlag)
    {
        return TRUE;
    }

    if (GOOD != VCCM_CheckForbiddenFiveGTAC(ptHrl, nbrTac, nbrLongId))
    {
        return FALSE;
    }

    if (GOOD != VCCM_CheckNotAllowedTA(ptHrl, nbrTac, nbrLongId))
    {
        return FALSE;
    }

    return TRUE;
}

int16_t VCCM_CheckPlmnAndTacInMrlAllowedList(const callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, uint32_t tac, uint32_t longId)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptHrl);

    uint16_t allowedIdx = 0;
    plmnId_type *nrAllowedPlmn;

    if (FALSE == ptHrl->existFlag)
    {
        return GOOD;
    }

    allwedPlmnList_type *pAllowedPlmn = FnVCCB_GetAllowedPlmnListByMRL(ptCi, ptHrl, MyRATRestriction);
    if (pAllowedPlmn != NULL)
    {
        for (allowedIdx = 0; allowedIdx < pAllowedPlmn->numNrAllowedPlmn; allowedIdx++)
        {
            nrAllowedPlmn = &(pAllowedPlmn->nrAllowedPlmn[allowedIdx]);

            if (nrAllowedPlmn->longId != longId) continue;

            if (FALSE == FnVCCB_CheckAllowedTAIwithMRL(ptHrl, tac, longId)) continue;

            return GOOD;
        }
    }

    return ERROR;
}

int VCCM_checkSaIFAvailableNbr(callInfo_type *ptCi, uint16_t cellNum, measurementObjectNRBaseDb_type *ptMO)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMO);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    allowedPlmnList_Type allowedPlmnList{};
    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;
    uint32_t numEquippedNbrCell = 0;
    uint16_t nbrIdx = 0;
    uint16_t nbrPlmnIdx = 0;

    // get Allowed Plmn List
    if (ERROR == VLIB_DecompressHoRestrictInfo(ptCi, ptHrl))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_DecompressHoRestrictInfo ERROR!\n");
        return ERROR;
    }

    // SM_CELL_HO 24A
    if (FnVCCB_IsValidSmallCellConfigNrMo(ptCi->gnbNum, ptMO->smallCellPciListIndex) == GOOD)
    {
        return GOOD;
    }

    smtc1_type measObjectSmtc1 = FnVCCB_GetEffectiveSmtc1(*ptCi, cellNum, *ptMO);

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        nbrGnbCellInfo_type *pNbr = nullptr;
        int status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbr);
        if (status != GOOD || pNbr == nullptr) continue;

        if (pNbr->ssbArfcn != ptMO->ssbFrequency) continue;

        if (FALSE == VHCM_isSaEnabledNbr(ptCi, pNbr)) continue;

        // NR_CONN_MC_23A modified
        if (GOOD != VCCM_CompareNbrSmtc1Condition(&measObjectSmtc1, pNbr)) continue;

        // count equipped nbrCell with same freq
        numEquippedNbrCell++;

        // get band information
        uint16_t band = VCCB_GetMoNrBandForUe(ptCi, ptMO);
        if (band == 0) continue;

        // check the cell BW with UE capability
        if (GOOD != VLIB_checkIntraNRChannelBWs(ptCi, pNbr, band, cellNum, FALSE)) continue;

        // FGR-MC1015 PLMN based Mobility Control - FR11.CACP.SR1.HD1 (Intra-NR)
        // gNB configurates a measure object regardless of allowed PLMN using MRL for an emergency UE.
        if (VCCM_CheckEmergencyCall(ptCi) == TRUE)
        {
            return GOOD;
        }

        status = FnVCCB_GetNbrPlmnList(ptCi, cellNum, nbrIdx, &allowedPlmnList);
        if (GOOD != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "VCCM_checkSaIFAvailableNbr [%d] FnVCCB_GetNbrPlmnList %d/%d\n", nbrIdx, GOOD, status);
            continue;
        }

        // SVR25B FGR-MC1007 FR152
        status = FnVCCB_GetNbrSaAvailablePlmnList(*ptCi, cellNum, nbrIdx, allowedPlmnList);
        if (GOOD != status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "check FnVCCB_GetNbrSaAvailablePlmnList (nbr:%d/numPlmn:%d) in VCCM_checkSaIFAvailableNbr\n", nbrIdx,
                allowedPlmnList.num_plmn);
            continue;
        }

        for (nbrPlmnIdx = 0; nbrPlmnIdx < MIN(allowedPlmnList.num_plmn, MAX_NUM_PLMN); nbrPlmnIdx++)
        {
            if (GOOD ==
                VCCM_CheckPlmnAndTacInMrlAllowedList(ptCi, ptHrl, pNbr->fiveGsTac, allowedPlmnList.plmn[nbrPlmnIdx].longId))
            {
                return GOOD;
            }
        }
    }

    // If there is no neighbor cell, return GOOD.
    if (0 == numEquippedNbrCell)
    {
        return GOOD;
    }

    return ERROR;
}

int FnVCCB_checkNrdcSnIFAvailableNbr(callInfo_type *ptCi, uint16_t cellNum, measurementObjectNRBaseDb_type *ptMO)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMO);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    allowedPlmnList_Type allowedPlmnList{};
    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;
    uint32_t numEquippedNbrCell = 0;
    uint16_t nbrIdx = 0;
    uint16_t nbrPlmnIdx = 0;

    // get Allowed Plmn List
    if (ERROR == VLIB_DecompressHoRestrictInfo(ptCi, ptHrl))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_DecompressHoRestrictInfo ERROR!\n");
        return ERROR;
    }

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        nbrGnbCellInfo_type *pNbr;
        int status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbr);
        if (status != GOOD) continue;

        if (pNbr->ssbArfcn != ptMO->ssbFrequency) continue;

        // NR_CONN_MC_23A modified
        if (GOOD != VCCM_CompareNbrSmtc1Condition(&ptMO->smtc1, pNbr)) continue;

        // count equipped nbrCell with same freq
        numEquippedNbrCell++;

        // get band information
        uint16_t band = VCCB_GetMoNrBandForUe(ptCi, ptMO);
        if (band == 0) continue;

        // check the BC List for NR-DC SN
        if (VCCB_isBandSupportedAsPcellBand(ptCi, band) != GOOD)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "NR band(%u) not satisfying the allowed MR-DC band combination!\n", band);
            continue;
        }

        // check the cell BW with UE capability
        if (GOOD != VLIB_checkIntraNRChannelBWs(ptCi, pNbr, band, cellNum, FALSE)) continue;

        status = FnVCCB_GetNbrPlmnList(ptCi, cellNum, nbrIdx, &allowedPlmnList);
        if (GOOD != status)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "FnVCCB_checkNrdcSnIFAvailableNbr [%d] FnVCCB_GetNbrPlmnList %d/%d\n", nbrIdx, GOOD, status);
            continue;
        }

        for (nbrPlmnIdx = 0; nbrPlmnIdx < MIN(allowedPlmnList.num_plmn, MAX_NUM_PLMN); nbrPlmnIdx++)
        {
            if (GOOD ==
                VCCM_CheckPlmnAndTacInMrlAllowedList(ptCi, ptHrl, pNbr->fiveGsTac, allowedPlmnList.plmn[nbrPlmnIdx].longId))
            {

                return GOOD;
            }
        }
    }

    // If there is no neighbor cell, return GOOD.
    if (0 == numEquippedNbrCell)
    {
        return GOOD;
    }

    return ERROR;
}

bool FnVCCB_isNRDC_allowedCell(const callInfo_type *ptCi, const nbrGnbCellInfo_type *pNbr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VALID_E_POINT_CHECK_RET_VAL(pNbr, false);

    if (FnVCCB_IsFr1Freq(pNbr->ssbArfcn))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "(ssb/pci:%u/%u, Gnb/Cell:%u/%u) is not allowed NRDC cell (arfcn:%u)!\n",
            pNbr->ssbArfcn, pNbr->nrPci, pNbr->globalGnbId.gnbId.id, pNbr->cellId, pNbr->ssbArfcn);
        return false;
    }

    // FGR-CC5200:FR172
    if (!FnVCCB_IsCellQualified_ForPSCell_BasedOnTAC(
            pNbr->configuredTacIndication, pNbr->fiveGsTacStatus, pNbr->fiveGsTac))
    {
        VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
            "(ssb/pci:%u/%u, Gnb/Cell:%u/%u) is not allowed NRDC cell (cfgTacInd:%u,5GSTacStatus:%u,5GSTac:%u)\n",
            pNbr->ssbArfcn, pNbr->nrPci, pNbr->globalGnbId.gnbId.id, pNbr->cellId, pNbr->configuredTacIndication,
            pNbr->fiveGsTacStatus, pNbr->fiveGsTac);
        return false;
    }
    return true;
}

int16_t FnVCCB_NRDC_checkTAI(callInfo_type *ptCi, uint16_t cellNum, hoRestrictInfo_type *ptHrl,
    candidateNbrInformation_type *pCand, enumProcedureTypeforSlice_type procType, nbrGnbCellInfo_type *pNbr)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptHrl);
    VALID_E_POINT_CHECK_ERROR(pCand);

    uint16_t nbrPlmnIdx = 0, allowedIdx = 0;

    allowedPlmnList_Type allowedBplmnList, allowedPlmnList;
    allowedPlmnList.num_plmn = 0;

    plmnId_type *ptNbrPlmn = NULL, *ptMrlPlmn = NULL;

    enumInternalRatRestriction_type ratRestriction = MyRATRestriction;
    if (IS_NRDC_MN(ptCi)) ratRestriction = OtherNeRATRestriction;

    allwedPlmnList_type *pAllowedPlmn = FnVCCB_GetAllowedPlmnListByMRL(ptCi, ptHrl, ratRestriction);
    if (pAllowedPlmn == NULL)
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "Not Allowed MRL Based PLMN Selection : Empty Allowed PLMN List By MRL (%s)\n", __FUNCTION__);
        return ERROR;
    }

    // 1. get BPLMN list which is supported at neighbour cell list
    if(pNbr->configuredTacIndication == CI_no_use)
    {
        if (FnVCCB_GetNbrSaAvailablePlmnList(*ptCi, cellNum, pCand->nbrIdx, pCand->nbrTaiInfo.plmnList) != GOOD)
        {
            VCCB_PRINT_CALL_TGT_SEL(
                ptCi, "FnVCCB_GetNbrSaAvailablePlmnList (numPlmn:%u) ERROR (%s)\n", pCand->nbrTaiInfo.plmnList.num_plmn, __FUNCTION__);
            return ERROR;
        }
    }
    allowedBplmnList = pCand->nbrTaiInfo.plmnList;    

    // for DEBUG
    if (allowedBplmnList.num_plmn == 0)
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "Not Allowed MRL Based PLMN Selection : Extract From BPLMN (%u)\n", allowedBplmnList.num_plmn);
        return BREAK;
    }

    // 2. Acquires the intersection of the neighbor broadcast PLMN and MRL PLMN. (MRL)
    for (nbrPlmnIdx = 0; nbrPlmnIdx < allowedBplmnList.num_plmn; nbrPlmnIdx++)
    {
        ptNbrPlmn = &allowedBplmnList.plmn[nbrPlmnIdx];

        if (ptHrl->existFlag == FALSE)
        {
            if (!VCOM_CheckPlmnIdentical(ptNbrPlmn, &ptCi->ueInfo.servedPlmn))
            {
                continue;
            }
            else
            {
                allowedPlmnList.plmn[allowedPlmnList.num_plmn++] = *ptNbrPlmn;
                break;
            }
        }
        else
        {
            // MRL PLMN
            for (allowedIdx = 0; allowedIdx < pAllowedPlmn->numNrAllowedPlmn; allowedIdx++)
            {
                ptMrlPlmn = &pAllowedPlmn->nrAllowedPlmn[allowedIdx];

                if (VCOM_CheckPlmnIdentical(ptNbrPlmn, ptMrlPlmn) == FALSE) continue;

                if (FALSE == FnVCCB_CheckAllowedTAIwithMRL(ptHrl, pCand->nbrTaiInfo.tac, ptNbrPlmn->longId)) continue;

                allowedPlmnList.plmn[allowedPlmnList.num_plmn++] = *ptNbrPlmn;
            }
        }
    }

    // for DEBUG
    if (allowedPlmnList.num_plmn == 0)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "Not Allowed MRL Based PLMN Selection : Excluding Not Allowed TAC (%u/%u)\n", allowedPlmnList.num_plmn,
            pAllowedPlmn->numNrAllowedPlmn);
        return BREAK;
    }

    // Slice
    if (1)  // TBD: need to check ue type and debug flag
    {
        // if (allowedPlmnList.num_plmn > 0)
        {
            uint32_t before_num_plmn = allowedPlmnList.num_plmn;

            // TODO: true -> false for 21D : TODO: Intra ? Inter?
            if (ERROR == VCCM_CheckSliceAwareForServing(ptCi, cellNum, pCand, &allowedPlmnList, false, procType))
            {
                VCCB_PRINT_CALL_TGT_SEL(ptCi,
                    "Not Allowed MRL Based PLMN Selection : Slice Aware For Serving (%u/%u)\n", before_num_plmn,
                    allowedPlmnList.num_plmn);
                return BREAK;
            }

            if (allowedPlmnList.num_plmn == 0)
            {
                VCCB_PRINT_CALL_TGT_SEL(ptCi,
                    "Not Allowed MRL Based PLMN Selection : Excluding Slice Aware (%u/%u)\n", before_num_plmn,
                    allowedPlmnList.num_plmn);
                return BREAK;
            }
        }
    }

    // 3. When the number of intersections is at least one, the following operation is performed.
    if (allowedPlmnList.num_plmn > 0)
    {
        // Mobility operation is performed with the finally selected PLMN list.
        memcpy(&pCand->nbrTaiInfo.plmnList, &allowedPlmnList, sizeof(allowedPlmnList_Type));
        return GOOD;
    }

    VCCB_PRINT_CALL_TGT_SEL(
        ptCi, "Not Allowed MRL Based PLMN Selection : cnt:%u\n", pCand->nbrTaiInfo.plmnList.num_plmn);

    return BREAK;
}

/********************************************************************************************
 * @brief           Check Slice Aware
 *
 * @param[in]       ptCi     :        call information / callInfo_type
 * @param[in]       pNbrInfo :        Pointer of candidate Nbr Information / candidateNbrInformation_type
 * @return          status   :        GOOD - is not restricted, ERROR - is restricted / int16_t
 ********************************************************************************************/
int16_t VCCM_CheckSliceAwareForServing(callInfo_type *ptCi, uint16_t cellNum, candidateNbrInformation_type *pNbrInfo,
    allowedPlmnList_Type *ptAllowedPlmnList, bool isPartialAllowed, enumProcedureTypeforSlice_type procType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pNbrInfo);
    VALID_E_POINT_CHECK_ERROR(ptAllowedPlmnList);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint16_t nbrPlmnIdx = 0;
    plmnId_type *nbrPlmn;

    unsigned int num_plmn = 0;
    allowedPlmnList_Type allowedPlmnList;
    allowedPlmnList.num_plmn = 0;

    uint8_t pduIdx = 0;
    callPDUSessInfo_type *ptPi = NULL;

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    const bool isIntraGnbNbr = (pGnb->globalGnbId == pNbrInfo->globalGnbId);
    
    auto IsSpecificSliceCondition = [ptCi](callPDUSessInfo_type *_ptPi) -> bool
    {
        uint8_t reportType, reportPurpose;
        GET_HO_REPORT_TYPE_AND_PURPOSE(ptCi, reportType, reportPurpose);
        if (not FnVCCB_IsServiceBorderTargetReportTypePurpose(reportType, reportPurpose)) return false;
        if (not FnVCCB_IsSpecificSlice(*ptCi, _ptPi->sNssai.sstSd)) return false;

        return true;
    };

    for (nbrPlmnIdx = 0; nbrPlmnIdx < ptAllowedPlmnList->num_plmn && nbrPlmnIdx < MAX_NUM_PLMN; nbrPlmnIdx++)
    {
        uint8_t pduCnt = 0;
        uint8_t notSupportedPduCnt = 0;

        nbrPlmn = &ptAllowedPlmnList->plmn[nbrPlmnIdx];

        for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
        {
            ptPi = &ptCi->pduSess[pduIdx];

            if (ptPi->usage != CI_use) continue;

            // FR146.CACP.SR1.HD1
            // MN VCCB shall not choose candidate/target PSCell if the cell does not satisfy following criteria:
            // Corresponding TAC supports all S-NSSAI of the requested PDU Sessions (both MN-terminated SCG leg and
            // SN-terminated bearers)
            if (procType & PROC_MN_SELECT_PSCELL) // for initial sn addition or checking whether keeping sn or not
            {
                if (!FnVCCB_IsAnyDCReqBearerPerPduSession(ptCi, pduIdx))
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "[NRDC] nbrIdx:%d) PDU Session(Idx:%d) has only mn-term-mcg bearers!\n",
                        nbrPlmnIdx, pduIdx);
                    continue;
                }
            }

            pduCnt++;

            // for non-neighbor handover or INTER_NB. (TODO: sr0325.kim, non-neighbor flag can be make.)
            if (pNbrInfo->nbrIdx >= MAX_NBR_PER_CELL || !isIntraGnbNbr)
            {
                if (GOOD != VLIB_CheckifSupportedSNSSAIListForInterGnb(ptCi, ptPi->sNssai, pNbrInfo, nbrPlmn->longId))
                {
                    notSupportedPduCnt++;
                    if (IsSpecificSliceCondition(ptPi)) //25B PMB FGR-MC1021:FR110
                    {
                        VCCB_PRINT_CALL_CRITICAL(ptCi, "specific slice not supported(nbrPlmnIdx:%d/PDU Idx:%d/sstSd:%d)\n",
                            nbrPlmnIdx, pduIdx, ptPi->sNssai.sstSd);

                        pNbrInfo->isSpecificSliceFailed = TRUE;
                        return ERROR;
                    }
                    continue;
                }
            }
            else  // isIntraGnbNbr (INTRA_NB)
            {
                uint16_t nbrCellNum = MAX_CELL_NUM_VCCB;
                // get CellNum by CellId
                VCCB_CHECK_E_RANGE_AND_RETURN(pNbrInfo->nbrIdx, MAX_NBR_PER_CELL);
                VCCB_GET_INTRA_GNB_NBR_CELLNUM(cellNum, pNbrInfo->nbrIdx, nbrCellNum);
                VCCB_CHECK_E_RANGE_AND_RETURN(nbrCellNum, MAX_CELL_NUM_VCCB);

                if (GOOD != VLIB_CheckifSupportedSNSSAIList(ptCi, ptPi->sNssai, nbrPlmn->longId, nbrCellNum))
                {
                    notSupportedPduCnt++;
                    if (IsSpecificSliceCondition(ptPi)) //25B PMB FGR-MC1021:FR110
                    {
                        VCCB_PRINT_CALL_CRITICAL(ptCi, "specific slice not supported(nbrPlmnIdx:%d/PDU Idx:%d/sstSd:%d)\n",
                            nbrPlmnIdx, pduIdx, ptPi->sNssai.sstSd);

                        pNbrInfo->isSpecificSliceFailed = TRUE;
                        return ERROR;
                    }
                    continue;
                }
            }
        }

        if (pduCnt == notSupportedPduCnt)
        {
            // FGR-MC1021 - Slice Aware Mobility Control - FR30.CACP.SR1.HD3.DD1
            // VCCB should exclude candidate cells for intra-NR handover that do not support all UE slices in use.
            continue;
        }
        else if (notSupportedPduCnt > 0)
        {
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

            if (true == isPartialAllowed)
            {
                // SVR21B FGR-MC1021 - Slice Aware Mobility Control - FR30.CACP.SR1.HD2.DD1
                // VCCB should maintain candidate cells for intra-NR handover that at least one UE slices in use at
                // target cell when slice-aware mobility option2. no action
            }
            else
            {
                // SVR21B FGR-MC1021 - Slice Aware Mobility Control - R30.CACP.SR1.HD1.DD1
                // VCCB should exclude candidate cells for intra-NR handover that do not support any UE slices in use at
                // target cell when slice-aware mobility option1.
                continue;
            }
        }
        allowedPlmnList.plmn[num_plmn++] = *nbrPlmn;
    }

    if (0 == num_plmn)
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "No Available Plmn : cell(%d) nbrType(%d) nbrIdx(%d) plmnNum(%u->%u)\n", cellNum,
            VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, pNbrInfo->nbrIdx), pNbrInfo->nbrIdx, ptAllowedPlmnList->num_plmn,
            num_plmn);

        // there is no available plmn
        return ERROR;
    }

    allowedPlmnList.num_plmn = num_plmn;

    *ptAllowedPlmnList = allowedPlmnList;

    return GOOD;
}

int16_t VCCM_CheckSliceAwareForSn(callInfo_type *ptCi, allowedPlmnList_Type *ptAllowedPlmnList, uint32_t targetCellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptAllowedPlmnList);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint16_t plmnIdx = 0;
    plmnId_type *ptAllowedPlmn;

    unsigned int num_plmn = 0;
    allowedPlmnList_Type allowedPlmnList;
    allowedPlmnList.num_plmn = 0;

    uint8_t pduIdx = 0;
    callPDUSessInfo_type *ptPi = NULL;

    for (plmnIdx = 0; plmnIdx < ptAllowedPlmnList->num_plmn && plmnIdx < MAX_NUM_PLMN; plmnIdx++)  // 12
    {
        uint8_t notSupportedPduCnt = 0;

        ptAllowedPlmn = &ptAllowedPlmnList->plmn[plmnIdx];

        for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)  // 8
        {
            ptPi = &ptCi->pduSess[pduIdx];

            if (ptPi->usage != CI_use) continue;

            // partial by slice aware
            if (GOOD != VLIB_CheckifSupportedSNSSAIList(
                            ptCi, ptPi->sNssai, ptAllowedPlmn->longId, static_cast<uint16_t>(targetCellNum)))
            {
                notSupportedPduCnt++;
                break;
            }
        }

        if (0 == notSupportedPduCnt)
        {
            allowedPlmnList.plmn[num_plmn++] = *ptAllowedPlmn;
        }
    }

    if (0 == num_plmn)
    {
        // there is no available plmn
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "PDU session's S-NSSAI is not supported. No Available Plmn : cell(%d) plmnNum(%u, %u)\n", targetCellNum,
            ptAllowedPlmnList->num_plmn, num_plmn);

        return ERROR;
    }

    allowedPlmnList.num_plmn = num_plmn;

    *ptAllowedPlmnList = allowedPlmnList;

    return GOOD;
}

void VCOM_ChangeStatus_DRBStatus_To_FailToSetup_ForHandover(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    uint8_t loop;
    uint8_t pduIdx;
    uint16_t drbIdxInCall = MAX_DRB_PER_SA_CALL;
    uint16_t qosFlowIdxInPdu;

    callPDUSessInfo_type *ptPi = NULL;
    // callDRBInfo_type *ptDi = NULL;
    qosFlowInfo_type *ptQi = NULL;

    numRelQosInfoInDRB_type relDrbInfo[MAX_DRB_PER_SA_CALL];
    memset(&relDrbInfo[0], 0, sizeof(relDrbInfo));

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];

        if (ptPi->usage != CI_use) continue;

        for (qosFlowIdxInPdu = 0; qosFlowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosFlowIdxInPdu++)
        {
            if (ptPi->qosFlowIndex[qosFlowIdxInPdu] >= MAX_QOS_FLOW_PER_CALL) continue;

            ptQi = &ptCi->qosFlow[ptPi->qosFlowIndex[qosFlowIdxInPdu]];

            if (ptQi->usage != CI_use) continue;

            if (ptQi->qosFlowStatus == S_FailToSetup)
            {
                drbIdxInCall = ptQi->drbIdxInCall;
                if (drbIdxInCall >= MAX_DRB_PER_SA_CALL)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi, "Invalid drbIdxInCall(%d) in ptQi(qosFlowStatus:%d)!\n", drbIdxInCall,
                        ptQi->qosFlowStatus);
                    return;
                }
                relDrbInfo[drbIdxInCall].numRelQos++;
            }
        }

        // Set DRB Status
        for (loop = 0; loop < MAX_DRB_PER_SA_CALL; loop++)
        {
            if (ptCi->drb[loop].usage != CI_use) continue;

            if (relDrbInfo[loop].numRelQos == 0) continue;  // There is no QosFlow to release

            if (ptCi->drb[loop].numQoSFlowPerDRB <=
                relDrbInfo[loop].numRelQos)  // Release all QoS means, drb have to be release.
            {
                // DRB Status Change To FailToSetup
                SET_DRB_STATUS(ptCi, loop, S_FailToSetup);

                // DRB ID Release
                ONBIT_U32(ptCi->drbIdsToRelease, ptCi->drb[loop].dRBId - 1);
            }
        }
    }

    return;
}

/********************************************************************************************
 * @brief           Change Status To FailToSetup for Slice Aware
 *
 * @param[in]       ptCi     :        call information / callInfo_type
 * @param[in]       pduIdx   :        pdu index
 * @return          status   :        void
 ********************************************************************************************/
void VCOM_ChangeStatus_PduSessionAndQosFlow_FailToSetup_ForSliceAware(callInfo_type *ptCi, uint8_t pduIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(pduIdx, MAX_PDU_SESS_PER_CALL);

    uint16_t drbIdxInCall = MAX_DRB_PER_SA_CALL;
    uint16_t qosIdx = 0;
    callPDUSessInfo_type *ptPi = &ptCi->pduSess[pduIdx];
    qosFlowInfo_type *ptQi = NULL;
    callDRBInfo_type *ptDi = NULL;

    // PDU Status Change
    SET_PDU_STATUS(ptCi, pduIdx, S_FailToSetup);

    // Qos Flow Search
    for (qosIdx = 0; qosIdx < MAX_QOS_FLOW_PER_PDU_SESS; qosIdx++)
    {
        if (ptPi->qosFlowIndex[qosIdx] >= MAX_QOS_FLOW_PER_CALL) continue;

        uint8_t callQosflowIdx = static_cast<uint8_t>(ptPi->qosFlowIndex[qosIdx]);

        if (callQosflowIdx >= MAX_QOS_FLOW_PER_CALL) continue;

        // Qos Flow Status Change
        SET_QOSFLOW_STATUS(ptCi, callQosflowIdx, S_FailToSetup);

        ptQi = &ptCi->qosFlow[callQosflowIdx];
        if (ptQi->usage != CI_use) continue;

        drbIdxInCall = ptQi->drbIdxInCall;
        if (drbIdxInCall >= MAX_DRB_PER_SA_CALL)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Invalid drbIdxInCall(%d) in ptQi(qosFlowStatus:%d)!\n", drbIdxInCall, ptQi->qosFlowStatus);
            return;
        }

        ptDi = &ptCi->drb[drbIdxInCall];

        if (ptDi->usage != CI_use) continue;

        // DRB Status Change To FailToSetup
        SET_DRB_STATUS(ptCi, drbIdxInCall, S_FailToSetup);

        // DRB ID Release
        ONBIT_U32(ptCi->drbIdsToRelease, ptDi->dRBId - 1);
    }
}

/********************************************************************************************
 *  * @brief           Change Status To FailToSetup for UP Integrity Protection
 *   *
 *    * @param[in]       ptCi     :        call information / callInfo_type
 *     * @param[in]       pduIdx   :        pdu index
 *      * @return          status   :        void
 *       ********************************************************************************************/
void VCOM_ChangeStatus_PduSessionAndQosFlow_FailToSetup_ForUPIntegrityProtection(callInfo_type *ptCi, uint8_t pduIdx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(pduIdx, MAX_PDU_SESS_PER_CALL);
    uint16_t drbIdxInCall = MAX_DRB_PER_SA_CALL;
    uint16_t qosIdx = 0;
    callPDUSessInfo_type *ptPi = &ptCi->pduSess[pduIdx];
    qosFlowInfo_type *ptQi = NULL;
    callDRBInfo_type *ptDi = NULL;
    // PDU Status Change
    SET_PDU_STATUS(ptCi, pduIdx, S_FailToSetup);
    // Qos Flow Search
    for (qosIdx = 0; qosIdx < MAX_QOS_FLOW_PER_PDU_SESS; qosIdx++)
    {
        if (ptPi->qosFlowIndex[qosIdx] >= MAX_QOS_FLOW_PER_CALL) continue;
        uint8_t callQosflowIdx = static_cast<uint8_t>(ptPi->qosFlowIndex[qosIdx]);
        if (callQosflowIdx >= MAX_QOS_FLOW_PER_CALL) continue;
        // 1. Find QosFlow
        ptQi = &ptCi->qosFlow[callQosflowIdx];
        if (ptQi->usage != CI_use) continue;

        // 2. Qos Flow Status Change
        SET_QOSFLOW_STATUS(ptCi, callQosflowIdx, S_FailToSetup);
        ptQi->failCause = CauseNgapRadioNetworkLayerUpIntegrityProtectionNotPossible;

        // 3. Find DRB
        drbIdxInCall = ptQi->drbIdxInCall;
        if (drbIdxInCall >= MAX_DRB_PER_SA_CALL)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "Invalid drbIdxInCall(%d) in ptQi(qosFlowStatus:%d)!\n", drbIdxInCall, ptQi->qosFlowStatus);
            return;
        }
        ptDi = &ptCi->drb[drbIdxInCall];
        if (ptDi->usage != CI_use) continue;

        // 4. DRB Status Change To FailToSetup
        SET_DRB_STATUS(ptCi, drbIdxInCall, S_FailToSetup);
        // DRB ID Release
        ONBIT_U32(ptCi->drbIdsToRelease, ptDi->dRBId - 1);
    }
}

/********************************************************************************************
 * @brief           Change Status To FailToSetup for Partial DRB
 *
 * @param[in]       ptCi     :        call information / callInfo_type
 * @param[in]       pduIdx   :        pdu index
 * @return          status   :        void
 ********************************************************************************************/
void VCOM_ChangeStatus_PduSessionAndQosFlow_FailToSetup_ForPartialDRB(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t pdu_idx = 0, pdu_qos_idx = 0, qos_idx = 0, num_qos_flow_with_mapped_drb = 0;
    callPDUSessInfo_type *ptPi = NULL;
    qosFlowInfo_type *ptQi = NULL;

    for (pdu_idx = 0; pdu_idx < MAX_PDU_SESS_PER_CALL; pdu_idx++)
    {
        ptPi = &ptCi->pduSess[pdu_idx];
        if (CI_use != ptPi->usage) continue;

        num_qos_flow_with_mapped_drb = 0;
        for (pdu_qos_idx = 0; pdu_qos_idx < MAX_QOS_FLOW_PER_PDU_SESS; pdu_qos_idx++)
        {
            // find the mapping qos information and update the list
            qos_idx = ptPi->qosFlowIndex[pdu_qos_idx];
            if (qos_idx >= MAX_QOS_FLOW_PER_CALL) continue;

            ptQi = &ptCi->qosFlow[qos_idx];
            if (ptQi->usage != CI_use) continue;

            // update the mapping rule
            if (ptQi->drbIdxInCall < MAX_DRB_PER_SA_CALL)
            {
                num_qos_flow_with_mapped_drb++;
            }
            else
            {
                SET_QOSFLOW_STATUS(ptCi, qos_idx, S_FailToSetup);
            }
        }

        if( num_qos_flow_with_mapped_drb == 0 )
        {
            SET_PDU_STATUS(ptCi, pdu_idx, S_FailToSetup);
        }
    }
}

/********************************************************************************************
 *  * @brief           Check  UP Integrity Protection
 *   *
 *    * @param[in]       ptCi     :        call information / callInfo_type
 *     * @return          status   :        GOOD - is not restricted, ERROR - is restricted / int16_t
 *      ********************************************************************************************/
int16_t VCCM_Check_UP_DRB_Integrity_Supported(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    uint8_t pduIdx = 0;
    uint8_t pduCnt = 0;
    uint8_t notSupportedPduCnt = 0;
    callPDUSessInfo_type *ptPi = NULL;
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];
        if (ptPi->usage != CI_use || ptPi->pduSessStatus != S_Setup)
        {
            continue;
        }
        pduCnt++;
        // Reject the PDU Sessions for which the Integrity Protection is set to Required
        // In case the Up DRB Protection is not supported in GNB
        if ((pGnb->security.isUpDrbIntegrityProtectionSupported == FALSE) &&
            ((static_cast<enumIntegProtectInd_type>(ptPi->securityInd.integProtectInd) == ci_integ_protect_required)))
        {
            VCCB_PRINT_CALL_ERROR(ptCi,
                "PDU Session(pduSessId:%d) Rejected due to Integrity Protection not Supported!\n", ptPi->pduSessId);

            // PDU Session & Qos Flow Status Change To FailToSetup
            VCOM_ChangeStatus_PduSessionAndQosFlow_FailToSetup_ForUPIntegrityProtection(ptCi, pduIdx);

            // Fill Fail Cause
            if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTER_GNB_XN_HANDOVER)
                ptPi->failCause = CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible;
            else
                ptPi->failCause = CauseNgapRadioNetworkLayerUpIntegrityProtectionNotPossible;
            notSupportedPduCnt++;
        }
    }
    if (pduCnt == 0)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "There is nothing to control in UPDrbIntegritySupported.\n");
        return GOOD;
    }
    if (pduCnt == notSupportedPduCnt)
    {
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerUpIntegrityProtectionNotPossible;
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerUpIntegrityProtectionNotPossible;
        return ERROR;
    }
    return GOOD;
}

/********************************************************************************************
 * @brief           Check Slice Aware
 *
 * @param[in]       ptCi     :        call information / callInfo_type
 * @return          status   :        GOOD - is not restricted, ERROR - is restricted / int16_t
 ********************************************************************************************/
int16_t VCCM_CheckSliceAwareForTarget(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t pduIdx = 0;
    uint8_t pduCnt = 0;
    uint16_t notSupportedPduCnt = 0;
    callPDUSessInfo_type *ptPi = NULL;
    
    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];

        if (ptPi->usage != CI_use || ptPi->pduSessStatus != S_Setup) continue;

        pduCnt++;

        // partial by slice aware
        if (GOOD !=
            VLIB_CheckifSupportedSNSSAIList(ptCi, ptPi->sNssai, ptCi->ueInfo.servedPlmn.longId, ptCi->hoInfo.targetCellNum))
        {
            if (FnVCCB_IsSpecificSlice(*ptCi, ptPi->sNssai.sstSd))
            {
                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerResourcesNotAvailableForTheSlice;
                ptCi->cause.ngCause = CauseNgapRadioNetworkLayerSliceNotSupported;
                return ERROR; // 25B PMB FGR-MC1021:FR140
            }

            // PDU Session & Qos Flow Status Change To FailToSetup
            VCOM_ChangeStatus_PduSessionAndQosFlow_FailToSetup_ForSliceAware(ptCi, pduIdx);

            // Fill Fail Cause
            if (ptCi->hoInfo.hoType.initiated == HO_TYPE_SA_INTER_GNB_XN_HANDOVER)
                ptPi->failCause = CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran;
            else
                ptPi->failCause = CauseNgapRadioNetworkLayerSliceNotSupported;

            notSupportedPduCnt++;
            continue;
        }
    }

    if (pduCnt == 0)
    {
        VCCB_PRINT_CALL_INFORMATIVE(
            ptCi, "There is nothing to control in SliceAware. Therefore, VCCB skip the SliceAware feature.\n");
        return GOOD;
    }

    if (pduCnt == notSupportedPduCnt)
    {
        ptCi->cause.xnCause = CauseXnapRadioNetworkLayerSlicesNotSupportedByNgran;
        ptCi->cause.ngCause = CauseNgapRadioNetworkLayerSliceNotSupported;
        return ERROR;
    }

    return GOOD;
}

/********************************************************************************************
 * @brief           Check Cell Against Handover Restriction List for SA intraNrHandover
 *
 * @param[in]       ptHrl    :        Handover Restriction List / hoRestrictInfo_type
 * @param[in]       pNbrInfo :        Pointer of candidate Nbr Information / candidateNbrInformation_type
 * @return          status   :        GOOD - is not restricted, ERROR - is restricted / int16_t
 ********************************************************************************************/
int16_t VCCM_CheckSaNrHoAgainstHrl(callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, candidateNbrInformation_type *pNbrInfo)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptHrl);
    VALID_E_POINT_CHECK_ERROR(pNbrInfo);

    uint16_t nbrPlmnIdx = 0;
    plmnId_type *nbrPlmn;

    allowedPlmnList_Type allowedPlmnList;
    allowedPlmnList.num_plmn = 0;

    if (NULL == ptHrl)
    {
        return GOOD;
    }
    if (FALSE == ptHrl->existFlag)
    {
        return GOOD;
    }

    for (nbrPlmnIdx = 0; nbrPlmnIdx < pNbrInfo->nbrTaiInfo.plmnList.num_plmn; nbrPlmnIdx++)
    {
        nbrPlmn = &pNbrInfo->nbrTaiInfo.plmnList.plmn[nbrPlmnIdx];

        if (GOOD != VCCM_CheckPlmnAndTacInMrlAllowedList(ptCi, ptHrl, pNbrInfo->nbrTaiInfo.tac, nbrPlmn->longId)) continue;

        allowedPlmnList.plmn[allowedPlmnList.num_plmn++] = *nbrPlmn;
    }

    if (0 == allowedPlmnList.num_plmn)
    {
        // there is no available plmn
        return ERROR;
    }

    pNbrInfo->nbrTaiInfo.plmnList = allowedPlmnList;

    return GOOD;
}

/***************************************************************************
 * @brief           Check Intra Gnb Nbr Service State
 *
 * @param[in]       cellNum           : cell Number / uint16_t
 * @param[in]       nbrIdx            : cell neighbor index / uint16_t
 * @return          status            : GOOD, ERROR / int16_t
 ***************************************************************************/
int16_t VCCM_CheckIntraGnbCellServiceState(callInfo_type *ptCi, uint16_t cellNum, uint16_t nbrIdx)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);

    uint16_t targetCellNum = MAX_CELL_NUM_VCCB;

    if (VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, nbrIdx))
    {
        VCCB_GET_INTRA_GNB_NBR_CELLNUM(cellNum, nbrIdx, targetCellNum);
        VCCB_CHECK_E_RANGE_AND_RETURN(targetCellNum, MAX_CELL_NUM_VCCB);

        if (ERROR == VCCM_CheckCellInService(ptCi, targetCellNum, TRUE, FALSE))
        {
            return ERROR;
        }
    }
    // inter gnb Nbr return GOOD
    return GOOD;
}

void VLIB_DrbStatusToReleasePerPDU(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPi);

    int drbIdx = 0, idx = 0, maxIdx = static_cast<int>(UMIN(MAX_DRB_PER_PDU_SESS, ptPi->numDRBPerPDUSess));

    for (idx = 0; idx < maxIdx; idx++)
    {
        drbIdx = ptPi->drbIndex[idx];
        if (drbIdx >= MAX_DRB_PER_SA_CALL) continue;
        if (CI_use != ptCi->drb[drbIdx].usage) continue;
        SET_DRB_STATUS(ptCi, drbIdx, S_Release);
    }
}

int16_t FnVCCB_CheckSliceAwareForRREAndRRCResume(
    callInfo_type *ptCi, uint8_t statusChange)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t pduIdx = 0;
    uint8_t pduCnt = 0;
    uint8_t notSupportedPduCnt = 0;
    callPDUSessInfo_type *ptPi = NULL;

    // Only RRE and intra-gNB/inter-gNB RRC resume cases are allowed
    if (ptCi->stateCmd != RrcReestablish_cmd &&
        (ptCi->ueInfo.rrcResumeInfo.isRRCResumeRequestReceived == TRUE &&
           (ptCi->ueInfo.rrcResumeInfo.resumeType != RESUME_TYPE_INTRA_GNB &&
            ptCi->ueInfo.rrcResumeInfo.resumeType != RESUME_TYPE_INTER_GNB_TARGET)))
        return GOOD;
        
    // SVR25B FGR-CC0103 FR700, FR701
    if (ptCi->ueInfo.rrcResumeInfo.isRRCResumeRequestReceived == TRUE &&
        ptCi->ueInfo.RrcInactiveInfo.resumeCause == NRRRC_rna_Update)
        return GOOD;

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];

        if (ptPi->usage != CI_use) continue;

        pduCnt++;

        if (GOOD == VLIB_CheckifSupportedSNSSAIList(ptCi, ptPi->sNssai, ptCi->ueInfo.servedPlmn.longId, ptCi->servCellNum))
            continue;

        notSupportedPduCnt++;
        
        // In case of inter-gNB RRC resume, it skips the procedure for the bearer rearrangement
        // and perform the fallback procedure
        if (ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTER_GNB_TARGET)
            return ERROR;

        if (statusChange)
        {
            VCCB_SetBearerReleaseInfo(
                &ptPi->releaseInfo, e_ReleaseTriggerBySliceNotSupport, CauseNgapRadioNetworkLayerSliceNotSupported);
            SET_PDU_STATUS(ptCi, pduIdx, S_FailToSetup);
            VLIB_DrbStatusToReleasePerPDU(ptCi, ptPi);
        }

        if ((RrcReestablish_cmd == ptCi->stateCmd && RRE_TYPE_INTER_GNB == ptCi->ueInfo.reestablishInfo.reestablishType) ||
            (ptCi->ueInfo.rrcResumeInfo.isRRCResumeRequestReceived == TRUE))
        {
            if (FnVCCB_IsSpecificSlice(*ptCi, ptPi->sNssai.sstSd) == true)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "[RRE/RRCInactive] Failed with the specific slice (SSTSD:%u sst:%u sd:%u) sessId:%d, so trigger "
                    "RRC Setup!\n",
                    ptPi->sNssai.sstSd, ptPi->sNssai.sst, ptPi->sNssai.sd, ptPi->pduSessId);

                if (ptCi->ueInfo.rrcResumeInfo.isRRCResumeRequestReceived != TRUE)
                    return ERROR;
            }
        }
    }

    // SVR26A FGR-CC0103 FR720: If all slices are failed, it begins RRC fallback procedure
    if (ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTRA_GNB)
    {
        return (pduCnt <= notSupportedPduCnt) ? ERROR : GOOD;
    }
    else if (ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTER_GNB_TARGET)
    {
        return GOOD;
    }

    // RRE...???
    if (pduCnt <= notSupportedPduCnt)
    {
        return ERROR;  // RRC Setup (FR63)
    }
    return GOOD;
}

int16_t FnVCCB_CheckValidSegmentedUeForInterGnbRREandResume(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_VALID_GNBNUM_ERROR(ptCi->gnbNum);

    if (TRUE == FnVCCB_Check_isSegmentedUciCall(ptCi))  // Segmented UE
    {
        const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
        VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.xnIdx, MAX_XN_NBR_PER_GNB);
        vccbGlobalGnbId_type targetGnbId;
        targetGnbId.plmn = pGnb->xnNbr[ptCi->endPointInfo.xnIdx].plmn;
        targetGnbId.gnbId = pGnb->xnNbr[ptCi->endPointInfo.xnIdx].gnbId;

        // check target gNB is supporting UL segmentation function
        // check end-point-xn/ul-rrc-segmentation-support-xn-neighbor-entries values
        if (TRUE == FnVCCB_CheckTgtNodeSupportUlSegmentCapability(
                        ptCi->gnbNum, targetGnbId.gnbId.id, targetGnbId.plmn, NODE_XN))
        {  // send all received UE Capability container to the tgt
            VCCB_PRINT_CALL_DATA(
                ptCi, "SegmentedUciCall and target-gNB(%u) support ULSegmentation\n", targetGnbId.gnbId.id);
            return GOOD;
        }
        else  // Tgt Not Support Segmentation - NR only
        {
            if (TRUE == FnVCCB_isBigCapabilityRatContainer(ptCi, NRRRC_RAT_Type_nr))
            {
                VCCB_PRINT_CALL_DATA(
                    ptCi, "SegmentedUciCall and target-gNB(%u) Not support ULSegmentation\n", targetGnbId.gnbId.id);
                return ERROR;
            }
            else
            {  // send tgt RAT(UE NR Capability) container only to the Tgt
                VCCB_PRINT_CALL_DATA(ptCi,
                    "SegmentedUciCall and target-gNB(%u) Not support ULSegmentation, NR capaLength:%d(Ext:%d)OK\n",
                    targetGnbId.gnbId.id, ptCi->ueContainerNR.numocts, ptCi->ueContainerNR_Ext.capaLength);
                return BREAK;
            }
        }
    }

    return GOOD;  // General Case - Not Segmented UE
}

// When Intra gNB RRE and RRCResume, in finalize function, check SupportedSNSSAI in order to forced mobility.
// void VHCM_FinalizeReestablish_CheckSliceAwareForRRE(callInfo_type *ptCi, uint8_t *ptSendPduNotiFlag, uint8_t *ptForcedMobilityFlag)
void FnVCCB_CheckSliceAwareRREAndRRCResume_AfterFinalize(callInfo_type *ptCi, uint8_t *ptSendPduNotiFlag, uint8_t *ptForcedMobilityFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptSendPduNotiFlag);

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return;
    }

    // check the pdu session is needed to release
    uint32_t pduIdx;
    callPDUSessInfo_type *ptPi;

    *ptSendPduNotiFlag = FALSE;

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &(ptCi->pduSess[pduIdx]);

        if (ptPi->usage != CI_use) continue;

        // SAME Condition with HandoverPreparationInformation
        if ((ptCi->pduSess[pduIdx].pduSessStatus == S_FailToModify) ||
            (ptCi->pduSess[pduIdx].pduSessStatus == S_FailToRelease))
            continue;

        // The purpose of this procedure is to release the Partial from Intra-gNB RRE/RRCResume by SliceAware.
        if (GOOD != VLIB_CheckifSupportedSNSSAIList(ptCi, ptPi->sNssai, ptCi->ueInfo.servedPlmn.longId, ptCi->servCellNum))
        {
            VCCB_SetBearerReleaseInfo(
                &ptPi->releaseInfo, e_ReleaseTriggerBySliceNotSupport, CauseNgapRadioNetworkLayerSliceNotSupported);
            *ptSendPduNotiFlag = TRUE;  // PDU Session Resource Notify

            if (FnVCCB_IsSpecificSlice(*ptCi, ptPi->sNssai.sstSd) == true)
            {
                *ptForcedMobilityFlag = TRUE;
                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "[RRE/RRCInactive] Failed with the specific slice (SSTSD:%u sst:%u sd:%u) sessId:%d, so set forcedMobilityFlag as TRUE!\n",
                    ptPi->sNssai.sstSd, ptPi->sNssai.sst, ptPi->sNssai.sd, ptPi->pduSessId);
            }
        }
    }
}

bool FnVCCB_IsInterGnbNbrDeactivated(const nbrGnbCellInfo_type &nbrGnbCell)
{
    return (nbrGnbCell.deactivationIndication == VCCB_NBR_GNB_CELL_DEACTIVATE);
}

bool FnVCCB_IsInterVendorHandoverNotAllowed(callInfo_type &rCall, const nbrGnbCellInfo_type &rNbrGnbCell)
{
    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, false);
    VccbGnbInfo_type const &rGnb = GNBINFO[rCall.gnbNum];

    if (rGnb.cfg.gnbMobilityConfig.interVendorIntraNrHandoverAllowed) return false;

    uint16_t xnIdx =
        fnVLIB_FindXnEndPointIndexByGnbId(rCall.gnbNum, const_cast<vccbGlobalGnbId_type *>(&rNbrGnbCell.globalGnbId));
    if (xnIdx >= MAX_XN_NBR_PER_GNB || rGnb.xnGnbInfo[xnIdx].status != EQUIP) return false;

    return (rGnb.xnGnbInfo[xnIdx].samsungVendorInd == VENDOR_IND_OTHER);
}

bool FnVCCB_IsIntraGnbCellHasInvalidSib1SizeForTddType(uint16_t targetCellNum, uint16_t duplexType)
{
    VCCB_CHECK_E_RANGE_AND_VAL(targetCellNum, MAX_CELL_NUM_VCCB, false);
    if (duplexType != ci_DUPLEXTYPE_TDD) return false;

    VccbCellInfo_type *pCell = &CELLINFO[targetCellNum];
    return (pCell->sib1.sib1Size == 0);
}

bool FnVCCB_CheckVoiceOverNRForIntraGnbTargetCellSelection(callInfo_type &rCall, uint16_t cellNum, uint16_t nbrIdx)
{
    AUTO_TRACE_FUNC;
    auto isEmergencyCall = [rCall]() -> uint8_t
    {
        return FnVCCB_IsEmergencyCallWithRequestedVal(const_cast<callInfo_type*>(&rCall), false);
    };

    if (FnVCCB_IsVoNRCall(const_cast<callInfo_type *>(&rCall)) != TRUE)
    {
        return true;
    }

    if (VCCB_UNSUPPORTED == VCCM_CheckVoiceOverNRCapa(rCall, cellNum, true))
    {
        VCCB_PRINT_CALL_TGT_SEL(
            &rCall, "nbrIdx(%d) targetCellNum %u is not supported vonr with nr capa\n", nbrIdx, cellNum);
        return false;
    }
    else if (TRUE != FnVCCB_SupportVoiceWithControlInfo(rCall, cellNum, true))
    {
        VCCB_PRINT_CALL_TGT_SEL(
            &rCall, "nbrIdx(%d) targetCellNum %u is not supported vonr with rfsp\n", nbrIdx, cellNum);
        return false;
    }
    else if (isEmergencyCall() && (TRUE != FnVCCB_SupportEmergencyVonrWithRfsp(rCall, cellNum, true)))
    {
        VCCB_PRINT_CALL_TGT_SEL(
            &rCall, "nbrIdx(%d) targetCellNum %u is not supported emergency vonr with rfsp\n", nbrIdx, cellNum);
        return false;
    }

    return true;
}

bool FnVCCB_CheckVoiceOverNRForInterGnbTargetCellSelection(callInfo_type &rCall, nbrGnbCellInfo_type &rNbrGnbCell, uint32_t ssbFreq, uint16_t nbrIdx)
{
    AUTO_TRACE_FUNC;

    if (FnVCCB_IsVoNRCall(const_cast<callInfo_type *>(&rCall)) != TRUE)
    {
        return true;
    }

    // Exclude any cell not to allow VoNR access
    if (TRUE != rNbrGnbCell.voNrSupport)
    {
        VCCB_PRINT_CALL_TGT_SEL(&rCall, "nbrIdx(%u): VoNR NOT Supported \n", nbrIdx);

        return false;
    }

    auto frequencyRange = (ssbFreq >= MIN_A6_NR_ARFCN) ? FrequencyRange_FR2 : FrequencyRange_FR1;
    if (FnVCCB_CheckVoiceOverNRCapaByFrequencyRange(rCall, frequencyRange, true) == VCCB_SUPPORTED)
    {
        return true;
    }
    else
    {
        VCCB_PRINT_CALL_TGT_SEL(&rCall, "nbrIdx(%u): VoNR Ue Capability NOT Supported for Frequency Range(%u) \n", nbrIdx, frequencyRange);
        return false;
    }
}

int16_t VCCM_CheckSaHandoverCondition_NR(callInfo_type *ptCi,
    uint16_t nbrIdx, measurementObjectNRUe_type *pMeasObj, nbrGnbCellInfo_type *ptNbrGnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(CELLINFO);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMeasObj);
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCell);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);

    const uint16_t servCellNum = ptCi->servCellNum;

    if (GOOD != VCCM_CompareNbrSmtc1Condition(&pMeasObj->minimal.smtc1, ptNbrGnbCell))  // NR_CONN_MC_23A modified
    {
        smtc1_type *ptSmtc = &pMeasObj->minimal.smtc1;

        VCCB_PRINT_CALL_TGT_SEL(ptCi, "nbrIdx(%d) doesn't match smtc1 offset (%u, Nbr:%u MeasObj:%u)\n",
            nbrIdx, ptNbrGnbCell->smtcStatus, ptNbrGnbCell->smtc1.periodicityAndOffset.offset, ptSmtc->periodicityAndOffset.offset);

        return ERROR;
    }

    if (FALSE == VHCM_isSaEnabledNbr(ptCi, ptNbrGnbCell))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "nbrIdx(%d) is not SaTacEnabled (sts:%u, cfgTac:%u, redcapBroadcastInfo:%u)\n",
            nbrIdx, ptNbrGnbCell->fiveGsTacStatus, ptNbrGnbCell->configuredTacIndication, ptNbrGnbCell->redcapBroadcastInfo);

        return ERROR;
    }

    VccbCellInfo_type *pCell = &CELLINFO[servCellNum];
    if (FnVCCB_IsServiceSpecificTargetCellExcluded(*ptCi, *pCell, nbrIdx, *ptNbrGnbCell)) 
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "nbrIdx(%d) service speciific execlude target cell \n", nbrIdx);
        return ERROR;
    }

    if (VCCB_IS_INTRA_GNB_NEIGHBOR(servCellNum, nbrIdx))
    {
        uint16_t targetCellNum = 0;
        VCCB_GET_INTRA_GNB_NBR_CELLNUM(servCellNum, nbrIdx, targetCellNum);
        VCCB_CHECK_E_RANGE_AND_RETURN(targetCellNum, MAX_CELL_NUM_VCCB);
        if (GOOD != VCCM_CheckIntraGnbCellServiceState(ptCi, servCellNum, nbrIdx))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "nbrIdx(%d) ServiceState is not in-service\n", nbrIdx);
            return ERROR;
        }

        if (VCCB_IsCellUlInterfered(CELLINFO[targetCellNum]))
        {
            VCCB_PRINT_CALL_TGT_SEL(
                ptCi, "nbrIdx(%d) targetCellNum %u is Ul Interfered Cell!\n", nbrIdx, targetCellNum);
            return ERROR;
        }

        if (!FnVCCB_CheckVoiceOverNRForIntraGnbTargetCellSelection(*ptCi, targetCellNum, nbrIdx))
        {
            VCCB_PRINT_CALL_TGT_SEL(
                ptCi, "nbrIdx(%d) targetCellNum %u is not supported voice with RFSP!\n", nbrIdx, targetCellNum);
            return ERROR;
        }

        if (IS_REDCAP_UE(ptCi) && FnVCCB_IsIntraGnbCellHasInvalidSib1SizeForTddType(targetCellNum,
                                      FnVCCB_GetNrDuplexTypeByBandIndicator(pMeasObj->minimal.freqBandIndicatorNR)))
        {
            return ERROR;
        }
    }
    else  // SVR23B FGR-MC1027 Connected mobility control for RedCap UE
    {
        // SVR25A FGR-MC1007 FR100
        if (FnVCCB_IsInterGnbNbrDeactivated(*ptNbrGnbCell))
        {
            VCCB_PRINT_CALL_TGT_SEL(
                ptCi, "cell(%d) nbrIdx(%d) is deactivated cell\n", ptCi->servCellNum, nbrIdx);
            return ERROR;
        }

        if (IS_REDCAP_UE(ptCi))
        {
            if (ptNbrGnbCell->redcapBroadcastInfo <= 0)
            {
                VCCB_PRINT_CALL_TGT_SEL(ptCi, "nbrIdx(%d) is not support redCap\n", nbrIdx);

                return ERROR;
            }
        }

        if (!FnVCCB_CheckVoiceOverNRForInterGnbTargetCellSelection(*ptCi, *ptNbrGnbCell, pMeasObj->minimal.ssbFrequency, nbrIdx))
        {
            return ERROR;
        }

        // Exclude any cell of overloaded target gNB
        if (TRUE == FnVCCB_IsOverloadedGnbNbr(ptCi, ptNbrGnbCell))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "nbrIdx(%u): Overloaded Tgt gNB(%X/%u) \n", nbrIdx,
                ptNbrGnbCell->globalGnbId.plmn.longId, ptNbrGnbCell->globalGnbId.gnbId.id);

            return ERROR;
        }

        if (FnVCCB_IsInterVendorHandoverNotAllowed(*ptCi, *ptNbrGnbCell))
        {
            VCCB_PRINT_CALL_TGT_SEL(
                ptCi, "cell(%d) nbrIdx(%d) is not allowed interVendor\n", ptCi->servCellNum, nbrIdx);
            return ERROR;
        }
    }

    if (TRUE == FnVCCB_IsNbrSDLCell(ptCi, ptNbrGnbCell))  // NR_CONN_MC_23A
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
                "gnbNbrCell(ssbArfcn:%u, gnbId:%u, cellId:%u, pci:%u arfcnDl/UL:%u/%u) SDL Cell!\n",
                ptNbrGnbCell->ssbArfcn, ptNbrGnbCell->globalGnbId.gnbId.id, ptNbrGnbCell->cellId,
                ptNbrGnbCell->nrPci, ptNbrGnbCell->nrArfcnDl, ptNbrGnbCell->nrArfcnUl);
        return ERROR;
    }

    uint16_t band = pMeasObj->minimal.freqBandIndicatorNR;
    if (GOOD != FnVCCB_CheckBandwidthCondition_NR_MN(ptCi, ptNbrGnbCell, nbrIdx, band))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "nbrIdx(%d) is not a ValidBandwidth (band:%u)\n", nbrIdx, band);
        return ERROR;
    }

    if (VCCM_IntraNrHandoverPrepFailedCell(*ptCi, *ptNbrGnbCell))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "nbrIdx(%d) is a failedCell\n", nbrIdx);

        return ERROR;
    }

    if (FOO.VF_SegmentationOfRrcMessages)
    {
        // NR_CONN_MC_22A check whether the target gNB supports UL segmentation if UE Capability Information is
        // segmented
        if (GOOD != VCCM_CheckValidSegmentedUeForIntraNrHO(ptCi, ptNbrGnbCell, nbrIdx))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "nbrIdx(%d) Not Support UL segmentation \n", nbrIdx);

            return ERROR;
        }
    }

    return GOOD;
}

int16_t VCCM_CheckSaHandoverCondition_EUTRA(callInfo_type *ptCi, uint16_t nbrIdx, nbrEnbCellInfo_type *ptNbrEnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(CELLINFO);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrEnbCell);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL);

    if (VCCM_InterRatHandoverPrepFailedCell(*ptCi, *ptNbrEnbCell))
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "call(%d) cell(%d) nbrIdx(%d) is a failedCell\n", ptCi->callId, ptCi->servCellNum, nbrIdx);

        return ERROR;
    }

    // NR_CONN_MC_21D check whether candidate EUTRA NBR cell is in-service
    if (GOOD != VCCM_CheckCellServiceState_EUTRA(ptCi, ptNbrEnbCell))
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "call(%d) NBR ENB cell(%d) is not in-service\n", ptCi->callId, ptNbrEnbCell->cellId);

        return ERROR;
    }

    if (FOO.VF_SegmentationOfRrcMessages)
    {
        // NR_CONN_MC_22A check whether target eNB supports a UL segmentation if UE Capability Information is segmented
        if (GOOD != VCCM_CheckValidSegmentedUeForIratHO(ptCi, ptNbrEnbCell))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi,
                "call(%d) cell(%d) target eNB(%d): not support UL segmentation \n", ptCi->callId, ptNbrEnbCell->cellId,
                ptNbrEnbCell->enbId);

            return ERROR;
        }
    }

    return GOOD;
}

int16_t VCCM_FillCandidateCellInfo_NR(
    callInfo_type *ptCi, uint16_t cellNum, uint16_t nbrIdx, candidateNbrInformation_type *candidateCell, bool checkSaAvailablePlmn)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);

    int status;
    uint16_t targetCellNum = 0, numPlmn = 0;
    uint16_t cellPlmnIdx = 0;
    nbrGnbCellInfo_type *ptNbrGnbCell;

    status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &ptNbrGnbCell);
    if (status != GOOD)
    {
        return BREAK;
    }

    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    /* fill 5GC TAC  */
    candidateCell->nbrIdx = nbrIdx;
    candidateCell->rank = pCell->Nbr[nbrIdx].rank;
    candidateCell->nbrTaiInfo.tac = ptNbrGnbCell->fiveGsTac;
    candidateCell->nbrTaiInfo.plmnList.num_plmn = 0;
    candidateCell->freq = ptNbrGnbCell->ssbArfcn;
    candidateCell->pci = ptNbrGnbCell->nrPci;
    candidateCell->globalGnbId = ptNbrGnbCell->globalGnbId;

    if (VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, nbrIdx))
    {  // intra gnb Nbr

        VCCB_GET_INTRA_GNB_NBR_CELLNUM(cellNum, nbrIdx, targetCellNum);
        VCCB_CHECK_E_RANGE_AND_RETURN(targetCellNum, MAX_CELL_NUM_VCCB);

        candidateCell->cellNum = targetCellNum;

        status = VLIB_getBPLMN(ptCi, targetCellNum, &candidateCell->nbrTaiInfo.plmnList);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VLIB_getBPLMN ERROR in VCCM_FillCandidateCellInfo_NR.\n");
    }
    else
    {  // inter gnb Nbr
        /* Without using the plmn information of neighbor-gnb-entries,
        Use the information of neighbor-gnb-cell-entries according to the design */
        for (cellPlmnIdx = 0; cellPlmnIdx < MAX_PLMN_INDEX; cellPlmnIdx++)
        {
            if (EQUIP != ptNbrGnbCell->cellPlmnInfo[cellPlmnIdx].shmStatus) continue;

            numPlmn = static_cast<uint16_t>(candidateCell->nbrTaiInfo.plmnList.num_plmn);
            candidateCell->nbrTaiInfo.plmnList.plmn[numPlmn].longId = ptNbrGnbCell->cellPlmnInfo[cellPlmnIdx].longId;
            candidateCell->nbrTaiInfo.plmnList.num_plmn++;
        }
    }

    // SVR25B FGR-MC1007 FR100
    if (checkSaAvailablePlmn == true &&
        FnVCCB_GetNbrSaAvailablePlmnList(*ptCi, cellNum, nbrIdx, candidateCell->nbrTaiInfo.plmnList) != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "FnVCCB_GetNbrSaAvailablePlmnList (numPlmn:%u) ERROR\n", candidateCell->nbrTaiInfo.plmnList.num_plmn);
        return ERROR;
    }

    return GOOD;
}

int16_t VCCM_FillCandidateCellInfo_EUTRA(uint16_t cellNum, uint16_t nbrIdx, candidateNbrInformation_type *candidateCell)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL);

    int status;
    uint16_t numPlmn = 0;
    uint16_t cellPlmnIdx = 0;
    nbrEnbCellInfo_type *ptNbrEnbCell;
    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    status = getNbrEnbCellByCellNbrIdx(cellNum, nbrIdx, &ptNbrEnbCell);
    if (status != GOOD)
    {
        return BREAK;
    }

    /* fill 5GC TAC  */
    candidateCell->nbrIdx = nbrIdx;
    candidateCell->nbrTaiInfo.tac = ptNbrEnbCell->tac;
    candidateCell->nbrTaiInfo.plmnList.num_plmn = 0;
    candidateCell->rank = pCell->eutraNbr[nbrIdx].rank;
    candidateCell->pci = ptNbrEnbCell->pci;
    candidateCell->freq = ptNbrEnbCell->earfcnDl;

    for (cellPlmnIdx = 0; cellPlmnIdx < MAX_NUM_PLMN_LTE; cellPlmnIdx++)
    {
        if (EQUIP != ptNbrEnbCell->cellPlmnInfo[cellPlmnIdx].shmStatus) continue;

        numPlmn = static_cast<uint16_t>(candidateCell->nbrTaiInfo.plmnList.num_plmn);
        candidateCell->nbrTaiInfo.plmnList.plmn[numPlmn].longId = ptNbrEnbCell->cellPlmnInfo[cellPlmnIdx].longId;
        candidateCell->nbrTaiInfo.plmnList.num_plmn++;
    }

    return GOOD;
}

/**
 * @brief Check if slice-aware check is required for the given GNB and neighbor information
 * @param[in] pGnb        Pointer to GNB configuration information (VccbGnbInfo_type)
 * @param[in] pNbrInfo    Pointer to neighbor cell information (candidateNbrInformation_type)
 * @return bool          true if slice-aware check is required, false otherwise
 */
bool FnVCCB_IsSliceAwareCheckRequired(const VccbGnbInfo_type *const pGnb, candidateNbrInformation_type *pNbrInfo) // SVR25B FGR-MC1021:FR60
{
    if (pGnb->cfg.gnbMobilityConfig.sliceAware.targetSliceAwareEnabled == enabled) return true;

    const bool isNonNeighbor = (pNbrInfo->nbrIdx >= MAX_NBR_PER_CELL);
    const bool isInterGnbNbr = !(pGnb->globalGnbId == pNbrInfo->globalGnbId);

    if (isNonNeighbor || isInterGnbNbr) return false;

    return true;        
}

int16_t VCCM_CheckAndUpdate_NbrPlmnValidation_NR(
    callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, candidateNbrInformation_type *pNbrInfo, enumHandoverTriggerType hoTrigger)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptHrl);
    VALID_E_POINT_CHECK_ERROR(pNbrInfo);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    bool isPartialAllowed = false;

    uint16_t nbrPlmnIdx = 0, allowedIdx = 0;

    uint8_t isBplmnFindMode = FALSE;

    uint16_t cellNum = ptCi->servCellNum;

    allowedPlmnList_Type allowedBplmnList, allowedPlmnList, allowedPlmnListWithTAC, *pSelctAllowPlmnList = NULL;
    allowedPlmnList.num_plmn = allowedPlmnListWithTAC.num_plmn = 0;

    plmnId_type *ptNbrPlmn = NULL, *ptMrlPlmn = NULL;

    allwedPlmnList_type *pAllowedPlmn = FnVCCB_GetAllowedPlmnListByMRL(ptCi, ptHrl, MyRATRestriction);
    if (pAllowedPlmn == NULL)
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "Empty Allowed PLMN List By MRL (%s)\n", __FUNCTION__);

        return ERROR;
    }

    if (pGnb->cfg.gnbMobilityConfig.sliceAware.mobilityMode == e_SliceAware_Partial_Mobility_Mode2)
    {
        isPartialAllowed = true;
    }

    // SVR25B FGR-MC1021:FR60
    bool isSliceAwareCheckRequired = (hoTrigger == e_HoTrigger_ImmediateHandover)? FnVCCB_IsSliceAwareCheckRequired(pGnb, pNbrInfo) : true;

    // 1. get BPLMN list which is supported at neighbour cell list
    allowedBplmnList = pNbrInfo->nbrTaiInfo.plmnList;

    // 2. Acquires the intersection of the neighbor broadcast PLMN and MRL PLMN. (MRL)
    if (TRUE == ptHrl->existFlag)
    {
        for (nbrPlmnIdx = 0; nbrPlmnIdx < allowedBplmnList.num_plmn; nbrPlmnIdx++)
        {
            ptNbrPlmn = &allowedBplmnList.plmn[nbrPlmnIdx];

            // MRL PLMN
            for (allowedIdx = 0; allowedIdx < pAllowedPlmn->numNrAllowedPlmn; allowedIdx++)
            {
                ptMrlPlmn = &pAllowedPlmn->nrAllowedPlmn[allowedIdx];

                if (VCOM_CheckPlmnIdentical(ptNbrPlmn, ptMrlPlmn) == FALSE) continue;

                allowedPlmnList.plmn[allowedPlmnList.num_plmn++] = *ptNbrPlmn;

                if (FALSE == FnVCCB_CheckAllowedTAIwithMRL(ptHrl, pNbrInfo->nbrTaiInfo.tac, ptNbrPlmn->longId))
                    continue;

                allowedPlmnListWithTAC.plmn[allowedPlmnListWithTAC.num_plmn++] = *ptNbrPlmn;
            }
        }
    }
    else  // If there is no MRL, there is no restriction, so the BPLMN is used as it is.
    {
        isBplmnFindMode = TRUE;
    }

    // 3. When the number of intersections is at least one, the following operation is performed.
    if (allowedPlmnList.num_plmn > 0)  // TODO
    {
        if (VCCM_CheckEmergencyCall(ptCi) == TRUE)
        {
            pSelctAllowPlmnList = &allowedPlmnList;  // (BPLMN) U (MRL-PLMN)
        }
        else
        {
            pSelctAllowPlmnList = &allowedPlmnListWithTAC;  // (BPLMN) U (MRL-PLMN) U (TAC)
        }

        if (pSelctAllowPlmnList->num_plmn > 0)
        {
            if (not isSliceAwareCheckRequired)
            {
                // Mobility operation is performed with the finally selected PLMN list.
                pNbrInfo->nbrTaiInfo.plmnList = *pSelctAllowPlmnList;
                return GOOD;
            }

            if (VCCM_CheckSliceAwareForServing(ptCi, cellNum, pNbrInfo, pSelctAllowPlmnList, isPartialAllowed, PROC_UNKNOWN) ==
                GOOD)  // Number of PLMNs available > 0 by SliceAware
            {
                // Mobility operation is performed with the finally selected PLMN list.
                pNbrInfo->nbrTaiInfo.plmnList = *pSelctAllowPlmnList;
                return GOOD;
            }
        }
    }

    // 4. In case of an emergency call, the search is attempted with BPLMN.
    if (VCCM_CheckEmergencyCall(ptCi) == TRUE)
    {
        isBplmnFindMode = TRUE;
    }
    // 5. Attempt to search by PLMN.
    if (isBplmnFindMode == TRUE)
    {
        // (BPLMN)
        pSelctAllowPlmnList = &allowedBplmnList;  // (BPLMN)

        if (pSelctAllowPlmnList->num_plmn > 0)
        {
            if (not isSliceAwareCheckRequired)
            {
                // Mobility operation is performed with the finally selected PLMN list.
                pNbrInfo->nbrTaiInfo.plmnList = *pSelctAllowPlmnList;
                return GOOD;
            }

            // Slice Check
            if (VCCM_CheckSliceAwareForServing(ptCi, cellNum, pNbrInfo, pSelctAllowPlmnList, isPartialAllowed, PROC_UNKNOWN) ==
                GOOD)  // Number of PLMNs available > 0 by SliceAware
            {
                // Mobility operation is performed with the finally selected PLMN list.
                pNbrInfo->nbrTaiInfo.plmnList = *pSelctAllowPlmnList;
                return GOOD;
            }
        }
    }

    VCCB_PRINT_CALL_TGT_SEL(ptCi,
        "Not Allowed Plmn : cell(%d) nbrIdx(%d) emer(%u) bplmnMode(%u) plmnNum(B:%u,M:%u,T:%u)\n", cellNum,
        pNbrInfo->nbrIdx, VCCM_CheckEmergencyCall(ptCi), isBplmnFindMode, allowedBplmnList.num_plmn,
        allowedPlmnList.num_plmn, allowedPlmnListWithTAC.num_plmn);

    return BREAK;
}

int16_t VCCM_CheckAndUpdate_NbrPlmnValidation_EUTRA(
    callInfo_type *ptCi, hoRestrictInfo_type *ptHrl, candidateNbrInformation_type *pNbrInfo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptHrl);
    VALID_E_POINT_CHECK_ERROR(pNbrInfo);

    uint16_t nbrPlmnIdx = 0, allowedIdx = 0;

    uint8_t isBplmnFindMode = FALSE;

    allowedPlmnList_Type allowedBplmnList, allowedPlmnList, *pSelctAllowPlmnList = NULL;
    allowedPlmnList.num_plmn = 0;

    plmnId_type *ptNbrPlmn = NULL, *ptMrlPlmn = NULL;

    allwedPlmnList_type *pAllowedPlmn = FnVCCB_GetAllowedPlmnListByMRL(ptCi, ptHrl, MyRATRestriction);
    if (pAllowedPlmn == NULL)
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "Empty Allowed PLMN List By MRL (%s)\n", __FUNCTION__);
        return ERROR;
    }

    // 1. get BPLMN list which is supported at neighbour cell list
    allowedBplmnList = pNbrInfo->nbrTaiInfo.plmnList;

    // 2. Acquires the intersection of the neighbor broadcast PLMN and MRL PLMN. (MRL)
    if (TRUE == ptHrl->existFlag)
    {
        for (nbrPlmnIdx = 0; nbrPlmnIdx < allowedBplmnList.num_plmn; nbrPlmnIdx++)
        {
            ptNbrPlmn = &allowedBplmnList.plmn[nbrPlmnIdx];

            // MRL PLMN
            for (allowedIdx = 0; allowedIdx < pAllowedPlmn->numEutraAllowedPlmn; allowedIdx++)
            {
                ptMrlPlmn = &pAllowedPlmn->eutraAllowedPlmn[allowedIdx];

                if (VCOM_CheckPlmnIdentical(ptNbrPlmn, ptMrlPlmn) == FALSE) continue;

                allowedPlmnList.plmn[allowedPlmnList.num_plmn++] = *ptNbrPlmn;
            }
        }
    }
    else  // If there is no MRL, there is no restriction, so the BPLMN is used as it is.
    {
        isBplmnFindMode = TRUE;
    }

    // 3. When the number of intersections is at least one, the following operation is performed.
    if (allowedPlmnList.num_plmn > 0)  // TODO
    {
        pSelctAllowPlmnList = &allowedPlmnList;  // (BPLMN) U (MRL-PLMN)

        if (pSelctAllowPlmnList->num_plmn > 0)
        {
            // Mobility operation is performed with the finally selected PLMN list.
            pNbrInfo->nbrTaiInfo.plmnList = *pSelctAllowPlmnList;
            return GOOD;
        }
    }

    // 4. In case of an emergency call, the search is attempted with BPLMN.
    if (VCCM_CheckEmergencyCall(ptCi) == TRUE)
    {
        isBplmnFindMode = TRUE;
    }

    // 5. Attempt to search by PLMN.
    if (isBplmnFindMode == TRUE)
    {
        // (BPLMN)
        pSelctAllowPlmnList = &allowedBplmnList;  // (BPLMN)

        if (pSelctAllowPlmnList->num_plmn > 0)
        {
            // Mobility operation is performed with the finally selected PLMN list.
            pNbrInfo->nbrTaiInfo.plmnList = *pSelctAllowPlmnList;
            return GOOD;
        }
    }

    VCCB_PRINT_CALL_TGT_SEL(ptCi,
        "Not Allowed Plmn : cell(%d) nbrIdx(%d) emer(%u) bplmnMode(%u) plmnNum(B:%u,M:%u)\n", ptCi->servCellNum,
        pNbrInfo->nbrIdx, VCCM_CheckEmergencyCall(ptCi), isBplmnFindMode, allowedBplmnList.num_plmn,
        allowedPlmnList.num_plmn);

    return BREAK;
}

/****************************************************************************
 * @brief           Check CHO Preparation Candidate Cell
 *
 * @param[in]       ptCi             : call information / callInfo_type
 * @param[in]       usedFreq         : frequency from measResult to compare
 * @param[in]       nbrIdx           : neighbor index
 * @param[in]       pMeasObj         : pointer of measurement object
 * @param[in]       hoTrigger        : e_HoTrigger_ImmediateHandover, e_HoTrigger_ConditionalHandoverPrep,
 *e_HoTrigger_ConditionalHandoverExec
 * @param[in]       candidateCell    : Pointer of candidate Nbr Information
 * @return          bool             : true, false
 ****************************************************************************/
bool FnVCCB_CheckChoPreparationCandidateCell(callInfo_type *ptCi, uint32_t usedFreq, uint16_t nbrIdx,
    measurementObjectNRUe_type *pMeasObj, enumHandoverTriggerType hoTrigger,
    candidateNbrInformation_type *candidateCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);
    VCCB_CHECK_E_RANGE_AND_VAL(nbrIdx, MAX_NBR_PER_CELL, false);
    VALID_E_POINT_CHECK_RET_VAL(pMeasObj, false);
    VALID_E_POINT_CHECK_RET_VAL(candidateCell, false);

    nbrGnbCellInfo_type *ptNbrGnbCell = NULL;
    uint8_t xnLink = FALSE;
    enumHoTypeInterface eHoTypeInterface = HO_TYPE_NG;
    selectedTAI_Type selectedTAI;
    selectedTAI_Type tempSelectedTAI;
    enumNgHoSelectionCause ngHoSelectionCause = NG_HO_CAUSE_NONE;

    if (e_HoTrigger_ConditionalHandoverPrep == hoTrigger)
    {
        if (STATE_Conn != ptCi->state)
        {
            VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) state(%d) is not Conn in CheckChoPreparationCandidateCell\n", ptCi->state);

            return false;
        }

        if (GOOD != getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCell))
        {
            VCCB_PRINT_CALL_SA_CHO(ptCi,"(*CHO) check getNbrGnbCellByCellNbrIdx (nbrIdx:%d) in CheckChoPreparationCandidateCell\n", nbrIdx);

            return false;
        }

        // 2) Check whether it is a CHO candidate cell. (If it is a CHO Candidate cell, return false.)
        cgi_type cgi;
        cgi.ci = VLIB_GnbIdCellId2NrCellId(&ptNbrGnbCell->globalGnbId.gnbId, ptNbrGnbCell->cellId);
        cgi.plmn = ptNbrGnbCell->globalGnbId.plmn;

        conditionalCellInfo_type *ptCondCell = FnVCCB_GetConditionalCellInfoForCGI(ptCi, cgi);
        if (ptCondCell != NULL)
        {
            // TODO: MR may be received during the Cancel procedure, so it may need to see the status.
            VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) Already it is a CHO Candidate cell in CheckChoPreparationCandidateCell.\n");

            return false;
        }

        // 3) Check whether it is a CHO Blocklisted cell.
        if (TRUE == FnVCCB_IsCHOBlockedCell(ptCi, ptNbrGnbCell))
        {
            VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) IsCHOBlockedCell true in CheckChoPreparationCandidateCell\n");

            return false;
        }

        // 4) Supports all currently set slices, (already check)
        // VCCM_CheckNbHoCandidate_NR -> VCCM_CheckAndUpdate_NbrPlmnValidation_NR -> VCCM_CheckSliceAwareForServing

        // 5) Intra-gNB Neighbor Cell, (already check)
        // VCCM_CheckSaHandoverCondition_NR

        // 6) Inter-gNB Cell (Xn-C connection is established),
        if (GOOD != VCOM_GetSelectedPLMN_FromAllowedPLMN(ptCi, candidateCell, intra5gs, &selectedTAI))
        {
            VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) check GetSelectedPLMN_FromAllowedPLMN in CheckChoPreparationCandidateCell\n");

            return false;
        }

        tempSelectedTAI = ptCi->hoInfo.selectedTAI;
        ptCi->hoInfo.selectedTAI = selectedTAI;

        if (GOOD !=
            VHCM_DecisionInterGnbSaHandoverType(ptCi, &ptNbrGnbCell->globalGnbId, &eHoTypeInterface, &xnLink, hoTrigger, ngHoSelectionCause))
        {
            ptCi->hoInfo.selectedTAI = tempSelectedTAI;
            VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) check DecisionInterGnbSaHandoverType in CheckChoPreparationCandidateCell\n");

            return false;
        }

        ptCi->hoInfo.selectedTAI = tempSelectedTAI;

        if (HO_TYPE_NG == eHoTypeInterface)
        {
            VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) XN HO Not Allowed (ngHoSelCause:%d) in CheckChoPreparationCandidateCell\n", ngHoSelectionCause);

            return false;
        }

        // 7) CHO Execution Condition1 Event should be configurable.
        if (GOOD !=
            FnVCCB_CheckChoExecution1Event(ptCi, pMeasObj->minimal.choExecutionCond1Event, usedFreq, ptCi->servCellNum))
        {
            VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) check ChoExecution1Event in CheckChoPreparationCandidateCell\n");

            return false;
        }
    }

    return true;
}

/****************************************************************************
 * @brief           Check LTM Preparation Candidate Cell
 *
 * @param[in]       ptCi             : call information / callInfo_type
 * @param[in]       hoTrigger        : e_HoTrigger_LtmHandoverPrep
 * @param[in]       candidateCell    : Pointer of candidate Nbr Information
 * @return          bool             : true, false
 ****************************************************************************/
bool FnVCCB_CheckLtmPCandidateCellSupportServingPlmn(callInfo_type &rCall, enumHandoverTriggerType hoTrigger, candidateNbrInformation_type *candidateCell)
{
    AUTO_TRACE_FUNC;

    if (hoTrigger != e_HoTrigger_LtmHandoverPrep) return true;

    for (auto iter : candidateCell->nbrTaiInfo.plmnList.plmn)
    {
        // Ltm target Cell should support ue served plmn
        if (VCOM_CheckPlmnIdentical(&iter, &rCall.ueInfo.servedPlmn) == TRUE) return true;
    }

    return false;
}

/***************************************************************************
 * @brief           Check HO neighbour candidate from other gnb
 *
 * @param[in]       ptCi              : call information / callInfo_type
 * @param[in]       usedFreq          : frequency from measResult to compare
 * @param[in]       nbrIdx            : index of neighbour to check
 * @param[in]       ptHrl             : ho restrict info
 * @param[out]      candidateCell     : ho candidate Cell info
 * @param[in]       pMeasObj          : meas object DB
 * @param[in]       hoTrigger         : ho trigger type (IM or CHO)
 * @param[in]       pNbrGnbCell       : nbr DB
 * @return          status            : GOOD, ERROR, BREAK / int16_t
 ***************************************************************************/
int16_t VCCM_CheckNbHoCandidate_NR(callInfo_type *ptCi, uint32_t usedFreq, uint16_t nbrIdx,
        hoRestrictInfo_type *ptHrl, candidateNbrInformation_type *candidateCell,
        measurementObjectNRUe_type *pMeasObj, enumHandoverTriggerType hoTrigger, nbrGnbCellInfo_type *ptNbrGnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(CELLINFO);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMeasObj);
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCell);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);

    if (GOOD != VCCM_CheckSaHandoverCondition_NR(ptCi, nbrIdx, pMeasObj, ptNbrGnbCell))
    {
        return BREAK;
    }

    if (GOOD != VCCM_FillCandidateCellInfo_NR(ptCi, ptCi->servCellNum, nbrIdx, candidateCell, true))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "call(%d) cell(%d) nbrIdx(%d) fail to VCCM_FillCandidateCellInfo_NR\n", ptCi->callId, ptCi->servCellNum,
            nbrIdx);

        return BREAK;
    }

    /* Check and update the normality of PLMN registered in Nbr. */
    if (GOOD != VCCM_CheckAndUpdate_NbrPlmnValidation_NR(ptCi, ptHrl, candidateCell, hoTrigger))
    {
        return BREAK;
    }

    /* Check condition about Conditional Handover Preparation Canidate Cell. */
    if (true != FnVCCB_CheckChoPreparationCandidateCell(ptCi, usedFreq, nbrIdx, pMeasObj, hoTrigger, candidateCell))
    {
        VCCB_PRINT_CALL_SA_CHO(ptCi, "(*CHO) FnVCCB_CheckChoPreparationCandidateCell false\n");
        return BREAK;
    }

    /* Check condition about LTM Handover Preparation Canidate Cell. */
    if (true != FnVCCB_CheckLtmPCandidateCellSupportServingPlmn(*ptCi, hoTrigger, candidateCell))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "FnVCCB_CheckLtmPCandidateCellSupportServingPlmn ERROR!\n");
        return BREAK;
    }

    // VCCB_PRINT_CALL_COMMENT(ptCi, "candidate with pci(%d) gnbId(%d) cellId(%d) found\n",
    //                         ptNbrGnbCell->nrPci, ptNbrGnbCell->globalGnbId.gnbId.id, ptNbrGnbCell->cellId);
    return GOOD;
}

/***************************************************************************
 * @brief           Check HO neighbour candidate from other enb
 *
 * @param[in]       ptCi              : call information / callInfo_type
 * @param[in]       nbrIdx            : index of neighbour to check
 * @param[in]       ptHrl             : ho restrict info
 * @param[in]       ptNbrEnbCell      : nbr DB
 * @param[out]      candidateCell     : ho candidate Cell info
 * @return          status            : GOOD, ERROR, BREAK / int16_t
 ***************************************************************************/
int16_t VCCM_CheckNbHoCandidate_EUTRA(callInfo_type *ptCi, uint16_t nbrIdx,
        hoRestrictInfo_type *ptHrl, candidateNbrInformation_type *candidateCell, nbrEnbCellInfo_type *ptNbrEnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(CELLINFO);
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrEnbCell);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL);

    if (GOOD != VCCM_CheckSaHandoverCondition_EUTRA(ptCi, nbrIdx, ptNbrEnbCell))
    {
        return BREAK;
    }

    if (GOOD != VCCM_FillCandidateCellInfo_EUTRA(ptCi->servCellNum, nbrIdx, candidateCell))
    {
        VCCB_PRINT_CALL_TGT_SEL(ptCi,
            "call(%d) cell(%d) nbrIdx(%d) fail to VCCM_FillCandidateCellInfo_EUTRA\n", ptCi->callId, ptCi->servCellNum,
            nbrIdx);

        return BREAK;
    }

    /* Check and update the normality of PLMN registered in Nbr. */
    if (GOOD != VCCM_CheckAndUpdate_NbrPlmnValidation_EUTRA(ptCi, ptHrl, candidateCell))
    {
        return BREAK;
    }

    // VCCB_PRINT_CALL_COMMENT(ptCi, "candidate with pci(%d) gnbId(%d) cellId(%d) found\n",
    //                         ptNbrGnbCell->nrPci, ptNbrGnbCell->globalGnbId.gnbId.id, ptNbrGnbCell->cellId);
    return GOOD;
}

/****************************************************************************
 * @brief           Select Target Cell for intra NR Handover
 *
 * @param[in]       ptCi              : call information / callInfo_type
 * @param[in]       usedFreq          : frequency from measResult to compare
 * @param[in]       nbrIdx            : index of neighbour to check
 * @param[in]       ptHrl             : ho restrict info
 * @param[out]      candidateCellList : ho candidateCell info
 * @param[in]       pMeasObj          : meas object DB
 * @param[in]       hoTrigger         : ho trigger type (IM or CHO)
 * @param[in]       ptNbrGnbCell      : nbr DB
 * @return          status            : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCM_ConditionallyUpdateIdxsOfBestCells_NR(callInfo_type *ptCi, uint32_t usedFreq, uint16_t nbrIdx,
        hoRestrictInfo_type *ptHrl, candidateNbrList_type *candidateCellList, measurementObjectNRUe_type *pMeasObj,
        enumHandoverTriggerType hoTrigger, nbrGnbCellInfo_type *ptNbrGnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(candidateCellList);
    VALID_E_POINT_CHECK_ERROR(ptHrl);
    VALID_E_POINT_CHECK_ERROR(pMeasObj);
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCell);
    VALID_E_POINT_CHECK_ERROR(CELLINFO);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    int16_t status = GOOD;
    int32_t currentCellRank = CANDIDATE_CELL_MAX_RANK;
    candidateNbrInformation_type candidateCell;
    candidateCell.isSpecificSliceFailed = FALSE;

    status = VCCM_CheckNbHoCandidate_NR(ptCi, usedFreq, nbrIdx, ptHrl, &candidateCell, pMeasObj, hoTrigger, ptNbrGnbCell);
    if (status != GOOD)
    {
        return candidateCell.isSpecificSliceFailed ? HO_BREAK_SPECIFIC_SLICE : status;
    }

    currentCellRank = pCell->Nbr[nbrIdx].rank;

    if (candidateCellList->numNbr < MAX_NBR_PER_CELL)
    {
        candidateCellList->nbrList[(candidateCellList->numNbr)++] = candidateCell;
        if (candidateCellList->maxRank > currentCellRank)
        {
            candidateCellList->maxRank = currentCellRank;
        }
    }


    return GOOD;
}

/****************************************************************************
 * @brief           Select Target Cell for inter RAT Handover
 *
 * @return          status            : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCM_ConditionallyUpdateIdxsOfBestCells_EUTRA(callInfo_type *ptCi, uint16_t nbrIdx,
        hoRestrictInfo_type *ptHrl, candidateNbrList_type *candidateCellList, nbrEnbCellInfo_type *ptNbrEnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(candidateCellList);
    VALID_E_POINT_CHECK_ERROR(ptHrl);
    VALID_E_POINT_CHECK_ERROR(CELLINFO);
    VALID_E_POINT_CHECK_ERROR(ptNbrEnbCell);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    int16_t status = GOOD;
    int32_t currentCellRank = CANDIDATE_CELL_MAX_RANK;
    candidateNbrInformation_type candidateCell;

    status = VCCM_CheckNbHoCandidate_EUTRA(ptCi, nbrIdx, ptHrl, &candidateCell, ptNbrEnbCell);
    if (status != GOOD)
    {
        return status;
    }

    currentCellRank = pCell->eutraNbr[nbrIdx].rank;

    if (candidateCellList->numNbr < MAX_NBR_PER_CELL)
    {
        candidateCellList->nbrList[(candidateCellList->numNbr)++] = candidateCell;
        if (candidateCellList->maxRank > currentCellRank)
        {
            candidateCellList->maxRank = currentCellRank;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Select Target Cell for NRDC SN PScell Change
 *
 * @param[in]       ptCi              : call information / callInfo_type
 * @param[in]       rsType            : RSType_CSIRS / RSType_SSB
 * @param[in]       ptMeasResultNR    : meas result information
 * @param[in]       usedFreq          : frequency from measResult to compare
 * @param[in]       nbrIdx            : index of neighbour to check
 * @param[in]       ptHrl             : ho restrict info
 * @param[in]       freqIdx           : freq index of ptMeasResultNR
 * @param[in]       pciIdx            : pci index of ptMeasResultNR per freq
 * @param[in]       skip_inter        : skip inter gNB neighbour
 * @param[in-out]   candidateCellList_intra : candidate list of intra gNB
 * @param[in-out]   candidateCellList_inter : candidate list of inter gNB
 * @param[in]       pMeasObj          : pointer of measurement object
 * @return          status            : GOOD, ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t FnVCCB_ConditionallyUpdateIdxsOfBestCells_NrdcSN(callInfo_type *ptCi, enumRSType rsType,
    const measResultNR_type *ptMeasResultNR, uint32_t usedFreq, uint16_t nbrIdx, hoRestrictInfo_type *ptHrl,
    uint16_t freqIdx, int pciIdx, SN_PscellSelectionCandidateNbrList_type *pCand, measurementObjectNRUe_type *pMeasObj,
    uint8_t reportCgiSupport)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM3(ptCi, ptMeasResultNR, ptHrl);
    VALID_E_POINT_CHECK_ERROR_PARAM2(pCand, pMeasObj);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);

    const uint16_t cellNum = ptCi->servCellNum;
    const bool isIntraGnb = (VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, nbrIdx) == TRUE);
    const bool isInterGnb = !isIntraGnb;

    int16_t status = GOOD;
    nbrGnbCellInfo_type *pNbr = NULL;
    candidateNbrInformation_type candidateCell;

    // FGR-CC5201 FR110: 7) In neighbour list

    // 1) Get Nbr Information
    status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbr);
    if (status != GOOD || !pNbr)
    {
        VCCB_PRINT_CALL_TGT_SEL(
            ptCi, "call(%d) cell(%d) nbrIdx(%d) fail to get nbrGnbCellInfo\n", ptCi->callId, cellNum, nbrIdx);

        return ERROR;
    }

    // 2) Check MeasResult
    if (GOOD != VCCM_ComparePcisAndFreqsOfNbrCell(ptMeasResultNR, usedFreq, rsType, pNbr))
    {
        return ERROR;
    }

    // 3) Check Gnb Based Validation
    {
        { // 3-1) Valid MN
            // TBD : OtherVendor, ...
        }

        { // 3-2) Valid Target-SN
            if (isInterGnb == true)
            {
                // If InterGnb is not a target, InterGNB may be excluded from the search target.
                if (pCand->skip_inter == true)
                {
                    VCCB_PRINT_CALL_TGT_SEL(ptCi,
                        "Skip, candidate cell(gnb(Id:%u/Len:%u)-cell(Id:%u) is Inter-GNB Cell! (Only Intra-GNB) (cell:%u, nbrIdx:%u)\n",
                        pNbr->globalGnbId.gnbId.id, pNbr->globalGnbId.gnbId.idLength, pNbr->cellId, cellNum, nbrIdx);
                    return BREAK;
                }

                // FGR-CC5201 FR120 [S-Node] SN Init Mobility
                // [S-Node]
                // If the Inter S-Node PSCell change is refused by M-Node,
                // S-Node list the target S-Node as 'PSCell change preparation failed target (S-Node)" for the UE
                if (GOOD != VCCM_CheckAgainstRefusedTargetGnb(ptCi, pNbr))
                {
                    VCCB_PRINT_CALL_TGT_SEL(ptCi,
                        "Skip, candidate cell(gnb(Id:%u/Len:%u)-cell(Id:%u) is PSCell change preparation failed target S-Node (cell:%u, nbrIdx:%u)\n",
                        pNbr->globalGnbId.gnbId.id, pNbr->globalGnbId.gnbId.idLength, pNbr->cellId, cellNum, nbrIdx);
                    return BREAK;
                }
            }
        }
    }

    // 4) Check Cell Based Validation
    {
        if (GOOD != VCCM_FillCandidateCellInfo_NR(ptCi, cellNum, nbrIdx, &candidateCell))
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "[%02u] Fail, VCCM_FillCandidateCellInfo_NR(cellNum: %u, pci: %u, gnb:%X/%u, ci:%u arfcn(%u/%u/%u))!\n",
            nbrIdx, cellNum, pNbr->nrPci, pNbr->globalGnbId.plmn.longId, pNbr->globalGnbId.gnbId.id, pNbr->cellId,
            pNbr->ssbArfcn, pNbr->nrArfcnDl, pNbr->nrArfcnUl);
            return BREAK;
        }

        if (FnVCCB_IsValidNrdcSnPerCell_ForSN(ptCi, cellNum, nbrIdx, pNbr, ptHrl, &candidateCell, pMeasObj) == false)
        {
            VCCB_PRINT_CALL_TGT_SEL(ptCi, "[%02u] Fail, IsValidNrdcSnPerCell(cellNum: %u, pci: %u, gnb:%X/%u, ci:%u, arfcn(%u/%u/%u))!\n",
                nbrIdx, cellNum, pNbr->nrPci, pNbr->globalGnbId.plmn.longId, pNbr->globalGnbId.gnbId.id, pNbr->cellId,
                pNbr->ssbArfcn, pNbr->nrArfcnDl, pNbr->nrArfcnUl);
            return BREAK;
        }
    }

    // 5) Final Proc
    {
        VccbCellInfo_type *pCell = &CELLINFO[cellNum];

        const uint16_t requiredBand = pMeasObj->minimal.freqBandIndicatorNR;
        candidatePscellNbrList_type *pInfo = NULL;
        uint16_t tempIntraTargetCellNum = 0;

        VCCB_GET_INTRA_GNB_NBR_CELLNUM(cellNum, nbrIdx, tempIntraTargetCellNum);
        if (VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, nbrIdx) == TRUE)  // relation type INTRA NB
        {
            pInfo = &pCand->intraSn;

            // temp code..
            candidateCell.cellNum = tempIntraTargetCellNum;
            candidateCell.cellBand = requiredBand;
        }
        else  // relation type INTER NB
        {
            pInfo = &pCand->interSn;

            // update the index of measResult
            candidateCell.freqIdx = static_cast<uint8_t>(freqIdx);
            candidateCell.pciIdx = static_cast<uint8_t>(pciIdx);
        }

        // FGR-MC1007 FR160
        uint16_t ueBasedCgiReportingForHOFlag = pCell->mobilityConfig.ueBasedCgiReportingForHo;
        VCCB_PRINT_CALL_TGT_SEL(ptCi, "ueBasedCgiReportingForHOFlag:%d reportCgiSupport:%d!\n",
            ueBasedCgiReportingForHOFlag, reportCgiSupport);

        if ((TRUE == ueBasedCgiReportingForHOFlag) && (TRUE == reportCgiSupport))
        {
            // fill candidateCellList without compare rank
            if (pInfo->numNbr < MAX_NBR_PER_CELL)
            {
                pInfo->nbrList[pInfo->numNbr] = candidateCell;
                pInfo->numNbr++;
            }
        }
        else
        {
            int32_t currentCellRank = CANDIDATE_CELL_MAX_RANK;

            // FGR-CC5201 FR112 : handling rank
            currentCellRank = pCell->Nbr[nbrIdx].rank;
            if (pCand->maxRank < currentCellRank)
            {
                VCCB_PRINT_CALL_COMMENT(ptCi,
                    "current rank is less than already selected - maxRank:%d, currentRank:%d\n", pCand->maxRank,
                    currentCellRank);
                return BREAK;
            }

            if (pCand->maxRank > currentCellRank)
            {
                pInfo->numNbr = 0;
                pCand->maxRank = currentCellRank;
            }

            if (pInfo->numNbr < MAX_NBR_PER_CELL)
            {
                pInfo->nbrList[pInfo->numNbr] = candidateCell;
                pInfo->numNbr++;
            }
        }
    }

    return GOOD;
}

int16_t VCCM_CheckEutraAllowedPlmn(callInfo_type *ptCi, uint32_t longId, hoRestrictInfo_type *ptHrl)
{
    AUTO_TRACE_FUNC;

    uint16_t plmnIdx;

    if (NULL == ptHrl)
    {
        return GOOD;
    }
    if (FALSE == ptHrl->existFlag)
    {
        return GOOD;
    }

    allwedPlmnList_type *pAllowedPlmn = FnVCCB_GetAllowedPlmnListByMRL(ptCi, ptHrl, MyRATRestriction);
    if (pAllowedPlmn != NULL)
    {
        for (plmnIdx = 0; plmnIdx < pAllowedPlmn->numEutraAllowedPlmn; plmnIdx++)
        {
            if (longId == pAllowedPlmn->eutraAllowedPlmn[plmnIdx].longId)
            {
                return GOOD;
            }
        }
    }

    return ERROR;
}

int VCCM_checkSaIRATAvailableNbr(callInfo_type *ptCi, uint16_t cellNum, measurementObjectEUTRABaseDb_type *ptMO)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMO);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;
    uint32_t numEquippedNbrCell = 0;
    uint32_t nbrPlmnIdx = 0;
    uint16_t nbrIdx = 0;

    // FGR-MC1015 PLMN based Mobility Control - FR21.CACP.SR1.HD1 (Inter-RAT)
    // gNB configurates a measure object regardless of allowed PLMN using MRL for an emergency UE.
    if (VCCM_CheckEmergencyCall(ptCi) == TRUE)
    {
        return GOOD;
    }

    // FGR-MC1028 FR60
    if (FnVCCB_IsValidSmallCellConfigEutraMo(ptCi->gnbNum, ptMO->smallCellPciListIndex) == GOOD)
    {
        VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "%s carrierFreq(%u) smallCellPciListIndex(%d) Valid!!\n",
                __func__, ptMO->carrierFreq, ptMO->smallCellPciListIndex);
        return GOOD;
    }
    else
    {
        VCCB_PRINT_CALL_NON_NBR_HO(ptCi, "%s carrierFreq(%u) smallCellPciListIndex(%d) Invalid !!\n",
                __func__, ptMO->carrierFreq, ptMO->smallCellPciListIndex);
    }

    // get Allowed Plmn List
    if (ERROR == VLIB_DecompressHoRestrictInfo(ptCi, ptHrl))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_DecompressHoRestrictInfo ERROR!\n");
        return ERROR;
    }

    for (nbrIdx = 0; nbrIdx < MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL; nbrIdx++)
    {
        nbrEnbCellInfo_type *pNbr;
        int status = getNbrEnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbr);
        if (status != GOOD) continue;

        if (pNbr->earfcnDl != ptMO->carrierFreq) continue;

        numEquippedNbrCell++;

        for (nbrPlmnIdx = 0; nbrPlmnIdx < MAX_NUM_PLMN_LTE; nbrPlmnIdx++)
        {
            if (EQUIP != pNbr->cellPlmnInfo[nbrPlmnIdx].shmStatus) continue;

            if (GOOD == VCCM_CheckEutraAllowedPlmn(ptCi, pNbr->cellPlmnInfo[nbrPlmnIdx].longId, ptHrl))
            {
                return GOOD;
            }
        }
    }

    // If there is no neighbor cell, return GOOD.
    if (0 == numEquippedNbrCell)
    {
        return GOOD;
    }

    return ERROR;
}

/****************************************************************************
 * @brief           Find whether the strongest PCI is known or Unknown
 *
 * @param[in]       ptCi :          call information / callInfo_type
 * @param[in]       rsType :        SSB/CSI-RS / enumRSType
 * @return          status :        GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_StatStrongestPciMrPScellChange(callInfo_type *ptCi, enumRSType rsType, int8_t smallCellListIdx)
{
    AUTO_TRACE_FUNC;

    uint32_t targetCellNum = 0;
    uint16_t idx = 0, nbrIdx = 0, nbrCellIdx = 0, allowedNcrCnt = 0;
    uint32_t usedFreq = 0;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(CELLINFO);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);

    measResultList2NR_type *ptMeasResultList2NR =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;
    measResult2NR_type *measResult2NR = ptMeasResultList2NR->measResult2NR;
    measResultNR_type *ptMeasResultNR = NULL;
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    VccbCellInfo_type *pTargetCell = NULL;
    bool knownFlag = false;
    int status;

    for (idx = 0; idx < MIN(ptMeasResultList2NR->nrofFreq, MAX_NUM_FREQ); idx++)  // go through the measurement list
    {
        if (TRUE == measResult2NR[idx].ssbFrequency_Flag && RSType_SSB == rsType)
        {
            usedFreq = measResult2NR[idx].ssbFrequency;
        }
        else if (TRUE == measResult2NR[idx].refFreqCSI_RS_Flag && RSType_CSIRS == rsType)
        {
            usedFreq = measResult2NR[idx].refFreqCSI_RS;
        }
        else
        {
            continue;
        }

        for (nbrCellIdx = 0;
             nbrCellIdx < MIN(measResult2NR[idx].measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);
             nbrCellIdx++)
        {
            ptMeasResultNR = &measResult2NR[idx].measResultNeighCellListNR.measResultNR[nbrCellIdx];

            if ((FALSE == ptMeasResultNR->physCellIdFlag))
            {
                continue;
            }
            // VCCB_PRINT_COMMENT("nbr PCI : %d, ssbFreq : %d  in MR\n", ptMeasResultNR->physCellId, usedFreq );

            for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)  // go through all the neighbors
            {
                const nbrCellInfo_type *pCellNbr = &pCell->Nbr[nbrIdx];
                if (N_EQUIP == pCellNbr->status)
                {
                    continue;
                }

                if (VCCB_IS_INTRA_GNB_NEIGHBOR(ptCi->servCellNum, nbrIdx))  // relation type INTRA NB
                {
                    VCCB_GET_INTRA_GNB_NBR_CELLNUM(ptCi->servCellNum, nbrIdx, targetCellNum);
                    if (targetCellNum >= MAX_CELL_NUM_VCCB)
                    {
                        continue;
                    }
                    pTargetCell = &CELLINFO[targetCellNum];
                    if (EQUIP != pTargetCell->status)
                    {
                        continue;
                    }

                    if (RSType_SSB == rsType)
                    {
                        if ((pTargetCell->phyCellId != ptMeasResultNR->physCellId) ||
                            (pTargetCell->ssbArfcn != usedFreq))
                        {
                            continue;
                        }
                        else
                        {
                            if (pCellNbr->isEndcHoAllowed) allowedNcrCnt++;
                            knownFlag = true;
                        }
                    }
                    else  // if(RSType_CSIRS == rsType)
                    {
                        if ((pTargetCell->phyCellId != ptMeasResultNR->physCellId) ||
                            (pTargetCell->nrArfcnDl != usedFreq))
                        {
                            continue;
                        }
                        else
                        {
                            if (pCellNbr->isEndcHoAllowed) allowedNcrCnt++;
                            knownFlag = true;
                        }
                    }
                }
                else  // relation type INTER NB
                {
                    // VCCB_PRINT_COMMENT(" nbr DB index : %d, type:%d, gnbIndex:%d \n", nbrIdx, INTER_NB,
                    // tempTargetInterCellNum);
                    nbrGnbCellInfo_type *ptNbrGnbCell;

                    status = getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCell);
                    if (status != GOOD)
                    {
                        continue;
                    }
                    // VCCB_PRINT_COMMENT(" nbrGbrCell, state:%d, pci:%d, ssbFreq :%d, rsType:%s \n",
                    //   ptNbrGnbCell->status, ptNbrGnbCell->nrPci,
                    //   ptNbrGnbCell->ssbArfcn,(rsType==RSType_SSB)?"RSType_SSB":"RSTYPE_CSIRS" );

                    if (N_EQUIP == ptNbrGnbCell->status)
                    {
                        continue;
                    }

                    if (RSType_SSB == rsType)
                    {
                        if ((ptNbrGnbCell->nrPci != ptMeasResultNR->physCellId) || (ptNbrGnbCell->ssbArfcn != usedFreq))
                        {
                            continue;
                        }
                        else
                        {
                            if (pCellNbr->isEndcHoAllowed) allowedNcrCnt++;
                            knownFlag = true;
                        }
                    }
                    else  // if(RSType_CSIRS  == rsType)
                    {
                        if ((ptNbrGnbCell->nrPci != ptMeasResultNR->physCellId) ||
                            (ptNbrGnbCell->nrArfcnDl != usedFreq))
                        {
                            continue;
                        }
                        else
                        {
                            if (pCellNbr->isEndcHoAllowed) allowedNcrCnt++;
                            knownFlag = true;
                        }
                    }
                }
            }

            VLIB_StatUnKnownPciCount(ptCi, ptMeasResultNR->physCellId, knownFlag, usedFreq,
                    NRMeas_PSCell_Change, smallCellListIdx, allowedNcrCnt);

            return GOOD;
        }
    }

    VCCB_PRINT_CALL_ERROR(ptCi, "%s: Could not find PCI in MeasResult!\n", __FUNCTION__);

    return GOOD;
}

/**
 * @brief This function checks if the given target cell is allowed by the intra-NR handover restriction list (HRL).
 *
 * @param ptHrl The intra-NR handover restriction list.
 * @param targetCellNum The cell number of the target cell.
 * @return int16_t Returns GOOD if the target cell is allowed, otherwise ERROR.
 */
static
int16_t FnVCCB_CheckAgainstHRL_IntraNB(hoRestrictInfo_type *ptHrl, uint16_t targetCellNum)
{
    AUTO_TRACE_FUNC;

    uint16_t plmnIdx = 0, taIdx = 0;
    uint8_t isSupportedPlmn = FALSE;
    VccbCellInfo_type *pTargetCell = NULL;

    VCCB_CHECK_E_RANGE_AND_RETURN(targetCellNum, MAX_CELL_NUM_VCCB);
    pTargetCell = &CELLINFO[targetCellNum];
    VCCB_CHECK_E_RANGE_AND_RETURN(pTargetCell->gnbNum, MAX_GNB_PER_SYS);

    // For support of multiple PLMN, check

    if (TRUE != VLIB_CheckCellPlmn(ptHrl->servedPlmn.longId, targetCellNum))
    {
        for (plmnIdx = 0; plmnIdx < MIN(ptHrl->numEplmn, X2_maxnoofEPLMNs); plmnIdx++)
        {
            if (TRUE == VLIB_CheckCellPlmn(ptHrl->ePlmn[plmnIdx].longId, targetCellNum))
            {
                isSupportedPlmn = TRUE;
                break;
            }
        }
    }
    else
    {
        isSupportedPlmn = TRUE;
    }

    if (FALSE == isSupportedPlmn)
    {
        VCCB_PRINT_COMMENT("VCCM_CheckAgainstHRL found INTRA_NB restricted cellPlmn\n");
        return ERROR;
    }

    if (N_EQUIP == pTargetCell->configuredTacStatus)
    {
        return GOOD;
    }
    for (taIdx = 0; taIdx < MIN(ptHrl->numForbidTaPlmn, X2_maxnoofEPLMNsPlusOne); taIdx++)
    {
        if (ptHrl->forbiddenTA[taIdx].plmn.longId != GNBINFO[pTargetCell->gnbNum].globalGnbId.plmn.longId)
        {
            continue;
        }
        // ptHrl->forbiddenTA are sorted in ascending order
        if (NULL != bsearch(&pTargetCell->configuredTac, ptHrl->forbiddenTA[taIdx].tac,
                        MIN(ptHrl->forbiddenTA[taIdx].numTac, X2_maxnoofForbTACs), sizeof(uint16_t),
                        VLIB_QsortUint16AscendingOrder))
        {
            VCCB_PRINT_COMMENT(
                "VCCM_CheckAgainstHRL found INTRA_NB forbiddenTA(0x%x)\n", pTargetCell->configuredTac);
            return ERROR;
        }
    }

    return GOOD;
}

/**
 * @brief This function checks if the given neighbor cell is allowed by the HO restriction list (HRL).
 *
 * @param cellNum The cell number of the target cell.
 * @param ptHrl The HO restriction list.
 * @param nbrIdx The index of the neighbor cell in the target cell's neighbor list.
 * @return int16_t Returns GOOD if the neighbor cell is allowed by the HRL, otherwise returns ERROR.
 */
static
int16_t FnVCCB_CheckAgainstHRL_InterNB(uint16_t cellNum, hoRestrictInfo_type *ptHrl, uint16_t nbrIdx)
{
    AUTO_TRACE_FUNC;

    uint16_t plmnIdx = 0, taIdx = 0, cellPlmnIdx = 0;
    int status = GOOD;
    nbrGnbCellInfo_type *pNbr;

    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_GNB_CELL_PER_GNB);
    status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbr);
    if (status != GOOD)
    {
        return GOOD;
    }
    for (cellPlmnIdx = 0; cellPlmnIdx < MAX_PLMN_INDEX; cellPlmnIdx++)
    {
        if (N_EQUIP == pNbr->cellPlmnInfo[cellPlmnIdx].shmStatus)
        {
            continue;
        }
        if (pNbr->cellPlmnInfo[cellPlmnIdx].longId == ptHrl->servedPlmn.longId)
        {
            break;
        }

        for (plmnIdx = 0; plmnIdx < MIN(ptHrl->numEplmn, X2_maxnoofEPLMNs); plmnIdx++)
        {
            if (pNbr->cellPlmnInfo[cellPlmnIdx].longId == ptHrl->ePlmn[plmnIdx].longId)
            {
                break;
            }
        }

        if (plmnIdx < MIN(ptHrl->numEplmn, X2_maxnoofEPLMNs))
        {
            break;
        }
    }
    if (cellPlmnIdx >= MAX_PLMN_INDEX)
    {
        VCCB_PRINT_COMMENT("VCCM_CheckAgainstHRL found INTER_NB restricted cellPlmn\n");
        return ERROR;
    }
    if (N_EQUIP == pNbr->configuredTacStatus)
    {
        return GOOD;
    }
    for (taIdx = 0; taIdx < X2_maxnoofEPLMNsPlusOne; taIdx++)
    {
        if (ptHrl->forbiddenTA[taIdx].plmn.longId != pNbr->globalGnbId.plmn.longId)
        {
            continue;
        }
        // ptHrl->forbiddenTA are sorted in ascending order
        if (NULL != bsearch(&pNbr->configuredTac, ptHrl->forbiddenTA[taIdx].tac,
                        MIN(ptHrl->numForbidTaPlmn, X2_maxnoofForbTACs), sizeof(uint16_t),
                        VLIB_QsortUint16AscendingOrder))
        {
            VCCB_PRINT_COMMENT("VCCM_CheckAgainstHRL found INTER_NB forbiddenTA(0x%x)\n", pNbr->configuredTac);
            return ERROR;
        }
    }

    return GOOD;
}

/**
 * @brief This function checks if the given cell is allowed to perform handover according to the HO Restriction List (HRL) information.
 *
 * @param cellNum The cell number of the source cell.
 * @param ptHrl The HO Restriction List information.
 * @param relationType The type of the neighbor relation (INTRA_NB or INTER_NB).
 * @param targetCellNumOrNbrIdx The target cell number for intra-NB handovers or the neighbor index for inter-NB handovers.
 * @return int16_t GOOD if the cell is allowed to perform handover, otherwise ERROR.
 */
int16_t VCCM_CheckAgainstHRL(uint16_t cellNum, hoRestrictInfo_type *ptHrl, uint8_t relationType, uint16_t targetCellNumOrNbrIdx)
{
    AUTO_TRACE_FUNC;

    if (NULL == ptHrl)
    {
        return GOOD;
    }

    if (FALSE == ptHrl->existFlag)
    {
        return GOOD;
    }

    VALID_E_POINT_CHECK_ERROR(GNBINFO);
    VALID_E_POINT_CHECK_ERROR(CELLINFO);

    if (INTRA_NB == relationType)
    {
        return FnVCCB_CheckAgainstHRL_IntraNB(ptHrl, targetCellNumOrNbrIdx/*TargetCellNum*/);
    }
    else  // INTER_NB
    {
        return FnVCCB_CheckAgainstHRL_InterNB(cellNum, ptHrl, targetCellNumOrNbrIdx/*NbrIdx*/);
    }
}

/****************************************************************************
 * @brief           Check Target FR1 Cell Against 'PScell change preparation failure for the FR2 to FR1 PSCell change'
 *list
 *
 * @param[in]       ptCi :          pointer to call information / callInfo_type
 * @param[in]       ptNbrGnbCell :  pointer to target checked cell / nbrGnbCellInfo_type
 * @return          status :        GOOD, BREAK, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_CheckAgainstRefusedTargetFR1Cells(callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCell);

    uint8_t loop = 0;

    for (loop = 0; loop < MAX_REFUSED_TARGET_FR1_CELLS_PER_CALL; loop++)
    {
        if ((EQUIP == ptCi->refusedTargetFR1CellsForFR2FR1HO[loop].status) &&
            (ptCi->refusedTargetFR1CellsForFR2FR1HO[loop].globalGnbId.gnbId.id == ptNbrGnbCell->globalGnbId.gnbId.id) &&
            (ptCi->refusedTargetFR1CellsForFR2FR1HO[loop].globalGnbId.gnbId.idLength ==
                ptNbrGnbCell->globalGnbId.gnbId.idLength) &&
            (ptCi->refusedTargetFR1CellsForFR2FR1HO[loop].cellId == ptNbrGnbCell->cellId))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                "Restricted for HO FR1 target cell found in refusedTargetFR1CellsForFR2FR1HO "
                "array! gnbId(%d), gnbIdLen(%d), cellId(%d)\n",
                ptNbrGnbCell->globalGnbId.gnbId.id, ptNbrGnbCell->globalGnbId.gnbId.idLength, ptNbrGnbCell->cellId);
            return BREAK;
        }
    }

    return GOOD;
}

/**
 * @brief Find common PLMN in a cell and Handover Restriction List.
 *
 * @param rCall info
 * @param cellNum cell to check
 * @return uint16_t plmnIdx of a cell which will be assigned to UE as served PLMN or MAX_PLMN_INDEX
 */
uint16_t VCCM_DetermineUePlmnBasedOnHRLForCell(const callInfo_type &rCall, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_VALID_CELLNUM_RET_VAL(cellNum, MAX_PLMN_INDEX);

    uint8_t loopPlmnIdx = 0;
    uint8_t plmnInfoIdx = 0;
    uint8_t cellPlmnIdx = 0;
    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    const uint16_t gnbNum = pCell->gnbNum;
    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    const hoRestrictInfoCompressed_type *const ptHrl = &rCall.hoRestrict;

    if (FALSE == ptHrl->existFlag)
    {
        if (VCCB_FLAG_ON == pGnb->cfg.spidBasedServingCellSelectionEnable)
        {
            for (loopPlmnIdx = 0; loopPlmnIdx < MAX_PLMN_INDEX; ++loopPlmnIdx)
            {
                if ((TRUE == VLIB_GetCellPlmnIdx(pGnb->plmnIndexInfo[loopPlmnIdx].longId, cellNum, &cellPlmnIdx)) &&
                    (GOOD == VLIB_getMultipleGnbPlmnIndexInfo(
                                 &rCall, &plmnInfoIdx, pCell->cellPlmn.servedPlmn[cellPlmnIdx])) &&
                    (VLIB_IsPCellAndPlmnAvailableForUe(&rCall, plmnInfoIdx, pCell->ssbArfcn)))
                {
                    return cellPlmnIdx;
                }
            }
            VCCB_PRINT_CALL_ERROR(&rCall, "Cannot find matching PLMN index for cellNum(%u)!\n", cellNum);
            return MAX_PLMN_INDEX;
        }
        else
        {
            return 0;
        }
    }

    if ((TRUE == VLIB_GetCellPlmnIdx(ptHrl->servedPlmn.longId, cellNum, &cellPlmnIdx)) &&
        ((VCCB_FLAG_OFF == pGnb->cfg.spidBasedServingCellSelectionEnable) ||
            ((GOOD == VLIB_getMultipleGnbPlmnIndexInfo(&rCall, &plmnInfoIdx, ptHrl->servedPlmn.longId)) &&
                (VLIB_IsPCellAndPlmnAvailableForUe(&rCall, plmnInfoIdx, pCell->ssbArfcn)))))
    {
        return cellPlmnIdx;
    }
    else
    {
        for (loopPlmnIdx = 0; loopPlmnIdx < MIN(ptHrl->numEplmn, X2_maxnoofEPLMNs); loopPlmnIdx++)
        {
            if ((TRUE == VLIB_GetCellPlmnIdx(ptHrl->ePlmn[loopPlmnIdx].longId, cellNum, &cellPlmnIdx)) &&
                ((VCCB_FLAG_OFF == pGnb->cfg.spidBasedServingCellSelectionEnable) ||
                    ((GOOD == VLIB_getMultipleGnbPlmnIndexInfo(&rCall, &plmnInfoIdx, ptHrl->ePlmn[loopPlmnIdx].longId)) &&
                        (VLIB_IsPCellAndPlmnAvailableForUe(&rCall, plmnInfoIdx, pCell->ssbArfcn)))))
            {
                return cellPlmnIdx;
            }
        }
    }

    return MAX_PLMN_INDEX;
}

/****************************************************************************
 * @brief           Find common PLMN in current PSCell and Handover Restriction List
 *
 * @param[in]       cellNum : served cellNum / uint16_t
 * @param[in]       ptHrl :         Handover Restriction List / hoRestrictInfo_type

 * @return          uePlmnIdx :       plmnIdx of a cell which will be assigned to UE as served PLMN / uint16_t
 ****************************************************************************/
uint16_t VCCM_DetermineUePlmnBasedOnHRL(const callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_PLMN_INDEX);

    return VCCM_DetermineUePlmnBasedOnHRLForCell(*ptCi, ptCi->servCellNum);
}

/****************************************************************************
 * @brief           Check cell against list of Refused Target Gnb for SN Change
 *
 * @param[in]       ptCi :         call information / callInfo_type
 * @param[in]       ptNbrGnbCell :  pointer to target checked cell / nbrGnbCellInfo_type
 * @return          status :        GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_CheckAgainstRefusedTargetGnb(callInfo_type *ptCi, nbrGnbCellInfo_type *ptNbrGnbCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptNbrGnbCell);

    uint16_t loop = 0;

    for (loop = 0; loop < MAX_REFUSED_TARGET_GNB_PER_CALL; loop++)
    {
        if ((ptCi->refusedTargetGnbId[loop].plmn.longId == ptNbrGnbCell->globalGnbId.plmn.longId) &&
            (ptCi->refusedTargetGnbId[loop].gnbId.id == ptNbrGnbCell->globalGnbId.gnbId.id) &&
            (ptCi->refusedTargetGnbId[loop].gnbId.idLength == ptNbrGnbCell->globalGnbId.gnbId.idLength))
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "PScell change preparation failed target SgNB(0x%0x-%d).\n",
                ptCi->refusedTargetGnbId[loop].plmn.longId, ptCi->refusedTargetGnbId[loop].gnbId.id);
            return ERROR;
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Clear UE history - Performs an operation to initialize UE History.
 *
 * @param[in,out]   ptCi :      call information / callInfo_type
 ****************************************************************************/
void FnVCCB_ClearUeHistoryInformation(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    // FGR-CC5201, 24B
    FnVCCB_InitLastVisitedPSCellList(ptCi);

    memset(&ptCi->ueHistory, 0x00, sizeof(ptCi->ueHistory));
    FnVCCB_InitPpaRestrictInfo(ptCi->ueHistory.ppaRestrict);
}

/****************************************************************************
 * @brief           FnVCCB_InitVisitedCellInfo
 *
 * @param[in,out]   ptCi :      call information / callInfo_type
 ****************************************************************************/
void FnVCCB_InitVisitedCellInfo(callInfo_type *ptCi, visitedCellInfo_type *pVisited)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID_PARAM2(ptCi, pVisited);

    memset(pVisited, 0x00, sizeof(visitedCellInfo_type));
}

/****************************************************************************************
 * @brief           Update UE history - This function fills the Ho Cause for MN/SA.
 ****************************************************************************************/
static inline uint16_t FnVCCB_UpdateUeHistoryInformation_GetHoCause_ForMRDC_MN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, CAUSE_NO_FAULT);

    switch (ptCi->stateCmd)
    {
        case RrcReestablish_cmd:
            return CauseNgapRadioNetworkLayerTimeCriticalHandover;

        default:
            // LB priority is higher than CHO priority (despite of CHO configured UE)
            if ((ptCi->hoInfo.isLbHo == TRUE) ||
                (ptCi->hoInfo.isIratLbHo == TRUE) ||
                (ptCi->hoInfo.isVoNrLbHo == TRUE))
            {
                // SVR23B FGR-LC0703 (FR70) :
                // SVR23B FGR-LC0711 (FR91) :
                // SVR24B FGR-LC0712 (FR100):
                return CauseNgapRadioNetworkLayerReduceLoadInServingCell;
            }

            if ((FnVCCB_IsConditionalHandoverUE(ptCi) == true) || (ptCi->hoInfo.ltmHandover))
            {
                // FGR-MC1400:FR420, FGR-MC1034:FR761 gNB set Handover Request (& Last Visited NG-RAN Cell Info) cause as
                // 'Resource Optimisation handover' in CHO candidate preparation procedure
                return CauseNgapRadioNetworkLayerResourceOptimisationHandover;
            }

            uint16_t xnCause{}, ngCause{};
            if (FnVCCB_GetPingPongAvoidanceCause(*ptCi, xnCause, ngCause, ptCi->hoInfo.reportType, ptCi->hoInfo.reportPurpose))
            {
                return ngCause;
            }

            // Immediate HO UE
            return CauseNgapRadioNetworkLayerHandoverDesirableForRadioReasons;
    }
}

/****************************************************************************************
 * @brief           Update UE history - This function fills the Ho Cause for SN.
 ****************************************************************************************/
static inline uint16_t FnVCCB_UpdateUeHistoryInformation_GetHoCause_ForMRDC_SN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, CAUSE_NO_FAULT);

    if (HO_TYPE_INTRA_NB == ptCi->hoInfo.hoType.nb)
    {
        if (HO_TYPE_INTRA_DU == ptCi->hoInfo.hoType.du)
        {
            return csl_Intra_gnb_du_ho;
        }

        if (HO_TYPE_INTER_DU == ptCi->hoInfo.hoType.du)
        {
            return csl_Inter_gnb_du_ho;
        }
    }

    return csl_Other_ho;
}

/****************************************************************************************
 * @brief           Update UE history - This function fills the Ho Cause.
 ****************************************************************************************/
static inline uint16_t FnVCCB_UpdateUeHistoryInformation_GetHoCause(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, CAUSE_NO_FAULT);

    if (ptCi->callType == E_CALLTYPE_NSA)
    {
        return FnVCCB_UpdateUeHistoryInformation_GetHoCause_ForMRDC_SN(ptCi);
    }

    // SA, NRDC-MN/SN, NEDC-MN
    return FnVCCB_UpdateUeHistoryInformation_GetHoCause_ForMRDC_MN(ptCi);
}

/****************************************************************************************
 * @brief           Update UE history - This function fills the Cellnum.
 ****************************************************************************************/
static inline uint16_t FnVCCB_UpdateUeHistoryInformation_GetCellNum(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_CELL_NUM_VCCB);

    if (ptCi->stateCmd == RrcReestablish_cmd)
    {
        return ptCi->ueInfo.reestablishInfo.oldCellNum;
    }

    return ptCi->servCellNum;
}

bool FnVCCB_IsNeedUpmPrepare(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, true);

    if (ptCi->stateCmd == RrcReestablish_cmd)
    {
        if (ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_GNB)
        {
            if (ptCi->ueInfo.reestablishInfo.isTargetGnb == FALSE)
            {
                return false;
            }
        }
    }

    // TODO : Inactive Design
    // if (ptCi->stateCmd == RRCIdle_cmd)
    // {
    //     if (ptCi->ueInfo.rrcResumeInfo.resumeType == RESUME_TYPE_INTER_GNB_SOURCE)
    //     {
    //         return false;
    //     }
    // }

    return true;
}

/****************************************************************************
 * @brief           Update UE history - fill structure
 * @details         Use when HO is triggered
 *
 * @param[in,out]   ptCi :      call information / callInfo_type
 * @return          status :    GOOD, ERROR / int16_t
 ****************************************************************************/
VCCB_STATIC_INLINE
int16_t VHCM_UpdateUeHistoryInformation_Prepare_Core(
    callInfo_type *ptCi,
    visitedCellInfo_type *pVisited,
    const uint16_t cellNum,
    const uint16_t hoCause)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM2(ptCi, pVisited);

    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    FnVCCB_InitVisitedCellInfo(ptCi, pVisited);

    // Lamda Start
    auto getCellType = [&]() -> uint8_t
    {
        if (ptCi->callType == E_CALLTYPE_NSA)  // ENDC-SN
        {
            return 0xFF;
        }

        // SA, NRDC-MN/SN, NEDC-MN
        // In 19A, CellSize is a value that does not configurable.
        return NGAP_CellSize_medium;
    };

    auto getStayTime = [&]() -> float
    {
#ifdef VCCB_IPC_TEST
        if (isRunShmMsgApprovalTest() == true)
        {
            // use the hard coding value to pass the tc
            return 200;
        }
        else
#endif
        {
            const struct timespec timeElapsed = ComTimeUtil::get_elapsed_time(ptCi->ueHistory.startTime);

            float diffTime = FnVCCB_GetTimeMilliSecond(&timeElapsed);

            if (diffTime > MAX_CELL_STAY_TIME_MSEC)
            {
                return MAX_CELL_STAY_TIME_MSEC;  // If equal or greater, use maximum value as diffTime
            }

            if (diffTime < 0)
            {
                return 0;
            }

            return diffTime;
        }
    };

    auto fillLastVisitedNGRANCellInformation_Optional = [&]() -> void
    {
        // Presnet Init By FnVCCB_InitVisitedCellInfo

        // O - TimeUEStayedInCellEnhancedGranularity
        pVisited->uRat.nrCell.stayTimeEnhancedPresent = OPT_PRESENT;

        // O - Cause
        if (hoCause != CAUSE_NO_FAULT)
        {
            pVisited->uRat.nrCell.hoCausePresent = OPT_PRESENT;
        }

        // O - LastVisitedPSCellList
    };
    // Lamda End

    float stayTime = getStayTime();

    // Madantory - Internal DB (defined VCCB)
    {
        // M - RatType (Not Spec, ci_nr, ci_eutra, ...)
        pVisited->ratType = ci_nr;

        // M - PCI  (Not Spec, Physical Cell Id)
        pVisited->uRat.nrCell.pci = CELLINFO[cellNum].phyCellId;
    }

    // Madantory in LastVisitedNGRANCellInformation, LastVisitedEUTRANCellInformation
    {
        // M - globalCellID (NGRAN/EUTRAN-CGI)
        if (FnVCCB_Fill_CellInfo_NRCGI(cellNum, &pVisited->uRat.nrCell.cgi) == ERROR)
        {
            return ERROR;
        }

        // M - cellType
        pVisited->uRat.nrCell.cellSize = getCellType();

        // M - timeUEStayedInCell - Given in seconds
        pVisited->uRat.nrCell.stayTime = static_cast<uint32_t>(stayTime / 1000);
    }

    // Optional in LastVisitedNGRANCellInformation, LastVisitedEUTRANCellInformation
    {
        fillLastVisitedNGRANCellInformation_Optional();

        // O - TimeUEStayedInCellEnhancedGranularity - Given in 1/10th of second
        if (pVisited->uRat.nrCell.stayTimeEnhancedPresent == OPT_PRESENT)
        {
            pVisited->uRat.nrCell.stayTimeEnhanced = static_cast<uint16_t>(stayTime / 100);
        }

        // O - Cause
        if (pVisited->uRat.nrCell.hoCausePresent == OPT_PRESENT)
        {
            pVisited->uRat.nrCell.hoCause = hoCause;
        }

        // O - LastVisitedPSCellList
        // we do not control but check and add when message make the Last Visited PSCell List.
    }

    // USAGE (Fill Complete)
    pVisited->usage = CI_use;

    // This operation is for PCell-UPM, so PSCell-UPM does not care about this operation.
    if (!IS_MRDC_SN(ptCi))
    {
        if (FnVCCB_IsNeedUpmPrepare(ptCi))
        {
            if (VCOM_UpdateUPM_Prepare(ptCi) == ERROR)
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "Forced Disabled UPM (PCell, UHI) in %s!\n", __func__);
                VCOM_DisableUPM(ptCi);
            }
        }
        else
        {
            VCCB_PRINT_CALL_LOG_UPM(ptCi, "[UPM] recalculation not required !\n");
        }
    }

    memcpy(&ptCi->hoInfo.ppaRestrictPrev, &ptCi->ueHistory.ppaRestrict, sizeof(ppaRestrictInfo_type));
    uint16_t xnCausePpa = 0;
    uint16_t ngCausePpa = 0;
    if (pVisited->ratType == ci_nr &&
        FnVCCB_GetConfigPingPongAvoidanceCause(*ptCi, xnCausePpa, ngCausePpa) == true)
    {
        if (hoCause == ngCausePpa)
        {
            (void)xnCausePpa;
            VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
            const uint32_t windowSec = FnVCCB_GetPingPongRestrictionWindowSeconds(*ptCi);
            memset(&ptCi->ueHistory.ppaRestrict, 0x00, sizeof(ptCi->ueHistory.ppaRestrict));
            ptCi->ueHistory.ppaRestrict.status = PPA_RESTRICT;
            ptCi->ueHistory.ppaRestrict.startTime =
                FnVCCB_GetgVccbInfo()->cfg->tickRestrictionTime % SECONDS_PER_THREE_DAYS;
            ptCi->ueHistory.ppaRestrict.restrictTime = windowSec % SECONDS_PER_THREE_DAYS;
            ptCi->ueHistory.ppaRestrict.ncgi = pVisited->uRat.nrCell.cgi;
            ptCi->ueHistory.ppaRestrict.ssbFrequency = CELLINFO[cellNum].ssbArfcn;
            ptCi->ueHistory.ppaRestrict.measObjIdx = INVALID_OBJECT_ID;
            VCCB_PRINT_LOG_NC_MC(ptCi, "(PPA) HO prep: restrict on PPA cause (cellNum:%u)\n", cellNum);
        }
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Update UE history - fill structure
 * @details         Use when HO is triggered
 *
 * @param[in,out]   ptCi :      call information / callInfo_type
 * @return          status :    GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VHCM_UpdateUeHistoryInformation_Prepare(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint16_t hoCause = FnVCCB_UpdateUeHistoryInformation_GetHoCause(ptCi);
    uint16_t cellNum = FnVCCB_UpdateUeHistoryInformation_GetCellNum(ptCi);

    visitedCellInfo_type *pVisited = &ptCi->ueHistory.pendingUeHistoryEntry;

    return VHCM_UpdateUeHistoryInformation_Prepare_Core(ptCi, pVisited, cellNum, hoCause);
}

/****************************************************************************
 * @brief           Update UE history - fill structure
 * @details         Use when HO is triggered
 *
 * @param[in,out]   ptCi :      call information / callInfo_type
 * @return          status :    GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t FnVCCB_FillUeHistory_ServingCellInfo_ForSNodeAddition(
    callInfo_type *ptCi,
    visitedCellInfo_type *pVisited)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM2(ptCi, pVisited);

    uint16_t cellNum = FnVCCB_UpdateUeHistoryInformation_GetCellNum(ptCi);

    return VHCM_UpdateUeHistoryInformation_Prepare_Core(ptCi, pVisited, cellNum, CAUSE_NO_FAULT);
}

/****************************************************************************
 * @brief           get UE history DB pointer for serving cell
 *
 * @param[in,out]   ptCi :          call information
 * @return          visitedCellInfo_type pointer :  valid pointer, NULL
 ****************************************************************************/
visitedCellInfo_type *VHCM_getUeHistory_ServingCellInfo(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    return &ptCi->ueHistory.pendingUeHistoryEntry;
}  // }}}

/****************************************************************************
 * @brief           get UE history DB pointer for serving cell
 *
 * @param[in,out]   ptCi :          call information
 * @return          visitedCellInfo_type pointer :  valid pointer, NULL
 ****************************************************************************/
visitedCellInfo_type *VHCM_getUeHistory_ServingCellInfo_ForSNodeAddition(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);

    return &ptCi->ueHistory.pendingUeHistoryEntry;
}  // }}}

/****************************************************************************
 * @brief           get UE history DB pointer of neighber
 *
 * @param[in,out]   ptCi :          call information
 * @param[in,out]   index :         index-th is required
 * @return          visitedCellInfo_type pointer :  valid pointer, NULL
 ****************************************************************************/
visitedCellInfo_type *VHCM_getUeHistory_VisitedCellInfo(callInfo_type *ptCi, uint8_t index, uint8_t ratType)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_NULL(ptCi);
    // Don't check the NULL for pOffset

    int i;
    int idx;
    int num = 0;
    visitedCellInfo_type *pVisited;

    // get first idx
    idx = ptCi->ueHistory.lastIdx;

    for (i = 0; i < MAX_VISITED_CELL; i++)
    {
        if (idx < 0) idx = MAX_VISITED_CELL - 1;
        if (idx >= MAX_VISITED_CELL) idx = 0;

        pVisited = &ptCi->ueHistory.visitedCell[idx];

        // check the usage
        if (pVisited->usage != CI_use)
        {
            // There is no matched visited cell
            return NULL;
        }

        // check the rat type
        if (ratType != 0xFF)
        {
            if (pVisited->ratType != ratType)
            {
                // find the next visited cell
                idx--;
                continue;
            }
        }

        // check the n-th index
        if (num < index)
        {
            num++;
            idx--;
            continue;
        }

        return pVisited;
    }

    return NULL;
}  // }}}

/****************************************************************************
 * @brief           update UE history DB
 *
 * @param[in,out]   ptCi :          call information
 * @param[in,out]   pVisited :      pointer of visitedCellInfo_type
 * @return          status :    GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VHCM_updateUEHistory(callInfo_type *ptCi, visitedCellInfo_type *pVisited)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pVisited);

    visitedCellInfo_type *ptVisitCell;

    ptCi->ueHistory.lastIdx++;
    if (ptCi->ueHistory.lastIdx >= MAX_VISITED_CELL)
    {
        ptCi->ueHistory.lastIdx = 0;
    }

    ptVisitCell = &ptCi->ueHistory.visitedCell[ptCi->ueHistory.lastIdx];
    *ptVisitCell = *pVisited;

    return GOOD;
}  // }}}

/****************************************************************************
 * @brief           Set Memory Usage Info
 *
 * @param[in,out]   interface :     Interface type
 * @param[in,out]   messageType :   msgId (If it is not a protocol message, mark it as 0)
 * @param[in,out]   size :          call information
 * @param[in,out]   threadId :      thread Number(If it is not a callInfo, mark it as 0)
 * @return          void
 ****************************************************************************/
void VLIB_setMemoryUsageInfo(interface_memoryUsage interface, uint16_t messageType, uint32_t size, uint32_t threadId)
{
    AUTO_TRACE_FUNC;

    // uint16_t statFamily;
    vccbMemoryUsageInfo_type *ptStat = NULL;

    VCCB_CHECK_E_RANGE_AND_VOID(threadId, MAX_CALL_THREAD_NUM_VCCB);

    if (messageType != 0)
    {
        // statFamily = ((messageType - MSGBASE_NR_PROTOCOL) >> 8) << 8;  // first hexadecimal bit discard

        // Find timerfamily compared to msgbase
        switch (interface)
        {
            case buf_NRRRC:
                ptStat = &VCCB_STAT->localStat.memoryUsageInfo.rrcUsageInfo;
                break;
            case buf_F1AP:
                ptStat = &VCCB_STAT->localStat.memoryUsageInfo.f1UsageInfo;
                break;
            case buf_X2AP:
                ptStat = &VCCB_STAT->localStat.memoryUsageInfo.x2UsageInfo;
                break;
                //      TBD: for 19A
                //      case buf_E1AP:
                //            ptStat = &VCCB_STAT->localStat.memoryUsageInfo.e1UsageInfo;
                //            break;
            case buf_UeCapa:
                ptStat = &VCCB_STAT->localStat.memoryUsageInfo.ueCapaInfo;
                break;
            case buf_CgConfig:
                ptStat = &VCCB_STAT->localStat.memoryUsageInfo.cgConfigInfo;
                break;
            default:
                return;
        }
    }
    else
    {
        return;
    }

    ptStat->allocCount++;
    ptStat->totBufferSize += size;

    // minSize
    if (ptStat->minBufferSize > size) ptStat->minBufferSize = size;

    // maxSize
    if (ptStat->maxBufferSize < size) ptStat->maxBufferSize = size;

    return;
}

void VLIB_setMemoryUsageCallInfo(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    vccbMemoryUsageInfo_type *ptStat = NULL;
    uint32_t size = sizeof(callInfo_type);

    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    ptStat = &VCCB_STAT->localStat.memoryUsageInfo.callInfo[ptCi->myThreadId];
    VALID_E_POINT_CHECK_VOID(ptStat);

    MUTEX_LOCK(&gMemoryUsageMtx);
    ptStat->allocCount++;
    ptStat->totBufferSize = ptStat->allocCount * size;

    // minSize
    if (ptStat->minBufferSize >= ptStat->totBufferSize) ptStat->minBufferSize = ptStat->totBufferSize;

    // maxSize
    if (ptStat->maxBufferSize <= ptStat->totBufferSize) ptStat->maxBufferSize = ptStat->totBufferSize;
    MUTEX_UNLOCK(&gMemoryUsageMtx);

    return;
}

void VLIB_MarkImsiTrace(ZIMSI_type *Z_IMSI, callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(Z_IMSI);
    VALID_E_POINT_CHECK_VOID(ptCi);

    int16_t status = GOOD;
    IMSI_type buf;
    uint8_t length = 0, loop = 0, i = 0, strLen = 0, traceFlag = TRUE;

    char imsiPrintBuf[16];
    imsiPrintBuf[0] = '\0';
#define IMSI_PRINT_BUF imsiPrintBuf + strLen
    uint32_t buffSize = sizeof(imsiPrintBuf);

    // return case #1 : already saved
    if (ptCi->ueInfo.ueId.imsi.n != 0)
    {
        return;
    }

    memset(&buf, 0x00, sizeof(IMSI_type));

    // Convert ZIMSI to IMSI type
    status = ConvertZImsiToImsi(Z_IMSI, &buf);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_MarkImsiTrace ConvertZImsiToImsi Failed\n");
        return;
    }

    // update the imsi
    ptCi->ueInfo.ueId.imsi.n = buf.n;
    for (loop = 0; loop < MIN(buf.n, MAX_IMSI_DIGIT); loop++)
    {
        ptCi->ueInfo.ueId.imsi.digit[loop] = buf.digit[loop];
    }

    // Check if it's IMSI trace registered UE in PLDImsiTrace(UserPLD) -
    // usage : itscp_vccb set dbg log imsiTrace [xxx..xxx] (14 or 15digits)
    for (loop = 0; loop < MAX_TRACE_IMSI; loop++)
    {
        traceFlag = TRUE;
        if (Z_IMSI->length != DBG->imsiTraceInfo.ZIMSILen[loop]) continue;

        for (length = 0; length < MIN(MAX_IMSI_BYTE, DBG->imsiTraceInfo.ZIMSILen[loop]); length++)
        {
            if (Z_IMSI->value[length] != DBG->imsiTraceInfo.ZIMSI[loop][length])
            {
                traceFlag = FALSE;
                break;
            }
        }

        if (traceFlag)
        {
            ptCi->debugTrace = VCCB_FLAG_ON;
            for (i = 0; i < MIN(ptCi->ueInfo.ueId.imsi.n, sizeof(ptCi->ueInfo.ueId.imsi.digit)); i++)
            {
                strLen = static_cast<uint8_t>(
                    strLen + snprintf(IMSI_PRINT_BUF, buffSize - strLen, "%X", ptCi->ueInfo.ueId.imsi.digit[i]));
            }
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "[TraceUE] - IMSI of the current UE: n:%d %s\n", ptCi->ueInfo.ueId.imsi.n, imsiPrintBuf);
            break;
        }
    }

    return;
}

/**
 * @brief Get Nr Duplex Type from Band Indicator
 * @param [in] band indicator
 * @param [out] duplex type
 */
uint16_t FnVCCB_GetNrDuplexTypeByBandIndicator(uint16_t bandIndi)
{
    AUTO_TRACE_FUNC;

    uint16_t duplexType = 0xFF;  // 0xFF is invalid value. Duplex type (0:FDD, 1:TDD, 0xFF:SUL)
    switch (bandIndi)
    {
        // FR1

        // Duplex type: FDD
        case 1:
        case 2:
        case 3:
        case 5:
        case 7:
        case 8:
        case 12:
        case 13:
        case 14:
        case 18:
        case 20:
        case 24:
        case 25:
        case 26:
        case 28:
        case 30:
        case 65:
        case 66:
        case 70:
        case 71:
        case 74:
        case 85:
        case 91:
        case 92:
        case 93:
        case 94:
        case 100:
            duplexType = ci_DUPLEXTYPE_FDD;
            break;

        // Duplex type: TDD
        case 34:
        case 38:
        case 39:
        case 40:
        case 41:
        case 46:
        case 48:
        case 50:
        case 51:
        case 53:
        case 77:
        case 78:
        case 79:
        case 90:
        case 96:
        case 101:
        case 102:
        case 104:
            duplexType = ci_DUPLEXTYPE_TDD;
            break;

        // Duplex type: SDL
        case 29:
        case 67:
        case 75:
        case 76:
            duplexType = CI_DUPLEXTYPE_SDL;
            break;

        // Duplex type: SUL
        case 80:
        case 81:
        case 82:
        case 83:
        case 84:
        case 86:
        case 89:
        case 95:
        case 97:
        case 98:
        case 99:
            duplexType = CI_DUPLEXTYPE_SUL;
            break;

        // FR2
        case 257:
        case 258:
        case 259:
        case 260:
        case 261:
        case 262:
        case 263:
            duplexType = ci_DUPLEXTYPE_TDD;
            break;
        default:
            break;
    }

    return duplexType;
}

/**
 * @brief Get Eutra Band Indicator from EARFCN
 * @param [in] earfcn
 * @param [out] band indicator
 */
uint16_t GetEutraBandIndicatorByEARFCN(uint32_t earfcn)
{
    AUTO_TRACE_FUNC;

    uint16_t bandIndi = 0;  // 0 is invalid value.

    // Calculates EUTRA band indicator
    switch (earfcn)
    {
        case 0 ... 599:
            bandIndi = 1;
            break;
        case 600 ... 1199:
            bandIndi = 2;
            break;
        case 1200 ... 1949:
            bandIndi = 3;
            break;
        case 1950 ... 2399:
            bandIndi = 4;
            break;
        case 2400 ... 2649:
            bandIndi = 5;
            break;
        case 2650 ... 2749:
            bandIndi = 6;
            break;
        case 2750 ... 3449:
            bandIndi = 7;
            break;
        case 3450 ... 3799:
            bandIndi = 8;
            break;
        case 3800 ... 4149:
            bandIndi = 9;
            break;
        case 4150 ... 4749:
            bandIndi = 10;
            break;
        case 4750 ... 4949:
            bandIndi = 11;
            break;
        case 5010 ... 5179:
            bandIndi = 12;
            break;
        case 5180 ... 5279:
            bandIndi = 13;
            break;
        case 5280 ... 5379:
            bandIndi = 14;
            break;
        case 5730 ... 5849:
            bandIndi = 17;
            break;
        case 5850 ... 5999:
            bandIndi = 18;
            break;
        case 6000 ... 6149:
            bandIndi = 19;
            break;
        case 6150 ... 6449:
            bandIndi = 20;
            break;
        case 6450 ... 6599:
            bandIndi = 21;
            break;
        case 6600 ... 7399:
            bandIndi = 22;
            break;
        case 7500 ... 7699:
            bandIndi = 23;
            break;
        case 7700 ... 8039:
            bandIndi = 24;
            break;
        case 8040 ... 8689:
            bandIndi = 25;
            break;
        case 8690 ... 9039:
            bandIndi = 26;
            break;
        case 9040 ... 9209:
            bandIndi = 27;
            break;
        case 9210 ... 9659:
            bandIndi = 28;
            break;
        case 9770 ... 9869:
            bandIndi = 30;
            break;
        case 9870 ... 9919:
            bandIndi = 31;
            break;
        case 9920 ... 10359:
            bandIndi = 32;
            break;
        case 36000 ... 36199:
            bandIndi = 33;
            break;
        case 36200 ... 36349:
            bandIndi = 34;
            break;
        case 36350 ... 36949:
            bandIndi = 35;
            break;
        case 36950 ... 37549:
            bandIndi = 36;
            break;
        case 37550 ... 37749:
            bandIndi = 37;
            break;
        case 37750 ... 38249:
            bandIndi = 38;
            break;
        case 38250 ... 38649:
            bandIndi = 39;
            break;
        case 38650 ... 39649:
            bandIndi = 40;
            break;
        case 39650 ... 41589:
            bandIndi = 41;
            break;
        case 41590 ... 43589:
            bandIndi = 42;
            break;
        case 43590 ... 45589:
            bandIndi = 43;
            break;
        case 45590 ... 46589:
            bandIndi = 44;
            break;
        case 46590 ... 46789:
            bandIndi = 45;
            break;
        case 46790 ... 54539:
            bandIndi = 46;
            break;
        case 54540 ... 55239:
            bandIndi = 47;
            break;
        case 55240 ... 56739:
            bandIndi = 48;
            break;
        case 65536 ... 66435:
            bandIndi = 65;
            break;
        case 66436 ... 67335:
            bandIndi = 66;
            break;
        case 67336 ... 67535:
            bandIndi = 67;
            break;
        case 67536 ... 67835:
            bandIndi = 68;
            break;
        case 67836 ... 68335:
            bandIndi = 69;
            break;
        case 68336 ... 68585:
            bandIndi = 70;
            break;
        case 255144 ... 256143:
            bandIndi = 252;
            break;
        case 260894 ... 262143:
            bandIndi = 255;
            break;
        default:
            break;
    }

    return bandIndi;
}

/**
 * @brief Check if UE supports EUTRA band
 * @param [in] eutraBand
 * @param [out] VCCB_FLAG_ON/VCCB_FLAG_OFF - eutraBand supported / not supported
 */
enumVccbFlag VLIB_IsEutraBandSupported(callInfo_type *ptCi, uint16_t eutraBand)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, VCCB_FLAG_OFF);

    if (eutraBand < 1 || eutraBand > MAX_EUTRA_BAND_INDICATOR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "EUTRA band(%u) not in valid range [1, 256]\n", eutraBand);
        return VCCB_FLAG_OFF;
    }

    return static_cast<enumVccbFlag>(ptCi->ueInfo.ueCapa.nr.eutraBand.supportedBandListEutra[eutraBand]);
}

/**
 * @brief Check operator-specific-frequency-based-redirection
 * @param [in] ptCi : Call information / callInfo_type
 * @param [in] candidateNum : the number of candidate frequencies
 * @param [in] arfcnCandidateListIdx : list of candidate meas object index
 * @param [out] status
 */
int16_t SelectNRARFCN_BasedOnOperatorSpecificFrequency(const callInfo_type *ptCi,
    uint8_t *candidateNum, uint16_t *arfcnCandidateListIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(candidateNum);
    VALID_E_POINT_CHECK_ERROR(arfcnCandidateListIdx);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    const operatorFreqForRedir_type *operatorFreq;

    for (uint16_t freqIndex = 0; freqIndex < MAX_OPERATOR_REDIR_FREQ_INDEX; freqIndex++)
    {
        operatorFreq = &pGnb->cfg.operatorFreqListForRedir[freqIndex];
        if (operatorFreq->usage == CI_use && pCell->ssbArfcn == operatorFreq->ssbFreq)
        {
            arfcnCandidateListIdx[(*candidateNum)++] = INTRAFREQ_OBJECT_IDX;
            return GOOD;
        }
    }

    return BREAK;
}

/**
 * @brief Check frequency-priority-based-redirection
 * @param [in] ptCi : Call information / callInfo_type
 * @param [in] pMeasObjExt : measurement object nr db extension / measurementObjectNRExtensionDb_type
 * @param [in] plmnIndex : plmn index of a call
 * @param [in] priorityBasedList : list of candidate meas object index which of priority is the highest
 * @param [out] status
 */
int16_t SelectNRARFCN_BasedOnFrequencyPriority(const callInfo_type *ptCi,
    const measurementObjectNRExtensionDb_type *pMeasObjExt, uint8_t plmnIndex,
    maxPriorityFreqForRedir_type *priorityBasedList)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMeasObjExt);
    VALID_E_POINT_CHECK_ERROR(priorityBasedList);

    int16_t status = GOOD;
    uint8_t priority = 0;

    if (MAX_PLMN_INDEX > plmnIndex)
    {
        if (CI_use == pMeasObjExt->plmnBasedControl.plmn[plmnIndex].usage)
        {
            priority = pMeasObjExt->plmnSpecific[plmnIndex].redirFreqPriority;
            if (priorityBasedList->maxPriority > priority)
            {
                status = BREAK;
            }
            else if (priorityBasedList->maxPriority < priority)
            {
                priorityBasedList->maxPriority = priority;
                priorityBasedList->maxPriorityNum = 0;
                memset(priorityBasedList->maxPriorityListIdx, 0, sizeof(priorityBasedList->maxPriorityListIdx));
            }
            return status;
        }
    }

    if (priorityBasedList->maxPriority > priority)
    {
        status = BREAK;
    }

    return status;
}

/**
 * @brief Check IntraRAT Redirection (For Blind Redirection)
 * @param [in] ptCi : Call information / callInfo_type
 * @param [out] status
 */
int16_t SelectNRARFCN_ForIntraRATRedirection(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];
    VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    measurementObjectNRBaseDb_type *pMeasObj = NULL;
    measurementObjectNRExtensionDb_type *pMeasObjExt = NULL;

    uint8_t index;
    uint8_t candidateNum = 0;
    unsigned int selectedIdx = 0;
    uint16_t arfcnCandidateListIdx[MAX_NR_OF_OBJECT_ID_DB] = { 0, };

    uint8_t isServiceGroupBased = pGnb->cfg.supportServiceGroupBasedIntraRatBlindRedirection;
    uint8_t isOperatorFreqBased = pGnb->cfg.supportOperatorFreqBasedIntraRatBlindRedirection;
    uint8_t isFreqPriorityBased = pCell->mobilityConfig.supportFreqPriorityBasedIntraRatBlindRedirection;

    maxPriorityFreqForRedir_type priorityBasedList;
    memset(&priorityBasedList, 0, sizeof(priorityBasedList));

    uint8_t callPlmnIndex = 0, svcGrpId = 0;
    uint8_t isReleaseProcedure = FALSE;  // FALSE : Do not count 'S_Release' PDU as a service group candidate.

    callPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);
    if (ERROR == FnVCCB_GetServiceGroupId(ptCi, &svcGrpId, isReleaseProcedure))
    {
        svcGrpId = 0;
    }

    if (isOperatorFreqBased && GOOD != SelectNRARFCN_BasedOnOperatorSpecificFrequency(
            ptCi, &candidateNum, arfcnCandidateListIdx))
    {
        isOperatorFreqBased = FALSE;
    }

    for (index = 0; index < MAX_NR_OF_OBJECT_ID_DB && !isOperatorFreqBased; index++)
    {
        pMeasObj = &pCell->measurementsData.measurementObjectsNRDb[index].base;
        pMeasObjExt = &pCell->measurementsData.measurementObjectsNRDb[index].extension;

        if (CI_use != pMeasObj->usage) continue;

        if (pCell->ssbArfcn == pMeasObj->ssbFrequency) continue;

        if (!FnVCCB_IsValid_MeasObj_CellReselection(ptCi, index)) continue;

        if (!isServiceGroupBased) svcGrpId = MAX_SVC_GRP_DB_NUM; // check plmn config only
        if (GOOD != VLIB_CanPlmnBasedControlBeUsedWithCustomIds(
                ptCi, pMeasObjExt->plmnBasedControl, callPlmnIndex, svcGrpId))
        {
            continue;
        }

        // plmn config must be checked before
        if (isFreqPriorityBased && GOOD == SelectNRARFCN_BasedOnFrequencyPriority(
                ptCi, pMeasObjExt, callPlmnIndex, &priorityBasedList))
        {
            priorityBasedList.maxPriorityListIdx[priorityBasedList.maxPriorityNum++] = index;
        }

        arfcnCandidateListIdx[candidateNum++] = index; // add to candidate regardless of priority
    }

    if (isFreqPriorityBased && 0 < priorityBasedList.maxPriority
        && 0 < priorityBasedList.maxPriorityNum && priorityBasedList.maxPriorityNum < candidateNum)
    {
        candidateNum = 0;
        memset(arfcnCandidateListIdx, 0, sizeof(arfcnCandidateListIdx));
        for (index = 0; index < priorityBasedList.maxPriorityNum; index++)
        {
            arfcnCandidateListIdx[candidateNum++] = priorityBasedList.maxPriorityListIdx[index];
        }
    }

    if (0 == candidateNum)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Supported nr arfcn for Intra-RAT redirection does not exist!\n");
        return ERROR;
    }

    string logBuf;
    for (index = 0; index < candidateNum; index++)
    {
        logBuf += std::to_string(arfcnCandidateListIdx[index]) + "/";
    }
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Random selection among moIdx[%s] for Intra-RAT redirection\n", logBuf.c_str());

    selectedIdx = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, candidateNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(selectedIdx, MAX_NR_OF_OBJECT_ID_DB);

    // set the value RRCRelease - RedirectedCarrierInfo - CarrierInfoNR - ARFCN-ValueNR
    VCCB_CHECK_E_RANGE_AND_RETURN(arfcnCandidateListIdx[selectedIdx], MAX_NR_OF_OBJECT_ID_DB);
    pMeasObj = &pCell->measurementsData.measurementObjectsNRDb[arfcnCandidateListIdx[selectedIdx]].base;

    ptCi->redirectionInfo.redirType = INTRA_RAT_REDIRECTION;
    VLIB_CreateRedirectionInfoNrFromMeasObjectDb(&ptCi->redirectionInfo.rat.nr, pMeasObj);

    return GOOD;
}

/**
 * @brief Check InterRAT Redirection (For Blind Redirection)
 * @param [in] earfcn
 * @param [out] band indicator
 */
int16_t SelectEARFCN_ForInterRATRedirection(callInfo_type *ptCi, enumInterRatRedirectionForcedOption_type forcedOption)
{
    AUTO_TRACE_FUNC;

    uint16_t index;
    uint16_t band = 0;
    uint32_t earfcn = 0;
    uint8_t candidateNum = 0;
    unsigned int selectedIdx = 0;
    uint32_t arfcnCandidateListIdx[MAX_NR_OF_OBJECTEUTRA_ID_DB] = {
        0,
    };
    uint32_t mappedEarfcnCandidateList[MAX_NR_OF_OBJECTEUTRA_ID_DB] = {
        0,
    };
    uint8_t fallbackRedirectionMethod;
    uint8_t svcGrpId = 0;
    uint8_t callPlmnIndex = 0;

    // Debug only
    if (DBG->flag.isSkipRedirectionCondition)
    {
        return GOOD;
    }

    // From SVR20A, meas-object-eutra-entries is used instead of eutra-redirection-entries
    measurementObjectEUTRABaseDb_type *pMeasObj = NULL;
    measurementObjectEUTRAExtensionDb_type *pExtension = NULL;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];
    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint8_t isReleaseProcedure = FALSE;  // FALSE : Do not count 'S_Release' PDU as a service group candidate.
    if (ERROR == FnVCCB_GetServiceGroupId(ptCi, &svcGrpId, isReleaseProcedure))
    {
        svcGrpId = 0;
    }
    callPlmnIndex = VLIB_FindGnbPlmnIndexOfCall(ptCi);

    for (index = 0; index < MAX_NR_OF_OBJECTEUTRA_ID_DB; index++)
    {
        pMeasObj = &pCell->measurementsData.measurementObjectsEUTRADb[index].base;
        if (CI_use != pMeasObj->usage)
        {
            continue;
        }

        // Inter-RAT Redirection can be used in below functions.
        // 1) FGR-SV0201: EPS Fallback (SVR19A)
        // 2) FGR-MC1007: NR Connected Mobility Control (SVR19A) : RLF Timeout -> Blind Redirection
        // 3) FGR-SV0202: Emergency Fallback (SVR20A)
        // 4) A2 Blind Redirection

        // In case of EPS Fallback, earfcn which voice-support-flag is FALSE should not be selected.
        // In case of Emergency Fallback, earfcn which emergency-fallback-support-flag is FALSE should not be selected.
        if (IS_NOT_SUPPORT_FALLBACK_FLAG_IN_MEASOBJ(ptCi, pMeasObj)) continue;

        band = VCCB_GetMoEutraBandForUe(ptCi, pMeasObj, &earfcn);
        if (0 == band)
        {
            // not supported by UE
            continue;
        }

        if (pGnb->cfg.supportServiceGroupBasedInterRatBlindRedirection == TRUE)
        {
            pExtension = &pCell->measurementsData.measurementObjectsEUTRADb[index].extension;
            if (GOOD != VLIB_CanPlmnBasedControlBeUsedWithCustomIds(
                            ptCi, pExtension->plmnBasedControl, callPlmnIndex, svcGrpId))
            {
                continue;
            }
        }

        arfcnCandidateListIdx[candidateNum] = index;  // index of candidate list
        mappedEarfcnCandidateList[candidateNum] = earfcn;
        candidateNum++;
    }

    if (0 == candidateNum)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Supported eutra arfcn for Inter-RAT redirection does not exist!\n");
        return ERROR;
    }

    if(forcedOption == Redirection_Forced_Blind)
    {
        fallbackRedirectionMethod = BLIND_REDIR_ONLY;
    }
    else if(forcedOption == Redirection_Forced_MrBased) // Inter-RAT H/O by VoNR Setup Fail
    {
        fallbackRedirectionMethod = MR_BASED_REDIR_OR_HO;
    }
    else // EPS or Emergency Fallback
    {
        if (IS_EMERGENCY_FALLBACK_CASE(ptCi))
        {
            fallbackRedirectionMethod = pGnb->cfg.emergencyFallbackRedirectionMethod;
        }
        else
        {
            fallbackRedirectionMethod = pGnb->cfg.fallbackRedirectionMethod;
        }
    }

    // Update actualRedirectionMethod (Considering UE Capa and YANG)
    if (fallbackRedirectionMethod == BLIND_REDIR_ONLY)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Set Blind Redirection(forced:%d, fallbackMethod:%d)\n", forcedOption,
            fallbackRedirectionMethod);

        ptCi->redirectionInfo.actualRedirectionMethod = BLIND_REDIR_ONLY;
    }
    else
    {
        enumIRATMeasState state = VCCM_CheckIRATMeasState(ptCi, ptCi->servCellNum, VCCB_FLAG_ON);

        if (state == IRAT_MEAS_STATE_INACTIVE)
        {
            // Measurement is possible
            ptCi->redirectionInfo.actualRedirectionMethod = MR_BASED_REDIR_OR_HO;
        }
        else  // Measurement is not possible for Fallback
        {
            VCCB_PRINT_CALL_INFORMATIVE(
                ptCi, "B1/B2 Report Config is not registered! Blind Redirection will be triggered!\n");

            if ( IS_EMERGENCY_FALLBACK_CASE(ptCi) &&
                 (ptCi->bitFlag.isEmergencyFallbackByAmf == VCCB_FLAG_ON ) &&
                 (fallbackRedirectionMethod == MR_BASED_REDIR_OR_HO      ))
            {
                VLIB_SetStatusToFailforAllRequestedBearerWithForced(
                    ptCi, CauseNgapRadioNetworkLayerImsVoiceEpsFallbackOrRatFallbackTriggered);

                // Execute forced Blind
                if (GOOD != SelectEARFCN_ForInterRATRedirection(ptCi, Redirection_Forced_Blind))
                {
                    return ERROR;
                }
                return GOOD;
            }
            else
            {
                ptCi->redirectionInfo.actualRedirectionMethod = BLIND_REDIR_ONLY;
            }
        }
    }

    selectedIdx = FnVCCB_GetRandomValue(__func__, ptCi->gnbNum, candidateNum);
    VCCB_CHECK_E_RANGE_AND_RETURN(selectedIdx, MAX_NR_OF_OBJECTEUTRA_ID_DB);

    // set the value RRCRelease - RedirectedCarrierInfo - RedirectedCarrierInfo-CUTRA - ARFCN-ValueEUTRA
    VCCB_CHECK_E_RANGE_AND_RETURN(arfcnCandidateListIdx[selectedIdx], MAX_NR_OF_OBJECTEUTRA_ID_DB);
    pMeasObj = &CELLINFO[ptCi->servCellNum]
                    .measurementsData.measurementObjectsEUTRADb[arfcnCandidateListIdx[selectedIdx]]
                    .base;

    ptCi->redirectionInfo.redirType = INTER_RAT_REDIRECTION;
    VLIB_CreateRedirectionInfoEutraFromMeasObjectDb(
        &ptCi->redirectionInfo.rat.eutra, pMeasObj, mappedEarfcnCandidateList[selectedIdx]);

    return GOOD;
}

int16_t VCCM_SDAP_AllocationAndUpdate_QosFlow_S_FailToSetup(callInfo_type *ptCi, qosFlowInfo_type *ptQi, numRelQosInfoInDRB_type relDrbInfo[])
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptQi);

    uint16_t drbIdxInCall;

    if (GOOD == VCCM_CheckInterGnbRRETarget(ptCi))
    {
        drbIdxInCall = ptQi->drbIdxInCall;
        if (drbIdxInCall >= MAX_DRB_PER_SA_CALL)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "Invalid drbIdxInCall(%d) in ptQi(qosFlowStatus:%d)!\n",
                drbIdxInCall, ptQi->qosFlowStatus);
            return GOOD; // For Partial DRB RRE 
        }
        relDrbInfo[drbIdxInCall].numRelQos++;
        // When there's no DRB relCause, use the first qosFlow's relCause for this DRB's release
        if (relDrbInfo[drbIdxInCall].relCause == CAUSE_NO_FAULT)
        {
            relDrbInfo[drbIdxInCall].relCause = ptQi->releaseInfo.releaseCause;
        }
    }

    return GOOD;
}

int16_t VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Release(callInfo_type *ptCi, qosFlowInfo_type *ptQi, numRelQosInfoInDRB_type relDrbInfo[])
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptQi);

    uint16_t drbIdxInCall;
    if(ptCi->bitFlag.pduChangeActionByAmf == VCCB_FLAG_ON)
    {
        if (ptCi->stateCmd == PDUModify_cmd)
        {
            FnVCCB_SaveEventForQosVonrEmerRetainStat(
                ptCi, ptQi, RetainCategory_PduSessonModifyByAMF, ptQi->releaseInfo.releaseCause);
        }
        else if (ptCi->stateCmd == PDURelease_cmd)
        {
            FnVCCB_SaveEventForQosVonrEmerRetainStat(
                ptCi, ptQi, RetainCategory_PduSessonReleaseByAMF, ptQi->releaseInfo.releaseCause);
        }
    }

    drbIdxInCall = ptQi->drbIdxInCall;
    if (drbIdxInCall >= MAX_DRB_PER_SA_CALL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid drbIdxInCall(%d) in ptQi(qosFlowStatus:%d)!\n",
            drbIdxInCall, ptQi->qosFlowStatus);
        return ERROR;
    }

    relDrbInfo[drbIdxInCall].numRelQos++;
    // When there's no DRB relCause, use the first qosFlow's relCause for this DRB's release
    if (relDrbInfo[drbIdxInCall].relCause == CAUSE_NO_FAULT)
    {
        relDrbInfo[drbIdxInCall].relCause = ptQi->releaseInfo.releaseCause;
    }

    return GOOD;
}

int16_t VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Modify(callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptQi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pduIdx, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(qosFlowIdxInPdu, MAX_QOS_FLOW_PER_PDU_SESS);

    uint16_t drbIdxInCall;
    callPDUSessInfo_type *ptPi = NULL;
    ptPi = &ptCi->pduSess[pduIdx];

    if(ptCi->bitFlag.pduChangeActionByAmf == VCCB_FLAG_ON)
    {
        if (ptCi->stateCmd == PDUModify_cmd)
        {
            FnVCCB_SaveEventForQosVonrEmerRetainStat(
                    ptCi, ptQi, RetainCategory_PduSessonModifyByAMF, No_CallDrb_RetainItem);
        }
    }

    drbIdxInCall = ptQi->drbIdxInCall;
    if (drbIdxInCall >= MAX_DRB_PER_SA_CALL)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid drbIdxInCall(%d) in ptQi(qosFlowStatus:%d)!\n",
            drbIdxInCall, ptQi->qosFlowStatus);
        return ERROR;
    }

    if (IS_NRDC_MN(ptCi) && (ptCi->drb[drbIdxInCall].drbStatus == S_Null ||
                                ptCi->drb[drbIdxInCall].drbStatus == S_Null_Release))
    {
        VCCB_PRINT_CALL_MSG(ptCi,
            ">>> drbStatus(%d, S_Null or S_Null_Release) was not changed to S_Modify "
            "during QoS flow[%d]'s modification in %s\n",
            ptCi->drb[drbIdxInCall].drbStatus, ptPi->qosFlowIndex[qosFlowIdxInPdu], __func__);
        return GOOD;
    }

    SET_DRB_STATUS(ptCi, drbIdxInCall, S_Modify);
    // ptDi = &ptCi->drb[drbIdxInCall];
    // TODO: Statistics for DRB_Modify
    // NEW 21A, Currently No Case, But
    // If DBR is released by QosFlowModify, then should save the RelCause and mark Event.

    return GOOD;
}

int16_t VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Setup_nonGBRQosFlow(callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptQi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pduIdx, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(qosFlowIdxInPdu, MAX_QOS_FLOW_PER_PDU_SESS);

    uint8_t isDedicatedAndMappingRuleListEmpty = TRUE;
    callPDUSessInfo_type *ptPi = NULL;
    ptPi = &ptCi->pduSess[pduIdx];

    // 1) check dedicatedQosFlowGroupInfo
    int16_t status = VLIB_AllocDrbByDedicatedQosFlowGroup(
        ptCi, pduIdx, qosFlowIdxInPdu, &isDedicatedAndMappingRuleListEmpty);
    switch (status)
    {
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_AllocDrbByDedicatedQosFlowGroup ERROR!\n");
            return ERROR;

        case GOOD:  // matching dedicated qos flow group exists so jump to next qosFlow
            VCCB_CHECK_E_RANGE_AND_RETURN(ptQi->drbIdxInCall, MAX_DRB_PER_SA_CALL);
            ptCi->drb[ptQi->drbIdxInCall].mappingType = MAPPING_DedicatedGroup;
            VCCB_PRINT_CALL_MSG(ptCi, "%s QoS flow[%d] is allocated to new DRB[%d]\n", __func__,
                ptPi->qosFlowIndex[qosFlowIdxInPdu], ptQi->drbIdxInCall);
            return GOOD;

        default:
            break;
    }

    //  2) check mappingRuleInfo
    status = VLIB_AllocDrbByMappingRule(
        ptCi, pduIdx, qosFlowIdxInPdu, &isDedicatedAndMappingRuleListEmpty);
    switch (status)
    {
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_AllocDrbByMappingRule ERROR!\n");
            return ERROR;

        case GOOD:  // matching mapping rule exists so jump to next qosFlow
            VCCB_CHECK_E_RANGE_AND_RETURN(ptQi->drbIdxInCall, MAX_DRB_PER_SA_CALL);
            if (IS_NRDC_MN(ptCi) &&
                ptCi->drb[ptQi->drbIdxInCall].mappingType == MAPPING_DedicatedGroup)
            {
                VCCB_PRINT_CALL_MSG(ptCi,
                    "%s QoS flow[%d] is allocated to new DRB[%d] by "
                    "MAPPING_DedicatedGroup instead of MappingRule!!\n",
                    __func__, ptPi->qosFlowIndex[qosFlowIdxInPdu], ptQi->drbIdxInCall);
            }
            else
            {
                ptCi->drb[ptQi->drbIdxInCall].mappingType = MAPPING_MappingRule;
            }
            VCCB_PRINT_CALL_MSG(ptCi, "%s QoS flow[%d] is allocated to DRB[%d]\n", __func__,
                ptPi->qosFlowIndex[qosFlowIdxInPdu], ptQi->drbIdxInCall);
            return GOOD;

        default:
            break;
    }
    if (isDedicatedAndMappingRuleListEmpty == TRUE)
    {
        status = VLIB_AllocDrbByDedicatedQosFlowGroup_NoConfiguration_Available(
            ptCi, pduIdx, qosFlowIdxInPdu);
        switch (status)
        {
            case ERROR:
                VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_AllocDrbByDedicatedQosFlowGroup ERROR!\n");
                return ERROR;

            case GOOD:  // matching dedicated qos flow group exists so jump to next qosFlow
                VCCB_CHECK_E_RANGE_AND_RETURN(ptQi->drbIdxInCall, MAX_DRB_PER_SA_CALL);
                ptCi->drb[ptQi->drbIdxInCall].mappingType = MAPPING_DedicatedGroup;
                VCCB_PRINT_CALL_MSG(ptCi, "%s QoS flow[%d] is allocated to new DRB[%d]\n",
                    __func__, ptPi->qosFlowIndex[qosFlowIdxInPdu], ptQi->drbIdxInCall);

                return GOOD;
            default:
                break;
        }
    }

    // 3) check default DRB
    status = VLIB_AllocDrbByDefault(ptCi, pduIdx, qosFlowIdxInPdu);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_AllocDrbByDefault ERROR!\n");
        return ERROR;
    }
    else
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(ptQi->drbIdxInCall, MAX_DRB_PER_SA_CALL);
        ptCi->drb[ptQi->drbIdxInCall].mappingType = MAPPING_Default;
        VCCB_PRINT_CALL_MSG(ptCi, "%s QoS flow[%d] is allocated to default DRB[%d]\n", __func__,
            ptPi->qosFlowIndex[qosFlowIdxInPdu], ptQi->drbIdxInCall);
    }

    return GOOD;
}

int16_t VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Setup(callInfo_type *ptCi, qosFlowInfo_type *ptQi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptQi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pduIdx, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(qosFlowIdxInPdu, MAX_QOS_FLOW_PER_PDU_SESS);

    uint16_t drbIdxInCall;
    int16_t status = GOOD;
    callPDUSessInfo_type *ptPi = NULL;
    ptPi = &ptCi->pduSess[pduIdx];

    if (ptQi->drbIdxInCall >=
        MAX_DRB_PER_SA_CALL)  // Allocate DRB only when drbIdxInCall is invalid for HO case.
    {
        if (ptQi->qosParam.gbrQosInformationPresent == OPT_PRESENT)  // For GBR QoS flow
        {
            if (ERROR == VLIB_AllocNewCallDrbInfo(ptCi, pduIdx, qosFlowIdxInPdu, &drbIdxInCall))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VLIB_AllocNewCallDrbInfo ERROR!\n");
                return ERROR;
            }
            ptCi->drb[drbIdxInCall].mappingType = MAPPING_GbrQosFlow;
            VCCB_PRINT_CALL_MSG(ptCi, "%s GBR QoS flow[%d] is allocated to new DRB[%d]\n", __func__,
                ptPi->qosFlowIndex[qosFlowIdxInPdu], drbIdxInCall);
            return GOOD;
        }
        else  // For Non-GBR QoS flow
        {
            status = VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Setup_nonGBRQosFlow(ptCi, ptQi, pduIdx, qosFlowIdxInPdu);
        }
    }
    return status;
}

int16_t VCCM_SDAP_AllocationAndUpdate_QosFlowStatus(callInfo_type *ptCi, uint8_t pduIdx, uint16_t qosFlowIdxInPdu, numRelQosInfoInDRB_type relDrbInfo[])
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(pduIdx, MAX_PDU_SESS_PER_CALL);
    VCCB_CHECK_E_RANGE_AND_RETURN(qosFlowIdxInPdu, MAX_QOS_FLOW_PER_PDU_SESS);

    qosFlowInfo_type *ptQi = NULL;
    callPDUSessInfo_type *ptPi = NULL;
    ptPi = &ptCi->pduSess[pduIdx];
    VCCB_CHECK_E_RANGE_AND_RETURN(ptPi->qosFlowIndex[qosFlowIdxInPdu], MAX_QOS_FLOW_PER_CALL);
    ptQi = &ptCi->qosFlow[ptPi->qosFlowIndex[qosFlowIdxInPdu]];
    if (ptQi->usage != CI_use) return GOOD;

    int16_t status = GOOD;
    switch (ptQi->qosFlowStatus)
    {
        case S_Setup:
        {
            status = VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Setup(ptCi, ptQi, pduIdx, qosFlowIdxInPdu);
        }
        break;

        case S_Modify:
        {
            status = VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Modify(ptCi, ptQi, pduIdx, qosFlowIdxInPdu);
        }
        break;

        case S_Release:
        {
            status = VCCM_SDAP_AllocationAndUpdate_QosFlow_S_Release(ptCi, ptQi, relDrbInfo);
        }
        break;

        case S_FailToSetup:
        {
            status = VCCM_SDAP_AllocationAndUpdate_QosFlow_S_FailToSetup(ptCi, ptQi, relDrbInfo);
        }
        break;

        default:
            // VCCB_PRINT_CALL_ERROR(ptCi, "Invalid qosFlowStatus(%d)\n", ptQi->qosFlowStatus);
            break;
    }

    return status;
}

/**
 * @brief Allocate DRB with QosFlow for supporting SDAP
 * @param [in] ptCi
 * @param [out] status
 */
int16_t VCCM_SDAP_AllocationAndUpdate_DRBStatus(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t loop;
    uint8_t pduIdx;
    uint8_t drbIdxInCall;
    uint16_t qosFlowIdxInPdu;
    uint8_t drbSetupStatCslFlag = VCCB_FLAG_OFF;
    uint8_t drbRetainStatCslFlag = VCCB_FLAG_OFF;

    callPDUSessInfo_type *ptPi = NULL;
    // callDRBInfo_type *ptDi = NULL;

    int16_t status = GOOD;
    numRelQosInfoInDRB_type relDrbInfo[MAX_DRB_PER_SA_CALL];
    memset(&relDrbInfo[0], 0, sizeof(relDrbInfo));

    // CASE1. QosFlow Addition     : Allocated new DRB (In SVR19A, DRB:QosFlow = 1:1 / from SVR20A, DRB:QosFlow = 1:N)
    // CASE2. QosFlow Modification : Set DRB status as S_Modify
    // CASE3. QosFlow Release
    //     3-1: If all the QosFlow is released in DRB, then set DRB status as S_Release
    //     3-2: If some of the QosFlow is released in DRB, then set DRB status as S_Modify

    for (pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        ptPi = &ptCi->pduSess[pduIdx];

        if (ptPi->usage != CI_use) continue;

        for (qosFlowIdxInPdu = 0; qosFlowIdxInPdu < MAX_QOS_FLOW_PER_PDU_SESS; qosFlowIdxInPdu++)
        {
            if (ptPi->qosFlowIndex[qosFlowIdxInPdu] >= MAX_QOS_FLOW_PER_CALL) continue;

            status = VCCM_SDAP_AllocationAndUpdate_QosFlowStatus(ptCi, pduIdx, qosFlowIdxInPdu, relDrbInfo);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "pduSwitch ERROR!\n"); //change name
        }

        // Set DRB Status
        for (loop = 0; loop < MAX_DRB_PER_SA_CALL; loop++)
        {
            if (ptCi->drb[loop].usage != CI_use) continue;

            if (relDrbInfo[loop].numRelQos == 0) continue;  // There is no QosFlow to release

            if (IS_NRDC_MN(ptCi) && ptCi->drb[loop].drbStatus == S_Null)
            {
                if (ptCi->drb[loop].numQoSFlowPerDRB <= relDrbInfo[loop].numRelQos)
                {
                    SET_DRB_STATUS(ptCi, loop, S_Null_Release);
                }
                continue;
            }

            if (ptCi->drb[loop].numQoSFlowPerDRB <=
                relDrbInfo[loop].numRelQos)  // Release all QoS means, drb have to be release.
            {
                SET_DRB_STATUS(ptCi, loop, S_Release);  // TODO : considering S_FailToSetup
                if(ptCi->bitFlag.pduChangeActionByAmf == VCCB_FLAG_ON)
                {
                    if (ptCi->stateCmd == PDUModify_cmd)
                    {
                        drbRetainStatCslFlag = VCCB_FLAG_ON;
                        VLIB_SaveEventForDrbRetainStat(
                            ptCi, &ptCi->drb[loop], RetainCategory_PduSessonModifyByAMF, relDrbInfo[loop].relCause);
                    }
                    else if (ptCi->stateCmd == PDURelease_cmd)
                    {
                        drbRetainStatCslFlag = VCCB_FLAG_ON;
                        VLIB_SaveEventForDrbRetainStat(
                            ptCi, &ptCi->drb[loop], RetainCategory_PduSessonReleaseByAMF, relDrbInfo[loop].relCause);
                    }
                    else
                    {
                        // Not Save Event.
                    }
                }
            }
            else
            {
                SET_DRB_STATUS(ptCi, loop, S_Modify);  // Modify Case
            }
        }
    }

    if (drbRetainStatCslFlag == VCCB_FLAG_ON)
    {
        MACRO_INCREASE_RETAIN_STAT_CSL_COLLECT_ORDER(ptCi);
    }

    // After allocating QosFlow to DRB
    for (drbIdxInCall = 0; drbIdxInCall < MAX_DRB_PER_SA_CALL; drbIdxInCall++)
    {
        callDRBInfo_type* ptDi = &ptCi->drb[drbIdxInCall];
        if (ptDi->usage == CI_use &&
            (ptDi->drbStatus == S_Setup || ptDi->drbStatus == S_Modify))
        {
            if (ERROR == FnVCCB_FillCallRbInfoPer5qi(ptCi, ptDi, NR_PDCP_UPDATE_FINAL))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "Set RbInfo DRB(%d) fail!\n", drbIdxInCall);
                return ERROR;
            }
        
            for (uint8_t i = 0; i < MAX_QOS_FLOW_PER_DRB; i++)
            {
                if(ptDi->qosFlowIndex[i] >= MAX_QOS_FLOW_PER_CALL) continue;
                
                qosFlowInfo_type *qosFlowInfo = &ptCi->qosFlow[ptDi->qosFlowIndex[i]];
                if(qosFlowInfo->usage != CI_use) continue;
                if(qosFlowInfo->qosParam.qosMonitoringRequestPresent)
                {
                    enumQosMonitoringRequest_type output = QOS_MONITORING_REQUEST_NOT_PRESENT;
                    if(GOOD == FnVCCB_Decide_QosMonitoringInfo_ForDrbQos(ptCi, ptDi, &output))
                    {
                        ptDi->drbQosMonitoring = output;
                    }                    
                    break;
                }
            }
        }

        // Collect Attempt Statistics
        switch (ptDi->drbStatus)
        {
            case S_Setup:
                if( (ptCi->stateCmd == RRCConnection_cmd) ||
                    (ptCi->stateCmd == PDUSetup_cmd     ) ||
                    (ptCi->stateCmd == PDUModify_cmd    ))
                {
                    int16_t checkType = DRB_SETUP;

                    if(ptCi->stateCmd == RRCConnection_cmd)
                        checkType = INITIAL_DRB_SETUP;
                    else if(ptCi->stateCmd == PDUModify_cmd)
                        checkType = DRB_SETUP_IN_PDUSESSION_MODIFY;

                    MACRO_STAT_PMCC_DRB_SETUP_FAMILY_ALL(
                        DrbSetupAtt, ptCi, ptDi, 0, 0, 0, 0, checkType);

                    // Start DRB Setup Time for 5QI=1
                    FnVCCB_CalculateDrbSetupTime(ptCi, ptDi, CAL_START);

                    drbSetupStatCslFlag = VCCB_FLAG_ON;
                }
                break;
            case S_Modify:
                break;
            case S_Release:
                if(!IS_NRDC_SN(ptCi))
                {
                    if (VCCB_IS_SN_TERM_DRB_WITH_ONLY_CHECK_BEARER_TYPE(ptDi) )
                    {
                        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "DRB[%u] is SN-TERM, So Not Collect STAT_DRB_RELEASE !\n", drbIdxInCall);
                    }
                    else
                    {
                        MACRO_STAT_PMCC_DRB(STAT_DRB_RELEASE_AND_ERASE, DrbRelAtt, ptCi, ptDi, 0, 0, 0, 0);
                    }
                }
                break;
            default:
                break;
        }
    }

    // Increase CSL Collect Order
    if(drbSetupStatCslFlag == VCCB_FLAG_ON)
    {
        MACRO_INCREASE_BASIC_CALL_STAT_CSL_COLLECT_ORDER(ptCi);
    }
    ptCi->drbPartialInfo.reqDrbModiOrRelExist = FnVCCB_IsModifyOrReleaseInAllDrb(ptCi);

    return GOOD;
}

int16_t VCCM_SetServCellNum(callInfo_type *ptCi, cgi_type *pNRCGI)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pNRCGI);

    uint16_t cellNum = 0;
    int16_t status = ERROR;

    status = VCCM_GetCellNumFromNrCgi(ptCi->gnbNum, pNRCGI, &cellNum, true);
    if (ERROR == status)
    {
        // Invalid Cell Num(Reject)
        return ERROR;
    }

    const uint16_t oldCellNum = ptCi->servCellNum;
    ptCi->servCellNum = cellNum;
    // - if band is not yet set for example because UE-NR-Capability wasn't available, or
    // - cell is changed, for example due to RRC Reestablishment
    // set servCellBand
    if ((BAND_NOT_FOUND == ptCi->servCellBand) || (oldCellNum != ptCi->servCellNum))
    {
        FnVCCB_SetServCellBand(ptCi);
    }

    UeSpeedState::VCCB_SetCallSpeedStateBasedOnCellSpeedState(*ptCi, ptCi->servCellNum);

    return GOOD;
}

bool VCCM_CheckAnrMnsSchedule(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->servCellNum, MAX_CELL_NUM_VCCB, false);
    VCCB_CHECK_E_RANGE_AND_VAL(ptCi->gnbNum, MAX_GNB_PER_SYS, false);

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    uint16_t mns_duration = pGnb->mnsScheduleInfo.duration;
    uint16_t mns_start_hour = pGnb->mnsScheduleInfo.hour;

    uint8_t schedule[7] = {
        0,
    };

    if (mns_duration < 1 || mns_duration > 24)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Exception : mns_duration:%d has wrong number\n", mns_duration);
        return false;
    }

    if (mns_start_hour > 23)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Exception : mns_start_hour(%d) is not in range\n", mns_start_hour);
        // cout << "Exception : mns_start_hour is not in range" << "\n";
        return false;
    }

    time_t timeThis;
    struct tm sTime_l;
    struct tm *date = &sTime_l;
    uint16_t weekDay = 0;

    // gen dateTime string
    timeThis = time(NULL);
    localtime_r(&timeThis, date);

    for (weekDay = 0; weekDay < 7; weekDay++)
    {
        if (pGnb->mnsScheduleInfo.schedule[weekDay] != 0) break;
    }

    if (weekDay < 7)
    {
        memcpy(schedule, pGnb->mnsScheduleInfo.schedule, sizeof(uint8_t) * 7);
    }
    else
    {
        for (weekDay = 0; weekDay < 7; weekDay++) schedule[weekDay] = ON;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi,
        "check schedule hour(%d) duration(%d) wday(%d/%d/%d/%d/%d/%d/%d) CurrTime(%d:%d(wday:%d))!\n", mns_start_hour,
        mns_duration, schedule[0], schedule[1], schedule[2], schedule[3], schedule[4], schedule[5], schedule[6],
        date->tm_hour, date->tm_min, date->tm_wday);

    if (schedule[date->tm_wday] == ON && date->tm_hour >= mns_start_hour &&
        date->tm_hour < mns_start_hour + mns_duration)
    {
        return true;
    }
    else
    {
        if (date->tm_wday == 0)
        {
            if (schedule[6] == ON && mns_start_hour + mns_duration >= 24 &&
                date->tm_hour < mns_start_hour + mns_duration - 24)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            if (schedule[date->tm_wday - 1] == ON && mns_start_hour + mns_duration >= 24 &&
                date->tm_hour < mns_start_hour + mns_duration - 24)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    /*
    else
    {
        //cout << "Exception : mns_switch has wrong data" << "\n";
        return false;
    }
*/
}

/****************************************************************************
 * @brief           Check schedule for UE Meas For SON
 *
 * @param[in,out]   ptCi :   call information
 * @return          status : GOOD (on schedule or schedule not used), ERROR, BREAK / int16_t
 ****************************************************************************/
int16_t VCCM_CheckUeMeasForSonSchedule(callInfo_type *ptCi, uint32_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    if (VCCB_FLAG_OFF == pCell->measColocInfo.ueMeasSchedule)
    {
        VCCB_PRINT_LOG_UMFS(ptCi, "Schedule is OFF\n");
        return GOOD;
    }

    if (false == VCCM_CheckAnrMnsSchedule(ptCi))
    {
        VCCB_PRINT_LOG_UMFS(ptCi, "Out of MNS schedule\n");
        return BREAK;
    }

    VCCB_PRINT_LOG_UMFS(ptCi, "On MNS schedule\n");

    return GOOD;
}

/****************************************************************************
 * Function      : VCCM_getIdleState
 * Description   :
 * Proc called   :
 * Proc calling  :
 * Input         :
 * Output        :
 * Update History:
 ****************************************************************************/
int VCCM_IsUeIdleState(enumCallType_type callType, enumVccbCallState_type callState)
{
    AUTO_TRACE_FUNC;
    uint8_t isIdleState = FALSE;

    if (E_CALLTYPE_SA == callType)
    {
        switch (callState)
        {
            case STATE_Conn:
                isIdleState = TRUE;
                break;

            default:
                break;
        }
    }
    else  // E_CALLTYPE_NSA
    {
        switch (callState)
        {
            case STATE_DB:
                isIdleState = TRUE;
                break;

            default:
                break;
        }
    }

    return isIdleState;
}

/**
 * @brief Get AMF
 * @param [in] pointer of call information
 */
int16_t VLIB_getAmfFromGuami(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->endPointInfo.ngIdx > MAX_AMF_PER_GNB_CU_CP || ptCi->endPointInfo.ngTnlIdx >= MAX_TNL_PER_AMF)
    {
        if (ERROR == VRRM_AMFSelectionByGuami(ptCi))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VRRM_AMFSelection ERROR!\n");
            // send RRCRelease //TBD coding
            return ERROR;
        }
    }
    else
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Use the same AMF IP. ngIdx(%d) ngTnlIdx(%d)\n", ptCi->endPointInfo.ngIdx,
            ptCi->endPointInfo.ngTnlIdx);
    }

    return GOOD;
}  // }}}

/**
 * @brief Find AMF set of XN Neighbor gNB same as served GUAMI
 * @param [in] pointer of XN Neighbor gNB Information struct
 * @param [in] pointer of GUAMI
 */
uint16_t VHCM_FindSameRegionAmfByServedGuami(xnNbrInfo_type *pNbr, ho_guami_type *pServedGuami)
{  // {{{
    AUTO_TRACE_FUNC;

    uint16_t amfIdx = MAX_AMF_SET_INFO;

    VALID_E_POINT_CHECK_RET_VAL(pNbr, MAX_AMF_SET_INFO);
    VALID_E_POINT_CHECK_RET_VAL(pServedGuami, MAX_AMF_SET_INFO);

    VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION_WO_CALL(
        "[DEBUG-VHCM_FindSameRegionAmfByServedGuami] Start (Mcc/Mnc: %X, regionId: %u)\n", pServedGuami->plmn.longId,
        pServedGuami->amf.regionId);

    /* Search AMF In EndPointXn */
    for (amfIdx = 0; amfIdx < MAX_AMF_SET_INFO; amfIdx++)
    {
        amfSetInformation_type *pAmf = &pNbr->extension.amfSetInfo[amfIdx];

        if (pAmf->status == N_EQUIP) continue;

        VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION_WO_CALL("[%02u] Mcc/Mnc: %u/%u/%X, regionId:%u/%u\n", amfIdx,
            pAmf->present.amfPlmnMcc, pAmf->present.amfPlmnMnc, pAmf->amfPlmn.longId, pAmf->present.amfRegionId,
            pAmf->amfRegionId);

        if (pAmf->present.amfPlmnMcc == OPT_NOT_PRESENT) continue;
        if (pAmf->present.amfPlmnMnc == OPT_NOT_PRESENT) continue;
        if (pAmf->amfPlmn.longId != pServedGuami->plmn.longId) continue;

        if (pAmf->present.amfRegionId == OPT_NOT_PRESENT) continue;
        if (pAmf->amfRegionId != pServedGuami->amf.regionId) continue;

        VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION_WO_CALL("[%02u] Selected Same Region AMF!\n", amfIdx);

        break;
    }

    /* Not Same Served AMF In EndPointXn - Need NG Handover (Inter-AMF Handover) */
    if (amfIdx >= MAX_AMF_SET_INFO)
    {
        amfIdx = MAX_AMF_SET_INFO;
    }

    VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION_WO_CALL(
        "[DEBUG-VHCM_FindSameRegionAmfByServedGuami] End (amfIdx:%u)\n", amfIdx);

    return amfIdx;
}  // }}}

/**
 * @brief Find AMF set of XN Neighbor gNB same as served GUAMI for INTER-PLMN
 * @param [in] pointer of XN Neighbor gNB Information struct
 */
uint16_t VHCM_FindSameRegionAmfByServedGuamiForInterPlmn(callInfo_type *ptCi, xnNbrInfo_type *pNbr)
{  // {{{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;
    uint16_t amf_set_idx = 0, amfIdx = 0;
    supportedAmfSetList_Type servingAmfList;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pNbr);

    VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(ptCi,
        "[DEBUG-VHCM_FindSameRegionAmfByServedGuamiForInterPlmn] Start (selectedTAI:%x)\n",
        ptCi->hoInfo.selectedTAI.plmn.longId);

    /* get serving AMF capability */
    status = VRRM_GetAmfSetList(ptCi, ptCi->endPointInfo.ngIdx, ptCi->servedGuami, &servingAmfList);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed PLMN Selection. (Cause:No Match PLMN in Served Guami)\n");
        return FALSE;
    }

    /* check the selected plmn is available xn handover or not */
    for (amf_set_idx = 0; amf_set_idx < servingAmfList.num_set; amf_set_idx++)
    {
        // Search AMF region list corresponding to selected PLMN in GUAMI List of Serving AMF.
        if (VCOM_CheckPlmnIdentical(&servingAmfList.amf_set_info[amf_set_idx].plmn, &ptCi->hoInfo.selectedTAI.plmn) ==
            FALSE)
            continue;

        VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(
            ptCi, "[%02u] Mcc/Mnc: %X\n", amf_set_idx, servingAmfList.amf_set_info[amf_set_idx].plmn.longId);

        for (amfIdx = 0; amfIdx < MAX_AMF_SET_INFO; amfIdx++)
        {
            amfSetInformation_type *pAmf = &pNbr->extension.amfSetInfo[amfIdx];

            if (pAmf->status == N_EQUIP) continue;

            VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(ptCi,
                "[%02u-%02u] Mcc/Mnc: %u/%u/%X, amfRegionId:%u/%u, servingAmfList.region:%u\n", amf_set_idx, amfIdx,
                pAmf->present.amfPlmnMcc, pAmf->present.amfPlmnMnc, pAmf->amfPlmn.longId, pAmf->present.amfRegionId,
                pAmf->amfRegionId, servingAmfList.amf_set_info[amf_set_idx].region);

            if (pAmf->present.amfPlmnMcc == OPT_NOT_PRESENT) continue;
            if (pAmf->present.amfPlmnMnc == OPT_NOT_PRESENT) continue;
            if (pAmf->present.amfRegionId == OPT_NOT_PRESENT) continue;

            // Check whether selected PLMN AMF region information exists in AMF Set infomration of target gNB
            if (VCOM_CheckPlmnIdentical(&pAmf->amfPlmn, &ptCi->hoInfo.selectedTAI.plmn) == FALSE) continue;
            if (pAmf->amfRegionId != servingAmfList.amf_set_info[amf_set_idx].region) continue;

            VCCB_PRINT_CALL_LOG_PLMN(ptCi, "Allowed PLMN Selection. (amf_set_idx:%u, amfIdx:%u, amfRegionId:%u)\n",
                amf_set_idx, amfIdx, pAmf->amfRegionId);

            // XN handover possible when at least one exists
            return TRUE;
        }
    }

    VCCB_PRINT_CALL_LOG_PLMN(
        ptCi, "Not Allowed PLMN Selection. (Cause:No Match PLMN in AMF Set Information of Target gNB)\n");

    VCCB_PRINT_CALL_SA_HO_TARGET_XN_SELECTION(ptCi, "[DEBUG-VHCM_FindSameRegionAmfByServedGuamiForInterPlmn] End\n");

    return FALSE;
}  // }}}

/**
 * @brief Compare the time value.
 * @param [in] a, b : time information
 * @return -1 : right is bigger
 * @return 1 : left is bigger
 */
int VHCM_DiffTimeVal(struct timeval a, struct timeval b)
{  // {{{
    if (a.tv_sec < b.tv_sec)
    {
        return -1;
    }
    else if (a.tv_sec == b.tv_sec)
    {
        if (a.tv_usec < b.tv_usec)
        {
            return -1;
        }
    }
    return 1;

}  // }}}

/**
 * @brief handle Location reporting procedure AoI
 * @param [in] ptCi :   Call information / callInfo_type
 * @return TRUE
 * @return FALSE
 */
int16_t VCCM_IsTAIInAoI(
    callInfo_type *ptCi, plmnId_type plmn, uint32_t tac, NGAP_UEPresence uEPres, uint8_t *ptrUeAoIChange)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptrUeAoIChange);

    int16_t status = GOOD;
    *ptrUeAoIChange = FALSE;
    unsigned short aoIIndex = 0;
    unsigned short aoITAI = 0;

    for (aoIIndex = 0; aoIIndex < ptCi->locRpt.areaofInterest.noofAoI; aoIIndex++)
    {
        locRptAoIItem_type *aoIItem = &ptCi->locRpt.areaofInterest.aoI[aoIIndex];
        if (aoIItem->numAoITAI > 0)
        {
            for (aoITAI = 0; aoITAI < aoIItem->numAoITAI; aoITAI++)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "AoI-TAI plmnLongId(%d), tac(%d), aoIuePres(%d), plmn-cell(%d), tac-cell(%d) uePres(%d)\n",
                    aoIItem->aOITAI[aoITAI].plmn.longId, aoIItem->aOITAI[aoITAI].tac, aoIItem->uEPresence, plmn.longId,
                    tac, uEPres);

                if ((aoIItem->aOITAI[aoITAI].plmn.longId == plmn.longId) && (aoIItem->aOITAI[aoITAI].tac == tac))
                {
                    if (aoIItem->uEPresence != uEPres)
                    {
                        aoIItem->uEPresence = uEPres;
                        *ptrUeAoIChange = TRUE;
                    }
                }
            }
        }
    }

    return status;
}
/**
 * @brief handle Location reporting procedure AoI
 * @param [in] ptCi :   Call information / callInfo_type
 * @return TRUE
 * @return FALSE
 */
int16_t VCCM_IsNRCGIInAoI(callInfo_type *ptCi, cgi_type cellCGI, NGAP_UEPresence uEPres, uint8_t *ptrUeAoIChange)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptrUeAoIChange);

    int16_t status = GOOD;
    *ptrUeAoIChange = FALSE;
    unsigned short aoIIndex = 0;
    unsigned short aoICGI = 0;
    uint64_t cgiCell = 0;
    uint64_t plmnLongId = 0;

    for (aoIIndex = 0; aoIIndex < ptCi->locRpt.areaofInterest.noofAoI; aoIIndex++)
    {
        locRptAoIItem_type *aoIItem = &ptCi->locRpt.areaofInterest.aoI[aoIIndex];
        if (aoIItem->numAoICell > 0)
        {
            for (aoICGI = 0; aoICGI < aoIItem->numAoICell; aoICGI++)
            {
                cgiCell = 0;
                plmnLongId = 0;

                cgiCell = GET_CELLID_FROM_CGI(aoIItem->aOICell[aoICGI].nGRAN_CgiBitStr);
                plmnLongId = GET_PLMNID_FROM_CGI(aoIItem->aOICell[aoICGI].nGRAN_CgiBitStr);

                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "AoI-CELL plmbLongId(%llu), ci(%llu), AOIuePres(%d), plmn-cell(%d), ci-cell(%llu), uePres(%d)\n",
                    1ULL * plmnLongId, 1ULL * cgiCell, aoIItem->uEPresence, cellCGI.plmn.longId, 1ULL * cellCGI.ci,
                    uEPres);

                if ((plmnLongId == cellCGI.plmn.longId) && (cgiCell == cellCGI.ci))
                {
                    if (aoIItem->uEPresence != uEPres)
                    {
                        aoIItem->uEPresence = uEPres;
                        *ptrUeAoIChange = TRUE;
                    }
                }
            }
        }
    }

    return status;
}
/**
 * @brief handle Location reporting procedure AoI
 * @param [in] ptCi :   Call information / callInfo_type
 * @return TRUE
 * @return FALSE
 */
int16_t VCCM_IsNGRANNODEInAoI(
    callInfo_type *ptCi, vccbGlobalGnbId_type cellRANNodeID, NGAP_UEPresence uEPres, uint8_t *ptrUeAoIChange)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptrUeAoIChange);

    int16_t status = GOOD;
    *ptrUeAoIChange = FALSE;
    unsigned short aoIIndex = 0;
    unsigned short aOIRAN = 0;

    for (aoIIndex = 0; aoIIndex < ptCi->locRpt.areaofInterest.noofAoI; aoIIndex++)
    {
        locRptAoIItem_type *aoIItem = &ptCi->locRpt.areaofInterest.aoI[aoIIndex];
        if (aoIItem->numAoIRANNode > 0)
        {
            for (aOIRAN = 0; aOIRAN < aoIItem->numAoIRANNode; aOIRAN++)
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "AoI-RAN plmbLongId(%d), gnbid(%d), gnbidLength(%d), AoIuePres(%d), "
                    "plmn-cell(%d), gnbid-cell(%d), gnbIdlength-cell(%d), uePres(%d)\n",
                    aoIItem->aOIRAN[aOIRAN].globalRANNodeID.plmn.longId,
                    aoIItem->aOIRAN[aOIRAN].globalRANNodeID.gnbId.id,
                    aoIItem->aOIRAN[aOIRAN].globalRANNodeID.gnbId.idLength, aoIItem->uEPresence,
                    cellRANNodeID.plmn.longId, cellRANNodeID.gnbId.id, cellRANNodeID.gnbId.idLength, uEPres);

                if ((aoIItem->aOIRAN[aOIRAN].globalRANNodeID.plmn.longId == cellRANNodeID.plmn.longId) &&
                    (aoIItem->aOIRAN[aOIRAN].globalRANNodeID.gnbId.id == cellRANNodeID.gnbId.id) &&
                    (aoIItem->aOIRAN[aOIRAN].globalRANNodeID.gnbId.idLength == cellRANNodeID.gnbId.idLength))
                {
                    if (aoIItem->uEPresence != uEPres)
                    {
                        aoIItem->uEPresence = uEPres;
                        *ptrUeAoIChange = TRUE;
                    }
                }
            }
        }
    }

    return status;
}
/**
 * @brief handle Location reporting procedure AoI
 * @param [in] ptCi :   Call information / callInfo_type
 * @return TRUE
 * @return FALSE
 */
int16_t VCCM_ProcessVisitedCellForAoI(callInfo_type *ptCi, uint8_t *ptrUeAoIChange)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptrUeAoIChange);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    VccbCellInfo_type *pTargetCell = NULL;
    const VccbGnbInfo_type *const pGnb = &GNBINFO[pCell->gnbNum];

    *ptrUeAoIChange = FALSE;

    int16_t status = ERROR;
    uint8_t index = 0;
    visitedCellInfo_type *ptVisitedCell = NULL;

    uint32_t tac = 0;
    vccbGlobalGnbId_type globalRANNodeID;
    uint32_t targetCellNum = 0;
    uint16_t nbrIdx = 0;
    uint8_t uEAoIChange_TAI = FALSE;
    uint8_t uEAoIChange_CELL = FALSE;
    uint8_t uEAoIChange_RAN = FALSE;

    /* Visited cell is not incremented in normal scenarios. This can be uncommented once VCCB starts using this.
    if(ptCi->ueHistory.numVisitedCell <= 0)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,"No Visited Cell for the UE (%d)\n", ptCi->locRpt.eventType);
        return GOOD;
    }
*/
    for (index = 0; index < MAX_VISITED_CELL_CSL; index++)
    {
        ptVisitedCell = &ptCi->ueHistory.visitedCell[index];

        VCCB_PRINT_CALL_COMMENT(ptCi, "Visited Cell for the UE (%d)-Usuage(%d)-ratType(%d)\n", index,
            ptVisitedCell->usage, ptVisitedCell->ratType);
        if (ptVisitedCell->usage != CI_use) continue;

        if (ptVisitedCell->ratType != ci_nr) continue;

        // skip the serving cell in visited cell!
        if ((ptVisitedCell->uRat.nrCell.cgi.ci == pCell->cgi.ci) &&
            (ptVisitedCell->uRat.nrCell.cgi.plmn.longId == pGnb->globalGnbId.plmn.longId))
            continue;

        for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)  // go through all the neighbors
        {
            if (N_EQUIP == pCell->Nbr[nbrIdx].status)
            {
                continue;
            }

            if (VCCB_IS_INTRA_GNB_NEIGHBOR(ptCi->servCellNum, nbrIdx))  // relation type INTRA NB
            {
                VCCB_GET_INTRA_GNB_NBR_CELLNUM(ptCi->servCellNum, nbrIdx, targetCellNum);
                if (targetCellNum >= MAX_CELL_NUM_VCCB)
                {
                    continue;
                }
                pTargetCell = &CELLINFO[targetCellNum];
                if (EQUIP != pTargetCell->status)
                {
                    continue;
                }

                VCCB_CHECK_E_RANGE_AND_RETURN(pTargetCell->gnbNum, MAX_GNB_PER_SYS);

                tac = pTargetCell->tac;
                globalRANNodeID = GNBINFO[pTargetCell->gnbNum].globalGnbId;
                break;
            }
            else  // relation type INTER NB
            {
                nbrGnbCellInfo_type *ptNbrGnbCell;
                status = getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &ptNbrGnbCell);
                if (status != GOOD)
                {
                    continue;
                }

                if (N_EQUIP == ptNbrGnbCell->status)
                {
                    continue;
                }

                {
                    if (ptNbrGnbCell->fiveGsTacStatus == EQUIP)
                        tac = ptNbrGnbCell->fiveGsTac;
                    else
                        tac = 0xFFFFFFFF;
                    globalRANNodeID = ptNbrGnbCell->globalGnbId;
                    break;
                }
            }
        }

        // if serving cell cgi ignore the cgi
        // if((ptVisitedCell->uRat.nrCell.cgi.plmn.longId == cellCGI.plmn.longId) &&
        // (aoIItem->aOICell[aoICGI].nGRAN_CGI.ci ==  cellCGI.ci))
        //    continue;

        // if serving cell tai ignore the TAI
        if ((tac == pCell->tac) && (ptVisitedCell->uRat.nrCell.cgi.plmn.longId == pGnb->globalGnbId.plmn.longId))
            continue;

        //  same for rannode of visisted cell is same as serving cell
        if ((pGnb->globalGnbId.plmn.longId == globalRANNodeID.plmn.longId) &&
            (pGnb->globalGnbId.gnbId.id == globalRANNodeID.gnbId.id) &&
            (pGnb->globalGnbId.gnbId.idLength == globalRANNodeID.gnbId.idLength))
            continue;

        VCCB_PRINT_CALL_INFORMATIVE(ptCi,
            "AoI-VisitedCell plmbLongId(%d), tac(%d), ci(%llu), gnbid(%d), gnbidLength(%d), uePres(%d)\n",
            ptVisitedCell->uRat.nrCell.cgi.plmn.longId, tac, 1ULL * ptVisitedCell->uRat.nrCell.cgi.ci,
            globalRANNodeID.gnbId.id, globalRANNodeID.gnbId.idLength, NGAP_out);

        VCCM_IsTAIInAoI(ptCi, ptVisitedCell->uRat.nrCell.cgi.plmn, tac, NGAP_out, &uEAoIChange_TAI);
        VCCM_IsNRCGIInAoI(ptCi, ptVisitedCell->uRat.nrCell.cgi, NGAP_out, &uEAoIChange_CELL);
        VCCM_IsNGRANNODEInAoI(ptCi, globalRANNodeID, NGAP_out, &uEAoIChange_RAN);

        if (uEAoIChange_TAI || uEAoIChange_CELL || uEAoIChange_RAN) *ptrUeAoIChange = TRUE;
    }

    return GOOD;
}
/**
 * @brief handle Location reporting procedure AoI
 * @param [in] ptCi :   Call information / callInfo_type
 * @return TRUE
 * @return FALSE
 */
int16_t VCCM_ProcLocationReportForAoI(callInfo_type *ptCi, uint8_t *ptrUeAoIChange)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptrUeAoIChange);

    int16_t status = GOOD;
    uint8_t uEAoIChange_TAI = FALSE;
    uint8_t uEAoIChange_CELL = FALSE;
    uint8_t uEAoIChange_RAN = FALSE;
    uint8_t uEAoIChange_visited = FALSE;
    *ptrUeAoIChange = FALSE;

    if (ptCi->locRpt.reportOn == CI_no_use)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "location rep off (%d)\n", ptCi->locRpt.reportOn);
        return GOOD;
    }
    if (ptCi->locRpt.eventType != ci_5g_Rpt_UE_in_AoI)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "location rep type not AoI (%d)\n", ptCi->locRpt.eventType);
        return GOOD;
    }

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];
    VCCB_CHECK_E_RANGE_AND_RETURN(pCell->gnbNum, MAX_GNB_PER_SYS);

    cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(ptCi->servCellNum);

    VCCM_IsTAIInAoI(ptCi, cgi.plmn, pCell->tac, NGAP_in, &uEAoIChange_TAI);
    VCCM_IsNRCGIInAoI(ptCi, cgi, NGAP_in, &uEAoIChange_CELL);
    VCCM_IsNGRANNODEInAoI(ptCi, GNBINFO[pCell->gnbNum].globalGnbId, NGAP_in, &uEAoIChange_RAN);

    if (uEAoIChange_TAI || uEAoIChange_CELL || uEAoIChange_RAN) *ptrUeAoIChange = TRUE;
    // Visited cell
    status = VCCM_ProcessVisitedCellForAoI(ptCi, &uEAoIChange_visited);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_ProcessVisitedCellForAoI ERROR!\n");
    if ((uEAoIChange_visited == TRUE) || (*ptrUeAoIChange == TRUE)) *ptrUeAoIChange = TRUE;

    return status;
}

/**
 * @brief handle Location report after RRC Reconfig Complete For Intra GNB HO
 * @param [in] ptCi :   Call information / callInfo_type
 * @return TRUE
 * @return FALSE
 */
int16_t VCCM_HandleIntragNBHO_LocationReportAoI_OnRRCReconfComplete(callInfo_type *ptCi, uint8_t *ptrUeAoIChange)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptrUeAoIChange);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    int16_t status = GOOD;
    *ptrUeAoIChange = FALSE;
    uint8_t uEAoIChange_TAI = FALSE;
    uint8_t uEAoIChange_CELL = FALSE;
    uint8_t uEAoIChange_RAN = FALSE;

    if (ptCi->locRpt.reportOn == CI_no_use)
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "location rep off (%d)\n", ptCi->locRpt.reportOn);
        return status;
    }
    if (!(ptCi->locRpt.eventType == ci_5g_Rpt_UE_in_AoI))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "location rep type not AoI(%d)\n", ptCi->locRpt.eventType);
        return status;
    }

    {
        cgi_type cgi = FnVCCB_GetNrcgiFromCellNum(ptCi->servCellNum);

        VCCM_IsTAIInAoI(ptCi, cgi.plmn, pCell->tac, NGAP_out, &uEAoIChange_TAI);
        VCCM_IsNRCGIInAoI(ptCi, cgi, NGAP_out, &uEAoIChange_CELL);
        VCCM_IsNGRANNODEInAoI(ptCi, GNBINFO[pCell->gnbNum].globalGnbId, NGAP_out, &uEAoIChange_RAN);

        if (uEAoIChange_TAI || uEAoIChange_CELL || uEAoIChange_RAN) *ptrUeAoIChange = TRUE;
    }
    /*
    if((TRUE == uEAoIChange) ||
            (ptCi->locRpt.eventType == ci_5g_Rpt_change_of_serve_cell) || (ptCi->locRpt.eventType == ci_5g_Rpt_direct))
    {
        status = MsgNgapSender::createMessageSender(ptCi, NG_LocationReportAllAmf_id)->sendMsg();
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "sendMsg(NG_LocationReportAllAmf) ERROR !!\n");
            ptCi->locRpt.reportOn = CI_no_use;
            return ERROR;
        }
        if((ptCi->locRpt.eventType == ci_5g_Rpt_direct))
            ptCi->locRpt.reportOn = CI_no_use;
    }
*/

    return status;
}

int VCCM_CheckN26Support(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->endPointInfo.ngIdx, MAX_AMF_PER_GNB_CU_CP);

    // This value is considered valid because the UE is in service. AMF Status and serviceState
    if (TRUE != CFG->amf.amfN26Support[ptCi->gnbNum][ptCi->endPointInfo.ngIdx])
    {
        return ERROR;
    }

    return GOOD;

}  // }}}

int16_t VCCM_CompareNbrSmtc1Condition(const smtc1_type *ptSmtc, nbrGnbCellInfo_type *pNbrGnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptSmtc);
    VALID_E_POINT_CHECK_ERROR(pNbrGnbCell);

    if (CI_use == pNbrGnbCell->smtcStatus)
    {
        // NR_CONN_MC_23A modified
        // As of 23A Pkg, the gNB shall select a cell which has the same 'offset' of the SSB-MTC in MeasObjectNR.
        if (pNbrGnbCell->smtc1.periodicityAndOffset.offset != ptSmtc->periodicityAndOffset.offset)  // NR_CONN_MC_23A
        {
            VCCB_PRINT_COMMENT("Different pNbrGnbCell.offset:%u MO.offset:%u - Not eligible for Tgt\n",
                pNbrGnbCell->smtc1.periodicityAndOffset.offset, ptSmtc->periodicityAndOffset.offset);
            return ERROR;
        }
    }

    return GOOD;
}

/**
 * @brief Check Serving Cell duplexType
 * @param [in] ptCi : Call information / callInfo_type
 * @param [out] 0xFF : fail to get duplexType
 * @param [out] ci_DUPLEXTYPE_FDD
 * @param [out] ci_DUPLEXTYPE_TDD
 */
uint16_t VCCM_GetNrCellDuplexType(callInfo_type *ptCi, uint16_t cellNum)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, 0xFF);
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, 0xFF);

    uint16_t duplexType;
    uint16_t nRFrequencyBand = 0;

    nRFrequencyBand = VLIB_GetFreqBandIndForCellNum(ptCi, cellNum);
    if (0 == nRFrequencyBand)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "VCCM_GetNrCellDuplexType : Cannot get common FreqBandInd for cellNum(%u)!!\n", cellNum);
        return 0xFF;
    }
    duplexType = FnVCCB_GetNrDuplexTypeByBandIndicator(nRFrequencyBand);

    return duplexType;
}  // }}}

int VCCM_CheckUeCapaForHandoverToLTE(callInfo_type *ptCi, uint16_t cellNum)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *ptCell = &CELLINFO[cellNum];

    // FRX handoverEPC capa check
    if (ptCell->nrArfcnDl < MIN_A6_NR_ARFCN)
    {
        if (TRUE != ptCi->ueInfo.ueCapa.nr.fr1Capa.measAndMob.handoverLTE_EPC)
        {
            return ERROR;
        }
    }
    else
    {
        if (TRUE != ptCi->ueInfo.ueCapa.nr.fr2Capa.measAndMob.handoverLTE_EPC)
        {
            return ERROR;
        }
    }
    uint16_t duplexType = 0;
    uint16_t nRFrequencyBand = 0;
    nRFrequencyBand = VLIB_GetFreqBandIndForCell(ptCi, ptCell);
    if (BAND_NOT_FOUND == nRFrequencyBand)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "CA: Cannot get common FreqBandInd for cellNum(%u)!!\n", cellNum);
        return ERROR;
    }
    duplexType = FnVCCB_GetNrDuplexTypeByBandIndicator(nRFrequencyBand);
    if (ci_DUPLEXTYPE_FDD == duplexType)
    {
        if (TRUE != ptCi->ueInfo.ueCapa.nr.fddCapa.measAndMob.handoverLTE_EPC)
        {
            return ERROR;
        }
    }
    else if (ci_DUPLEXTYPE_TDD == duplexType)
    {
        if (TRUE != ptCi->ueInfo.ueCapa.nr.tddCapa.measAndMob.handoverLTE_EPC)
        {
            return ERROR;
        }
    }
    else
    {
        return ERROR;
    }

    return GOOD;
}  // }}}

uint8_t VCCM_getUeLongDrxCycleCapa(callInfo_type *ptCi, uint16_t cellNum)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    uint8_t longDRX_Cycle = FALSE;

    uint16_t duplexType = VCCM_GetNrCellDuplexType(ptCi, cellNum);
    if (ci_DUPLEXTYPE_FDD == duplexType)
    {
        longDRX_Cycle = ptCi->ueInfo.ueCapa.nr.fddCapa.mac.longDRX_Cycle;
        VCCB_PRINT_CALL_COMMENT(ptCi, "VCCM_getUeLongDrxCycleCapa : nr.fddCapa.mac.longDRX_Cycle(%ums)\n",
            FnVCCB_GetLongDrxCycleTime(static_cast<enumVccbLongDrxCycle_type>(longDRX_Cycle)));
    }
    else if (ci_DUPLEXTYPE_TDD == duplexType)
    {
        longDRX_Cycle = ptCi->ueInfo.ueCapa.nr.tddCapa.mac.longDRX_Cycle;
        VCCB_PRINT_CALL_COMMENT(ptCi, "VCCM_getUeLongDrxCycleCapa : nr.tddCapa.mac.longDRX_Cycle(%ums)\n",
            FnVCCB_GetLongDrxCycleTime(static_cast<enumVccbLongDrxCycle_type>(longDRX_Cycle)));
    }

    return longDRX_Cycle;
}  // }}}

/**
 * @brief Check UE and Cell handover to EPC supportness
 * @param [in] ptCi : Call information / callInfo_type
 * @param [out] GOOD : ue and cell can support handover to EPC
 * @param [out] ERROR : ue and cell cannot support handover to EPC
 */
int VCCM_IsIratHandoverCondition(callInfo_type *ptCi)
{  // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (VCCB_FLAG_ON != ptCi->ueContainerEUTRA.rxFlag)
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "The UE doesn't support handover to EPC, there is no UE Eutra Capa!! (%u)\n",
            (unsigned)ptCi->ueContainerEUTRA.rxFlag);
        return ERROR;
    }

    if (GOOD != VCCM_CheckN26Support(ptCi))
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "The UE doesn't support handover to EPC n26 interface doesn't Support (%u/%u)!!\n",
            (unsigned)ptCi->gnbNum, (unsigned)ptCi->endPointInfo.ngIdx);
        return ERROR;
    }

    if (GOOD != VCCM_CheckUeCapaForHandoverToLTE(ptCi, ptCi->servCellNum))
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "The UE doesn't support handover to EPC ueCapa doesn't Support!!\n");
        return ERROR;
    }

    if (IS_FALLBACK_CASE(ptCi) && (ptCi->numPDUSess == 0))
    {
        VCCB_PRINT_CALL_CRITICAL(
            ptCi, "There is no PDU session. So MR Based redirection will be triggered instead of HO!!\n");
        return ERROR;
    }
    if (IS_FALLBACK_CASE(ptCi) && GOOD == CheckPDUSessionExistencewithUPIntegritySupported(ptCi))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi,
            " For all PDU Sessions UPIntegritySupported is set to required\n");
        return ERROR;
    }

    if (TRUE == FnVCCB_IsNrToEutraHoNotAllowedFromSvcGrp(ptCi))  // NR_CON_MC_22C2
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "nr-to-eutra-handover-not-allowed. So Redirection triggered Not HO!!\n");
        return ERROR;
    }

    return GOOD;
}  // }}}

/**
 * @brief Get aMF_UE_NGAP_ID from ptUnpack for sending Error Indication
 * @param [in] pointer of callInfo_type
 */
uint64_t VCCB_GetAmfUeNgapId(msgUnpack_type *ptUnpack)
{
    AUTO_TRACE_FUNC;

    uint64_t ngCallId = UINT64_MAX;

    VALID_E_POINT_CHECK_RET_VAL(ptUnpack, ngCallId);
    NG_UEContextReleaseCommandAmfAll_type *ptMsg = NULL;

    switch (ptUnpack->msgId)
    {
        case NG_DownlinkNASTransportAmfAll_id:
            ngCallId = (reinterpret_cast<NG_DownlinkNASTransportAmfAll_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_PDUSessionResourceSetupRequest_id:
            ngCallId = (reinterpret_cast<NG_PDUSessionSetupRequest_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_PDUSessionResourceReleaseCommand_id:
            ngCallId = (reinterpret_cast<NG_PDUSessionReleaseCommand_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_PDUSessionResourceModifyRequest_id:
            ngCallId = (reinterpret_cast<NG_PDUSessionModifyRequest_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_PDUSessionResourceModifyConfirm_id:
            ngCallId = (reinterpret_cast<NG_PDUSessionResourceModifyConfirm_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_InitialContextSetupRequestAmfAll_id:
            ngCallId = (reinterpret_cast<NG_InitialContextSetupRequestAmfAll_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_UEContextModificationRequestAmfAll_id:
            ngCallId =
                (reinterpret_cast<NG_UEContextModificationRequestAmfAll_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_HandoverCommandAmfGnb_id:
            ngCallId = (reinterpret_cast<NG_HandoverCommandAmfGnb_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_HandoverPreparationFailureGnbAmf_id:
            ngCallId = (reinterpret_cast<NG_HandoverPreparationFailureAmfGnb_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_HandoverRequestAmfgnb_id:
            ngCallId = (reinterpret_cast<NG_HandoverRequestAmfgnb_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_PathSwitchRequestAcknowledgeAmfGnb_id:
            ngCallId =
                (reinterpret_cast<NG_PathSwitchRequestAcknowledgeAmfGnb_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_PathSwitchRequestFailureAmfGnb_id:
            ngCallId = (reinterpret_cast<NG_PathSwitchRequestFailureAmfGnb_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_HandoverCancelAcknowledgeAmfGnb_id:
            ngCallId = (reinterpret_cast<NG_HandoverCancelAcknowledgeAmfGnb_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_DownlinkRANStatusTransferAmfAll_id:
            ngCallId = (reinterpret_cast<NG_DownlinkRANStatusTransferAmfAll_type *>(ptUnpack->unpack))->aMF_UE_NGAP_ID;
            break;
        case NG_UEContextReleaseCommandAmfAll_id:
            ptMsg = reinterpret_cast<NG_UEContextReleaseCommandAmfAll_type *>(ptUnpack->unpack);
            if (ptMsg->uE_NGAP_IDs.choice == NGAP_uE_NGAP_ID_pair_chosen)
            {
                ngCallId = ptMsg->uE_NGAP_IDs.u.uE_NGAP_ID_pair.aMF_UE_NGAP_ID;
            }
            else
            {
                ngCallId = ptMsg->uE_NGAP_IDs.u.aMF_UE_NGAP_ID;
            }
            break;
        default:
            // aMF_UE_NGAP_ID will not be used when sending Error Indication to AMF.
            break;
    }

    return ngCallId;
}

int16_t VCCM_CheckAcceptDownlinkNASTransportDuringHO(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (VHCM_isSaHandoverUE(ptCi) == TRUE)
    {
        // The handover command is transmitted to the UE and cannot be transmitted until the handover complete is
        // received.
        if (!GET_RRC_CONNECTION_FLAG(ptCi->flag.setupFlag))
        {
            return ERROR;
        }
    }

    return GOOD;
}

/**
 * @brief Check acceptable call state for handling NgapDownlinkNASTransport
 * @param [in] pointer of callInfo_type
 */
int16_t VCCM_CheckAcceptDownlinkNASTransport(
    callInfo_type *ptCi, NG_DownlinkNASTransportAmfAll_type *ptDlNas, uint16_t *ptCause)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptDlNas);
    VALID_E_POINT_CHECK_ERROR(ptCause);
    // For Supporting FR200 of FGR-CC3101(Basic Operation for NR SA)
    // gNB shall support NG-C NAS Non Delivery Indication procedure.

    // 1) After sending Handover Command to UE
    if (GOOD != VCCM_CheckAcceptDownlinkNASTransportDuringHO(ptCi))
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "%s: During HO procedure!\n", __FUNCTION__);
        switch (ptCi->hoInfo.hoType.initiated)
        {
            case HO_TYPE_SA_INTER_SYSTEM_INTER_RAT_HANDOVER:
                *ptCause = CauseNgapRadioNetworkLayerNgInterSystemHandoverTriggered;
                break;

            case HO_TYPE_SA_INTER_GNB_XN_HANDOVER:
                *ptCause = CauseNgapRadioNetworkLayerXnHandoverTriggered;
                break;

            case HO_TYPE_SA_INTRA_GNB_INTER_DU_HANDOVER:
            case HO_TYPE_SA_INTRA_GNB_INTRA_DU_HANDOVER:
            case HO_TYPE_SA_INTRA_SYSTEM_INTER_RAT_HANDOVER:
            case HO_TYPE_SA_INTER_GNB_NG_HANDOVER:
            default:
                *ptCause = CauseNgapRadioNetworkLayerNgIntraSystemHandoverTriggered;
                break;
        }

        return ERROR;
    }

    // 2) Cell Change due to inter-gNB RRE
    if ((ptCi->stateCmd == RrcReestablish_cmd) &&
        (ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_GNB) &&
        (ptCi->ueInfo.reestablishInfo.isTargetGnb == FALSE))
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "%s: During inter-gNB RRE procedure!\n", __FUNCTION__);
        *ptCause = CauseNgapRadioNetworkLayerCellNotavailable;

        return ERROR;
    }

    // 3) When receiving F1 UE Context Modification Required with Radio Link Failure of gNB, RLC Max Retransmission of
    // gNB
    if ((ptCi->cause.callFault.callFaultCause == CauseCpInternalDuRlcMaxNumRetx) ||
        (ptCi->cause.callFault.callFaultCause == CauseCpInternalDuULRadioLinkFailure) ||
        (ptCi->rlfHandlingTimer.id > 0))
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "%s: During RLF procedure!\n", __FUNCTION__);
        *ptCause = CauseNgapRadioNetworkLayerRadioConnectionWithUeLost;

        return ERROR;
    }

    // 4) at the source-gNB in the inter-gNB Resume procedure
    if (RESUME_TYPE_INTER_GNB_SOURCE == ptCi->ueInfo.rrcResumeInfo.resumeType)
    {
        VCCB_PRINT_CALL_CRITICAL(ptCi, "%s: During Inter-gNB Resume procedure! (@source-gNB)\n", __FUNCTION__);
        *ptCause = CauseNgapRadioNetworkLayerUeInRrcInactiveStateNotReachable;

        return ERROR;
    }

    return GOOD;
}

int16_t VCCM_BackupDbForRreFailure(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (ptCi->ueInfo.reestablishInfo.firstOldCellFlag == VCCB_FLAG_ON)
    {
        ptCi->ueInfo.reestablishInfo.firstOldCellNum = ptCi->servCellNum;
        ptCi->ueInfo.reestablishInfo.firstOldCellFlag = VCCB_FLAG_OFF;
    }

    ptCi->ueInfo.reestablishInfo.oldCellNum = ptCi->servCellNum;  // Record the cell before RRE occurs.
    ptCi->ueInfo.reestablishInfo.oldCellBand = ptCi->servCellBand;
    ptCi->ueInfo.reestablishInfo.oldDuUeId = ptCi->auCallId;
    ptCi->ueInfo.reestablishInfo.oldF1Idx = ptCi->endPointInfo.f1Idx;

    return GOOD;
}

int16_t VCCM_RestoreDbForRreFailure(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    ptCi->servCellNum = ptCi->ueInfo.reestablishInfo.oldCellNum;  // Record the cell before RRE occurs.
    ptCi->nRCGI = FnVCCB_GetNrcgiFromCellNum(ptCi->ueInfo.reestablishInfo.oldCellNum);
    ptCi->servCellBand = ptCi->ueInfo.reestablishInfo.oldCellBand;
    ptCi->auCallId = ptCi->ueInfo.reestablishInfo.oldDuUeId;
    ptCi->endPointInfo.f1Idx = ptCi->ueInfo.reestablishInfo.oldF1Idx;

    return GOOD;
}

void VCCM_SetPrevStateForRreDuringPDUChg(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    for (int pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        if (CI_use != ptCi->pduSess[pduIdx].usage) continue;
        if (S_Modify != ptCi->pduSess[pduIdx].pduSessStatus) continue;

        if(S_Idle == ptCi->pduSess[pduIdx].prevPduSessStatus && S_Modify == ptCi->pduSess[pduIdx].pduSessStatus)
        {
            ptCi->pduSess[pduIdx].prevPduSessStatus = S_Modify;
        }
    }
}
/**
 * @brief Check acceptable call state for RRC Reestablish
 * @param [in] pointer of callInfo_type
 */
int16_t VCCM_CheckAcceptRRE(callInfo_type *ptCi, enumReestablishType_type rreType)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int16_t result = ERROR;
    enumVccbCallState_type state;
    uint8_t oldCallReestablishType = ptCi->ueInfo.reestablishInfo.reestablishType;

    if (STATE_RLF_WaitRRE == ptCi->state)
    {
        state = ptCi->prevFnState;
    }
    else
    {
        state = ptCi->state;
    }

    if (IS_MRDC_MN(ptCi))
    {
        switch (state)
        {
            case STATE_Conn:
                result = GOOD;
                break;

            default:
                result = ERROR;
                break;
        }
    }
    else
    {
        switch (state)
        {
            // case STATE_I2E:
            // case STATE_Est:
            // case STATE_E2C_RRCRecCmpl: // In case of Initial Attach, the bearer is not set up yet.
            case STATE_Conn:
            case STATE_Anr_RrcConfig:
                result = GOOD;
                break;

            case STATE_RRE_RRCRecCmpl:
                if(PDUSetup_cmd == ptCi->prevStateCmd || PDUModify_cmd == ptCi->prevStateCmd || PDURelease_cmd == ptCi->prevStateCmd)
                {
                     result = ERROR;
                }
                // case STATE_RLF_WaitRRE: // state would be ptCi->prevFnState.
                else
                {
                    result = GOOD;
                }
                break;

            case STATE_PDUChg_RRCRecCmpl:
                if(IS_EPS_FALLBACK_CASE(ptCi))
                {
                    result = ERROR;
                }
                else
                {
                    VCCM_SetPrevStateForRreDuringPDUChg(ptCi);
                    ptCi->bitFlag.isPartialDrbForRreDuringPduChg = VCCB_FLAG_ON;    
                    result = GOOD;
                }
                break;

            case STATE_RRE_RreCmpl:
                if ((RRE_TYPE_INTRA_DU == oldCallReestablishType) || (RRE_TYPE_INTER_DU == oldCallReestablishType))
                {
                    if(PDUSetup_cmd == ptCi->prevStateCmd || PDUModify_cmd == ptCi->prevStateCmd || PDURelease_cmd == ptCi->prevStateCmd)
                    {
                         result = ERROR;
                    }
                    // In case of Inter gNB RRE STATE_RRE_RreCmpl, the bearer is not set up yet.
                    // Only Intra gNB RRE accepted.
                    else
                    {
                        result = GOOD;
                    }
                }
                break;

            /* Inter gNB Serving - INTER-GNB (Source) PREPARE */
            case STATE_INTER_Pre_DU_S:
            case STATE_INTER_Pre_CU_S:
            case STATE_INTER_Exe_S:
            case STATE_INTER_SeqNum_S:
            case STATE_INTER_Compl_S:
                result = GOOD;
                break;

            /* Inter gNB Target - INTER-GNB (Target) EXCUTE ~ */
            // case STATE_INTER_Pre_UP_T:
            // case STATE_INTER_Pre_DU_T:
            case STATE_INTER_Exe_T:
            case STATE_INTER_Switch_T:
            case STATE_INTER_Compl_T:
                if (HO_TYPE_XN == ptCi->hoInfo.hoType.interface)
                {
                    if (ptCi->security.newSecurityContextChangeInd == FALSE) 
                    {
                        ptCi->bitFlag.isPartialDrbForRreDuringHo = VCCB_FLAG_ON;    
                        result = GOOD;
                    }
                }
                break;

            /* Intra gNB, Inter DU - INTRA-GNB (INTER_DU) EXCUTE ~ */
            case STATE_INTER_DU_Prepare:
            case STATE_INTER_DU_Exe_T:
            case STATE_INTER_DU_Execution:
            case STATE_INTER_DU_Complete:
                ptCi->bitFlag.isPartialDrbForRreDuringHo = VCCB_FLAG_ON;    
                result = GOOD;
                break;

            /* Intra gNB, Intra DU - INTRA-GNB (INTRA-DU) ALL OK */
            case STATE_INTRA_DU_Prepare:
            case STATE_INTRA_DU_Execution:
            case STATE_INTRA_DU_Complete:
            case STATE_INTRA_DU_Cancel:
                ptCi->bitFlag.isPartialDrbForRreDuringHo = VCCB_FLAG_ON;    
                result = GOOD;
                break;

            case STATE_Conn_UeNrCapa:    
                if (VCCB_FLAG_ON == ptCi->supportRreDuringUeCapaEnquiry)
                {
                    result = GOOD;
                }
                break;

                /* Intra gNB, Intra Cell - INTRA-GNB (INTRA-CELL) ALL OK */
                /*
            // TODO : check UP supports RRE during key change.
            case STATE_Intra_Cell_Prepare:
            case STATE_Intra_Cell_Execution:
            case STATE_INTRA_Cell_Complete:
                result = GOOD;
                break;
    */
            default:
                result = ERROR;
                break;
        }
    }

    if (GOOD == result)
    {
        // SVR22B FGR-CC5203: Deconfigure A4 for SCG resume and Update MeasConfig
        ptCi->nrdcScgFailureInfo.A4Configured = VCCB_FLAG_OFF;

        // SVR25B FGR-CC0102 RRC Fallback for LTM RRE
        if ((RRE_TYPE_INTRA_DU == rreType || RRE_TYPE_INTER_DU == rreType) && (ptCi->ltmUeInfo.numOfCellList > 0)) 
        {
            return ERROR;
        }
    }

    return result;
}

/**
 * @brief This function determines whether there is Non-GBR Qos Flow in the PDU Session.
 * @param [in] pointer of callInfo_type
 * @param [in] pointer of callPDUSessInfo_type
 */
int16_t VCCM_CheckNonGbrQosFlowInPduSession(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptPi);

    uint32_t loop = 0;
    qosFlowInfo_type *ptQi = NULL;

    for (loop = 0; loop < MAX_QOS_FLOW_PER_PDU_SESS; loop++)
    {
        uint8_t qosFlowIdx = static_cast<uint8_t>(ptPi->qosFlowIndex[loop]);

        // valid check
        if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL) continue;

        ptQi = &ptCi->qosFlow[qosFlowIdx];

        if (ptQi->usage != CI_use) continue;

        if (VLIB_IsCommonValidStateOfPduQosDrb(ptQi->qosFlowStatus) != GOOD) continue;

        // If the GBR parameter does not exist, it is regarded as Non-GBR.
        if (ptQi->qosParam.gbrQosInformationPresent == OPT_NOT_PRESENT)
        {
            return TRUE;
        }
    }

    return FALSE;
}

/**
 * @brief When calculating AMBR, this function checks whether PDU is activated.
 * @param [in] pointer of callPDUSessInfo_type
 */
int VCCM_CheckActivatedPduForAMBR(callInfo_type *ptCi, callPDUSessInfo_type *ptPi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptPi);

    if (ptPi->usage != CI_use) goto DEACTIVATED_PDU;

    switch (ptPi->pduSessStatus)
    {
        // Aloowed PDU Sess Status
        case S_Setup:
        case S_Modify:
        case S_Idle:
        case S_FailToModify:  // For restore operation in case of Modify failure.
            break;

        // Not Allowed PDU Sess Status
        default:
            goto DEACTIVATED_PDU;
    }

    // For the AMBR feature, at least one Non-GBR Qos Flow must exist.
    if (VCCM_CheckNonGbrQosFlowInPduSession(ptCi, ptPi) == FALSE)
    {
        goto DEACTIVATED_PDU;
    }

    return TRUE;

DEACTIVATED_PDU:
    return FALSE;
}

/**
 * @brief Provides an action to output a warning according to the AMBR value.
 * @param [in] pointer of callInfo_type
 */
void VCCM_WarningPrint_SA_UE_AMBR(callInfo_type *ptCi, enumNrInterface_type interface, uint64_t dl, uint64_t ul)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    char *pFrom = (char*)"AMF";

    // Get From Log
    if (interface == interface_xn)
    {
        if (IS_NRDC_SN(ptCi))
        {
            if (VHCM_isSaHandoverUE(ptCi) == TRUE)
                pFrom = (char*)"Source-SN";
            else
                pFrom = (char*)"MN";
        }
        else
        {
            if (VHCM_isSaHandoverUE(ptCi) == TRUE)
                pFrom = (char*)"Source-gNB";
            else
                pFrom = (char*)"Old-gNB";
        }
    }

    // Check Zero Condition
    bool dlCheck = true;

    if (IS_NRDC_SN(ptCi))
    {
        callDRBInfo_type *ptDi;
        uint8_t dIdx = 0;
        bool isAllMnTermSplitBearer = true;

        for (dIdx = 0; dIdx < MAX_DRB_PER_SA_CALL; dIdx++)
        {
            ptDi = &ptCi->drb[dIdx];

            if (ptDi->drbStatus == S_Release || ptDi->drbStatus == S_FailToSetup || ptDi->drbStatus == S_RelToModify)
                continue;

            uint8_t bearerType = FnVCCB_getSaDrbBearerType(ptCi, ptDi, current_bearerType);

            if (bearerType != MN_Term_SPLIT_Bearer)
            {
                isAllMnTermSplitBearer = false;
            }
        }

        if (isAllMnTermSplitBearer == true)
        {
            dlCheck = false;
        }
    }

    // Check
    if ((dlCheck == true && dl == 0) || (ul == 0))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Warning: VCCB have received a UE-AMBR value of DL(%lld)/UL(%lld) from %s.\n",
            1ULL * dl, 1ULL * ul, pFrom);
    }
}

/**
 * @brief Determines UE AMBR from pduSession and subscribed AMBR values
 * @param [in] pointer of callInfo_type
 */
void VCCM_DetermineSA_UE_AMBR(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    const uint64_t prev_aggrMbrDl = ptCi->ueInfo.ambr.aggrMbrDl;
    const uint64_t prev_aggrMbrUl = ptCi->ueInfo.ambr.aggrMbrUl;
    // Check Lisense
    if (FOO.VF_UeAmbrSupport_SA == FALSE)
    {
        // Select Subscribed UE-AMBR received from Core.
        ptCi->ueInfo.ambr.aggrMbrDl = ptCi->ueInfo.ambr.subAmbrDl;
        ptCi->ueInfo.ambr.aggrMbrUl = ptCi->ueInfo.ambr.subAmbrUl;
        if (prev_aggrMbrDl != ptCi->ueInfo.ambr.aggrMbrDl)
        {
            SET_NEED_TO_MODIFY_DL_UEAMBR(ptCi, VCCB_FLAG_ON);
        }

        if (prev_aggrMbrUl != ptCi->ueInfo.ambr.aggrMbrUl)
        {
            SET_NEED_TO_MODIFY_UL_UEAMBR(ptCi, VCCB_FLAG_ON);
        }

        return;
    }

    // sum of the Session-AMBR of active PDU sessions
    uint8_t existNonGbrPduSession = FALSE;
    uint64_t actPduSessDlAmbr = 0;
    uint64_t actPduSessUlAmbr = 0;
    int pduSessI = 0;
    for (pduSessI = 0; pduSessI < MAX_PDU_SESS_PER_CALL; ++pduSessI)
    {
        // Only the PDUs required for AMBR summation are judged.
        if (VCCM_CheckActivatedPduForAMBR(ptCi, &ptCi->pduSess[pduSessI]) == FALSE) continue;

        // If the NonGBR parameter does not exist, it is ignored.
        if (ptCi->pduSess[pduSessI].pduSessAmbrPresent == OPT_NOT_PRESENT) continue;

        actPduSessDlAmbr += ptCi->pduSess[pduSessI].pduSessAmbrDL;
        actPduSessUlAmbr += ptCi->pduSess[pduSessI].pduSessAmbrUL;

        // If the PDU summing operation is successful even once, it is set to TRUE.
        existNonGbrPduSession = TRUE;
    }

    // Subscribed UE-AMBR
    uint64_t sDlAmbr = ptCi->ueInfo.ambr.subAmbrDl;
    uint64_t sUlAmbr = ptCi->ueInfo.ambr.subAmbrUl;

    // Determine the UE-AMBR value.
    if (existNonGbrPduSession == FALSE)
    {
        // not exist 'Non-GBR' Qos Flow . select UE-AMBR.

        ptCi->ueInfo.ambr.aggrMbrDl = sDlAmbr;
        ptCi->ueInfo.ambr.aggrMbrUl = sUlAmbr;
    }
    else
    {
        // Determine UE-AMBR, UE-AMBR = min[Subscribed UE-AMBR, sum of the Session-AMBR of active PDU sessions]

        ptCi->ueInfo.ambr.aggrMbrDl = MIN(sDlAmbr, actPduSessDlAmbr);
        ptCi->ueInfo.ambr.aggrMbrUl = MIN(sUlAmbr, actPduSessUlAmbr);
    }

    if (prev_aggrMbrDl != ptCi->ueInfo.ambr.aggrMbrDl)
    {
        SET_NEED_TO_MODIFY_DL_UEAMBR(ptCi, VCCB_FLAG_ON);
    }

    if (prev_aggrMbrUl != ptCi->ueInfo.ambr.aggrMbrUl)
    {
        SET_NEED_TO_MODIFY_UL_UEAMBR(ptCi, VCCB_FLAG_ON);
    }
}

/**
 * @brief Recalculate AMBR value according to confD configuration.
 * @param [in] pointer of callInfo_type
 * @param [in,out] pointer of recalculated value
 */
void VCCM_RecalculateUeAmbrValueForMultiUp(callInfo_type *ptCi, uint16_t endPointIdx, uint64_t *pAmbr)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(pAmbr);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint8_t loop;
    uint32_t proportionSum = 0;
    uint32_t proportionThisUp = 0;
    uint64_t ambr = *pAmbr;

    const VccbGnbInfo_type *const pGnb = &GNBINFO[ptCi->gnbNum];

    if (ptCi->endPointInfo.srvAupfNum <= 1)
    {
        return;
    }

    if (E_CALLTYPE_NSA == ptCi->callType)
    {
        switch (pGnb->aupf.ambrAupfDistributionENDC)
        {
            case AmbrEndcAupfDistribution_equalDistribution:
                ambr = ptCi->endPointInfo.srvAupfNum > 0 ? ambr / ptCi->endPointInfo.srvAupfNum : ambr;
                break;
            case AmbrEndcAupfDistribution_proportionalToNumOfBearers:
                for (loop = 0; loop < MAX_ERAB_PER_CALL; loop++)
                {
                    if (CI_use == ptCi->erabInfo[loop].usage && ERAB_Release != ptCi->erabInfo[loop].erabStatus)
                    {
                        proportionSum++;
                        if (endPointIdx == ptCi->erabInfo[loop].e1Idx)
                        {
                            proportionThisUp++;
                        }
                    }
                }
                ambr = proportionSum ? (ambr * proportionThisUp) / proportionSum : ambr;
                break;
            case AmbrEndcAupfDistribution_proportionalToWeightFactorsPerPlmnQci:
                for (loop = 0; loop < MAX_ERAB_PER_CALL; loop++)
                {
                    if (CI_use == ptCi->erabInfo[loop].usage && ERAB_Release != ptCi->erabInfo[loop].erabStatus)
                    {
                        if (TRUE == FOO.VF_QoSSchedulingPerPLMN)
                        {
                            uint8_t plmnIdx = VLIB_FindGnbPlmnIndexOfCall(ptCi);
                            VCCB_CHECK_E_RANGE_AND_VOID(plmnIdx, MAX_PLMN_INDEX);

                            proportionSum += pGnb->perPlmnQciSupport[plmnIdx][ptCi->erabInfo[loop].erabQos.qciValue.QCI]
                                                 .qciWeightFactor;
                            if (endPointIdx == ptCi->erabInfo[loop].e1Idx)
                            {
                                proportionThisUp =
                                    proportionThisUp +
                                    GNBINFO[ptCi->gnbNum]
                                        .perPlmnQciSupport[plmnIdx][ptCi->erabInfo[loop].erabQos.qciValue.QCI]
                                        .qciWeightFactor;
                            }
                        }
                        else
                        {
                            proportionSum +=
                                pGnb->qciSupport[ptCi->erabInfo[loop].erabQos.qciValue.QCI].qciWeightFactor;
                            if (endPointIdx == ptCi->erabInfo[loop].e1Idx)
                            {
                                proportionThisUp =
                                    proportionThisUp + GNBINFO[ptCi->gnbNum]
                                                           .qciSupport[ptCi->erabInfo[loop].erabQos.qciValue.QCI]
                                                           .qciWeightFactor;
                            }
                        }
                    }
                }
                ambr = proportionSum ? (proportionThisUp * ambr) / proportionSum : ambr;
                break;
            case AmbrEndcAupfDistribution_noDistribution:
                break;

            default:
                break;
        }
    }
    else
    {
        switch (pGnb->aupf.ambrAupfDistributionSA)
        {
            case AmbrAupfDistribution_equalDistribution:
                ambr = ptCi->endPointInfo.srvAupfNum > 0 ? ambr / ptCi->endPointInfo.srvAupfNum : ambr;
                break;
            case AmbrAupfDistribution_proportionalToNumOfQosFlows:
                for (loop = 0; loop < MAX_PDU_SESS_PER_CALL; loop++)
                {
                    if (CI_use == ptCi->pduSess[loop].usage && S_Release != ptCi->pduSess[loop].pduSessStatus)
                    {
                        proportionSum++;
                        if (endPointIdx == ptCi->pduSess[loop].e1Idx)
                        {
                            proportionThisUp++;
                        }
                    }
                }
                ambr = proportionSum ? (ambr * proportionThisUp) / proportionSum : ambr;
                break;
            case AmbrAupfDistribution_noDistribution:
                break;

            default:
                break;
        }
    }
    *pAmbr = ambr;
}
/**
 * @brief Obtain the AMBR value. If the pointer of the required data is passed during UL/DL, the value is filled.
 * @param [in] pointer of callInfo_type
 */
int16_t VCCM_GetUeAmbrValue(callInfo_type *ptCi, uint64_t *pUl, uint64_t *pDl)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (FOO.VF_UeAmbrSupport_SA == TRUE)  // For SLR850 Samsung eNB
    {
        if (pUl) *pUl = ptCi->ueInfo.ambr.aggrMbrUl;
        if (pDl) *pDl = ptCi->ueInfo.ambr.aggrMbrDl;
    }
    else  // For SLR850 Samsung eNB
    {
        if (pUl) *pUl = ptCi->ueInfo.aggrMbrUl;
        if (pDl) *pDl = ptCi->ueInfo.aggrMbrDl;
    }

    return GOOD;
}

/**
 * @brief Compare two UE Slice MBR lists and set the appropriate modification 
 *        flags if the lists are different
 * @param [in]  rCi        : callInfo_type &
 * @param [in]  prev_list  : ueSliceMbrList_type
 * @param [in]  new_list   : ueSliceMbrList_type
 */
void FnVCCB_CompareUeSliceMBRListAndSetModifyFlags(callInfo_type &rCi,
    ueSliceMbrList_type (&prev_list)[MAX_NR_OF_SLICE_MBR], ueSliceMbrList_type (&new_list)[MAX_NR_OF_SLICE_MBR])
{
    AUTO_TRACE_FUNC;

    for (uint8_t sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; sliceMbrIdx++)
    {
        if (prev_list[sliceMbrIdx].usage != new_list[sliceMbrIdx].usage)
        {
            rCi.ueInfo.sliceMbrInfo.fNeedModifyDl = VCCB_FLAG_ON;
            rCi.ueInfo.sliceMbrInfo.fNeedModifyUl = VCCB_FLAG_ON;
        }

        if (CI_use != new_list[sliceMbrIdx].usage)
        {
            continue;
        }

        if (!FnVCCB_IsSameSNSSAI(prev_list[sliceMbrIdx].sNssai, new_list[sliceMbrIdx].sNssai))
        {
            rCi.ueInfo.sliceMbrInfo.fNeedModifyDl = VCCB_FLAG_ON;
            rCi.ueInfo.sliceMbrInfo.fNeedModifyUl = VCCB_FLAG_ON;
        }
        if (prev_list[sliceMbrIdx].bitRateDl != new_list[sliceMbrIdx].bitRateDl)
        {
            rCi.ueInfo.sliceMbrInfo.fNeedModifyDl = VCCB_FLAG_ON;
        }
        if (prev_list[sliceMbrIdx].bitRateUl != new_list[sliceMbrIdx].bitRateUl)
        {
            rCi.ueInfo.sliceMbrInfo.fNeedModifyUl = VCCB_FLAG_ON;
        }

        if (VCCB_FLAG_ON == rCi.ueInfo.sliceMbrInfo.fNeedModifyDl &&
            VCCB_FLAG_ON == rCi.ueInfo.sliceMbrInfo.fNeedModifyUl)
        {
            return;
        }
    }
}

/**
 * @brief Determine UE Slice MBR
 * @param [in]  rCi        : callInfo_type &
 */
void FnVCCB_DetermineSA_UE_SliceMBR(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    if (VCCB_FLAG_OFF == rCi.ueInfo.sliceMbrInfo.isSliceMBRListProvided)
    {
        return;
    }

    VCCB_CHECK_E_RANGE_AND_VOID(rCi.gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCi.gnbNum];

    ueSliceMbrList_type prev_detSliceMbr[MAX_NR_OF_SLICE_MBR];
    ueSliceMbrList_type (&detSliceMbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.detSliceMbr;
    ueSliceMbrList_type (&subSliceMbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.subSliceMbr;
    bool isSliceMBRPreviouslyDetermined = !(
        VCCB_FLAG_ON == rCi.ueInfo.sliceMbrInfo.fNeedModifyDl && VCCB_FLAG_ON == rCi.ueInfo.sliceMbrInfo.fNeedModifyUl);
    uint8_t sliceMbrIdx = 0;
    uint8_t detSliceMbrIdx = 0;
    uint64_t pduSessionsAmbrAndMfbrDl = 0;
    uint64_t pduSessionsAmbrAndMfbrUl = 0;
    bool isPduSessWithSubUeSliceMBR = false;

    if (isSliceMBRPreviouslyDetermined)
    {
        // store previous values to check if something has changed
        for (sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; sliceMbrIdx++)
        {
            prev_detSliceMbr[sliceMbrIdx].sNssai = detSliceMbr[sliceMbrIdx].sNssai;
            prev_detSliceMbr[sliceMbrIdx].bitRateDl = detSliceMbr[sliceMbrIdx].bitRateDl;
            prev_detSliceMbr[sliceMbrIdx].bitRateUl = detSliceMbr[sliceMbrIdx].bitRateUl;
            prev_detSliceMbr[sliceMbrIdx].usage = detSliceMbr[sliceMbrIdx].usage;
        }
    }

    FnVCCB_InitUeSliceMBRList(detSliceMbr);

    // Determine UE-Slice-MBR = min[Subscribed UE-Slice-MBR, sum of the Session-AMBR and MFBR for 
    // GBR QoS Flows of all PDU Sessions corresponding to the slice]
    for (sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; sliceMbrIdx++)
    {
        if (CI_use != subSliceMbr[sliceMbrIdx].usage)
        {
            continue;
        }

        pduSessionsAmbrAndMfbrDl = 0;
        pduSessionsAmbrAndMfbrUl = 0;

        for (uint8_t pduSessIdx = 0; pduSessIdx < MAX_PDU_SESS_PER_CALL; pduSessIdx++)
        {
            if (CI_use != rCi.pduSess[pduSessIdx].usage)
            {
                continue;
            }

            if (GOOD != VLIB_IsCommonValidStateOfPduQosDrb(rCi.pduSess[pduSessIdx].pduSessStatus))
            {
                continue;
            }

            if (!FnVCCB_IsSameSNSSAI(rCi.pduSess[pduSessIdx].sNssai, subSliceMbr[sliceMbrIdx].sNssai))
            {
                continue;
            }

            isPduSessWithSubUeSliceMBR = true;

            if (VCCB_FLAG_OFF == rGnb.cfg.nrSliceMbrOnOff)
            {
                break;
            }

            if (OPT_PRESENT == rCi.pduSess[pduSessIdx].pduSessAmbrPresent)
            {
                pduSessionsAmbrAndMfbrDl += rCi.pduSess[pduSessIdx].pduSessAmbrDL;
                pduSessionsAmbrAndMfbrUl += rCi.pduSess[pduSessIdx].pduSessAmbrUL;
            }

            for (uint8_t qosIdx = 0; qosIdx < MAX_QOS_FLOW_PER_PDU_SESS; qosIdx++)
            {
                if (rCi.pduSess[pduSessIdx].qosFlowIndex[qosIdx] >= MAX_QOS_FLOW_PER_CALL)
                {
                    continue;
                }

                const auto rQi = rCi.qosFlow[rCi.pduSess[pduSessIdx].qosFlowIndex[qosIdx]];
                if (CI_use != rQi.usage)
                {
                    continue;
                }

                if (GOOD != VLIB_IsCommonValidStateOfPduQosDrb(rQi.qosFlowStatus))
                {
                    continue;
                }

                if (OPT_PRESENT == rQi.qosParam.gbrQosInformationPresent)
                {
                    pduSessionsAmbrAndMfbrDl += static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.maximumFlowBitRateDL);
                    pduSessionsAmbrAndMfbrUl += static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.maximumFlowBitRateUL);
                }
            }
        }

        if (isPduSessWithSubUeSliceMBR)
        {
            detSliceMbr[detSliceMbrIdx].usage = CI_use;
            detSliceMbr[detSliceMbrIdx].sNssai = subSliceMbr[sliceMbrIdx].sNssai;
            detSliceMbr[detSliceMbrIdx].bitRateDl =
                (VCCB_FLAG_OFF == rGnb.cfg.nrSliceMbrOnOff)
                    ? MAX_EXTENDED_BITRATE
                    : (0 == pduSessionsAmbrAndMfbrDl)
                        ? subSliceMbr[sliceMbrIdx].bitRateDl
                        : MIN(subSliceMbr[sliceMbrIdx].bitRateDl, pduSessionsAmbrAndMfbrDl);
            detSliceMbr[detSliceMbrIdx].bitRateUl =
                (VCCB_FLAG_OFF == rGnb.cfg.nrSliceMbrOnOff)
                    ? MAX_EXTENDED_BITRATE
                    : (0 == pduSessionsAmbrAndMfbrUl) 
                        ? subSliceMbr[sliceMbrIdx].bitRateUl
                        : MIN(subSliceMbr[sliceMbrIdx].bitRateUl, pduSessionsAmbrAndMfbrUl);
            detSliceMbrIdx++;
            isPduSessWithSubUeSliceMBR = false;
        }
    }

    if (isSliceMBRPreviouslyDetermined && 0 != detSliceMbrIdx)
    {
        // check if something has changed
        FnVCCB_CompareUeSliceMBRListAndSetModifyFlags(rCi, prev_detSliceMbr, detSliceMbr);
    }
}

/**
 * @brief Store GFBR for all QoS flows in NSSAI separately for MN and SN
 * @param [in]  rCi        : callInfo_type &
 */
void FnVCCB_StoreExistedGFBRValuesForSlice_NRDC(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    ueSliceMbrList_type (&detSliceMbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.detSliceMbr;
    ueSliceMbrList_type (&sliceGfbrMN)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbr;
    ueSliceMbrList_type (&sliceGfbrSN)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbrSN;

    uint64_t sumOfGFBRValuesDlMN = 0;
    uint64_t sumOfGFBRValuesUlMN = 0;
    uint64_t sumOfGFBRValuesDlSN = 0;
    uint64_t sumOfGFBRValuesUlSN = 0;
    uint8_t sliceGfbrIdx = 0;

    FnVCCB_InitUeSliceMBRList(sliceGfbrMN);
    FnVCCB_InitUeSliceMBRList(sliceGfbrSN);

    for (uint8_t sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; sliceMbrIdx++)
    {
        if (CI_use != detSliceMbr[sliceMbrIdx].usage)
        {
            continue;
        }

        sumOfGFBRValuesDlMN = 0;
        sumOfGFBRValuesUlMN = 0;
        sumOfGFBRValuesDlSN = 0;
        sumOfGFBRValuesUlSN = 0;

        for (uint8_t pduSessIdx = 0; pduSessIdx < MAX_PDU_SESS_PER_CALL; pduSessIdx++)
        {
            if (CI_use != rCi.pduSess[pduSessIdx].usage)
            {
                continue;
            }

            if (GOOD != VLIB_IsCommonValidStateOfPduQosDrb(rCi.pduSess[pduSessIdx].pduSessStatus))
            {
                continue;
            }

            if (!FnVCCB_IsSameSNSSAI(rCi.pduSess[pduSessIdx].sNssai, detSliceMbr[sliceMbrIdx].sNssai))
            {
                continue;
            }

            sliceGfbrMN[sliceGfbrIdx].usage = CI_use;
            sliceGfbrMN[sliceGfbrIdx].sNssai = detSliceMbr[sliceMbrIdx].sNssai;
            sliceGfbrSN[sliceGfbrIdx].usage = CI_use;
            sliceGfbrSN[sliceGfbrIdx].sNssai = detSliceMbr[sliceMbrIdx].sNssai;

            for (uint8_t qosIdx = 0; qosIdx < MAX_QOS_FLOW_PER_PDU_SESS; qosIdx++)
            {
                if (rCi.pduSess[pduSessIdx].qosFlowIndex[qosIdx] >= MAX_QOS_FLOW_PER_CALL)
                {
                    continue;
                }

                auto rQi = rCi.qosFlow[rCi.pduSess[pduSessIdx].qosFlowIndex[qosIdx]];
                if (CI_use != rQi.usage)
                {
                    continue;
                }

                if (GOOD != VLIB_IsCommonValidStateOfPduQosDrb(rQi.qosFlowStatus))
                {
                    continue;
                }

                if (OPT_PRESENT == rQi.qosParam.gbrQosInformationPresent)
                {
                    rQi.qosParam.gbrQosInfo.prevGuaranteedFlowBitRateDL = 0;
                    rQi.qosParam.gbrQosInfo.prevGuaranteedFlowBitRateUL = 0;

                    const uint16_t drbIdxInCall = rQi.drbIdxInCall;
                    if (drbIdxInCall >= MAX_DRB_PER_SA_CALL || CI_use != rCi.drb[drbIdxInCall].usage)
                    {
                        continue;
                    }

                    if (CellGroup_Mcg == rCi.drb[drbIdxInCall].bearerType.cellGroup &&
                        GOOD == VLIB_IsCommonValidStateOfPduQosDrb(rCi.drb[drbIdxInCall].drbStatus))
                    {
                        sumOfGFBRValuesDlMN += static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateDL);
                        sumOfGFBRValuesUlMN += static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateUL);
                    }
                    else if (CellGroup_Scg == rCi.drb[drbIdxInCall].bearerType.cellGroup &&
                             GOOD == VLIB_IsCommonValidStateOfPduQosDrb(rCi.drb[drbIdxInCall].snDrbStatus))
                    {
                        sumOfGFBRValuesDlSN += static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateDL);
                        sumOfGFBRValuesUlSN += static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateUL);
                    }
                    // SPLIT bearers with GFBR are not supported
                }
            }
        }

        sliceGfbrMN[sliceGfbrIdx].bitRateDl = sumOfGFBRValuesDlMN;
        sliceGfbrMN[sliceGfbrIdx].bitRateUl = sumOfGFBRValuesUlMN;
        sliceGfbrSN[sliceGfbrIdx].bitRateDl = sumOfGFBRValuesDlSN;
        sliceGfbrSN[sliceGfbrIdx].bitRateUl = sumOfGFBRValuesUlSN;
        sliceGfbrIdx++;
    }
}

/**
 * @brief Store GFBR for all QoS flows in NSSAI
 * @param [in]  rCi        : callInfo_type &
 */
void FnVCCB_StoreExistedGFBRValuesForSlice(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(rCi.gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCi.gnbNum];

    if (VCCB_FLAG_OFF == rCi.ueInfo.sliceMbrInfo.isSliceMBRListProvided ||
        VCCB_FLAG_OFF == rGnb.cfg.nrSliceMbrOnOff)
    {
        return;
    }

    // NRDC
    if (IS_NRDC_MN(&rCi))
    {
        FnVCCB_StoreExistedGFBRValuesForSlice_NRDC(rCi);
        return;
    }

    // SA
    ueSliceMbrList_type (&detSliceMbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.detSliceMbr;
    ueSliceMbrList_type (&sliceGfbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbr;

    uint64_t sumOfGFBRValuesDl = 0;
    uint64_t sumOfGFBRValuesUl = 0;
    uint8_t sliceGfbrIdx = 0;

    FnVCCB_InitUeSliceMBRList(sliceGfbr);

    for (uint8_t sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; sliceMbrIdx++)
    {
        if (CI_use != detSliceMbr[sliceMbrIdx].usage)
        {
            continue;
        }

        sumOfGFBRValuesDl = 0;
        sumOfGFBRValuesUl = 0;

        for (uint8_t pduSessIdx = 0; pduSessIdx < MAX_PDU_SESS_PER_CALL; pduSessIdx++)
        {
            if (CI_use != rCi.pduSess[pduSessIdx].usage)
            {
                continue;
            }

            if (GOOD != VLIB_IsCommonValidStateOfPduQosDrb(rCi.pduSess[pduSessIdx].pduSessStatus))
            {
                continue;
            }

            if (!FnVCCB_IsSameSNSSAI(rCi.pduSess[pduSessIdx].sNssai, detSliceMbr[sliceMbrIdx].sNssai))
            {
                continue;
            }

            sliceGfbr[sliceGfbrIdx].usage = CI_use;
            sliceGfbr[sliceGfbrIdx].sNssai = detSliceMbr[sliceMbrIdx].sNssai;

            for (uint8_t qosIdx = 0; qosIdx < MAX_QOS_FLOW_PER_PDU_SESS; qosIdx++)
            {
                if (rCi.pduSess[pduSessIdx].qosFlowIndex[qosIdx] >= MAX_QOS_FLOW_PER_CALL)
                {
                    continue;
                }

                auto rQi = rCi.qosFlow[rCi.pduSess[pduSessIdx].qosFlowIndex[qosIdx]];
                if (CI_use != rQi.usage)
                {
                    continue;
                }

                if (GOOD != VLIB_IsCommonValidStateOfPduQosDrb(rQi.qosFlowStatus))
                {
                    continue;
                }

                if (OPT_PRESENT == rQi.qosParam.gbrQosInformationPresent)
                {
                    rQi.qosParam.gbrQosInfo.prevGuaranteedFlowBitRateDL = 0;
                    rQi.qosParam.gbrQosInfo.prevGuaranteedFlowBitRateUL = 0;

                    sumOfGFBRValuesDl += static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateDL);
                    sumOfGFBRValuesUl += static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateUL);
                }
            }
        }

        sliceGfbr[sliceGfbrIdx].bitRateDl = sumOfGFBRValuesDl;
        sliceGfbr[sliceGfbrIdx].bitRateUl = sumOfGFBRValuesUl;
        sliceGfbrIdx++;
    }
}

/**
 * @brief Update existing GFBR values when QoS is requested to be released during PDUSessionModifyReq
 * @param [in]  rCi        : callInfo_type &
 */
void FnVCCB_UpdateSliceGFBRDuringPDUSessModQoSRel(callInfo_type &rCi, callPDUSessInfo_type &rPi, qosFlowInfo_type &rQi)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(rCi.gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCi.gnbNum];

    if (VCCB_FLAG_OFF == rCi.ueInfo.sliceMbrInfo.isSliceMBRListProvided || VCCB_FLAG_OFF == rGnb.cfg.nrSliceMbrOnOff ||
        CI_use != rPi.usage || CI_use != rQi.usage || S_Release != rQi.qosFlowStatus)
    {
        return;
    }

    // NRDC
    if (IS_NRDC_MN(&rCi))
    {
        ueSliceMbrList_type (&sliceGfbrMN)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbr;
        ueSliceMbrList_type (&sliceGfbrSN)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbrSN;

        for (uint8_t sliceGfbrIdx = 0; sliceGfbrIdx < MAX_NR_OF_SLICE_MBR; sliceGfbrIdx++)
        {
            // sliceGfbrMN and sliceGfbrSN have same table index for used SNSSAI
            if (CI_use != sliceGfbrMN[sliceGfbrIdx].usage || CI_use != sliceGfbrSN[sliceGfbrIdx].usage)
            {
                continue;
            }

            if (!FnVCCB_IsSameSNSSAI(rPi.sNssai, sliceGfbrMN[sliceGfbrIdx].sNssai))
            {
                continue;
            }

            if (OPT_PRESENT == rQi.qosParam.gbrQosInformationPresent)
            {
                const uint16_t drbIdxInCall = rQi.drbIdxInCall;

                if (drbIdxInCall >= MAX_DRB_PER_SA_CALL || CI_use != rCi.drb[drbIdxInCall].usage)
                {
                    continue;
                }

                if (CellGroup_Mcg == rCi.drb[drbIdxInCall].bearerType.cellGroup)
                {
                    sliceGfbrMN[sliceGfbrIdx].bitRateDl -=
                        static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateDL);
                    sliceGfbrMN[sliceGfbrIdx].bitRateUl -=
                        static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateUL);

                    return;
                }
                else if (CellGroup_Scg == rCi.drb[drbIdxInCall].bearerType.cellGroup)
                {
                    sliceGfbrSN[sliceGfbrIdx].bitRateDl -=
                        static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateDL);
                    sliceGfbrSN[sliceGfbrIdx].bitRateUl -=
                        static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateUL);

                    return;
                }
            }
        }
    }
    else // SA
    {
        ueSliceMbrList_type(&sliceGfbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbr;

        for (uint8_t sliceGfbrIdx = 0; sliceGfbrIdx < MAX_NR_OF_SLICE_MBR; sliceGfbrIdx++)
        {
            if (CI_use != sliceGfbr[sliceGfbrIdx].usage)
            {
                continue;
            }

            if (!FnVCCB_IsSameSNSSAI(rPi.sNssai, sliceGfbr[sliceGfbrIdx].sNssai))
            {
                continue;
            }

            if (OPT_PRESENT == rQi.qosParam.gbrQosInformationPresent)
            {
                sliceGfbr[sliceGfbrIdx].bitRateDl -=
                    static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateDL);
                sliceGfbr[sliceGfbrIdx].bitRateUl -=
                    static_cast<uint64_t>(rQi.qosParam.gbrQosInfo.guaranteedFlowBitRateUL);

                return;
            }
        }
    }
}

/**
 * @brief Check if "sum(GFBR values) < UE-Slice-MBR" for incoming SA/NRDC HO and RRE
 * @param [in]  rCi          : callInfo_type &
 * @return      status       : GOOD, ERROR / int16_t
 */
int16_t FnVCCB_ValidateGFBRComparedToUeSliceMBR_HoRrePrep(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    ueSliceMbrList_type (&sliceGfbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbr;
    ueSliceMbrList_type (&sliceGfbrSN)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbrSN;
    ueSliceMbrList_type (&detSliceMbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.detSliceMbr;

    for (uint8_t sliceGfbrIdx = 0; sliceGfbrIdx < MAX_NR_OF_SLICE_MBR; sliceGfbrIdx++)
    {
        if (CI_use != sliceGfbr[sliceGfbrIdx].usage)
        {
            continue;
        }

        for (uint8_t sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; sliceMbrIdx++)
        {
            if (CI_use != detSliceMbr[sliceMbrIdx].usage)
            {
                continue;
            }

            if (!FnVCCB_IsSameSNSSAI(sliceGfbr[sliceGfbrIdx].sNssai, detSliceMbr[sliceMbrIdx].sNssai))
            {
                continue;
            }

            uint64_t sumOfSliceGfbrDl = sliceGfbr[sliceGfbrIdx].bitRateDl;
            uint64_t sumOfSliceGfbrUl = sliceGfbr[sliceGfbrIdx].bitRateUl;

            if (IS_NRDC_MN(&rCi))
            {
                // sliceGfbr and sliceGfbrSN have same table index for used SNSSAI
                sumOfSliceGfbrDl += sliceGfbrSN[sliceGfbrIdx].bitRateDl;
                sumOfSliceGfbrUl += sliceGfbrSN[sliceGfbrIdx].bitRateUl;
            }

            if (sumOfSliceGfbrDl > detSliceMbr[sliceMbrIdx].bitRateDl ||
                sumOfSliceGfbrUl > detSliceMbr[sliceMbrIdx].bitRateUl)
            {
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "FnVCCB_ValidateGFBRComparedToUeSliceMBR_HOPrep ERROR for S-NSSAI SST(%x)/SD(%x)!\n",
                    sliceGfbr[sliceGfbrIdx].sNssai.sst, sliceGfbr[sliceGfbrIdx].sNssai.sd);
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "Sum of GFBR DL(%" PRIu64 ") > sliceMBR DL(%" PRIu64 ") or sum of GFBR UL(%" PRIu64
                    ") > sliceMBR UL(%" PRIu64 ")\n",
                    sumOfSliceGfbrDl, detSliceMbr[sliceMbrIdx].bitRateDl, sumOfSliceGfbrUl,
                    detSliceMbr[sliceMbrIdx].bitRateUl);

                return ERROR;
            }
            else
            {
                break;
            }
        }
    }

    // Clear stored existed GFBR values for slice
    FnVCCB_InitUeSliceMBRList(sliceGfbr);
    FnVCCB_InitUeSliceMBRList(sliceGfbrSN);

    return GOOD;
}

/**
 * @brief Check if "sum(existed GFBR values) < min(MN ratio, SN ratio) * UE-Slice-MBR / 100"
 * @param [in]  rCi          : callInfo_type &
 * @return      status       : GOOD, ERROR / int16_t
 */
int16_t FnVCCB_ValidateGFBRComparedToUeSliceMBR_SNAddPrep(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    ueSliceMbrList_type (&sliceGfbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbr;
    ueSliceMbrList_type (&detSliceMbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.detSliceMbr;

    FnVCCB_GetNrdcUeSliceMbrConfig(rCi);
    const nrdcUeSliceMbrConfig_type &sliceMbrConfig = rCi.ueInfo.sliceMbrInfo.nrdcUeSliceMbrCfg;

    for (uint8_t sliceGfbrIdx = 0; sliceGfbrIdx < MAX_NR_OF_SLICE_MBR; sliceGfbrIdx++)
    {
        if (CI_use != sliceGfbr[sliceGfbrIdx].usage)
        {
            continue;
        }

        for (uint8_t sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; sliceMbrIdx++)
        {
            if (CI_use != detSliceMbr[sliceMbrIdx].usage)
            {
                continue;
            }

            if (!FnVCCB_IsSameSNSSAI(sliceGfbr[sliceGfbrIdx].sNssai, detSliceMbr[sliceMbrIdx].sNssai))
            {
                continue;
            }

            const uint64_t allowedNrdcSliceMbrDl =
                MIN(sliceMbrConfig.mnDlRatio, sliceMbrConfig.snDlRatio) * detSliceMbr[sliceMbrIdx].bitRateDl / 100;
            const uint64_t allowedNrdcSliceMbrUl =
                MIN(sliceMbrConfig.mnUlRatio, sliceMbrConfig.snUlRatio) * detSliceMbr[sliceMbrIdx].bitRateUl / 100;

            if (sliceGfbr[sliceGfbrIdx].bitRateDl > allowedNrdcSliceMbrDl ||
                sliceGfbr[sliceGfbrIdx].bitRateUl > allowedNrdcSliceMbrUl)
            {
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "FnVCCB_ValidateGFBRComparedToUeSliceMBR_SNAddPrep ERROR for S-NSSAI SST(%x)/SD(%x)!\n",
                    sliceGfbr[sliceGfbrIdx].sNssai.sst, sliceGfbr[sliceGfbrIdx].sNssai.sd);
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "DL: Sum of GFBR(%" PRIu64 ") > Allowed sliceMBR(%" PRIu64
                    ") [min ratio(MN[%u], SN[%u])%% * sliceMBR(%" PRIu64 ")] or\n",
                    sliceGfbr[sliceGfbrIdx].bitRateDl, allowedNrdcSliceMbrDl, sliceMbrConfig.mnDlRatio,
                    sliceMbrConfig.snDlRatio, detSliceMbr[sliceMbrIdx].bitRateDl);
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "UL: Sum of GFBR(%" PRIu64 ") > Allowed sliceMBR(%" PRIu64
                    ") [min ratio(MN[%u], SN[%u])%% * sliceMBR(%" PRIu64 ")]\n",
                    sliceGfbr[sliceGfbrIdx].bitRateUl, allowedNrdcSliceMbrUl, sliceMbrConfig.mnUlRatio,
                    sliceMbrConfig.snUlRatio, detSliceMbr[sliceMbrIdx].bitRateUl);

                return ERROR;
            }
            else
            {
                break;
            }
        }
    }

    // Clear stored existed GFBR values for slice
    FnVCCB_InitUeSliceMBRList(sliceGfbr);

    return GOOD;
}

/**
 * @brief Check if "sum(existed GFBR value of MgNB) < MN ratio * new UE-Slice-MBR / 100" and
 *                 "sum(existed GFBR value of SgNB) < SN ratio * new UE-Slice-MBR / 100"
 * @param [in]  rCi          : callInfo_type &
 * @return      status       : GOOD, ERROR / int16_t
 */
int16_t FnVCCB_ValidateGFBRComparedToUeSliceMBR_NRDC(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    ueSliceMbrList_type (&sliceGfbrMN)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbr;
    ueSliceMbrList_type (&sliceGfbrSN)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbrSN;
    ueSliceMbrList_type (&detSliceMbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.detSliceMbr;
    const nrdcUeSliceMbrConfig_type &sliceMbrConfig = rCi.ueInfo.sliceMbrInfo.nrdcUeSliceMbrCfg;

    for (uint8_t sliceGfbrIdx = 0; sliceGfbrIdx < MAX_NR_OF_SLICE_MBR; sliceGfbrIdx++)
    {
        // sliceGfbrMN and sliceGfbrSN have same table index for used SNSSAI
        if (CI_use != sliceGfbrMN[sliceGfbrIdx].usage || CI_use != sliceGfbrSN[sliceGfbrIdx].usage)
        {
            continue;
        }

        for (uint8_t sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; sliceMbrIdx++)
        {
            if (CI_use != detSliceMbr[sliceMbrIdx].usage)
            {
                continue;
            }

            if (!FnVCCB_IsSameSNSSAI(sliceGfbrMN[sliceGfbrIdx].sNssai, detSliceMbr[sliceMbrIdx].sNssai))
            {
                continue;
            }

            const uint64_t allowedMNSliceMbrDl = sliceMbrConfig.mnDlRatio * detSliceMbr[sliceMbrIdx].bitRateDl / 100;
            const uint64_t allowedMNSliceMbrUl = sliceMbrConfig.mnUlRatio * detSliceMbr[sliceMbrIdx].bitRateUl / 100;

            if (sliceGfbrMN[sliceGfbrIdx].bitRateDl > allowedMNSliceMbrDl ||
                sliceGfbrMN[sliceGfbrIdx].bitRateUl > allowedMNSliceMbrUl)
            {
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "FnVCCB_ValidateGFBRComparedToUeSliceMBR_NRDC ERROR for S-NSSAI SST(%x)/SD(%x)!\n",
                    sliceGfbrMN[sliceGfbrIdx].sNssai.sst, sliceGfbrMN[sliceGfbrIdx].sNssai.sd);
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "DL: Sum of MN GFBR(%" PRIu64 ") > Allowed MN sliceMBR(%" PRIu64
                    ") [MN ratio[%u]%% * sliceMBR(%" PRIu64 ")] or\n",
                    sliceGfbrMN[sliceGfbrIdx].bitRateDl, allowedMNSliceMbrDl, sliceMbrConfig.mnDlRatio,
                    detSliceMbr[sliceMbrIdx].bitRateDl);
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "UL: Sum of MN GFBR(%" PRIu64 ") > Allowed sliceMBR(%" PRIu64
                    ") [MN ratio[%u]%% * sliceMBR(%" PRIu64 ")]\n",
                    sliceGfbrMN[sliceGfbrIdx].bitRateUl, allowedMNSliceMbrUl, sliceMbrConfig.mnUlRatio,
                    detSliceMbr[sliceMbrIdx].bitRateUl);

                return ERROR;
            }
            else
            {
                const uint64_t allowedSNSliceMbrDl = sliceMbrConfig.snDlRatio * detSliceMbr[sliceMbrIdx].bitRateDl / 100;
                const uint64_t allowedSNSliceMbrUl = sliceMbrConfig.snUlRatio * detSliceMbr[sliceMbrIdx].bitRateUl / 100;

                if (sliceGfbrSN[sliceGfbrIdx].bitRateDl > allowedSNSliceMbrDl ||
                    sliceGfbrSN[sliceGfbrIdx].bitRateUl > allowedSNSliceMbrUl)
                {
                    VCCB_PRINT_CALL_ERROR(&rCi,
                        "FnVCCB_ValidateGFBRComparedToUeSliceMBR_NRDC ERROR for S-NSSAI SST(%x)/SD(%x)!\n",
                        sliceGfbrSN[sliceGfbrIdx].sNssai.sst, sliceGfbrSN[sliceGfbrIdx].sNssai.sd);
                    VCCB_PRINT_CALL_ERROR(&rCi,
                        "DL: Sum of SN GFBR(%" PRIu64 ") > Allowed SN sliceMBR(%" PRIu64
                        ") [SN ratio[%u]%% * sliceMBR(%" PRIu64 ")] or\n",
                        sliceGfbrSN[sliceGfbrIdx].bitRateDl, allowedSNSliceMbrDl, sliceMbrConfig.snDlRatio,
                        detSliceMbr[sliceMbrIdx].bitRateDl);
                    VCCB_PRINT_CALL_ERROR(&rCi,
                        "UL: Sum of SN GFBR(%" PRIu64 ") > Allowed sliceMBR(%" PRIu64
                        ") [SN ratio[%u]%% * sliceMBR(%" PRIu64 ")]\n",
                        sliceGfbrSN[sliceGfbrIdx].bitRateUl, allowedSNSliceMbrUl, sliceMbrConfig.snUlRatio,
                        detSliceMbr[sliceMbrIdx].bitRateUl);

                    return ERROR;
                }

                break;
            }
        }
    }

    // Clear stored existed GFBR values for slice
    FnVCCB_InitUeSliceMBRList(sliceGfbrMN);
    FnVCCB_InitUeSliceMBRList(sliceGfbrSN);

    return GOOD;
}

/**
 * @brief Check if "if sum(existed GFBR values) < UE-Slice-MBR"
 * @param [in]  rCi          : callInfo_type &
 * @return      status       : GOOD, ERROR / int16_t
 */
int16_t FnVCCB_ValidateGFBRComparedToUeSliceMBR_SA(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    ueSliceMbrList_type (&sliceGfbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.sliceGfbr;
    ueSliceMbrList_type (&detSliceMbr)[MAX_NR_OF_SLICE_MBR] = rCi.ueInfo.sliceMbrInfo.detSliceMbr;

    for (uint8_t sliceGfbrIdx = 0; sliceGfbrIdx < MAX_NR_OF_SLICE_MBR; sliceGfbrIdx++)
    {
        if (CI_use != sliceGfbr[sliceGfbrIdx].usage)
        {
            continue;
        }

        for (uint8_t sliceMbrIdx = 0; sliceMbrIdx < MAX_NR_OF_SLICE_MBR; sliceMbrIdx++)
        {
            if (CI_use != detSliceMbr[sliceMbrIdx].usage)
            {
                continue;
            }

            if (!FnVCCB_IsSameSNSSAI(sliceGfbr[sliceGfbrIdx].sNssai, detSliceMbr[sliceMbrIdx].sNssai))
            {
                continue;
            }

            if (sliceGfbr[sliceGfbrIdx].bitRateDl > detSliceMbr[sliceMbrIdx].bitRateDl ||
                sliceGfbr[sliceGfbrIdx].bitRateUl > detSliceMbr[sliceMbrIdx].bitRateUl)
            {
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "FnVCCB_ValidateGFBRComparedToUeSliceMBR_SA ERROR for S-NSSAI SST(%x)/SD(%x)!\n",
                    sliceGfbr[sliceGfbrIdx].sNssai.sst, sliceGfbr[sliceGfbrIdx].sNssai.sd);
                VCCB_PRINT_CALL_ERROR(&rCi,
                    "Sum of GFBR DL(%" PRIu64 ") > sliceMBR DL(%" PRIu64 ") or sum of GFBR UL(%" PRIu64
                    ") > sliceMBR UL(%" PRIu64 ")\n",
                    sliceGfbr[sliceGfbrIdx].bitRateDl, detSliceMbr[sliceMbrIdx].bitRateDl,
                    sliceGfbr[sliceGfbrIdx].bitRateUl, detSliceMbr[sliceMbrIdx].bitRateUl);

                return ERROR;
            }
            else
            {
                break;
            }
        }
    }

    // Clear stored existed GFBR values for slice
    FnVCCB_InitUeSliceMBRList(sliceGfbr);

    return GOOD;
}

/**
 * @brief Store existed GFBR values and check if sum(existed GFBR values) does not exceed UE-Slice-MBR
 * @param [in]  rCi          : callInfo_type &
 * @return      status       : GOOD, ERROR / int16_t
 */
int16_t FnVCCB_ValidateGFBRComparedToUeSliceMBR(callInfo_type &rCi, bool isNrdcSNAddPrep, bool isHoRre)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_RETURN(rCi.gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCi.gnbNum];

    if (VCCB_FLAG_OFF == rCi.ueInfo.sliceMbrInfo.isSliceMBRListProvided || 
        VCCB_FLAG_OFF == rGnb.cfg.nrSliceMbrOnOff ||
        (!isNrdcSNAddPrep && !(VCCB_FLAG_ON == rCi.ueInfo.sliceMbrInfo.fNeedModifyDl ||
                               VCCB_FLAG_ON == rCi.ueInfo.sliceMbrInfo.fNeedModifyUl ||
                               VCCB_FLAG_ON == rCi.ueInfo.sliceMbrInfo.fNeedModifySN)))
    {
        return GOOD;
    }

    FnVCCB_StoreExistedGFBRValuesForSlice(rCi);

    // SA -> NRDC Preparation
    if (isNrdcSNAddPrep)
    {
        return FnVCCB_ValidateGFBRComparedToUeSliceMBR_SNAddPrep(rCi);
    }

    // HO (SA/NRDC) / RRE (SA)
    if (isHoRre)
    {
        return FnVCCB_ValidateGFBRComparedToUeSliceMBR_HoRrePrep(rCi);
    }

    // NRDC established
    if (IS_NRDC_MN(&rCi))
    {
        return FnVCCB_ValidateGFBRComparedToUeSliceMBR_NRDC(rCi);
    }

    // SA
    return FnVCCB_ValidateGFBRComparedToUeSliceMBR_SA(rCi);
}

/**
 * @brief Check whether bearer support ECN Marking
 * @param [in]  rCi          : callInfo_type &
 * @return      void
 */
void FnVCCB_CheckQoSSupportForEcnMarking(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VOID(rCi.gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCi.gnbNum];

    static const int FIVE_QI_RANGE = 256;
    static const int NO_ENTRY = -1;
    int qciToIndexMap[FIVE_QI_RANGE];

    memset(qciToIndexMap, NO_ENTRY, sizeof(qciToIndexMap));

    for (int i = 0; i < MAX_NRDC_CONTROL_ENTRIES; i++)
    {
        if (rGnb.nrdcControlInfo[i].usage == CI_use)
        {
            uint8_t fiveQi = rGnb.nrdcControlInfo[i].fiveQi;
            qciToIndexMap[fiveQi] = i;
        }
    }

    // Iterate through all active QoS flows
    for (int qosIdx = 0; qosIdx < MAX_QOS_FLOW_PER_CALL; qosIdx++)
    {
        auto &qosFlow = rCi.qosFlow[qosIdx];

        // Check if the QoS flow is actually in use
        if (qosFlow.usage != CI_use || ECN_MARKING_RECEIVED != qosFlow.qosFlowInfoExtension.ecn.ecnMarkingState)
        {
            continue;
        }

        // Get the 5QI value for this QoS flow
        uint8_t fiveQi;
        VLIB_getFiveQi(&qosFlow, &fiveQi);

        // Use lookup table to check if we have a matching entry
        if (qciToIndexMap[fiveQi] != NO_ENTRY)
        {
            // Get the matching entry
            int index = qciToIndexMap[fiveQi];
            const NrdcControlInfo_type &entry = rGnb.nrdcControlInfo[index];

            // present but Term point and MN Bearer of specific qos-5qi are configured as mn-term and mn-term-mcg -
            // so consider as supported - ECN marking/Congestion Information Reporting Status IE should be send to UP
            if (FnVCCB_GetYangValueMnTerm() == entry.terminationPoint &&
                FnVCCB_GetYangValueMnTermMcg() == entry.mnBearerType)
            {
                qosFlow.qosFlowInfoExtension.ecn.ecnMarkingState = ECN_MARKING_VALID;
            }
            else
            {
                // unsupported - ECN marking/Congestion Information Reporting Status IE should NOT be send to UP
                qosFlow.qosFlowInfoExtension.ecn.ecnMarkingState = ECN_MARKING_INVALID;
            }
        }
        else
        {
            // not present in container so considered as supported - ECN marking/ongestion Information Reporting
            // Status IE
            qosFlow.qosFlowInfoExtension.ecn.ecnMarkingState = ECN_MARKING_VALID;
        }
    }
}

/**
 * @brief Check DRB Setup Case only or not
 * @param [in] pointer of callInfo_type
 */
int VCCM_IsDrbSetupOnly(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, FALSE);

    uint8_t drbIdxInCall;
    callDRBInfo_type *ptDi = NULL;

    for (drbIdxInCall = 0; drbIdxInCall < MAX_DRB_PER_SA_CALL; drbIdxInCall++)
    {
        ptDi = &ptCi->drb[drbIdxInCall];
        if (ptDi->usage != CI_use) continue;

        if ((ptDi->drbStatus != S_Idle) && (ptDi->drbStatus != S_Setup))
        {
            return FALSE;
        }
    }

    return TRUE;
}

ConfStatus VCCM_CheckSupport5QI(callInfo_type *ptCi, uint16_t gnbNum, uint8_t fiveQi, bool isErrorPrintRequired)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, N_EQUIP);
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, N_EQUIP);
    const VccbGnbInfo_type *const pGnb = &GNBINFO[gnbNum];
    // The parameter of the function is limited within the MAX_5QI_VALUE value, which is an unnecessary condition
    // statement.
    // VCCB_CHECK_E_RANGE_AND_VAL(fiveQi, MAX_5QI_VALUE, N_EQUIP);
    if (TRUE == FOO.VF_QoS5qiSupportPerPLMN)
    {
        uint8_t plmnIdx = VLIB_FindGnbPlmnIndexOfCall(ptCi);
        if (IS_VALID_PLMNNUM(plmnIdx))
        {
            if (pGnb->perPlmnQos5qiSupport[plmnIdx][fiveQi] == False)
            {
                if (isErrorPrintRequired == true)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "qos5qi(%d) is not supported for this plmn(%d)! (Check: "
                        "per-plmn-qos-5qi-support/per-plmn-qos-5qi-support-entries/status)\n",
                        fiveQi, plmnIdx);
                }
                return N_EQUIP;
            }
        }
        else
        {
            if (isErrorPrintRequired == true)
            {
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "CheckSupport5QI ERROR: can't find PLMN. PlmnIdx: %d is invalid. Checking default PlmnIdx(%d) for qos5qi(%d).\n",
                    plmnIdx, DEFAULT_PLMN_INDEX_SUPPORT, fiveQi);
            }
            if (pGnb->perPlmnQos5qiSupport[DEFAULT_PLMN_INDEX_SUPPORT][fiveQi] == False)
            {
                if (isErrorPrintRequired == true)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "qos5qi(%d) is not supported for this plmn(%d)! (Check: "
                        "per-plmn-qos-5qi-support/per-plmn-qos-5qi-support-entries/status)\n",
                        fiveQi, DEFAULT_PLMN_INDEX_SUPPORT);
                }
                return N_EQUIP;
            }
        }
    }
    else
    {
        if (pGnb->qos5qiSupport[fiveQi] == False)
        {
            if (isErrorPrintRequired == true)
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "qos5qi(%d) is not supported! (Check: qos-5qi-support/qos-5qi-support-entries/status)\n", fiveQi);
            }
            return N_EQUIP;
        }
    }

    pdcpInfo5qi_type *pPdcpInfo = FnVCCB_GetPdcpInfo5qi(ptCi->servCellNum, ptCi->gnbNum, fiveQi);
    VALID_E_POINT_CHECK_RET_VAL(pPdcpInfo, N_EQUIP);

    if (pPdcpInfo->shmStatus == N_EQUIP)
    {
        if (isErrorPrintRequired == true)
        {
            VCCB_PRINT_CALL_ERROR(
                ptCi, "pdcpInfo5qi(%d) is not supported! (Check: pdcp-info/pdcp-info-entries-5qi)\n", fiveQi);
        }
        return N_EQUIP;
    }

    return EQUIP;
}

/**
 * @brief Check if voice over NR is supported for given frequency range
 * @param [in] ref of callInfo_type
 * @param [in] serving cell frequency range (FR1/FR2)
 * @param [in] whether unsupported reason should be printed
 * @return VCCB_SUPPORTED/VCCB_UNSUPPORTED/VCCB_UNKNOWN
 */
enumSupport_type FnVCCB_CheckVoiceOverNRCapaByFrequencyRange(
    const callInfo_type &callInfo, enumFrequencyRange_type currFrequencyServCell, bool isErrorPrintRequired)
{
    if (callInfo.ueContainerNR.rxFlag == VCCB_FLAG_OFF)
    {
        VCCB_PRINT_CALL_COMMENT(&callInfo, "voice over NR capabilities are unknown yet.\n");
        return VCCB_UNKNOWN;
    }

    const uint8_t &imsVoiceOverNR = callInfo.ueInfo.ueCapa.nr.voiceOverNRParam.imsVoiceOverNR;
    const uint8_t &fr1VoiceOverNR = callInfo.ueInfo.ueCapa.nr.voiceOverNRParam.fr1VoiceOverNR;
    const uint8_t &fr2VoiceOverNR = callInfo.ueInfo.ueCapa.nr.voiceOverNRParam.fr2VoiceOverNR;

    if (imsVoiceOverNR ||
        (fr1VoiceOverNR && FrequencyRange_FR1 == currFrequencyServCell) ||
        (fr2VoiceOverNR && FrequencyRange_FR2 == currFrequencyServCell))
    {
        VCCB_PRINT_CALL_COMMENT(&callInfo,
            "voice over NR is supported for: FR%u. (imsVoiceOverNR:%u, fr1VoiceOverNR:%u, fr2VoiceOverNR:%u)\n",
            currFrequencyServCell, imsVoiceOverNR, fr1VoiceOverNR, fr2VoiceOverNR);
        return VCCB_SUPPORTED;
    }

    if (isErrorPrintRequired == true)
    {
        VCCB_PRINT_CALL_CRITICAL(&callInfo,
            "voice over NR is not supported for: FR%u!. (imsVoiceOverNR:%u, fr1VoiceOverNR:%u, fr2VoiceOverNR:%u)\n",
            currFrequencyServCell, imsVoiceOverNR, fr1VoiceOverNR, fr2VoiceOverNR);
    }
    return VCCB_UNSUPPORTED;
}

/**
 * @brief Check if voice over NR is supported in UE capabilitis
 * @param [in] ref of callInfo_type
 * @return VCCB_SUPPORTED/VCCB_UNSUPPORTED/VCCB_UNKNOWN
 */
enumSupport_type VCCM_CheckVoiceOverNRCapa(const callInfo_type &callInfo, uint16_t cellNum, bool isErrorPrintRequired)
{
    AUTO_TRACE_FUNC;

    if (cellNum >= MAX_CELL_NUM_VCCB)
    {
        VCCB_PRINT_CALL_ERROR(&callInfo, "servCellNum out of range (%u:%u)\n", cellNum, MAX_CELL_NUM_VCCB);
        return VCCB_UNKNOWN;
    }

    if (callInfo.ueContainerNR.rxFlag == VCCB_FLAG_OFF)
    {
        VCCB_PRINT_CALL_COMMENT(&callInfo, "voice over NR capabilities are unknown yet.\n");
        return VCCB_UNKNOWN;
    }

    // checking servCell FR
    const VccbCellInfo_type &cellInfo = CELLINFO[cellNum];
    enumFrequencyRange_type currFrequencyServCell =
        (MIN_A6_NR_ARFCN <= cellInfo.nrArfcnDl) ? FrequencyRange_FR2 : FrequencyRange_FR1;

    return FnVCCB_CheckVoiceOverNRCapaByFrequencyRange(callInfo, currFrequencyServCell, isErrorPrintRequired);
}

/**
 * @brief Check if voice over NR can apply
 * @param [in] pointer of callInfo_type
 * @return GOOD/ERROR
 */
int16_t VCCM_CheckVoiceOverNR(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint8_t isEmergencyCallByRequestedVal = FnVCCB_IsEmergencyCallWithRequestedVal(ptCi, false);

    int qosIdx = 0;
    for (qosIdx = 0; qosIdx < MAX_QOS_FLOW_PER_CALL; ++qosIdx)
    {
        if (ptCi->qosFlow[qosIdx].qosParam.nonDyna.fiveQi == VONR_5QI && ptCi->qosFlow[qosIdx].usage == CI_use)
        {
            if (N_EQUIP == VCCM_CheckSupport5QI(ptCi, ptCi->gnbNum, VONR_5QI, true))
            {
                ptCi->qosFlow[qosIdx].failCause = CauseCpInternalSaNotSupported5qiValue;
                return ERROR;
            }
            else if (TRUE != FnVCCB_SupportVoiceWithControlInfo(*ptCi, cellNum, true))
            {
                ptCi->qosFlow[qosIdx].failCause = CauseCpInternalSaNotSupported5qiValue;
                return ERROR;
            }
            else if ((isEmergencyCallByRequestedVal) &&
                     ( TRUE != FnVCCB_SupportEmergencyVonrWithRfsp (*ptCi, cellNum, true)))
            {
                ptCi->qosFlow[qosIdx].failCause = CauseCpInternalSaNotSupported5qiValue;
                return ERROR;
            }
            else if (VCCB_UNSUPPORTED == VCCM_CheckVoiceOverNRCapa(*ptCi, cellNum, true))
            {
                ptCi->qosFlow[qosIdx].failCause = CauseCpInternalSaUeCapaNotSupported;
                return ERROR;
            }
        }
    }

    return GOOD;
}

/**
 * @brief Check if intra gNB PScell change will be performed between FR1 and FR2 or FR2 and FR1
 * @param [in] pointer of callInfo_type
 * @return enumFRPSCellChangeType/ERROR
 */
int16_t VCCM_CheckFR1FR2HO(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    uint8_t currFrequencyServCell = 0, currFrequencyTgtCell = 0;
    nbrGnbCellInfo_type *nbrGnbCellInfo = NULL;

    // Check Frequency Range for serving cell
    if (MIN_A6_NR_ARFCN <= pCell->ssbArfcn)
    {
        currFrequencyServCell = FrequencyRange_FR2;
    }
    else
    {
        currFrequencyServCell = FrequencyRange_FR1;
    }

    // Check Frequency Range for target cell
    if (HO_TYPE_INTRA_NB == ptCi->hoInfo.hoType.nb)
    {
        VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->hoInfo.targetCellNum, MAX_CELL_NUM_VCCB);
        if (MIN_A6_NR_ARFCN <= CELLINFO[ptCi->hoInfo.targetCellNum].ssbArfcn)
        {
            currFrequencyTgtCell = FrequencyRange_FR2;
        }
        else
        {
            currFrequencyTgtCell = FrequencyRange_FR1;
        }
    }
    else if (HO_TYPE_INTER_NB == ptCi->hoInfo.hoType.nb)
    {
        VCCB_RETURN_ON_CALL_ERROR(ptCi,
            getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, ptCi->hoInfo.tgtNbrGnbCell, &nbrGnbCellInfo),
            "getNbrGnbCellByCellNbrIdx ERROR!\n");
        if (MIN_A6_NR_ARFCN <= nbrGnbCellInfo->ssbArfcn)
        {
            currFrequencyTgtCell = FrequencyRange_FR2;
        }
        else
        {
            currFrequencyTgtCell = FrequencyRange_FR1;
        }
    }

    if ((FrequencyRange_FR1 == currFrequencyServCell) && (FrequencyRange_FR2 == currFrequencyTgtCell))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "FR1->FR2 HO detected\n");
        return FR1FR2PSCellChange;
    }
    else if ((FrequencyRange_FR2 == currFrequencyServCell) && (FrequencyRange_FR1 == currFrequencyTgtCell))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "FR2->FR1 HO detected\n");
        return FR2FR1PSCellChange;
    }

    VCCB_PRINT_CALL_COMMENT(ptCi, "No Inter Frequency Range HO detected\n");
    return NonFRPSCellChange;
}

/****************************************************************************
 * @brief           Check if the UE CAPA supports InterFreqHandover.
 *
 * @param[in,out]   ptCi       :    call information
 * @param[in]       tgtSsbFreq :    target ssb Freq
 * @param[in]       rsType     :    report type
 * @return          status :        GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_FindSaEnabledNbr(callInfo_type *ptCi, enumRSType rsType, uint32_t ssbFreq)
{
    AUTO_TRACE_FUNC;
    (void)rsType;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    uint16_t nbrIdx;

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        nbrGnbCellInfo_type *pNbr = NULL;
        int status = getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &pNbr);
        if (status != GOOD) continue;

        if (pNbr->ssbArfcn != ssbFreq) continue;

        // 5g tac & redCap validation check
        if (FALSE == VHCM_isSaEnabledNbr(ptCi, pNbr)) continue;

        return GOOD;
    }

    return ERROR;
}

inline bool VCCM_VerifyInterFreqHOwithFreqRange(const callInfo_type &rCi, uint16_t freqRange)
{
    AUTO_TRACE_FUNC;

    if (FrequencyRange_FR1 == freqRange)
    {
        return rCi.ueInfo.ueCapa.nr.fr1Capa.measAndMob.handoverInterF == TRUE;
    }
    else if (FrequencyRange_FR2 == freqRange)
    {
        return rCi.ueInfo.ueCapa.nr.fr2Capa.measAndMob.handoverInterF == TRUE;
    }
    return false;
}

inline bool VCCM_VerifyInterFreqHOwithDuplexType(const callInfo_type &rCi, uint16_t duplexType)
{
    AUTO_TRACE_FUNC;

    if (ci_DUPLEXTYPE_FDD == duplexType)
    {
        return rCi.ueInfo.ueCapa.nr.fddCapa.measAndMob.handoverInterF == TRUE;
    }
    else if (ci_DUPLEXTYPE_TDD == duplexType)
    {
        return rCi.ueInfo.ueCapa.nr.tddCapa.measAndMob.handoverInterF == TRUE;
    }
    return false;
}

/****************************************************************************
 * @brief           Check if the UE CAPA supports InterFreqHandover.
 *
 * @param[in,out]   ptCi                    :    call information
 * @param[in]       tgtSsbFrequency         :    target frequency
 * @param[in]       tgtFreqBandIndicatorNR  :    target frequency band indicator
 * @return          status :        GOOD, ERROR / int16_t
 ****************************************************************************/
int16_t VCCM_CheckUeCapaForNrInterFrequencySaHandover(
    callInfo_type *ptCi, uint16_t cellNum, uint32_t tgtSsbFrequency, uint16_t tgtFreqBandIndicatorNR)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(cellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    uint16_t srcCellDuplexType = 0, tgtCellDuplexType = 0;
    uint16_t srcCellFreqRange = FrequencyRange_FR1;
    uint16_t tgtCellFreqRange = FrequencyRange_FR1;

    srcCellDuplexType = VCCM_GetNrCellDuplexType(ptCi, cellNum);
    tgtCellDuplexType = FnVCCB_GetNrDuplexTypeByBandIndicator(tgtFreqBandIndicatorNR);

    // Check Frequency Range for serving cell
    if (MIN_A6_NR_ARFCN <= pCell->ssbArfcn)
    {
        srcCellFreqRange = FrequencyRange_FR2;
    }

    // Check Frequency Range for target Freq
    if (MIN_A6_NR_ARFCN <= tgtSsbFrequency)
    {
        tgtCellFreqRange = FrequencyRange_FR2;
    }

    if (!VCCM_VerifyInterFreqHOwithFreqRange(*ptCi, srcCellFreqRange))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "UeCapability Freq range does not allow handoverInterF\n");
        return ERROR;
    }

    if (!VCCM_VerifyInterFreqHOwithDuplexType(*ptCi, srcCellDuplexType))
    {
        VCCB_PRINT_CALL_COMMENT(ptCi, "UeCapability Duplex type does not allow handoverInterF\n");
        return ERROR;
    }

    if (srcCellFreqRange != tgtCellFreqRange)
    {
        if (TRUE != ptCi->ueInfo.ueCapa.nr.measAndMob.handoverFR1_FR2)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "UeCapability does not allow handoverFR1_FR2\n");
            return ERROR;
        }
    }

    if (srcCellDuplexType != tgtCellDuplexType)
    {
        if (TRUE != ptCi->ueInfo.ueCapa.nr.measAndMob.handoverFDD_TDD)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "UeCapability does not allow handoverFDD_TDD\n");
            return ERROR;
        }
    }

    return GOOD;
}  // }}}

uint8_t VLIB_setDrbsToIdleInPdu(callInfo_type *ptCi, callPDUSessInfo_type *ptPi, uint8_t callPduIdx)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptPi);
    VCCB_CHECK_E_RANGE_AND_VAL(callPduIdx, MAX_PDU_SESS_PER_CALL, FALSE);

    uint8_t pduDrbIdx = 0, callDrbIdx = 0;
    callDRBInfo_type *ptDi = NULL;
    uint8_t isEachDrbSetToIdle = TRUE;

    for (pduDrbIdx = 0; pduDrbIdx < MAX_DRB_PER_PDU_SESS; pduDrbIdx++)
    {
        callDrbIdx = static_cast<uint8_t>(ptPi->drbIndex[pduDrbIdx]);
        if (callDrbIdx >= MAX_DRB_PER_SA_CALL) continue;
        if (!IS_VALID_NODE(DRB_NODE, ptCi, &(ptCi->drb[callDrbIdx]))) continue;
        ptDi = &ptCi->drb[callDrbIdx];

        switch (ptDi->drbStatus)
        {
            case S_Setup:
                // Unreachable status?
                VCCB_PRINT_CALL_ERROR(
                    ptCi, "VLIB_setDrbsToIdleInPdu invalid DRB status(S_Setup) during DRB prosessing operation.\n");
                break;
            case S_Modify:
                if (DBG->flag.reuseDrbId == FLAG_ON)
                {
                    // Reset drbId in POOL for preventing drbId management error
                    ON_BIT_DRB_ID_IN_POOL(ptCi, ptCi->drb[callDrbIdx].dRBId);
                }

                // Backup prev PdcpInfo
                ptDi->rbInfo.pdcpInfoPrev = ptDi->rbInfo.pdcpInfo;
                ptDi->rbInfo.pdcpInfoPrevFlagInfo.present.value = NR_PDCP_PREV_FLAG_SET_ALL;

                // Statistics
                if ((ptDi->prevDrbStatus == S_Setup) &&
                    (ptDi->drbStatistic.attemptFlag[DRB_SETUP] == ATTEMPT_MADE))
                {
                    MACRO_STAT_PMCC_DRB_SETUP_FAMILY_ALL(
                        DrbSetupSucc, ptCi, &ptCi->drb[callDrbIdx], 0, 0, 0, 0, MAX_VCCB_DRB_STAT_FAMILY_TYPE);
                }

                // Clear for RRE
                if (ptDi->drbConnStat.drbSetupTime.isRunning)
                {
                    ptDi->drbConnStat.drbSetupTime.isRunning = FALSE;
                }
                break;
            case S_Release:
                if (IS_NEDC_MN(ptCi) && MN_Term_SPLIT_Bearer == ptDi->bearerType.val)
                {
                    VCCB_PRINT_CALL_ERROR(ptCi,
                        "%d is MN_Term_SPLIT_Bearer bearer, waiting to remove after it is removed from NEDC!!\n",
                        pduDrbIdx);
                    isEachDrbSetToIdle = FALSE;
                    continue;
                }
                // Statistics is collected in below drb free function.
                if (VLIB_FreeCallDrbInfoUnderPdu(ptCi, callPduIdx, pduDrbIdx) != GOOD)
                {
                    VCCB_PRINT_ERROR("VLIB_FreeCallDrbInfoUnderPdu ERROR!! \n");
                }
                break;
            case S_FailToSetup:
                if (VCCB_FLAG_ON == ptCi->bitFlag.isPartialDrbForRreDuringHo)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Skip VLIB_FreeCallDrbInfoUnderPdu pdu:%d drb:%d isPartialDrbForRreDuringHo(%llu)!\n",
                        ptPi->pduSessId, ptDi->dRBId, 1ULL * ptCi->bitFlag.isPartialDrbForRreDuringHo);
                    continue;
                }

                if (VLIB_FreeCallDrbInfoUnderPdu(ptCi, callPduIdx, pduDrbIdx) != GOOD)
                {
                    VCCB_PRINT_ERROR("VLIB_FreeCallDrbInfoUnderPdu ERROR!! \n");
                }
                break;
            case S_FailToModify:
                if (ptPi->firstReqStatusInThisProcedure == S_Setup)
                {
                    if (VLIB_FreeCallDrbInfoUnderPdu(ptCi, callPduIdx, pduDrbIdx) != GOOD)
                    {
                        VCCB_PRINT_ERROR("VLIB_FreeCallDrbInfoUnderPdu ERROR!! \n");
                    }
                }
                else
                {
                    // 21B : Currently no case to use. (Partial Modifcation not supported)
                    if (ptDi->rbInfo.pdcpInfoPrevFlagInfo.present.prev)
                    {
                        // Restore pdcpInfo before failing.
                        ptDi->rbInfo.pdcpInfo = ptDi->rbInfo.pdcpInfoPrev;
                        ptDi->rbInfo.pdcpInfoPrevFlagInfo.present.value = NR_PDCP_PREV_FLAG_SET_ALL;
                    }
                }
                break;

            case S_Null:
                VCCB_PRINT_DATA(
                    "Nothing to do for drb[idx:%u, id:%u] because its status is S_Null(sn-term-scg) in %s!!\n",
                    callDrbIdx, ptDi->dRBId, __FUNCTION__);
                continue;

            case S_Null_Release:
                if (VLIB_FreeCallDrbInfoUnderPdu(ptCi, callPduIdx, pduDrbIdx) != GOOD)
                {
                    VCCB_PRINT_ERROR("VLIB_FreeCallDrbInfoUnderPdu on drbStatus(S_Null_Release) ERROR!! \n");
                }
                break;

            default:
                break;
        }

        if (IS_GNB_SUPPORT_QOS_MONITORING(ptCi->gnbNum))
        {
            ptDi->qosMonitorActivated = FnVCCB_IsDrbQosMonitoringActivated(ptCi, ptDi);
        }

        SET_DRB_STATUS(ptCi, callDrbIdx, S_Idle);

        // isInSetupList is only used during SN Addition Request or Modification Request
        ptDi->isInSetupList = FALSE;
        ptCi->drb[callDrbIdx].prevDrbStatus = S_Idle;
        ptCi->drb[callDrbIdx].failCause = CAUSE_NO_FAULT;
        CLEAR_DRB_RETAIN_STAT_EVENT(ptDi);

        if (ptCi->drb[callDrbIdx].usage == CI_use)
        {
            SET_DRB_RETAIN_STAT_CAPABLE_FLAG(&ptCi->drb[callDrbIdx], VCCB_FLAG_ON);
        }
    }
    return isEachDrbSetToIdle;
}

void VLIB_setQosFlowsToIdleInPdu(
    callInfo_type *ptCi, callPDUSessInfo_type *ptPi, uint8_t callPduIdx, uint8_t collectSuccStatFlag)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptPi);
    VCCB_CHECK_E_RANGE_AND_VOID(callPduIdx, MAX_PDU_SESS_PER_CALL);

    uint8_t pduQosFlowIdx = 0, callQosFlowIdx = 0;
    qosFlowInfo_type *ptQi = NULL;

    for (pduQosFlowIdx = 0; pduQosFlowIdx < MAX_QOS_FLOW_PER_PDU_SESS; pduQosFlowIdx++)
    {
        callQosFlowIdx = static_cast<uint8_t>(ptCi->pduSess[callPduIdx].qosFlowIndex[pduQosFlowIdx]);
        if (callQosFlowIdx >= MAX_QOS_FLOW_PER_CALL) continue;
        if (!IS_VALID_NODE(QOSFLOW_NODE, ptCi, &(ptCi->qosFlow[callQosFlowIdx]))) continue;
        ptQi = &ptCi->qosFlow[callQosFlowIdx];

        switch (ptQi->qosFlowStatus)
        {
            case S_Setup:
            case S_Modify:
                if ((ptQi->firstReqStatusInThisProcedure == S_Setup) && (collectSuccStatFlag == VCCB_FLAG_ON))
                {
                    MACRO_STAT_PMCC_QOS_FLOW_SETUP_FAMILY_ALL(QosFlowSetupSucc, ptCi, ptPi, ptQi, 0, 0, 0);
                }
                break;
            case S_Release:
                // QosFlow Release Case
                if (VLIB_FreeCallQosFlowInfoUnderPdu(ptCi, callPduIdx, pduQosFlowIdx) != GOOD)
                {
                    VCCB_PRINT_ERROR("VLIB_FreeCallQosFlowInfoUnderPdu ERROR!! \n");
                }
                break;
            case S_FailToSetup:
                if (VCCB_FLAG_ON == ptCi->bitFlag.isPartialDrbForRreDuringHo)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Skip VLIB_FreeCallQosFlowInfoUnderPdu pdu:%d qos:%d isPartialDrbForRreDuringHo(%llu)!\n",
                        ptPi->pduSessId, ptQi->flowId, 1ULL * ptCi->bitFlag.isPartialDrbForRreDuringHo);
                    continue;
                }

                // QosFlow Release Case
                if (VLIB_FreeCallQosFlowInfoUnderPdu(ptCi, callPduIdx, pduQosFlowIdx) != GOOD)
                {
                    VCCB_PRINT_ERROR("VLIB_FreeCallQosFlowInfoUnderPdu ERROR!! \n");
                }
                break;
            case S_FailToModify:
                if (ptQi->firstReqStatusInThisProcedure == S_Setup)
                {
                    if (VLIB_FreeCallQosFlowInfoUnderPdu(ptCi, callPduIdx, pduQosFlowIdx) != GOOD)
                    {
                        VCCB_PRINT_ERROR("VLIB_FreeCallQosFlowInfoUnderPdu ERROR!! \n");
                    }
                }
                break;
            default:
                break;
        }

        SET_QOSFLOW_STATUS(ptCi, callQosFlowIdx, S_Idle);
        ptCi->qosFlow[callQosFlowIdx].prevQosFlowStatus = S_Idle;
        ptCi->qosFlow[callQosFlowIdx].failCause = CAUSE_NO_FAULT;
        CLEAR_RETAIN_STAT_EVENT(ptCi->qosFlow[callQosFlowIdx].retainStat);
        if (ptCi->qosFlow[callQosFlowIdx].usage == CI_use)
        {
            SET_QOSFLOW_RETAIN_STAT_CAPABLE_FLAG(&ptCi->qosFlow[callQosFlowIdx], VCCB_FLAG_ON);
        }

        /* Add the initailize data forwarding information */
        memset(&ptCi->qosFlow[callQosFlowIdx].dataFwdInfo, 0, sizeof(ptCi->qosFlow[callQosFlowIdx].dataFwdInfo));
        /* Add the initialize releaseInfo */
        memset(&ptCi->qosFlow[callQosFlowIdx].releaseInfo, 0, sizeof(ptCi->qosFlow[callQosFlowIdx].releaseInfo));
    }
}

void VCCM_InitBlacklistCell(callInfo_type *ptCi, int idx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (idx >= MAX_BLACK_CELL)
    {
        VCCB_PRINT_ERROR("idx (%d) >= MAX_BLACK_CELL ERROR!! \n", idx);
        return;
    }
    NEDC_SCG_FAILURE_BLACKLIST(idx).state = EMPTY_STATE;
    NEDC_SCG_FAILURE_BLACKLIST(idx).ci = 0xFFFFFFFFFFFFFFFF;
    NEDC_SCG_FAILURE_BLACKLIST(idx).longId = 0xFFFFFFFF;
    NEDC_SCG_FAILURE_BLACKLIST(idx).enbId = 0xFFFFFFFF;
    NEDC_SCG_FAILURE_BLACKLIST(idx).endTime = 0;

    return;
}

// clear the previous PENDING_STATE cells
// @ret : return value is the number of current blacklisted cells
uint16_t VCCM_CleanupBlacklistTblForNewPscell(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_BLACK_CELL);

    int loop;
    uint16_t cnt = 0;
    struct timeval now;

    if (ComTimeUtil::get_current_time(now) < 0)
    {
        VCCB_PRINT_ERROR("ComTimeUtil::get_current_time ERROR in %s\n", __FUNCTION__);
        return MAX_BLACK_CELL;  // fail
    }

    for (loop = 0; loop < MAX_BLACK_CELL; loop++)
    {
        if (ptCi->ueInfo.blacklistedCell.blacklist[loop].state == PENDING_STATE)
        {
            VCCM_InitBlacklistCell(ptCi, loop);
        }
        else if (ptCi->ueInfo.blacklistedCell.blacklist[loop].state == BLACKCELL_STATE)
        {
            if (now.tv_sec > ptCi->ueInfo.blacklistedCell.blacklist[loop].endTime)
                VCCM_InitBlacklistCell(ptCi, loop);
            else
                cnt++;
        }
    }

    return cnt;
}

uint16_t VCCM_CleanupBlacklistedCells(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_BLACK_CELL);

    int loop;
    uint16_t cnt = 0;
    struct timeval now;

    if (ComTimeUtil::get_current_time(now) < 0)
    {
        VCCB_PRINT_ERROR("ComTimeUtil::get_current_time ERROR in %s\n", __FUNCTION__);
        return MAX_BLACK_CELL;  // means not allowed
    }

    for (loop = 0; loop < MAX_BLACK_CELL; loop++)
    {
        if (ptCi->ueInfo.blacklistedCell.blacklist[loop].state == BLACKCELL_STATE)
        {
            if (now.tv_sec > ptCi->ueInfo.blacklistedCell.blacklist[loop].endTime)
                VCCM_InitBlacklistCell(ptCi, loop);
            else
                cnt++;
        }
    }

    return cnt;
}

void VCCM_FillInPscellInfo(callInfo_type *ptCi, int idx)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (idx >= MAX_BLACK_CELL)
    {
        VCCB_PRINT_ERROR("idx (%d) >= MAX_BLACK_CELL ERROR!! \n", idx);
        return;
    }

    neDcPsCellInfo_type *psCell = &ptCi->psCellInfo;

    NEDC_SCG_FAILURE_BLACKLIST(idx).state = PENDING_STATE;
    NEDC_SCG_FAILURE_BLACKLIST(idx).ci = psCell->eutraCgi.ci;
    NEDC_SCG_FAILURE_BLACKLIST(idx).longId = psCell->eutraCgi.plmn.longId;
    NEDC_SCG_FAILURE_BLACKLIST(idx).enbId = psCell->enbId;
    NEDC_SCG_FAILURE_BLACKLIST(idx).endTime = 0;

    return;
}

int16_t VCCM_RegisterNewEutraPscellInfo2BL(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    int loop;

    // clear previous PENDING_STATE Cells and expired black cells
    if (VCCM_CleanupBlacklistTblForNewPscell(ptCi) == MAX_BLACK_CELL)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Currently MAX_BLACK_CELL of Black Cells !!! \n");
        return ERROR;
    }

    // assign an empty slot
    for (loop = 0; loop < MAX_BLACK_CELL; loop++)
    {
        if (NEDC_SCG_FAILURE_BLACKLIST(loop).state == EMPTY_STATE)
        {
            VCCM_FillInPscellInfo(ptCi, loop);
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "New EUTRA pSCell added on Potential Blacklist Table[%d] CI(0x%llx) longId(0x%x) enbId(%u)  \n", loop,
                1ULL * NEDC_SCG_FAILURE_BLACKLIST(loop).ci, NEDC_SCG_FAILURE_BLACKLIST(loop).longId,
                NEDC_SCG_FAILURE_BLACKLIST(loop).enbId);

            return GOOD;
        }
    }

    VCCB_PRINT_CALL_MSG(ptCi, "No EMPTY_STATE Entry !!!\n");

    return ERROR;
}

void VCCM_MakeEutraPscellBlacklisted(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    int loop;
    struct timeval now;
    neDcPsCellInfo_type *pCell = &ptCi->psCellInfo;

    if (NEDC_SCG_FAILURE_BLACKCELL_FEATURE_ON(ptCi->gnbNum) != TRUE)
    {
        VCCB_PRINT_MSG("Return: blackcell management feature is off !! \n");
        return;
    }

    if (ptCi->psCellInfo.status == N_EQUIP)  // never received psCellInfo from SN
    {
        VCCB_PRINT_ERROR("No psCellInfo currently !! \n");
        return;
    }

    // In case the table was full and therefore failed to register PScellId.
    if (VCCM_RegisterNewEutraPscellInfo2BL(ptCi) == ERROR)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Full of Black Cells so can't add the black cell !!!\n");
        return;
    }

    if (ComTimeUtil::get_current_time(now) < 0)
    {
        VCCB_PRINT_ERROR("ComTimeUtil::get_current_time ERROR in %s\n", __FUNCTION__);
        return;
    }

    /* initiate the slots which the timer has expired on */
    for (loop = 0; loop < MAX_BLACK_CELL; loop++)
    {
        if (NEDC_SCG_FAILURE_BLACKLIST(loop).state == EMPTY_STATE) continue;

        if ((NEDC_SCG_FAILURE_BLACKLIST(loop).state == BLACKCELL_STATE) &&
            (now.tv_sec > NEDC_SCG_FAILURE_BLACKLIST(loop).endTime))
        {
            VCCM_InitBlacklistCell(ptCi, loop);
        }
        else
        {
            if ((NEDC_SCG_FAILURE_BLACKLIST(loop).ci == pCell->eutraCgi.ci) &&
                (NEDC_SCG_FAILURE_BLACKLIST(loop).longId == pCell->eutraCgi.plmn.longId) &&
                (NEDC_SCG_FAILURE_BLACKLIST(loop).enbId == pCell->enbId))
            {
                NEDC_SCG_FAILURE_BLACKLIST(loop).state = BLACKCELL_STATE;
                NEDC_SCG_FAILURE_BLACKLIST(loop).endTime =
                    static_cast<long>(now.tv_sec + NEDC_SCG_FAILURE_BLACKCELL_TIME(ptCi->gnbNum));

                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "New Black Cell !!  Table[%d] CI(0x%llx) longId(0x%x) enbId(%u) - for %ld secs \n", loop,
                    1ULL * NEDC_SCG_FAILURE_BLACKLIST(loop).ci, NEDC_SCG_FAILURE_BLACKLIST(loop).longId,
                    NEDC_SCG_FAILURE_BLACKLIST(loop).enbId,
                    (long)(NEDC_SCG_FAILURE_BLACKLIST(loop).endTime - now.tv_sec));

                return;
            }
        }
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Fail to make Blacklisted CI(0x%llx) longId(%u) enbId(%u)  \n",
        1ULL * pCell->eutraCgi.ci, pCell->eutraCgi.plmn.longId, pCell->enbId);

    return;
}

int16_t VCCM_IsThisEutraCellBlacklisted(callInfo_type *ptCi, nbrEnbCellInfo_type *pNbrEnbCell)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pNbrEnbCell);

    int loop, cnt = 0;
    uint64_t eci = 0;

    if (!NEDC_SCG_FAILURE_FEATURE_ON())
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "F_BasicOperationforNEDC_CALL is OFF !!! \n");
        return FALSE;
    }

    if (NEDC_SCG_FAILURE_BLACKCELL_FEATURE_ON(ptCi->gnbNum) != TRUE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Black Cell management function is OFF on gnb(%d)!!! \n", ptCi->gnbNum);
        return FALSE;
    }

    if ((cnt = VCCM_CleanupBlacklistedCells(ptCi)) == MAX_BLACK_CELL)  // full of TBL
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Full of Blacklist TBL !!! \n");
        return TRUE;
    }

    if (!cnt)  // No entry on TBL
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "No Entry on Blacklist TBL !!! \n");
        return FALSE;
    }

    // find and check the matched entry is or not
    eci = VCCB_GET_ECGI(pNbrEnbCell->enbId, pNbrEnbCell->cellId);
    for (loop = 0; loop < MAX_BLACK_CELL; loop++)
    {
        if (NEDC_SCG_FAILURE_BLACKLIST(loop).state == BLACKCELL_STATE)
        {
            if ((NEDC_SCG_FAILURE_BLACKLIST(loop).ci == eci) &&
                (NEDC_SCG_FAILURE_BLACKLIST(loop).longId == pNbrEnbCell->plmn.longId) &&
                (NEDC_SCG_FAILURE_BLACKLIST(loop).enbId == pNbrEnbCell->enbId))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                    "BLACKCELL_STATE Found on Blacklist[%d] TBL CI:0x%llx enbId:%d longId:0x%x!!! \n", loop, 1ULL * eci,
                    pNbrEnbCell->enbId, pNbrEnbCell->plmn.longId);
                return TRUE;
            }
        }
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Not Blacklisted CI(0x%llx) longId(%u) enbId(%u) !!! \n", 1ULL * eci,
        pNbrEnbCell->plmn.longId, pNbrEnbCell->enbId);

    return FALSE;
}

// Must be call while m.locationInformationSNPresent
// location information at S-NODE directly
// will be called just right after VXIL_Store_XN_LocationInformationSN function
void VCCM_UpdateEutraPSCellId(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    uint16_t nbrIdx;
    nbrEutraCellInfo_type *pNbr;
    nbrEnbCellInfo_type *pNbrEnbCell;
    uint32_t enbId = 0xFFFFFFFF;

    if (!NEDC_SCG_FAILURE_FEATURE_ON())  // check FOO
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "NEDC SCG Failure Function is OFF !!! \n");
        return;
    }

    if (NEDC_SCG_FAILURE_BLACKCELL_FEATURE_ON(ptCi->gnbNum) != TRUE)  // check feature on
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Black Cell management function is OFF !!! \n");
        return;
    }

    // fill neDcPsCellInfo_type
    if ((enbId = VLIB_GetNedcSnodeEnbId(ptCi)) == 0xFFFFFFFF)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Wrong enbId ERROR!!! \n");
        return;
    }

    // Compare it whether duplicated
    if (!memcmp((void *)&(ptCi->recvPsCell.eutraCgi), (void *)&(ptCi->psCellInfo.eutraCgi), sizeof(cgi_type)))
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Received Same PScell (MCC:0x%3x, MNC:0x%3x, CI:0x%llx) \n",
            ptCi->recvPsCell.eutraCgi.plmn.s2.mcc, ptCi->recvPsCell.eutraCgi.plmn.s2.mnc,
            1ULL * ptCi->recvPsCell.eutraCgi.ci);
        return;
    }

    RESET_NEDC_SCG_FAILINFO();

    ptCi->recvPsCell.enbId = enbId;  // enbId with xnIdx
    ptCi->invalidLocInfoSN = FALSE;

    // find PScell in neighbor list
    for (nbrIdx = 0; nbrIdx < MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL; nbrIdx++)  // go through all the neighbors
    {
        pNbr = &pCell->eutraNbr[nbrIdx];

        if (EQUIP != pNbr->status) continue;

        if (GOOD != getNbrEnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &pNbrEnbCell)) continue;

        if (EQUIP != pNbrEnbCell->status) continue;

        if (pNbrEnbCell->nedc_support <= 0) continue;

        if ((ptCi->recvPsCell.enbId == pNbrEnbCell->enbId) &&
            (ptCi->recvPsCell.eutraCgi.plmn.longId == pNbrEnbCell->plmn.longId) &&
            (ptCi->recvPsCell.eutraCgi.ci == VCCB_GET_ECGI(pNbrEnbCell->enbId, pNbrEnbCell->cellId)))
        {
            // update psCellInfo with valid Location Info
            memcpy((void *)&ptCi->psCellInfo, (void *)&ptCi->recvPsCell, sizeof(neDcPsCellInfo_type));
            ptCi->psCellInfo.status = EQUIP;
            ptCi->psCellInfo.nbrIdx = nbrIdx;
            break;
        }
    }

    if (nbrIdx == MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL) ptCi->invalidLocInfoSN = TRUE;

    if (ptCi->invalidLocInfoSN == FALSE)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Updated PScell (MCC:0x%3x, MNC:0x%3x, CI:0x%llx) for Blacklist mgmt\n",
            ptCi->psCellInfo.eutraCgi.plmn.s2.mcc, ptCi->psCellInfo.eutraCgi.plmn.s2.mnc,
            1ULL * ptCi->psCellInfo.eutraCgi.ci);

        if (VCCM_RegisterNewEutraPscellInfo2BL(ptCi) == ERROR)  // It may fail to register If full of black cells
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Full of Black Cells !!!\n");
            return;
        }
    }
    else
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Invalid Location Information at S-NODE - Not in neighbor list \n");
    }

    return;
}

const char *VCCM_strNedcScgFailure(uint16_t failType)
{
    switch (failType)
    {
        case NeDcScgFailCause_UeT313Expired:
            return "UeT313Expired";
        case NeDcScgFailCause_UeRandomAccessProblem:
            return "UeRandomAccessProblem";
        case NeDcScgFailCause_UeRlcMaxRetransmission:
            return "UeRlcMaxRetransmission";
        case NeDcScgFailCause_UeScgChangeFailureEutra:
            return "UeScgChangeFailureEutra";
        default:
            return "Unknown";
    }
}

void VCCM_MissingLocaInfoSN(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    ptCi->invalidLocInfoSN = TRUE;
    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Missing Location Information at S-NODE !!!!\n");
}

void VCCM_ScgFailureActionOnSnReleaseRequired(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (NEDC_SCG_FAILURE_FEATURE_ON())
    {
        // STAT_NEDC_SENB_INIT_REL statistics
        // Being updated in NEDC Basic Functionality - TODO_TODO
        // VLIB_StatNedcSenbInitRel(ptCi, NedcRelBySenb); // the number of SeNB Release Required messages received

        if (ptCi->cause.xnCause == CauseXnapRadioNetworkLayerRadioConnectionWithUeLost)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "Radio Connection with UE Lost Comes\n");
            // STAT_NEDC_SENB_INIT_REL statistics
            // Being updated in NEDC Basic Functionality - TODO_TODO
            // VLIB_StatNedcSenbInitRel(ptCi, NedcRelBySenb_RadioConnectionWithUeLost); // the number of SeNB Release
            // Required messages received

            // Blackcell Mgmt
            if (NEDC_SCG_FAILURE_BLACKCELL_FEATURE_ON(ptCi->gnbNum))
            {
                VCCM_MakeEutraPscellBlacklisted(ptCi);
            }
        }
    }
}

/***************************************************************************
 * @brief Decide whether the split Bearer Release Procedure is required
 * @param[in/out] ptCi : Pointer to call configuration. / callInfo_type*
 * @return status : TRUE,FALSE / int16_t
 ****************************************************************************/
int16_t VCCM_checkForSplitBearerSnNodeRelease(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    int16_t isReleaseRequired = FALSE;
    uint8_t drbId;
    for (drbId = 0; drbId < MAX_DRB_PER_SA_CALL; drbId++)
    {
        if (ptCi->drb[drbId].usage != CI_use) continue;
        if (ptCi->drb[drbId].bearerType.val != MN_Term_SPLIT_Bearer) continue;

        isReleaseRequired = TRUE;
        if (ptCi->drb[drbId].activityStatus == ActivityStatus_ACTIVE)
        {
            isReleaseRequired = FALSE;
            // If any one of the Split Bearer is active Return
            break;
        }
    }

    return isReleaseRequired;
}
/**
 *  @brief Processing SctpDataInd Message
 *  @param ptCi
 *  @param ptAll
 *  @param ptUnpack
 *  @return GOOD/ERROR
 */
int16_t VCCB_ProcMsgSctpDataInd(message_type *ptAll, msgUnpack_type *ptUnpack, uint8_t threadId)
{
    AUTO_TRACE_FUNC;

    long length = 0;
    uint16_t smallLen = 0;
    int stat;
    int16_t status;

    SctpDataType *ptMsg;
    messageHdr_type *ptHdr;

    VALID_E_POINT_CHECK_ERROR(ptAll);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(threadId, MAX_CALL_THREAD_NUM_VCCB);

    ptHdr = reinterpret_cast<messageHdr_type *>(ptAll);
    const uint32_t dstContextId = ptHdr->dst.contextId;

    status = VIIL_storeSctpDataInd(ptAll, threadId);
    if (status == ERROR)
    {
        VCCB_PRINT_ERROR("[dstContextId:%u] VIIL_storeSctpDataInd ERROR!!\n", dstContextId);
        return ERROR;
    }

    ptMsg = reinterpret_cast<SctpDataType *>(ptAll);
    length = static_cast<long>(ptMsg->length);

    if (DBG->flag.errorInd)
    {
        length = length - 100;
    }

    switch (ptMsg->interface)
    {
        case interface_e1:
            smallLen = static_cast<uint16_t>(length);
            stat = UnpackE1_AllMsg(ptUnpack, reinterpret_cast<char *>(ptMsg->data), smallLen);

            if (ASN_OK != stat)
            {
                VCCB_PRINT_ERROR("[dstContextId:%u] E1AP Decoding Impossible(%d) \n", dstContextId, stat);

                if (ptUnpack->procedureCode == E1_ErrorIndication_id)
                {
                    VCCB_PRINT_ERROR(
                        "[dstContextId:%u] procedureCode(%d) indicate ErrorIndication Msg, So should not send "
                        "ErrorIndcation\n",
                        dstContextId, ptUnpack->procedureCode);
                    return ERROR;
                }

                return ERROR;
            }
            break;
        case interface_f1:
        {
            smallLen = static_cast<uint16_t>(length);

            stat = UnpackF1_AllMsg(ptUnpack, reinterpret_cast<char *>(ptMsg->data), smallLen);
            if (ASN_OK != stat)
            {
                VCCB_PRINT_ERROR("[dstContextId:%u] F1AP Decoding Impossible(%d) \n", dstContextId, stat);

                if (ptUnpack->procedureCode == F1_ErrorIndication_id)
                {
                    VCCB_PRINT_ERROR(
                        "[dstContextId:%u] procedureCode(%d) indicate ErrorIndication Msg, So should not send "
                        "ErrorIndcaiton\n",
                        dstContextId, ptUnpack->procedureCode);
                    return ERROR;
                }

                /* TODO
                stat = VXIL_sendF1_ErrorIndication(ptMsg->associateIdx);
                */

                return ERROR;
            }
            VLIB_setMemoryUsageInfo(buf_F1AP, ptUnpack->msgId, ptMsg->length, 0);

            break;
        }
        case interface_x2:
        {
            stat = UnpackX2_Msg(ptUnpack, sizeof(ptUnpack->unpack), reinterpret_cast<char *>(ptMsg->data), static_cast<uint32_t>(length));
            if (ASN_OK != stat)
            {
                VCCB_PRINT_ERROR("[dstContextId:%u] NRX2AP Decoding Impossible(%d) \n", dstContextId, stat);

                if (ptUnpack->procedureCode == 3)  // id_X2AP_errorIndication from ASN_X2AP_3RD
                {
                    VCCB_PRINT_ERROR(
                        "[dstContextId:%u] procedureCode(%d) indicate ErrorIndication Msg, So should not send "
                        "ErrorIndcaiton\n",
                        dstContextId, ptUnpack->procedureCode);
                    return ERROR;
                }

                /* TODO
                stat = VXIL_sendNRX2_ErrorIndication(ptMsg->associateIdx);
                if (GOOD != stat)
                {
                    VCCB_PRINT_ERROR("VXIL_sendNRX2_ErrorIndication ERROR!!\n");
                }
                */

                return ERROR;
            }
            VLIB_setMemoryUsageInfo(buf_X2AP, ptUnpack->msgId, ptMsg->length, 0);
            break;
        }

        case interface_ng:
        {
            stat = fnNGAP_UnpackMsg(ptUnpack, reinterpret_cast<char *>(ptMsg->data), static_cast<int>(length));
            if (ASN_OK != stat)
            {
                VCCB_PRINT_ERROR("[dstContextId:%u] NRNGAP Decoding Impossible(%d) \n", dstContextId, stat);

                /* TODO
                stat = VXIL_sendNRNG_ErrorIndication(ptMsg->associateIdx);
                if (GOOD != stat)
                {
                    VCCB_PRINT_ERROR("VXIL_sendNRNG_ErrorIndication ERROR!!\n");
                }
                */

                return ERROR;
            }
            break;
        }

        case interface_xn:
        {
            stat = fnXNAP_UnpackMsg(ptUnpack, reinterpret_cast<char *>(ptMsg->data), static_cast<int>(length));
            if (ASN_OK != stat)
            {
                VCCB_PRINT_ERROR("[dstContextId:%u] NRXNAP Decoding Impossible(%d) \n", dstContextId, stat);

                /* TODO
                stat = VXIL_sendNRNG_ErrorIndication(ptMsg->associateIdx);
                if (GOOD != stat)
                {
                    VCCB_PRINT_ERROR("VXIL_sendNRNG_ErrorIndication ERROR!!\n");
                }
                */

                return ERROR;
            }
            break;
        }

        default:
            VCCB_PRINT_ERROR(
                "[dstContextId:%u] Invalid Interface in SctpDataInd(%d) \n", dstContextId, ptMsg->interface);
            return ERROR;
    }

    return GOOD;
}
int16_t VCCB_GetMsgUnpack_checkMsgId(message_type *ptAll, msgUnpack_type *ptUnpack, uint8_t threadId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptAll);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);
    VCCB_CHECK_E_RANGE_AND_RETURN(threadId, MAX_CALL_THREAD_NUM_VCCB);

    SctpDataType *ptSctpDataInd;
    messageHdr_type *ptHdr;
    int status = GOOD;

    ptHdr = reinterpret_cast<messageHdr_type *>(ptAll);
    const uint32_t dstContextId = ptHdr->dst.contextId;

    switch (ptAll->msgHdr.msgType)
    {
        case SctpDataTransfer_id:
            // VCCB_ProcMsgSctpDataInd is already processed...
            status = VCCB_ProcMsgSctpDataInd(ptAll, ptUnpack, threadId);
            if (status == ERROR)
            {
                VCCB_PRINT_ERROR("[dstContextId:%u] VCCB_ProcMsgSctpDataInd\n", dstContextId);
                return ERROR;
            }

            ptSctpDataInd = reinterpret_cast<SctpDataType *>(ptAll);

            switch (ptSctpDataInd->interface)
            {
                case interface_e1:
                    VCCB_PRINT_MSG("E1 msgId = 0x%x\n", ptUnpack->msgId);
                    break;

                case interface_f1:
                    VCCB_PRINT_MSG("F1 msgId = 0x%x\n", ptUnpack->msgId);
                    break;

                case interface_x2:
                    VCCB_PRINT_MSG("X2 msgId = 0x%x\n", ptUnpack->msgId);
                    /*
                    ptHdr->transactionId = (((MAX_SRB_PER_CALL+1)<<SRB_SHIFT)&SRB_MASK) +
                        (((MAX_ERAB_PER_CALL+1)<<ERAB_SHIFT)&ERAB_MASK) +
                        (((MAX_GNB_PER_CALL+1)<<GNB_SHIFT)&GNB_MASK) +
                        (ptUnpack->transactionId&SEQUENCE_MASK);
                        */
                    break;
                case interface_ng:
                    VCCB_PRINT_MSG("NG msgId = 0x%x\n", ptUnpack->msgId);
                    break;

                case interface_xn:
                    VCCB_PRINT_MSG("XN msgId = 0x%x\n", ptUnpack->msgId);
                    break;

                default:
                    VCCB_PRINT_ERROR(
                        "[dstContextId:%u]: Invalid Interface (%d) \n", dstContextId, ptSctpDataInd->interface);
                    return ERROR;
            }
            break;

        case msgTransferMessage_VnmbVccb_id:
        {
            msgTransferMessage_type *ptMsg = reinterpret_cast<msgTransferMessage_type *>(ptAll);
            if (ptMsg->interface == interface_xn)
            {
                status =
                    fnXNAP_UnpackMsg(ptUnpack, reinterpret_cast<char *>(ptMsg->data), static_cast<int>(ptMsg->length));
                if (ASN_OK != status)
                {
                    VCCB_PRINT_ERROR("XNAP Decoding Impossible(%d) \n", status);
                    return ERROR;
                }
            }
        }
        break;

        default:
            break;
    }

    return GOOD;
}
/****************************************************************************
 * @brief           Collect statistics for Resume in SCG Failure Handling
 *                  per fail cause
 *
 * @param[in]       ptCi :          call information / callInfo_type
 ****************************************************************************/
void VLIB_StatResumePerFailCauseSCGFailure(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    VLIB_FillSuspendTimeEndCsl(ptCi);

    if (VCCB_FLAG_ON == ptCi->scgSuspendState)
    {
        if (ScgFailCauseInfo_UeT310Expired == ptCi->scgFailCauseInfo)
        {
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_DL_t310Expiry_Resume, ptCi, 0, 0, 0, 0, 0);
        }
        else if (ScgFailCauseInfo_UeRandomAccessProblem == ptCi->scgFailCauseInfo)
        {
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_DL_randomAccessProblem_Resume, ptCi, 0, 0, 0, 0, 0);
        }
        else if (ScgFailCauseInfo_UeSynchReconfigFailureScg == ptCi->scgFailCauseInfo)
        {
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_DL_syncReconfFailure_Resume, ptCi, 0, 0, 0, 0, 0);
        }
        else if (ScgFailCauseInfo_UeRlcMaxRetransmission == ptCi->scgFailCauseInfo)
        {
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_UL_rlcMaxNumRetx_Resume, ptCi, 0, 0, 0, 0, 0);
        }
        else if (ScgFailCauseInfo_DuRlcMaxRetransmission == ptCi->scgFailCauseInfo)
        {
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_DL_rlcMaxNumRetx_Resume, ptCi, 0, 0, 0, 0, 0);
        }
        else if (ScgFailCauseInfo_DuUlRadioLinkFailureOthers == ptCi->scgFailCauseInfo)
        {
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_UL_outOfSync_Resume, ptCi, 0, 0, 0, 0, 0);
        }
        else if (ScgFailCauseInfo_MrBasedSuspend == ptCi->scgFailCauseInfo)
        {
            MACRO_STAT_PMCC(STAT_SCG_FAIL_OPER, SCGFailOper_MrBased_Resume, ptCi, 0, 0, 0, 0, 0);
        }

        ptCi->scgSuspendState = VCCB_FLAG_OFF;
        MACRO_RESET_CALL_FAULT_CAUSES;
    }

    ptCi->scgFailCauseInfo = ScgFailCauseInfo_NoScgFailure;

    return;
}
void VCCB_DetachHoTimer(handoverInfo_type *ptHo)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptHo);

    MACRO_CHECK_AND_DETACH(ptHo->timer.e1);
    MACRO_CHECK_AND_DETACH(ptHo->timer.f1);
    MACRO_CHECK_AND_DETACH(ptHo->timer.xn);
    MACRO_CHECK_AND_DETACH(ptHo->timer.spec);
}

// Be called while the call is released
void FnVCCB_DetachSaHoFeaturesTimer(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);

    MACRO_CHECK_AND_DETACH(ptCi->saPriorHOTimer);
    MACRO_CHECK_AND_DETACH(ptCi->saHoMrQueueInfo.t4);
    MACRO_CHECK_AND_DETACH(ptCi->saHoMrQueueInfo.t5);
    MACRO_CHECK_AND_DETACH(ptCi->forcedHO.timer);
    MACRO_CHECK_AND_DETACH(ptCi->lbMrTimer);
    MACRO_CHECK_AND_DETACH(ptCi->iratLbMrWaitTimer);
    MACRO_CHECK_AND_DETACH(ptCi->voNrLbMrWaitTimer); // FGR-LC0712

    // TODO - Need to check if there are more timers to be released
}

void VCCB_DetachAllTimer_sendReleaseAll(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    uint16_t srbIdx, erabIdx, hoGnbIdx;

    MACRO_CHECK_AND_DETACH(ptCi->timer);

    FnVCCB_DetachCallMultiTimer(ptCi);

    VCCB_DetachHoTimer(&ptCi->hoInfo);

    FnVCCB_DetachSaHoFeaturesTimer(ptCi);

    if (ptCi->callType == E_CALLTYPE_SA)
    {
        if (ptCi->secuModeCmpTimer.id >= 0)
        {
            VCCB_CLEAR_TIMER(&ptCi->secuModeCmpTimer, CANCEL_TIMER);
        }

        if (ptCi->dlNasWaitingAckTimer.id >= 0)
        {
            VCCB_CLEAR_TIMER(&ptCi->dlNasWaitingAckTimer, CANCEL_TIMER);
        }

        if (ptCi->ulDedicatedMsgSegTimer.id >= 0)
        {
            VCCB_CLEAR_TIMER(&ptCi->ulDedicatedMsgSegTimer, CANCEL_TIMER);
        }

        if (ptCi->ueCapaEnquiry.ueCapaInfoTimer.id >= 0)
        {
            VCCB_CLEAR_TIMER(&ptCi->ueCapaEnquiry.ueCapaInfoTimer, CANCEL_TIMER);
        }

        if (ptCi->ueInfo.RrcInactiveInfo.guardTimer.id > 0)
        {
            VCCB_CLEAR_TIMER(&ptCi->ueInfo.RrcInactiveInfo.guardTimer, CANCEL_TIMER);
        }

        if (ptCi->redirectionInfo.mrWaitTimer.id > 0)
        {
            VCCB_CLEAR_TIMER(&ptCi->redirectionInfo.mrWaitTimer, CANCEL_TIMER);
        }
    }

    if (IS_TIMER_VALID(ptCi->anrInfo.reportCgiTimer)) VCCB_CLEAR_TIMER(&ptCi->anrInfo.reportCgiTimer, CANCEL_TIMER);

    for (srbIdx = 0; srbIdx < MAX_SRB_PER_CALL; srbIdx++)
    {
        if (!IS_VALID_NODE(SRB_NODE, ptCi, &(ptCi->srbInfo[srbIdx]))) continue;

        if (ptCi->srbInfo[srbIdx].timer.id >= 0) VCCB_CLEAR_TIMER(&ptCi->srbInfo[srbIdx].timer, CANCEL_TIMER);
    }

    for (hoGnbIdx = 0; hoGnbIdx < MAX_GNB_PER_CALL; hoGnbIdx++)
    {
        if (!IS_VALID_NODE(GNB_NODE, ptCi, &(ptCi->gnbInfo[hoGnbIdx]))) continue;

        if (ptCi->gnbInfo[hoGnbIdx].timer.id >= 0) VCCB_CLEAR_TIMER(&ptCi->gnbInfo[hoGnbIdx].timer, CANCEL_TIMER);

        for (erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
        {
            if (!IS_VALID_NODE(PATH_NODE, &(ptCi->gnbInfo[hoGnbIdx]), &(ptCi->gnbInfo[hoGnbIdx].dlPath[erabIdx])))
                continue;

            if (ptCi->gnbInfo[hoGnbIdx].dlPath[erabIdx].timer.id >= 0)
                VCCB_CLEAR_TIMER(&ptCi->gnbInfo[hoGnbIdx].dlPath[erabIdx].timer, CANCEL_TIMER);
        }

        for (erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
        {
            if (!IS_VALID_NODE(PATH_NODE, &(ptCi->gnbInfo[hoGnbIdx]), &(ptCi->gnbInfo[hoGnbIdx].ulPath[erabIdx])))
                continue;

            if (ptCi->gnbInfo[hoGnbIdx].ulPath[erabIdx].timer.id >= 0)
                VCCB_CLEAR_TIMER(&ptCi->gnbInfo[hoGnbIdx].ulPath[erabIdx].timer, CANCEL_TIMER);
        }
    }

    for (auto ltmCellIdx = 0; ltmCellIdx < MAX_NUM_LTM_CELLS; ltmCellIdx++)
    {
        auto &ltmRelTimer = ptCi->ltmUeInfo.cellList[ltmCellIdx].handle.ltmCellReleaseTimer;
        if (IS_TIMER_VALID(ltmRelTimer)) VCCB_CLEAR_TIMER(&ltmRelTimer, CANCEL_TIMER);
    }
}

int16_t FnVCCB_SaveShm_For_SctpDataTransfer(const message_type *ptAll, const uint8_t threadId)
{
    AUTO_TRACE_FUNC;

    SctpDataTransfer_type *ptMsg;
    uint32_t length;

    VALID_E_POINT_CHECK_ERROR(ptAll);
    VCCB_CHECK_E_RANGE_AND_RETURN(threadId, MAX_CALL_THREAD_NUM_VCCB);

    ptMsg = (SctpDataTransfer_type *)ptAll;

    length = ptMsg->length + static_cast<uint16_t>((long)(ptMsg->data) - (long)(ptMsg));

    {
        uint16_t gnbNum = 0;
        uint8_t peerNode = BLK_VNMB;  // For Logging
        callInfo_type *ptTmpCi = NULL;

        uint32_t dstContextId = ptMsg->hdr.dst.contextId;
        callInfo_type *ptCi = FnVCCB_GetCallInUseByCuCpUeId(dstContextId);
        if (ptCi != NULL && ptCi->myThreadId == threadId)
        {
            ptTmpCi = ptCi;
        }
        else
        {
            ptTmpCi = &THREAD_INFO->call[threadId].tempCallInfo;

            // Initialize tmpCall
            if (VCOM_getSystemType() == e_VCCB_NVGNB || (TRUE == FOO.VF_MultipleOperatorRanSupport))
            {
                VCCB_CHECK_E_RANGE_AND_RETURN(ptMsg->gnbNum, MAX_GNB_PER_SYS);
                gnbNum = ptMsg->gnbNum;
            }
            else
            {
                VCCB_GET_GNB_NUM_FROM_ID_RETURN(ptMsg->gnbId, gnbNum);
            }
            VLIB_InitCallInfo(ptTmpCi, threadId, gnbNum, E_CALLTYPE_UNKNOWN);
            uint32_t vccbCallId = FnVCCB_GetVccbCallId(dstContextId);
            ptTmpCi->callId = (vccbCallId < VCCB_MAX_CALL_COUNT_PER_CPC) ? vccbCallId : UNKNOWN_CP_CALLID;
        }

        if (ptMsg->hdr.src.blockType == BLOCK_VCLB)
        {
            peerNode = BLK_VCLB;
        }
        else
        {
            peerNode = BLK_VNLB;
        }

        // LOGGING
        logShmIntMsg(ptTmpCi, RX_MSG, peerNode, SctpDataTransfer_id, length, reinterpret_cast<uint8_t *>(ptMsg));
    }

    return GOOD;
}

/**
 * @brief       store SctpDataInd message
 * @param       ptCi        : call info DB
 * @param       ptAll       : message type
 * @return      GOOD        : success store
 */
int16_t VIIL_storeSctpDataInd(message_type *ptAll, uint8_t threadId)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptAll);
    VCCB_CHECK_E_RANGE_AND_RETURN(threadId, MAX_CALL_THREAD_NUM_VCCB);

    if (DBG->log.logStoreSctpMsg == VCCB_FLAG_ON)
    {
        int16_t status = FnVCCB_SaveShm_For_SctpDataTransfer(ptAll, threadId);
        VCCB_RETURN_ON_ERROR(status, "FnVCCB_SaveShm_For_SctpDataTransfer ERROR!!\n");
    }

    return GOOD;
}

int16_t VCCB_findTargetCellNumDuringIntraGnbSaHO(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    uint16_t targetCellNum = MAX_CELL_NUM_VCCB;
    int16_t status = GOOD;

    if (ptCi->callType != E_CALLTYPE_SA)
    {
        return ERROR;
    }

    if (!VHCM_isSaHandoverUE(ptCi))
    {
        return ERROR;
    }

    status = VCCM_GetCellNumFromNrCgi(ptCi->gnbNum, &ptCi->nRCGI, &targetCellNum, false);
    if (status == GOOD && targetCellNum < MAX_CELL_NUM_VCCB)
    {
        return static_cast<int16_t>(targetCellNum);
    }

    return static_cast<int16_t>(ptCi->servCellNum);
}

/****************************************************************************
 * @brief           This function provides operation to acquire Emergency ARP information based on PLMN Index.
 *
 * @param[in]       pFunc            : parent function name / const char*
 * @param[in]       ptCi             : call information     / callInfo_type
 * @param[in]       plmnIndex        : target plmn index    / uint8_t
 *
 * @param[out]      Pointer          : if valid, {validation address}, else {null}  emergencyArpInfo_type
 ****************************************************************************/
emergencyArpInfo_type *FnVCCB_FindEmergencyArpInfoByPlmnIdx(
    const char *pFunc, callInfo_type *ptCi, uint8_t plmnIndex, bool isPrint)
{
    VALID_E_POINT_CHECK_NULL(pFunc);
    VALID_E_POINT_CHECK_NULL(ptCi);
    VCCB_CHECK_VALID_GNBNUM_NULL(ptCi->gnbNum);
    VCCB_CHECK_E_RANGE_AND_NULL(plmnIndex, MAX_PLMN_INDEX);

    emergencyArpInfo_type *pEmerArp = &GNBINFO[ptCi->gnbNum].emerArpInfo[plmnIndex];
    if (pEmerArp->shmStatus == N_EQUIP)
    {
        if (isPrint) VCCB_PRINT_CALL_COMMENT(ptCi, "%s pEmerArp->shmStatus is NOT EQUIPPED\n", pFunc);
        return NULL;
    }
    return pEmerArp;
}

/****************************************************************************
 * @brief           This function provides operation to acquire Emergency ARP information based on PLMN.
 *
 * @param[in]       pFunc            : parent function name / const char*
 * @param[in]       ptCi             : call information     / callInfo_type
 * @param[in]       ptTargetPlmn     : find target plmn     / plmnId_type*
 *
 * @param[out]      Pointer          : if valid, {validation address}, else {null}  emergencyArpInfo_type
 ****************************************************************************/
emergencyArpInfo_type *FnVCCB_FindEmergencyArpInfo(
    const char *pFunc, callInfo_type *ptCi, plmnId_type *ptTargetPlmn, bool isPrint)
{
    VALID_E_POINT_CHECK_NULL(pFunc);
    VALID_E_POINT_CHECK_NULL(ptCi);
    VALID_E_POINT_CHECK_NULL(ptTargetPlmn);
    int16_t status = GOOD;
    uint8_t plmnIndex = MAX_PLMN_INDEX;
    status = VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &plmnIndex, ptTargetPlmn->longId);
    if (status != GOOD)
    {
        if (isPrint) VCCB_PRINT_CALL_ERROR(ptCi, "%s VLIB_getMultipleGnbPlmnIndexInfo is Failed\n", pFunc);
        return NULL;
    }
    if (plmnIndex >= MAX_PLMN_INDEX)
    {
        if (isPrint) VCCB_PRINT_CALL_ERROR(ptCi, "%s plmnIndex is not valid\n", pFunc);
        return NULL;
    }
    return FnVCCB_FindEmergencyArpInfoByPlmnIdx(pFunc, ptCi, plmnIndex, isPrint);
}

/****************************************************************************
 * @brief           Check the emergency condition for the bearer.
 *                  For common code (BASIC, HO, ...), detailed algorithms were separated to the outside.
 *
 * @param[in]       pFunc               : parent function name  / const char*
 * @param[in]       ptCi                : call information     / callInfo_type
 * @param[in]       pEmerArp            : emergency information / emergencyArpInfo_type *
 * @param[in]       priorityLevel       : arp info in qos       / uint8_t
 * @param[in]       fiveQi              : 5qi in qosflow        / uint8_t
 *
 * @param[out]      true/false          : if valid, {validation address}, else {null}  emergencyArpInfo_type
 ****************************************************************************/
int16_t FnVCCB_CheckEmergencyBearerItem(const char *pFunc, callInfo_type *ptCi, emergencyArpInfo_type *pEmerArp,
    uint8_t priorityLevel, uint8_t fiveQi, bool isPrint)
{
    VALID_E_POINT_CHECK_FALSE(pFunc);
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pEmerArp);

    int combIndex = 0;

    if (pEmerArp->emerArpOption == ARP_ONLY_MODE)
    {
        // Check ARP Value
        if (priorityLevel <= pEmerArp->emerArpValue)
        {
            if (isPrint)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "%s The call is confirmed as an emergency call.\n", pFunc);
                VCCB_PRINT_CALL_DATA(
                    ptCi, "%s priorityLevel(%d) <= emerArpValue(%d)\n", pFunc, priorityLevel, pEmerArp->emerArpValue);
            }
            return TRUE;
        }
        return FALSE;
    }
    else
    {
        // FIVEQI_ARP_MODE
        // Check 5QI and ARP value and satisfy condition return true
        for( combIndex = 0 ; combIndex < MAX_5QI_ARP ; combIndex++ ){
            if( pEmerArp->fiveqiArp[combIndex].shmStatus == N_EQUIP ) continue;
            if (fiveQi == pEmerArp->fiveqiArp[combIndex].fiveqiValue && priorityLevel == pEmerArp->fiveqiArp[combIndex].fiveqiArpValue)
            {
                if (isPrint)
                {
                    VCCB_PRINT_CALL_DATA(ptCi, "%s The call is confirmed as an emergency call.\n", pFunc);
                    VCCB_PRINT_CALL_DATA(ptCi,
                        "%s fiveqi(%d) == fiveqiValue(%d), priorityLevel(%d) == fiveqiArpValue(%d)\n", pFunc, fiveQi,
                        pEmerArp->fiveqiArp[combIndex].fiveqiValue, priorityLevel, pEmerArp->fiveqiArp[combIndex].fiveqiArpValue);
                }
                return TRUE;
            }
        }
        return FALSE;
    }
}

/****************************************************************************
 * @brief           Check the emergency condition for the bearer. If satisfied,
 *                  TRUE or FALSE is returned.
 *
 * @param[in]       ptCi :          call information / callInfo_type
 ****************************************************************************/

int16_t VCCM_CheckEmergencyBearer(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_VALID_GNBNUM_FALSE(ptCi->gnbNum);

    emergencyArpInfo_type *pEmerArp = FnVCCB_FindEmergencyArpInfo(__func__, ptCi, &ptCi->ueInfo.servedPlmn, true);
    if (pEmerArp == NULL)
    {
        // LOG is output from FnVCCB_FindEmergencyArpInfo.
        return FALSE;
    }

    for (uint16_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[pduIdx]))) continue;
        for (uint16_t pduQosIdx = 0; pduQosIdx < MAX_QOS_FLOW_PER_PDU_SESS; pduQosIdx++)
        {
            uint16_t qosIdx = ptCi->pduSess[pduIdx].qosFlowIndex[pduQosIdx];
            if (qosIdx >= MAX_QOS_FLOW_PER_CALL) continue;
            qosFlowInfo_type *ptQi = &ptCi->qosFlow[qosIdx];
            if (ptQi->usage != CI_use) continue;
            if ((ptQi->qosFlowStatus != S_Setup) && (ptQi->qosFlowStatus != S_Modify) &&
                (ptQi->qosFlowStatus != S_Idle))
                continue;

            VCCB_PRINT_CALL_COMMENT(
                ptCi, "%s qosIdx(%d) ptQi->qosFlowStatus(%d)\n", __func__, qosIdx, ptQi->qosFlowStatus);

            uint8_t fiveqi = 0;
            if (pEmerArp->emerArpOption == FIVEQI_ARP_MODE)
            {
                // Need Only 'FIVEQI_ARP_MODE'
                VLIB_getFiveQi(ptQi, &fiveqi);
            }
            if (FnVCCB_CheckEmergencyBearerItem(
                    __func__, ptCi, pEmerArp, ptQi->qosParam.allocAndRetent.priorityLevel, fiveqi, true) == TRUE)
            {
                // Found EmegencyBearer
                return TRUE;
            }
        }
    }

    return FALSE;
}

/****************************************************************************
 * @brief           Check the emergency condition for the call. If satisfied,
 *                  TRUE or FALSE is returned.
 *
 * @param[in]       ptCi :          call information / callInfo_type
 ****************************************************************************/

int16_t VCCM_CheckEmergencyCall(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_VALID_GNBNUM_FALSE(ptCi->gnbNum);

    ptCi->bitFlag.emergencyCallFlagJustUsingCnfUpgrade = FALSE;

    if (ptCi->ueInfo.establishmentCause == ci_emergency)
    {
        VCCB_PRINT_CALL_DATA(
            ptCi, "This call is confirmed as an emergency call (establishmentCause is ci_emergency)\n");
        
        ptCi->bitFlag.emergencyCallFlagJustUsingCnfUpgrade = TRUE;
        return TRUE;
    }

    if (TRUE == VCCM_CheckEmergencyBearer(ptCi))
    {
        VCCB_PRINT_CALL_DATA(ptCi, "This call is confirmed as an emergency call (emergency bearer).\n");

        ptCi->bitFlag.emergencyCallFlagJustUsingCnfUpgrade = TRUE;
        return TRUE;
    }
    
    return FALSE;
}

int16_t FnVCCB_CheckEmergencyVoNR(callInfo_type *ptCi, uint8_t priorityLevel)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    emergencyArpInfo_type *pEmerArp = FnVCCB_FindEmergencyArpInfo(__func__, ptCi, &ptCi->ueInfo.servedPlmn, false);
    if (pEmerArp == NULL)
    {
        // LOG is output from FnVCCB_FindEmergencyArpInfo.
        return FALSE;
    }

    if (FnVCCB_CheckEmergencyBearerItem(__func__, ptCi, pEmerArp, priorityLevel, VONR_5QI, false) == TRUE)
    {
        // Found EmegencyBearer
        return TRUE;
    }

    return FALSE;
}

int16_t FnVCCB_CheckIsVoNRInService(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (N_EQUIP == VCCM_CheckSupport5QI(ptCi, ptCi->gnbNum, VONR_5QI, false))
    {
        return FALSE;
    }

    if (VCCB_UNSUPPORTED == VCCM_CheckVoiceOverNRCapa(*ptCi, ptCi->servCellNum, false))
    {
        return FALSE;
    }

    if (TRUE == FnVCCB_IsVoNRCall(ptCi))
    {
        return TRUE;
    }

    return FALSE;
}

uint16_t FnVCCB_GetVoNRQoSFlowIndex(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_QOS_FLOW_PER_CALL);

    uint8_t fiveQi;
    uint16_t qosFlowIdx;

    qosFlowInfo_type *ptQi = NULL;

    for (qosFlowIdx = 0; qosFlowIdx < MAX_QOS_FLOW_PER_CALL; qosFlowIdx++)
    {
        ptQi = &ptCi->qosFlow[qosFlowIdx];

        if (ptQi->usage != CI_use) continue;
        if ((ptQi->qosFlowStatus != S_Idle) && (ptQi->qosFlowStatus != S_Setup) && (ptQi->qosFlowStatus != S_Modify))
            continue;

        VLIB_getFiveQi(ptQi, &fiveQi);

        if (fiveQi != VONR_5QI) continue;

        return qosFlowIdx;
    }

    return MAX_QOS_FLOW_PER_CALL;
}

uint16_t FnVCCB_GetVoNRQosFlowIndexOfDRB(callInfo_type *ptCi, callDRBInfo_type *ptDi)
{
    AUTO_TRACE_FUNC;
 
    VALID_E_POINT_CHECK_RET_VAL(ptCi, MAX_QOS_FLOW_PER_CALL);
    VALID_E_POINT_CHECK_RET_VAL(ptDi, MAX_QOS_FLOW_PER_CALL);
 
    for (uint8_t drbQosIdx = 0; drbQosIdx < MAX_QOS_FLOW_PER_DRB; drbQosIdx++)
    {
        uint8_t fiveQi = 0;
        uint16_t qosFlowIndex = ptDi->qosFlowIndex[drbQosIdx];
        if (qosFlowIndex >= MAX_QOS_FLOW_PER_CALL) continue;
 
        qosFlowInfo_type *ptQi = &ptCi->qosFlow[qosFlowIndex];
 
        if (ptQi->usage != CI_use) continue;
        if ((ptQi->qosFlowStatus != S_Idle) && (ptQi->qosFlowStatus != S_Setup) && (ptQi->qosFlowStatus != S_Modify))
            continue;
 
        VLIB_getFiveQi(ptQi, &fiveQi);

        if (fiveQi != VONR_5QI) continue;
        
        return qosFlowIndex;
    }
 
    return MAX_QOS_FLOW_PER_CALL;
}

int16_t FnVCCB_CheckAllowedConcurrentNRDCandVoNR(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VCCB_CHECK_VALID_GNBNUM_FALSE(ptCi->gnbNum);
    VCCB_CHECK_E_RANGE_AND_FALSE(cellNum, MAX_CELL_NUM_VCCB);
    const VccbCellInfo_type *const pCell = &CELLINFO[cellNum];

    uint16_t qosFlowIdx;

    if (FALSE == FnVCCB_CheckIsVoNRInService(ptCi))
    {
        // No need to consider concurrent NR-DC and VoNR because VoNR is not in service.
        return TRUE;
    }

    qosFlowIdx = FnVCCB_GetVoNRQoSFlowIndex(ptCi);
    if (qosFlowIdx >= MAX_QOS_FLOW_PER_CALL)
    {
        // No need to consider concurrent NR-DC and VoNR because VoNR is not in service.
        return TRUE;
    }

    if (TRUE == FnVCCB_CheckEmergencyVoNR(ptCi, ptCi->qosFlow[qosFlowIdx].qosParam.allocAndRetent.priorityLevel))
    {
        if (pCell->nrdcCellInfo.gnbConfVonrEmergency == access_s5gtype_allowed)
        {
            return TRUE;
        }
    }
    else
    {
        if (pCell->nrdcCellInfo.gnbConfVonrRegular == access_s5gtype_allowed)
        {
            return TRUE;
        }
    }

    return FALSE;
}

/**
 * @brief  Initialize PDCP SN and set PDCP version change
 *
 * @param[in]       ptCi : call information / callInfo_type
 */
void VCCM_InitializePdcpSn(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    uint8_t erabIdx = 0;
    callERABInfo_type *ptRi = NULL;

    VALID_E_POINT_CHECK_VOID(ptCi);

    for (erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
    {
        ptRi = &ptCi->erabInfo[erabIdx];
        if (CI_use != ptRi->usage) continue;

        ptRi->snStatus.pdcpVersionChangeInd = 1;
    }

    return;
}

/**
 **  @brief Set Call Info for full config
 **  @param callInfo_type *ptCi
 **  @return int16_t GOOD/ERROR (1/-1)
 **/
int16_t VCCM_SetCallInfoForFullConfig(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if (IS_FULLCONFIGURATION_NOT_IN_PROCESS(ptCi))
    {
        return GOOD;
    }

    VCCM_InitInstalledMeasConfig_ByFullConfiguration(ptCi);
    VCCM_InitializePdcpSn(ptCi);

    return GOOD;
}

/**
 * @brief  Decide full config SgNB Addition
 *
 * @param[in]       ptCi : call information / callInfo_type
 */
int16_t VCCM_DecideFullConfigNSA(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;

    int16_t status = GOOD;
    uint8_t erabIdx = 0;
    callERABInfo_type *ptRi = NULL;

    VALID_E_POINT_CHECK_ERROR(ptCi);

    if ((SgnbAddTrigInd_Unknown != ptCi->hoInfo.sgnbAddTrigInd) &&
        (VCCB_FLAG_OFF == ptCi->cgConfigInfo.sourceConfigSCG_Flag))
    {
        for (erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
        {
            ptRi = &ptCi->erabInfo[erabIdx];
            if (CI_use != ptRi->usage) continue;
            if (GET_DRB_SRC_CFG_FLAG(ptRi->flag.setupFlag)) break;
        }

        if (MAX_ERAB_PER_CALL <= erabIdx)
        {
            VCCB_PRINT_CALL_INFORMATIVE(ptCi,
                "[FullConfig] sgnbAddTrigInd(%d), sourceConfigSCG and mcg/scg-RB-Config are not received, set FC\n",
                ptCi->hoInfo.sgnbAddTrigInd);
            VCCB_SET_FULLCONFIGURATION(
                ptCi, ci_fc_trigger, "NSA, Scenario::sourceConfigSCG and mcg/scg-RB-Config are not received");
        }
    }

    status = VCCM_DecisionCuInitFullConfigurationUE(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_DecisionCuInitFullConfigurationUE Error in %s\n", __func__);
    if (status == BREAK)
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "Reject by Full Configuration!! in %s\n", __func__);
        return BREAK;
    }

    return GOOD;
}

int16_t VCCM_DecideCuInitFullConfigSA(callInfo_type *ptCi, const cellSelection_type *ptTgtCellSelection, const char *ptFuncName)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR_PARAM2(ptCi, ptFuncName);

    const int16_t status = VCCM_DecisionCuInitFullConfigurationUE(ptCi, ptTgtCellSelection);
    switch(status)
    {
        case ERROR:
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCM_DecisionCuInitFullConfigurationUE (SA) Error in %s\n", ptFuncName);
            break;

        case BREAK:
            VCCB_PRINT_CALL_ERROR(ptCi, "Reject by CU Init Full Configuration (SA)!! Error in %s\n", ptFuncName);
            break;

        default:
            break;
    }

    return status;
}

/**
 *  @brief This function is used to force full configurtion over XN interface during mobility procedure.
 *  @details Officially, MN or SN initiated full configuration is not supported. This should only be used for testing purpose
 *  @param  ptCi          : pointer to UE Context
 *  @param  ptFuncName    : name of calling function
 **/
bool VCCM_ForceFullConfigOverXn(callInfo_type *ptCi, const char *ptFuncName, bool isSender)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptFuncName);

    VccbFullConfigScenario_type *pScenario = &CFG->fullConfig.dbg.forcedTriggerScenario;

    if (VCCB_FLAG_ON != DBG->flag.applySnInitFullConfigInMn_24B) return false;

    if (IS_NRDC_SN(ptCi))
    {
        if (isSender)
        {
            if (true != pScenario->EventScenario_MRDC_SN_SnInit) return false;
        }
        else
        {
            if (true != pScenario->EventScenario_MRDC_SN_MnInit) return false;
        }

        VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_trigger, "NR-DC SN, force %s-init full configuration in %s\n",
            (isSender)? "SN":"MN", ptFuncName);
    }
    else
    {
        if (isSender)
        {
            if (true != pScenario->EventScenario_MRDC_MN_MnInit) return false;
        }
        else
        {
            if (true != pScenario->EventScenario_MRDC_MN_SnInit) return false;
        }

        // VCCB_SET_FULLCONFIGURATION(ptCi, ci_fc_trigger, "NR-DC MN, force %s-init full configuration in %s\n",
        //     (isSender)? "SN":"MN", ptFuncName);
    }

    return true;
}

// NR_CONN_MC_21D
int VCCM_CheckCellServiceState_EUTRA(const callInfo_type *ptCi, const nbrEnbCellInfo_type *pNbrEnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);

    // If DL EARFCN and UL EARFCN are different and UL EARFCN is 'maxEARFCN2(262143, refer TS36.331)',
    // It is determined as a SDL cell.
    if ((pNbrEnbCell->earfcnDl != pNbrEnbCell->earfcnUl) && (MAX_EARFCN_EXT == pNbrEnbCell->earfcnUl))  //
    {
        VCCB_PRINT_CALL_INFORMATIVE(ptCi, "EUTRA NBR(cellId=%d) earfcnDl(%d) earfcnUl(%d) : SDL Cell!!\n",
            pNbrEnbCell->cellId, pNbrEnbCell->earfcnDl, pNbrEnbCell->earfcnUl);
        return BREAK;
    }

    return GOOD;
}

// SVR22B FGR-CC0103
int16_t FnVCCB_Check_OnlyRrcInactiveTransitionReportRequestIncluded(
    callInfo_type *ptCi, NG_UEContextModificationRequestAmfAll_type *ptMsg)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(ptMsg);

    if (ptMsg->m.rRCInactiveTransitionReportRequestPresent)
    {
        ptMsg->m.rRCInactiveTransitionReportRequestPresent = OPT_NOT_PRESENT;
        uint32_t temp = 0;
        if (!memcmp(&ptMsg->m, &temp, sizeof(ptMsg->m)))
        {
            ptMsg->m.rRCInactiveTransitionReportRequestPresent = OPT_PRESENT;
            return TRUE;
        }
        ptMsg->m.rRCInactiveTransitionReportRequestPresent = OPT_PRESENT;
    }
    return FALSE;
}

measResult2NR_type *FnVCCB_GetMeasResult2NRforNeighbor(callInfo_type *ptCi, measResultList2NR_type *pMeasResultList2NR)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_NULLPTR(ptCi);
    VALID_E_POINT_CHECK_NULLPTR(pMeasResultList2NR);

    measResult2NR_type *pMeasResult2NR;
    uint16_t freqIdx = 0, maxIdx = static_cast<uint16_t>(UMIN(pMeasResultList2NR->nrofFreq, (uint8_t)MAX_NUM_FREQ));

    for (freqIdx = 0; freqIdx < maxIdx; freqIdx++)
    {
        pMeasResult2NR = &pMeasResultList2NR->measResult2NR[freqIdx];
        if (!pMeasResult2NR->ssbFrequency_Flag)
        {
            continue;
        }

        if (pMeasResult2NR->measResultServingCell_Flag == VCCB_FLAG_ON)
        {
            continue;
        }
        return pMeasResult2NR;  // measResult2NR for Neighbor is just one
    }

    VCCB_PRINT_CALL_ERROR(ptCi, "Can't find measResult2NR for Neighbor in %s!!!\n", __func__);
    return nullptr;
}

int16_t FnVCCB_ReCompositeMeasResult2NRwithOnlyNeighCellListNR(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    measResultList2NR_type *pMeasResultList2NR =
        &THREAD_INFO->call[ptCi->myThreadId].buf.measResultList2NRRx.candidateCellInfoListSN;
    int16_t status = GOOD;

    measResult2NR_type *pMeasResult2NR = FnVCCB_GetMeasResult2NRforNeighbor(ptCi, pMeasResultList2NR);
    if (pMeasResult2NR == nullptr)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetMeasResult2NRforNeighbor ERROR in %s!!\n", __func__);
        return ERROR;
    }

    pMeasResultList2NR->nrofFreq = 1;
    if (pMeasResult2NR != pMeasResultList2NR->measResult2NR)
    {
        pMeasResultList2NR->measResult2NR[0] = *pMeasResult2NR;
    }

    msgContainer_type *pRrcTxBuf = &THREAD_INFO->call[ptCi->myThreadId].buf.rrcTx;
    long len = sizeof(pRrcTxBuf->data);
    NRRRC__octet1 packMsg;

    status = MakeMsgNRRRC_MeasResultList2NR(ptCi, pMeasResultList2NR, pRrcTxBuf->data, &len);
    if (GOOD != status)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "MakeMsgNRRRC_MeasResultList2NR ERROR in %s!!\n", __func__);
        return ERROR;
    }

    packMsg.length = static_cast<unsigned int>(len);
    packMsg.value = pRrcTxBuf->data;

    status = FnVCCB_Mrdc_Store_octetString(
        __func__, ptCi, &ptCi->loadBasedNrdcScgBandSelectInfo.measResultList2NR, &packMsg);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_Mrdc_Store_octetString for measResultList2NR ERROR in %s!!\n", __func__);
        return ERROR;
    }
    return GOOD;
}

int16_t FnVCCB_RestoreMeasResultList2NRforSelectedFr2Band(
    callInfo_type *ptCi, measResultList2NR_type *ptMeasResultList2NR)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptMeasResultList2NR);

    octetStringType *pOctetString = &ptCi->loadBasedNrdcScgBandSelectInfo.measResultList2NR;

    if (FnVCCB_CheckValid_octetString(pOctetString))
    {
        msgUnpack_type *ptUnpack = &THREAD_INFO->call[ptCi->myThreadId].buf.unpack.store;

        if (ERROR == UnpackNRRRC_MeasResultList2NR(ptUnpack, pOctetString->value, pOctetString->length))
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "UnpackNRRRC_MeasResultList2NR ERROR in %s!\n", __func__);
            return ERROR;
        }
        else
        {
            ptMeasResultList2NR->nrofFreq = 0;
            NRRRC_MeasResultList2NR pMeasResult2NR =
                *reinterpret_cast<NRRRC_MeasResultList2NR *>(&ptUnpack->unpack[0] + ptUnpack->unpackMsgOffset);

            if (ERROR == VRIL_StoreNRRRC_MeasResultList2NR(ptMeasResultList2NR, pMeasResult2NR))
            {
                VCCB_PRINT_CALL_ERROR(ptCi, "VRIL_StoreNRRRC_MeasResultList2NR ERROR,in %s!\n", __func__);
                return ERROR;
            }
            return GOOD;
        }
    }

    return ERROR;
}

int16_t FnVCCB_GetFr2BandMinimalResource(
    callInfo_type *ptCi, measResultList2NR_type *pMeasResultList2NR, uint16_t fr2Band, bool &rIsUL, uint32_t &rResource)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMeasResultList2NR);

    if (fr2Band != FR2_39GHz_n260 && fr2Band != FR2_28GHz_n261)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid fr2Band(D'%u, H':%x) in %s!!!\n", fr2Band, fr2Band, __func__);
        return ERROR;
    }

    measResult2NR_type *pMeasResult2NR = FnVCCB_GetMeasResult2NRforNeighbor(ptCi, pMeasResultList2NR);
    if (pMeasResult2NR == nullptr)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetMeasResult2NRforNeighbor ERROR in %s!!\n", __func__);
        return ERROR;
    }

    uint32_t ssbFreq = pMeasResult2NR->ssbFrequency;
    uint16_t ulSelNbrIdx = MAX_NBR_PER_CELL, ulSelPci = 0;
    uint16_t dlSelNbrIdx = MAX_NBR_PER_CELL, dlSelPci = 0;
    uint32_t ulSelSsbFreq = 0, dlSelSsbFreq = 0;

    VccbCellInfo_type *pCell = FnVCCB_GetCellInfo(ptCi->servCellNum);
    VALID_E_POINT_CHECK_ERROR(pCell);

    nbrCellInfo_type(&rCellNbr)[MAX_NBR_PER_CELL] = pCell->Nbr;
    uint32_t dlMinimalResource = MAX_SCG_BAND_SEL_AVAIL_RESOURCE, ulMinimalResource = MAX_SCG_BAND_SEL_AVAIL_RESOURCE;

    uint16_t maxNbrIdx =
        static_cast<uint16_t>(UMIN((uint16_t)MAX_NBR_RELATION_TABLE_PER_CELL, (uint16_t)MAX_NBR_PER_CELL));
    measResultListNR_type &rMeasResultNeighCellListNR = pMeasResult2NR->measResultNeighCellListNR;
    uint16_t resultNbrMaxIdx = MIN(rMeasResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);
    for (uint16_t resultNbrIdx = 0; resultNbrIdx < resultNbrMaxIdx; resultNbrIdx++)
    {
        ulSelNbrIdx = MAX_NBR_PER_CELL, ulSelPci = 0, ulSelSsbFreq = 0;
        dlSelNbrIdx = MAX_NBR_PER_CELL, dlSelPci = 0, dlSelSsbFreq = 0;
        measResultNR_type &rMeasResultNR = rMeasResultNeighCellListNR.measResultNR[resultNbrIdx];

        if (!rMeasResultNR.physCellIdFlag) continue;

        for (uint16_t nbrIdx = 0; nbrIdx < maxNbrIdx; nbrIdx++)
        {
            uint16_t nbrFr2Band = 0;

            if (rCellNbr[nbrIdx].status != EQUIP) continue;

            sonNbrPrbRsc_type &sonNbr = pCell->cellRscInfo.nbrPrb[nbrIdx];
            if (sonNbr.usage != EQUIP) continue;
            if (sonNbr.isRsUpdate != ON) continue;

            nbrGnbCellInfo_type *pNbrGnbCell = NULL;
            if ((GOOD != getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &pNbrGnbCell)))
            {
                VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                    "ERROR, getNbrGnbCellByCellNbrIdx(cellNum:%u, nbrIdx:%u, pNbr(%p)) in %s!\n", ptCi->servCellNum,
                    nbrIdx, pNbrGnbCell, __func__);
                continue;
            }

            if (rMeasResultNR.physCellId != pNbrGnbCell->nrPci || ssbFreq != pNbrGnbCell->ssbArfcn)
            {
                continue;
            }
            nbrFr2Band = static_cast<uint16_t>(FnVCCB_GetScgBandSelFR2BandofNbrGnbCellInfo(ptCi, pNbrGnbCell));
            if (!nbrFr2Band)
            {
                VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                    "FnVCCB_GetScgBandSelFR2BandofNbrGnbCellInfo(cellNum:%u, nbrIdx:%u) in %s!\n", ptCi->servCellNum,
                    nbrIdx, __func__);
                continue;
            }

            // first matched item will be selected, if duplicated pcis are exist.
            if (nbrFr2Band == fr2Band)
            {
                if (!sonNbr.dlCCCV || !sonNbr.ulCCCV)
                {
                    VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                        "[SCG-BAND SELC]   Invalid dlCCCV(%u) or ulCCCV(%u) for nbrIdx(%u) in %s!\n", sonNbr.dlCCCV,
                        sonNbr.ulCCCV, nbrIdx, __func__);
                    continue;
                }

                // there is no ulTotalBandwidth, so extracts it from dlTotalBandwidth and normalizer
                double ulNormalizer = static_cast<double>(sonNbr.ulCCCV) / (sonNbr.ulCCCV + sonNbr.dlCCCV);
                uint32_t ulAvailResource =
                    static_cast<uint32_t>(sonNbr.dlTotalBandwidth * sonNbr.ulCapacityValue * ulNormalizer);

                if (ulAvailResource < ulMinimalResource)
                {
                    ulMinimalResource = ulAvailResource;
                    ulSelNbrIdx = nbrIdx;
                    ulSelPci = pNbrGnbCell->nrPci;
                    ulSelSsbFreq = pNbrGnbCell->ssbArfcn;
                }

                double dlNormalizer = static_cast<double>(sonNbr.dlCCCV) / (sonNbr.ulCCCV + sonNbr.dlCCCV);
                uint32_t dlAvailResource =
                    static_cast<uint32_t>(sonNbr.dlTotalBandwidth * sonNbr.dlCapacityValue * dlNormalizer);
                if (dlAvailResource < dlMinimalResource)
                {
                    dlMinimalResource = dlAvailResource;
                    dlSelNbrIdx = nbrIdx;
                    dlSelPci = pNbrGnbCell->nrPci;
                    dlSelSsbFreq = pNbrGnbCell->ssbArfcn;
                }

                break;
            }
        }
    }

    if (ulMinimalResource <= dlMinimalResource)
    {
        rIsUL = true;
        rResource = ulMinimalResource;
    }
    else
    {
        rIsUL = false;
        rResource = dlMinimalResource;
    }

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC]   Get n%u minimalResource\n", fr2Band);
    VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC]    ul:%u for (nbrIdx:%u,pci:%u,ssbFreq:%u)\n", ulMinimalResource,
        ulSelNbrIdx, ulSelPci, ulSelSsbFreq);
    VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC]    dl:%u for (nbrIdx:%u,pci:%u,ssbFreq:%u)\n", dlMinimalResource,
        dlSelNbrIdx, dlSelPci, dlSelSsbFreq);

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi, "[SCG-BAND SELC]    >>> n%u MR minimalResource(%u), isUL(%s)\n", fr2Band,
        rResource, rIsUL ? "true" : "false");

    return GOOD;
}

int16_t FnVCCB_GetFr2BandAvailableResource(callInfo_type *ptCi, measResultList2NR_type *pMeasResultList2NR,
    uint16_t fr2Band, availResourcePerMeasResultCellReport_type *pAvailRscTuple)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pMeasResultList2NR);
    VALID_E_POINT_CHECK_ERROR(pAvailRscTuple);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);
    VccbCellInfo_type *pCell = FnVCCB_GetCellInfo(ptCi->servCellNum);
    VALID_E_POINT_CHECK_ERROR(pCell);

    nbrCellInfo_type *pCellNbr = pCell->Nbr;

    if (fr2Band != FR2_39GHz_n260 && fr2Band != FR2_28GHz_n261)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Invalid fr2Band(D'%u, H':%x) in %s!!!\n", fr2Band, fr2Band, __func__);
        return ERROR;
    }

    measResult2NR_type *pMeasResult2NR = FnVCCB_GetMeasResult2NRforNeighbor(ptCi, pMeasResultList2NR);
    if (pMeasResult2NR == nullptr)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "FnVCCB_GetMeasResult2NRforNeighbor ERROR in %s!!\n", __func__);
        return ERROR;
    }

    VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
        "[SCG-BAND SELC]  Get n%u maximal available resource\n", fr2Band);

    uint32_t bestAvailableResource = 0;
    measResultListNR_type &rMeasResultNeighCellListNR = pMeasResult2NR->measResultNeighCellListNR;

    uint16_t resultNbrMaxIdx = MIN(rMeasResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);
    uint16_t maxNbrIdx =
                 static_cast<uint16_t>(UMIN((uint16_t)MAX_NBR_RELATION_TABLE_PER_CELL, (uint16_t)MAX_NBR_PER_CELL)),
             bestNbrIdx = static_cast<uint16_t>(MAX_NBR_PER_CELL);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    nrdcScgBandSelectionMgmt_type const &scgBandSelMgmt =
        THREAD_INFO->call[ptCi->myThreadId].nrdcScgBandSelMgmtPerCell[ptCi->servCellNum];

    for (uint16_t resultNbrIdx = 0; resultNbrIdx < resultNbrMaxIdx; resultNbrIdx++)
    {
        measResultNR_type &rMeasResultNR = rMeasResultNeighCellListNR.measResultNR[resultNbrIdx];

        availResourcePerMeasResultCellReport_type &availRsc = pAvailRscTuple[resultNbrIdx];
        availRsc.measResultCellReportIdx = resultNbrIdx;

        if (!rMeasResultNR.physCellIdFlag)
        {
            continue;
        }

        for (uint16_t nbrIdx = 0; nbrIdx < maxNbrIdx; nbrIdx++)
        {
            uint16_t nbrFr2Band = 0;

            if (pCellNbr[nbrIdx].status != EQUIP) continue;

            sonNbrPrbRsc_type &sonNbr = pCell->cellRscInfo.nbrPrb[nbrIdx];
            if (sonNbr.usage != EQUIP) continue;
            if (sonNbr.isRsUpdate != ON) continue;

            nbrGnbCellInfo_type *pNbrGnbCell = NULL;
            if ((GOOD != getNbrGnbCellByCellNbrIdx(ptCi->servCellNum, nbrIdx, &pNbrGnbCell)))
            {
                VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                    "ERROR, getNbrGnbCellByCellNbrIdx(cellNum:%u, nbrIdx:%u, pNbr(%p)) in %s!\n", ptCi->servCellNum,
                    nbrIdx, pNbrGnbCell, __func__);
                continue;
            }

            if (rMeasResultNR.physCellId != pNbrGnbCell->nrPci || pMeasResult2NR->ssbFrequency != pNbrGnbCell->ssbArfcn)
            {
                continue;
            }
            nbrFr2Band = static_cast<uint16_t>(FnVCCB_GetScgBandSelFR2BandofNbrGnbCellInfo(ptCi, pNbrGnbCell));
            if (!nbrFr2Band)
            {
                VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                    "FnVCCB_GetScgBandSelFR2BandofNbrGnbCellInfo(cellNum:%u, nbrIdx:%u) in %s!\n", ptCi->servCellNum,
                    nbrIdx, __func__);
                continue;
            }

            // first matched item will be selected, if duplicated pcis are exist.
            if (nbrFr2Band == fr2Band)
            {
                VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                    "[SCG-BAND SELC]   nbr[%u]:"
                    "availUe:%u,CCCV(%u/%u),CapaValue(%u/%u),dlTotBW:%u\n",
                    nbrIdx, sonNbr.numAvailUe, sonNbr.dlCCCV, sonNbr.ulCCCV, sonNbr.ulCapacityValue,
                    sonNbr.dlCapacityValue, sonNbr.dlTotalBandwidth);

                if (scgBandSelMgmt.oprMode == SCG_BAND_SEL_OPR_RrcUeBased)
                {
                    availRsc.availableResource = static_cast<uint32_t>(sonNbr.numAvailUe);
                }
                else
                {
                    if (!sonNbr.dlCCCV || !sonNbr.ulCCCV)
                    {
                        VCCB_PRINT_CALL_NRDC_BASIC(ptCi,
                            "[SCG-BAND SELC]    Invalid dlCCCV(%u) or ulCCCV(%u) for nbrIdx(%u) in %s!\n",
                            sonNbr.dlCCCV, sonNbr.ulCCCV, nbrIdx, __func__);
                        continue;
                    }

                    if (scgBandSelMgmt.oprMode == SCG_BAND_SEL_OPR_UlCapaBased)
                    {
                        // son can't support ulTotalBandwidth, so ulTotalBandwidth will be extracted by normalizer
                        availRsc.availableResource =
                            static_cast<uint32_t>(sonNbr.ulCapacityValue * sonNbr.dlTotalBandwidth *
                                                  static_cast<double>(sonNbr.ulCCCV) / (sonNbr.ulCCCV + sonNbr.dlCCCV));
                    }
                    else  // SCG_BAND_SEL_OPR_DlCapaBased
                    {
                        availRsc.availableResource =
                            static_cast<uint32_t>(sonNbr.dlCapacityValue * sonNbr.dlTotalBandwidth *
                                                  static_cast<double>(sonNbr.dlCCCV) / (sonNbr.ulCCCV + sonNbr.dlCCCV));
                    }
                }
                VCCB_PRINT_CALL_NRDC_BASIC(
                    ptCi, "[SCG-BAND SELC]    availableResource:%u\n", availRsc.availableResource);

                availRsc.nci = VLIB_GnbIdCellId2NrCellId(&pNbrGnbCell->globalGnbId.gnbId, pNbrGnbCell->cellId);
                availRsc.ssbArfcn = pNbrGnbCell->ssbArfcn;

                if (availRsc.availableResource > bestAvailableResource)
                {
                    bestAvailableResource = availRsc.availableResource;
                    bestNbrIdx = nbrIdx;
                }

                break;
            }
        }
    }

    qsort(pAvailRscTuple, resultNbrMaxIdx, sizeof(availResourcePerMeasResultCellReport_type),
        FnVCCB_QsortAvailableResourceDescendingOrder);

    measResultNR_type tmpMeasResultNR[MAX_NUM_CELL_REPORT];
    uint16_t cnt = 0;
    for (uint16_t resultNbrIdx = 0; resultNbrIdx < resultNbrMaxIdx; resultNbrIdx++)
    {
        uint16_t idx = pAvailRscTuple[resultNbrIdx].measResultCellReportIdx;

        if (idx >= MAX_NUM_CELL_REPORT) continue;

        tmpMeasResultNR[cnt++] = rMeasResultNeighCellListNR.measResultNR[idx];
    }

    uint16_t loop = 0, maxLoop = static_cast<uint16_t>(UMIN(cnt, (uint16_t)MAX_NUM_CELL_REPORT));
    for (loop = 0; loop < maxLoop; loop++)
    {
        rMeasResultNeighCellListNR.measResultNR[loop] = tmpMeasResultNR[loop];
    }

    if (cnt != rMeasResultNeighCellListNR.nrofCellReport)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Warning, nrofCellReport is changed(%u=>%u) after sorting in %s\n",
            rMeasResultNeighCellListNR.nrofCellReport, cnt, __func__);

        rMeasResultNeighCellListNR.nrofCellReport = static_cast<uint8_t>(cnt);
    }

    if (pAvailRscTuple[0].availableResource != bestAvailableResource)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "Warning, sorted best available resource(%u) is not matched with availableResource(%u)) in %s\n",
            pAvailRscTuple[0].availableResource, bestAvailableResource, __func__);
    }

    VCCB_PRINT_CALL_NRDC_BASIC(
        ptCi, "[SCG-BAND SELC]   >>> BestNbrIdx:%u availableResource:%u\n", bestNbrIdx, bestAvailableResource);

    return GOOD;
}

int16_t FnVCCB_GetScgBandSelFR2BandofNbrGnbCellInfo(callInfo_type *ptCi, nbrGnbCellInfo_type *pNbrGnbCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);
    VALID_E_POINT_CHECK_ZERO(pNbrGnbCell);

    uint8_t freqBandIdx = 0;

    for (freqBandIdx = 0; freqBandIdx < MAX_FREQBAND_PER_CELL; freqBandIdx++)
    {
        if (pNbrGnbCell->freqBandInfoList[freqBandIdx].status != EQUIP) continue;

        // The first matched band will be used.
        if (pNbrGnbCell->freqBandInfoList[freqBandIdx].nRFrequencyBand == FR2_39GHz_n260 ||
            pNbrGnbCell->freqBandInfoList[freqBandIdx].nRFrequencyBand == FR2_28GHz_n261)
        {
            return pNbrGnbCell->freqBandInfoList[freqBandIdx].nRFrequencyBand;
        }
    }

    return 0;
}

void FnVCCB_ClearScgBandSelectionInfo(callInfo_type *ptCi)
{
    if (IS_SUPPORTABLE_ScgBandSelectionForNrdc_Foo())
    {
        VCCB_CLEAR_TIMER(&ptCi->loadBasedNrdcScgBandSelectInfo.newBandMrWaitTimer, CANCEL_TIMER);
        FnVCCB_Mrdc_Init_octetString(ptCi, &ptCi->loadBasedNrdcScgBandSelectInfo.measResultList2NR);
        memset(&ptCi->loadBasedNrdcScgBandSelectInfo, 0, sizeof(ptCi->loadBasedNrdcScgBandSelectInfo));
    }
}

uint16_t FnVCCB_GetFR2BandofColocCell(callInfo_type *ptCi, colocCellEntries_type *pColocCell, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);
    VALID_E_POINT_CHECK_ZERO(pColocCell);
    VCCB_CHECK_VALID_CELLNUM_ZERO(cellNum);
    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    uint16_t fr2BandIndi = 0;
    uint16_t nbrIdx = 0;
    nbrGnbCellInfo_type *pNbrGnbCell = NULL;

    if (pColocCell->usage == CI_no_use)
    {
        return 0;
    }

    for (nbrIdx = 0; nbrIdx < MAX_NBR_PER_CELL; nbrIdx++)
    {
        nbrCellInfo_type *pNbr = &pCell->Nbr[nbrIdx];
        sonNbrPrbRsc_type *pRsc = &pCell->cellRscInfo.nbrPrb[nbrIdx];

        if (pNbr->status != EQUIP) continue;
        if (pRsc->usage != EQUIP) continue;

        if ((GOOD != getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbrGnbCell)) || !pNbrGnbCell)
        {
            continue;
        }

        if (!(pColocCell->globalGnbId.plmn.longId == pNbrGnbCell->globalGnbId.plmn.longId &&
                pColocCell->globalGnbId.gnbId.id == pNbrGnbCell->globalGnbId.gnbId.id &&
                pColocCell->cellId == pNbrGnbCell->cellId))
        {
            continue;
        }

        fr2BandIndi = static_cast<uint16_t>(FnVCCB_GetScgBandSelFR2BandofNbrGnbCellInfo(ptCi, pNbrGnbCell));
        if (!fr2BandIndi)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi, "colocCell(%u) doesn't have FR2 Band in %s!\n", pColocCell->cellId, __func__);
        }
        break;
    }

    if (nbrIdx >= MAX_NBR_PER_CELL)
    {
        VCCB_PRINT_CALL_COMMENT(
            ptCi, "colocCell(:%u) was not registered to NBR in %s!\n", pColocCell->cellId, __func__);
    }

    return fr2BandIndi;
}

int16_t FnVCCB_NextStep_NRDC_RRE_Ready_RRE_E1ModTxStop(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);

    int16_t status = GOOD;

    status = VCCM_RRE_CommonProcessToSendReestablishment(ptCi);
    VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_RRE_CommonProcessToSendReestablishment ERROR !!\n");

    if (IS_NRDC(ptCi) ||                                                     // NRDC
        ((IsSupport_NEDC_Foo()) && (IS_ON_MRDC_RSC_SETUP_FLAG(xn_snConn))))  // NEDC
    {
        ptCi->mrdcInfo.sNodeRelCause = MrdcRelCause_Reestablishment;
        status = VCCM_TriggerMgNBInitSNReleaseProcedure(ptCi);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "VCCM_TriggerMgNBInitSNReleaseProcedure Error!\n");

        FnVCCB_UpdateBearerTypeForHandover_SnRelease(ptCi);
        ptCi->mrdcInfo.mobilityCfg.ueState = ci_scg_released_ue;

        FnVCCB_set_MrdcSnRelMnEvent(ptCi, StatMrdcSnRelMn_MnInit_IntraMnMobility);

        uint8_t targetXN = 0;
        status = FnVCCB_SendXNMessage(XN_SNodeReleaseRequest_id, ptCi, &targetXN, nullptr);
        VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage (XN_SNodeReleaseRequest_id) ERROR!\n");

        ON_SN_NODE_REL_ACK_RCV_FLAG(ptCi->flag.respFlag);

        VLIB_AttachTimer(&ptCi->timer, ptCi, timXN_SNodeRelease_id);
    }

    return GOOD;
}

uint16_t FnVCCB_FindEutraNbrIdxByCgi(uint16_t cellNum, const cgi_type eutraCgi)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL);

    uint16_t nbrIdx = MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL;
    nbrEutraCellInfo_type *pNbr = NULL;
    cgi_type cgi;

    for(nbrIdx = 0; nbrIdx < MAX_EUTRA_NBR_RELATION_TABLE_PER_CELL; nbrIdx++)
    {

        pNbr = &CELLINFO[cellNum].eutraNbr[nbrIdx];

        if(EQUIP != pNbr->status)
        {
            continue;
        }

        cgi.ci = 0;
        cgi.ci = (static_cast<uint64_t>(pNbr->targetEnbId) << 8) + pNbr->cellId;
        cgi.plmn = pNbr->plmn;

        /* Check ECGI */
        if(eutraCgi.plmn.longId != cgi.plmn.longId)
        {
            continue;
        }

        if(eutraCgi.ci != cgi.ci)
        {
            continue;
        }

        break;
    }

    return nbrIdx;
}

int16_t FnVCCB_NextStep_RRE_RreCmpl_SNRel_E1SetupMod(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ZERO(ptCi);

    int16_t status = GOOD;

    if (ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTRA_DU)
    {
        VLIB_ConfigSecondaryCellList(ptCi);
        status = VCCB_PrepareNewMeasConfigWithTaintedInstalledItems(ptCi);
        if (ERROR == status)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VCCB_PrepareNewMeasConfigWithTaintedInstalledItems ERROR!\n");
            return ERROR;
        }

        status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_UeContextModificationRequest ERROR!!\n");
            return ERROR;
        }
        VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextModification_id);

        if (IS_NRDC_MN(ptCi) &&
                (FnVCCB_IsAnySpecificBearerAndReqBearer(ptCi, SN_Term_SPLIT_Bearer, MN_Term_MCG_Bearer) ||
                 FnVCCB_IsAnySpecificBearerAndReqBearer(ptCi, SN_Term_SCG_Bearer, MN_Term_MCG_Bearer)))  // is SN TERM Exist?
        {
            uint8_t targetXN = e_Snode_MnToSrcSn;
            status = FnVCCB_SendXNMessage(XN_XnUAddressIndication_id, ptCi, &targetXN, nullptr);
            VCCB_RETURN_ON_CALL_ERROR(ptCi, status, "FnVCCB_SendXNMessage(XN_XnUAddressIndication) ERROR !!\n");
        }

        VLIB_SetCurStateAll(ptCi, STATE_RRE_F1SetupMod);
    }
    else if (ptCi->ueInfo.reestablishInfo.reestablishType == RRE_TYPE_INTER_DU)
    {
        ptCi->ueInfo.duConfQuery = VCCB_FLAG_ON;

        status = VFIL_sendF1_UeContextModificationRequest(ptCi, NULL);
        if (status == ERROR)
        {
            VCCB_PRINT_CALL_ERROR(ptCi, "VFIL_sendF1_UeContextModificationRequest ERROR!!\n");
            return ERROR;
        }

        ptCi->ueInfo.duConfQuery = VCCB_FLAG_OFF;

        VLIB_AttachTimer(&ptCi->timer, ptCi, timF1_UeContextModification_id);
        VLIB_SetCurStateAll(ptCi, STATE_RRE_F1ModQuery);
    }

    return GOOD;
}

/****************************************************************************
 * @brief           Set SpCell servingCellIndex
 *
 * @param[in,out]   ptCi :   call information
 * @return          status : N/A
 ****************************************************************************/
void VCCM_SetSpCellIndex(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if(VCCB_FLAG_ON == DBG->flag.forcedSpCellIndexation)
    {
        if (ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG_Flag == VCCB_FLAG_ON)
        {
            if ( ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG.lowBound < SPCELL_DEFAULT_INDEX &&
                 ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG.upBound >= SCELLS_DEFAULT_MIN_INDEX_END)
            {
                ptCi->servCellIndex = SPCELL_DEFAULT_INDEX;
            }
            else
            {
                ptCi->servCellIndex = ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG.lowBound;
            }
        }
        else
            ptCi->servCellIndex = SPCELL_DEFAULT_INDEX;
    }
    else
    {
        if (ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG_Flag == VCCB_FLAG_ON)
        {
            ptCi->servCellIndex = ptCi->cgConfigInfo.configRestrictInfo.servCellIndexRangeSCG.lowBound;
        }
        else
        {
            ptCi->servCellIndex = SPCELL_DEFAULT_INDEX;
        }
    }
    return;
}
/**
 * @brief   FGR-CC3502 VIP UE indication
 * @details Sends Dal/Ves notification about VIP UE occurrence
 * @param   [in] ptCi    : pointer to Call Context
 * @param   [in] cellNum : serving cellNum or hoInfo.targetCellNum
 * @return  void
 */
void VLIB_SendVipUeNotification(callInfo_type *ptCi, uint16_t cellNum)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);
    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];
    plmnId_type plmnId;
    plmnId.longId = pCell->cellPlmn.servedPlmn[0];

    // Build PLMN string
    char mcc[4] = {static_cast<char>(static_cast<char>(static_cast<char>(plmnId.s2.mcc & 0xF00) >> 8) + '0'),
        static_cast<char>(static_cast<char>(static_cast<char>(plmnId.s2.mcc & 0x0F0) >> 4) + '0'),
        static_cast<char>(static_cast<char>(plmnId.s2.mcc & 0x00F) + '0'), 0};
    char mnc[4] = {static_cast<char>(static_cast<char>(static_cast<char>(plmnId.s2.mnc & 0xF00) >> 8) + '0'),
        static_cast<char>(static_cast<char>(static_cast<char>(plmnId.s2.mnc & 0x0F0) >> 4) + '0'),
        static_cast<char>(static_cast<char>(plmnId.s2.mnc & 0x00F) + '0'), 0};

    if (0x00F == (plmnId.s2.mnc & 0x00F)) // When mnc has only 2 digits
    {
        mnc[2] = 0;
    }

    struct timespec tmpTimeSpec;
    long epochMicroSec;
    int index = 0;

#define MAX_INFO_STR_LEN_FOR_NOTI (100)
    char strSourceName[MAX_INFO_STR_LEN_FOR_NOTI] = { 0, };
    char strNfcNamingCode[MAX_INFO_STR_LEN_FOR_NOTI] = { 0, };

    int32_t status = VLIB_getSourceNameForNotification(strSourceName, MAX_INFO_STR_LEN_FOR_NOTI);
    VCCB_RETURN_ON_CALL_VOID(ptCi, status, "VLIB_sendVipUeNotification >> get SourceName failed\n");

    status = VLIB_getNfcNamingCode(strNfcNamingCode, MAX_INFO_STR_LEN_FOR_NOTI);
    VCCB_RETURN_ON_CALL_VOID(ptCi, status, "VLIB_sendVipUeNotification >> get NfcNamingCode failed\n");

    dal_tag_value_t tags[100];
    memset(tags, 0, sizeof(tags));

    epochMicroSec = clock_gettime(CLOCK_REALTIME, &tmpTimeSpec) == 0
                        ? (tmpTimeSpec.tv_nsec / 1000 + tmpTimeSpec.tv_sec * 1000000)
                        : 0;

#if defined(__NVGNB__)
    const int notificationTag = YANG_NS_PREFIX(Notification_Nvgnb_Samsung_VipUEindication);
    const char* eventName = "Notification_Nvgnb-Samsung_VipUEindication";
#else
    const int notificationTag = YANG_NS_PREFIX(Notification_Acpf_Samsung_VipUEindication);
    const char* eventName = "Notification_Acpf-Samsung_VipUEindication";
#endif

    DAL_SET_TAG_XMLBEGIN(&tags[index++], notificationTag, VCCB_YANG_NS);
    DAL_SET_TAG_ENUM_VALUE(&tags[index++], YANG_NS_PREFIX(domain), common_notification);

    if (TRUE == VCOM_IsHostSim())
    {
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(eventId), "0");
    }

    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(eventName), eventName);
    DAL_SET_TAG_INT64(&tags[index++], YANG_NS_PREFIX(lastEpochMicrosec), epochMicroSec);
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(nfcNamingCode), strNfcNamingCode);

    if (TRUE == VCOM_IsHostSim())
    {
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(nfNamingCode), "acpf-hostsim");
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(nfVendorName), "SAMSUNG");
    }

    DAL_SET_TAG_ENUM_VALUE(&tags[index++], YANG_NS_PREFIX(priority), common_Normal);

    if (TRUE == VCOM_IsHostSim())
    {
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(reportingEntityId), "123");
        DAL_SET_TAG_INT32(&tags[index++], YANG_NS_PREFIX(sequence), 0);
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(sourceId), "hostsim-vccb-id");
    }

    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(sourceName), strSourceName);
    DAL_SET_TAG_INT64(&tags[index++], YANG_NS_PREFIX(startEpochMicrosec), epochMicroSec);

    if (TRUE == VCOM_IsHostSim())
    {
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(stndDefinedNamespace), "TODO");
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(timeZoneOffset), "UTC+00:00");
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(version), "4.1");
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(vesEventListenerVersion), "7.2");
    }

    DAL_SET_TAG_INT32(&tags[index++], YANG_NS_PREFIX(statusCode), 1);

    if (TRUE == FOO.VF_RestfulEventDelivery_OnapMandatoryFields)
    {
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(changeIdentifier), "VipUEIndication");
        DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(changeType), "VipUEIndicationEvent");
    }

    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(mcc), mcc);
    DAL_SET_TAG_STR(&tags[index++], YANG_NS_PREFIX(mnc), mnc);

#if defined(__NVGNB__)
    DAL_SET_TAG_UINT8(&tags[index++], YANG_NS_PREFIX(gnodebNum), (uint8_t)ptCi->gnbNum);
#else
    DAL_SET_TAG_UINT32(&tags[index++], YANG_NS_PREFIX(gnbId), GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id);
#endif

    DAL_SET_TAG_UINT32(&tags[index++], YANG_NS_PREFIX(cellIdentity), CELLINFO[cellNum].cellIdentity);
    DAL_SET_TAG_XMLEND(&tags[index++], notificationTag, VCCB_YANG_NS);

    status = VccbNotiHandler_sendNotification(tags, index);
    VCCB_PRINT_WITHOUT_RETURN_ON_CALL_ERROR(ptCi, status, "VccbNotiHandler_sendNotification VipUeNotification ERROR!\n");

#undef MAX_INFO_STR_LEN_FOR_NOTI
}

/**
 * @brief   FGR-CC3502 VIP UE indication
 * @details Check if ENDC call is VIP UE (contain bearer with ARP2) and send notification to VNMB and confd
 *          FR 10: During initial connection or hand-in scenarios
 * @param   [in] ptCi : pointer to Call Context
 * @return  void
 */
void VLIB_CheckEndcVipUe(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->gnbNum, MAX_GNB_PER_SYS);

    uint16_t cellNum = ptCi->servCellNum;

    // During ENDC Intra-gNB HO after NR RRCRconfigComplete take targetCellNum
    if (  // NSA states
        (STATE_DCIntraDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCIntraDuHo_X2RecCmpl == ptCi->state) ||
        (STATE_DCIntraDuHo_X2SnStatus == ptCi->state) || (STATE_DCIntraDuHo_X2ModCnf == ptCi->state) ||
        (STATE_DCInterDuHo_RRCRecCmpl == ptCi->state) || (STATE_DCInterDuHo_X2RecCmpl == ptCi->state) ||
        (STATE_DCInterDuHo_X2SnStatus == ptCi->state) || (STATE_DCInterDuHo_X2ModCnf == ptCi->state) ||
        (STATE_DCNonDuHo_X2SnStatus == ptCi->state) || (STATE_DCNonDuHo_X2RecCmpl == ptCi->state))
    {
        cellNum = ptCi->hoInfo.targetCellNum;
    }

    VCCB_CHECK_E_RANGE_AND_VOID(cellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[cellNum];

    // Check feature activation by timer value
    if (0 == GNBINFO[ptCi->gnbNum].cfg.arpBasedUlPathSwitchTimerValue)
    {
        return;
    }

    // Check VIP UE by ARP2 existence
    uint8_t drbIdx = 0;
    for (drbIdx = 0; drbIdx < MAX_ERAB_PER_CALL; ++drbIdx)
    {
        if (CI_use != ptCi->erabInfo[drbIdx].usage)
        {
            continue;
        }

        if (ARP2_VIP_UE == ptCi->erabInfo[drbIdx].erabQos.aRP.priority)
        {
            ptCi->isEndcVipUe = TRUE;
            break;
        }
    }

    if (FALSE == ptCi->isEndcVipUe)
    {
        return;
    }

    VCCB_PRINT_CALL_INFORMATIVE(ptCi, "[VIP UE] ENDC VIP on cellNum(%u), Pci(%u), CellId(%u), gNBId(%u)!\n",
            cellNum, pCell->phyCellId, pCell->cellIdentity, GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id);

    FnVCCB_StartUlPathVipUeTimer(ptCi->gnbNum, cellNum);

    // Send VIP UE noti to vnmb. VNMB will propagate it to all VCCBs.
    if (ERROR == VIIL_sendVipUeInd(ptCi, cellNum))
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "VIIL_sendVipUeInd cellNum(%u) ERROR\n", cellNum);
    }

    // Send VIP UE noti to confd/EMS. EMS will propagate it to Inter-gNB cells (via confd).
    VLIB_SendVipUeNotification(ptCi, cellNum);
}

/**
 * @brief Update SA Call  DB previous DB
 * @details This function is used to store the previous state in the SA Call DB.
 * @param [in] ptCi : pointer to Call Context
 * @param [in] filter : This value determines which db to update.
 * @return void
 */
void VCCM_SetPrevSaCallDb(callInfo_type *ptCi, uint32_t filter)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (filter & SA_PREV_CALL_DB_TYPE_saMeas)
    {
        ptCi->saPrevInfo.saMeas = FnVCCB_GetSaMeas(*ptCi);
    }
    if (filter & SA_PREV_CALL_DB_TYPE_reportCgi)
    {
        ptCi->saPrevInfo.reportCgi = ptCi->anrInfo.reportCgi;
    }
    if (filter & SA_PREV_CALL_DB_TYPE_DrxConfig)
    {
        ptCi->drxCuInfo.backupDrxConfigInfo = ptCi->drxCuInfo.drxConfigInfo;
        ptCi->saPrevInfo.srsConfigTriggeredType = ptCi->drxCuInfo.srsConfigTriggeredType;
    }
    if (filter & SA_PREV_CALL_DB_TYPE_OnDemandHoMeas)
    {
        ptCi->onDemandInfo.prevTargetUe = ptCi->onDemandInfo.targetUe;
    }
}

/**
 * @brief Replace the SA Call DB with the previous information.
 * @details This function rolls back the SA Call DB to the previous state.
 * @param [in] ptCi : pointer to Call Context
 * @param [in] filter : This value determines which db to update.
 * @return void
 */
void VCCM_SetCurrentSaCallDbFromPrevInfoDb(callInfo_type *ptCi, uint32_t filter)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (filter & SA_PREV_CALL_DB_TYPE_saMeas)
    {
        FnVCCB_GetSaMeas(*ptCi) = ptCi->saPrevInfo.saMeas;
    }
    if (filter & SA_PREV_CALL_DB_TYPE_reportCgi)
    {
        ptCi->anrInfo.reportCgi = ptCi->saPrevInfo.reportCgi;
    }
    if (filter & SA_PREV_CALL_DB_TYPE_DrxConfig)
    {
        if (DBG->flag.drxConfig == VCCB_FLAG_ON)
        {
            if (memcmp(&ptCi->drxCuInfo.drxConfigInfo, &ptCi->drxCuInfo.backupDrxConfigInfo,
                    sizeof(VccbDrxConfigInfo_type)) != 0)
            {
                VCCB_PrintDrxConfigInfo(ptCi->drxCuInfo.backupDrxConfigInfo, __func__);
            }
        }
        ptCi->drxCuInfo.drxConfigInfo = ptCi->drxCuInfo.backupDrxConfigInfo;
        ptCi->drxCuInfo.srsConfigTriggeredType = ptCi->saPrevInfo.srsConfigTriggeredType;
    }
    if (filter & SA_PREV_CALL_DB_TYPE_OnDemandHoMeas)
    {
        ptCi->onDemandInfo.targetUe = ptCi->onDemandInfo.prevTargetUe;
        ptCi->onDemandInfo.hoTriggered = FALSE;
    }
    if (filter & SA_PREV_CALL_DB_TYPE_UstmForcedMobility)
    {
        ptCi->ustmInfo.intraNrHandoverTriggered = FALSE;
    }
}

/**
 * @brief Update NSA call DB previous DB
 * @details This function is used to store the previous state in the NSA Call DB.
 * @param [in] ptCi : pointer to Call Context
 * @param [in] filter : This value determines which db to update.
 * @return void
 */
void VCCM_SetPrevNsaCallDb(callInfo_type *ptCi, uint32_t filter)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (filter & NSA_PREV_CALL_DB_TYPE_ifMeasState)
    {
        ptCi->nsaPrevInfo.ifMeasState = ptCi->nsaMeas.ifMeasState;
    }
    if (filter & NSA_PREV_CALL_DB_TYPE_reportCgi)
    {
        ptCi->nsaPrevInfo.reportCgi = ptCi->anrInfo.reportCgi;
    }
    if (filter & NSA_PREV_CALL_DB_TYPE_DrxConfig)
    {
        ptCi->drxCuInfo.backupDrxConfigInfo = ptCi->drxCuInfo.drxConfigInfo;
    }
}

/**
 * @brief Replace the NSA call DB with the previous information.
 * @details This function rolls back the NSA Call DB to the previous state.
 * @param [in] ptCi : pointer to Call Context
 * @param [in] filter : This value determines which db to update.
 * @return void
 */
void VCCM_SetCurrentNsaCallDbFromPrevInfoDb(callInfo_type *ptCi, uint32_t filter)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);

    if (filter & NSA_PREV_CALL_DB_TYPE_ifMeasState)
    {
        ptCi->nsaMeas.ifMeasState = ptCi->nsaPrevInfo.ifMeasState;
    }
    if (filter & NSA_PREV_CALL_DB_TYPE_reportCgi)
    {
        ptCi->anrInfo.reportCgi = ptCi->nsaPrevInfo.reportCgi;
    }
    if (filter & NSA_PREV_CALL_DB_TYPE_DrxConfig)
    {
        if (DBG->flag.drxConfig == VCCB_FLAG_ON)
        {
            if (memcmp(&ptCi->drxCuInfo.drxConfigInfo, &ptCi->drxCuInfo.backupDrxConfigInfo,
                    sizeof(VccbDrxConfigInfo_type)) != 0)
            {
                VCCB_PrintDrxConfigInfo(ptCi->drxCuInfo.backupDrxConfigInfo, __func__);
            }
        }
        ptCi->drxCuInfo.drxConfigInfo = ptCi->drxCuInfo.backupDrxConfigInfo;
    }
}
/**
 *  @brief This function releases reportCgi Measment config when the t321 timer expires.
 *  @param callInfo_type* ptCi
 *  @return int16_t GOOD/BREAK/ERROR (1/0/-1)
 */
int16_t VCCB_AnrSgNBModificationRefuseTimerAction(callInfo_type *ptCi, message_type *ptAll, msgUnpack_type *ptUnpack)
{  // {{{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptAll);
    VALID_E_POINT_CHECK_ERROR(ptUnpack);

    VCCB_CLEAR_TIMER(&ptCi->timer, INIT_TIMER);

    logShmIntMsg(ptCi, RX_MSG, BLK_TIME, ptUnpack->msgId, sizeof(messageHdr_type), reinterpret_cast<uint8_t *>(ptAll));

    // don't release call because of report CGI,
    // send ncgiFailure
    if (E_CALLTYPE_NSA == ptCi->callType || IS_NRDC_SN(ptCi))
    {
        if (!VCCM_IsUeIdleState(ptCi->callType, ptCi->state))
        {
            if (ERROR == VCCM_enqueueAction(ptCi, ENQUEUE_ACTION_ANR_SGNB_MODIFICATION_REFUSE))
            {
                VCCB_PRINT_CALL_INFORMATIVE(ptCi, "VCCM_enqueueAction(ENQUEUE_ACTION_ANR_SGNB_MODIFICATION_REFUSE) fail\n");
            }
            return BREAK;
        }
    }

    return GOOD;
}  // }}}


bool FnVCCB_IsReportCGIConfigured(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_RET_VAL(ptCi, false);

    measurementsConfiguration_type *pUeConf = &(ptCi->measurementsConfiguration);
    for (uint16_t loop = 0; loop < MAX_NR_OF_MEAS_ID; loop++)
    {
        if (CI_use == pUeConf->measurementIdentities.installedItems[loop].usage)
        {
            // if reportCGI event(blind-inter-rat-redirection-purpose) is found, then return true
            if (pUeConf->measurementIdentities.installedItems[loop].callbackFuncId ==
                FUN_2_MEASREPORTCALLBACKID(VCCM_ProcMrReportCgi))
            {
                VCCB_PRINT_CALL_ERROR(ptCi,
                    "%s:ReportCgi meas config is installed "
                    "so trigger restore\n",
                    __func__);
                return true;
            }
        }
    }
    return false;
}

mpsCallInfo_type *FnVCCB_FindMpsCallInfoByPlmnIdx(const char *pFunc, callInfo_type *ptCi, uint8_t plmnIndex, bool isPrint)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_NULL(pFunc);
    VALID_E_POINT_CHECK_NULL(ptCi);
    VCCB_CHECK_VALID_GNBNUM_NULL(ptCi->gnbNum);
    VCCB_CHECK_E_RANGE_AND_NULL(plmnIndex, MAX_PLMN_INDEX);

    mpsCallInfo_type *pMpsCall = &GNBINFO[ptCi->gnbNum].mpsCallInfo[plmnIndex];
    if (pMpsCall->shmStatus == N_EQUIP)
    {
        if (isPrint) VCCB_PRINT_CALL_COMMENT(ptCi, "%s pMpsCall->shmStatus is NOT EQUIPPED\n", pFunc);
        return NULL;
    }

    return pMpsCall;
}

mpsCallInfo_type *FnVCCB_FindMpsCallInfo(const char *pFunc, callInfo_type *ptCi, plmnId_type *ptTargetPlmn, bool isPrint)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_NULL(pFunc);
    VALID_E_POINT_CHECK_NULL(ptCi);
    VALID_E_POINT_CHECK_NULL(ptTargetPlmn);

    int16_t status = GOOD;
    uint8_t plmnIndex = MAX_PLMN_INDEX;

    status = VLIB_getMultipleGnbPlmnIndexInfo(ptCi, &plmnIndex, ptTargetPlmn->longId);
    if (status != GOOD)
    {
        if (isPrint) VCCB_PRINT_CALL_ERROR(ptCi, "%s VLIB_getMultipleGnbPlmnIndexInfo is Failed\n", pFunc);
        return NULL;
    }
    if (plmnIndex >= MAX_PLMN_INDEX)
    {
        if (isPrint) VCCB_PRINT_CALL_ERROR(ptCi, "%s plmnIndex is not valid\n", pFunc);
        return NULL;
    }
    return FnVCCB_FindMpsCallInfoByPlmnIdx(pFunc, ptCi, plmnIndex, isPrint);
}

/****************************************************************************
 * @brief           Check the MPS condition for the bearer.
 *                  For common code (BASIC, HO, ...), detailed algorithms were separated to the outside.
 *
 * @param[in]       pFunc              : parent function name  / const char*
 * @param[in]       ptCi               : call information     / callInfo_type
 * @param[in]       pMpsCall           : MPS information / mpsCallInfo_type *
 * @param[in]       priorityLevel      : arp info in qos       / uint8_t
 * @param[in]       fiveQi             : 5qi in qosflow        / uint8_t
 *
 * @param[out]      true/false         : if valid, {validation address}, else {null} mpsCallInfo_type
 ****************************************************************************/
int16_t FnVCCB_CheckMpsBearerItem(const char *pFunc, callInfo_type *ptCi, mpsCallInfo_type *pMpsCall,
    uint8_t priorityLevel, uint8_t fiveQi, bool isPrint)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(pFunc);
    VALID_E_POINT_CHECK_FALSE(ptCi);
    VALID_E_POINT_CHECK_FALSE(pMpsCall);

    int combIndex = 0;

    if (pMpsCall->mpsArpOption == ARP_ONLY_MODE)
    {
        // Check ARP Value
        if (priorityLevel <= pMpsCall->mpsArpValue)
        {
            if (isPrint)
            {
                VCCB_PRINT_CALL_DATA(ptCi, "%s The call is confirmed as an mps call.\n", pFunc);
                VCCB_PRINT_CALL_DATA(
                    ptCi, "%s priorityLevel(%d) <= mpsArpValue(%d)\n", pFunc, priorityLevel, pMpsCall->mpsArpValue);
            }
            return TRUE;
        }
        return FALSE;
    }
    else
    {
        // FIVEQI_ARP_MODE
        // Check 5QI and ARP value and satisfy condition return true
        for( combIndex = 0 ; combIndex < MAX_5QI_ARP ; combIndex++ ){
            if( pMpsCall->fiveqiArp[combIndex].shmStatus == N_EQUIP ) continue;
            if (fiveQi == pMpsCall->fiveqiArp[combIndex].fiveqiValue &&
                priorityLevel == pMpsCall->fiveqiArp[combIndex].fiveqiArpValue)
            {
                if (isPrint)
                {
                    VCCB_PRINT_CALL_DATA(ptCi, "%s The call is confirmed as an mps call.\n", pFunc);
                    VCCB_PRINT_CALL_DATA(ptCi,
                        "%s fiveqi(%d) == fiveqiValue(%d), priorityLevel(%d) == fiveqiArpValue(%d)\n", pFunc, fiveQi,
                        pMpsCall->fiveqiArp[combIndex].fiveqiValue, priorityLevel, pMpsCall->fiveqiArp[combIndex].fiveqiArpValue);
                }
                return TRUE;
            }
        }
        return FALSE;
    }
}

int16_t VCCM_CheckMpsBearer(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    mpsCallInfo_type *pMpsCall = FnVCCB_FindMpsCallInfo(__func__, ptCi, &ptCi->ueInfo.servedPlmn, true);
    if (pMpsCall == NULL)
    {
        // LOG is output from FnVCCB_FindMpsCallInfo.
        VCCB_PRINT_CALL_ERROR(ptCi, "%s pMpsCall is NULL\n", __func__);
        return FALSE;
    }

    for (uint16_t pduIdx = 0; pduIdx < MAX_PDU_SESS_PER_CALL; pduIdx++)
    {
        if (!IS_VALID_NODE(PDU_NODE, ptCi, &(ptCi->pduSess[pduIdx]))) continue;
        for (uint16_t pduQosIdx = 0; pduQosIdx < MAX_QOS_FLOW_PER_PDU_SESS; pduQosIdx++)
        {
            uint16_t qosIdx = ptCi->pduSess[pduIdx].qosFlowIndex[pduQosIdx];
            if (qosIdx >= MAX_QOS_FLOW_PER_CALL) continue;
            qosFlowInfo_type *ptQi = &ptCi->qosFlow[qosIdx];
            if (ptQi->usage != CI_use) continue;
            if ((ptQi->qosFlowStatus != S_Setup) && (ptQi->qosFlowStatus != S_Modify) &&
                (ptQi->qosFlowStatus != S_Idle))
                continue;

            VCCB_PRINT_CALL_COMMENT(
                ptCi, "%s qosIdx(%d) ptQi->qosFlowStatus(%d)\n", __func__, qosIdx, ptQi->qosFlowStatus);

            uint8_t fiveqi = 0;
            if (pMpsCall->mpsArpOption == FIVEQI_ARP_MODE)
            {
                // Need Only 'FIVEQI_ARP_MODE'
                VLIB_getFiveQi(ptQi, &fiveqi);
            }
            if (FnVCCB_CheckMpsBearerItem(
                    __func__, ptCi, pMpsCall, ptQi->qosParam.allocAndRetent.priorityLevel, fiveqi, true) == TRUE)
            {
                // Found MpsBearer
                return TRUE;
            }
        }
    }

    return FALSE;
}

int16_t FnVCCB_CheckMpsBearerForAllPlmn(callInfo_type &rCall, const uint8_t priorityLevel, const uint8_t fiveQi)
{
    AUTO_TRACE_FUNC;

    uint8_t plmnIndex;
    for (plmnIndex = 0; plmnIndex < MAX_PLMN_INDEX; plmnIndex++)
    {
        mpsCallInfo_type *pMpsCall = FnVCCB_FindMpsCallInfoByPlmnIdx(__func__, &rCall, plmnIndex, true);

        if (NULL == pMpsCall) continue;

        if (TRUE == FnVCCB_CheckMpsBearerItem(__func__, &rCall, pMpsCall, priorityLevel, fiveQi, true))
        {
            return TRUE;
        }
    }

    return FALSE;
}

int16_t VCCM_CheckMpsCall(callInfo_type *ptCi)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_FALSE(ptCi);

    if (TRUE == VCCM_CheckMpsBearer(ptCi))
    {
        VCCB_PRINT_CALL_DATA(ptCi, "This call is confirmed as an MPS call (MPS bearer).\n");
        return TRUE;
    }

    return FALSE;
}

 /**
 * @brief Check if A2 measurement with en-dc-bearer-change-to-mcg-purpose needs to be installed/uninstalled
 * @param [in]  rCi   : callInfo_type &
 * @return      BREAK : nothing to do
 * @return      GOOD  : new meas config prepared
 * @return      ERROR : error during new meas config preparation
 */
int16_t FnVCCB_CheckIfBearerChangeToMcgMeasUpdateNeeded(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    int16_t status = BREAK;

    if (FOO.VF_EnDcBearerTypeChange_SnTermMcgBearerSNinitSupport)
    {
        VCCB_CHECK_VALID_GNBNUM_ERROR(rCi.gnbNum);
        const VccbGnbInfo_type &rGnb = GNBINFO[rCi.gnbNum];
        bool prepareNewMeasConfig = false;

        if (rCi.nsaMeas.bearerChangeToMcgMeasFlag)
        {
            if (GOOD != VLIB_CheckSplitDrb(&rCi) || !rGnb.cfg.snTermMcgBearerSnInitSupport)
            {
                prepareNewMeasConfig = true;
            }
        }
        else
        {
            if (rGnb.cfg.snTermMcgBearerSnInitSupport)
            {
                if (GOOD == VLIB_CheckSplitDrb(&rCi))
                {
                    prepareNewMeasConfig = true;
                }
            }
        }

        if (prepareNewMeasConfig)
        {
            status = VCCB_PrepareNewMeasConfig(&rCi);
            VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "VCCB_PrepareNewMeasConfig ERROR!\n");
        }
    }

    return status;
}

 /**
 * @brief Initiate a bearer change from SPLIT to MCG
 * @param [in]  rCi        : callInfo_type &
 * @return      GOOD/ERROR : int16_t
 */
int16_t FnVCCB_InitiateSplitToMcgChange(callInfo_type &rCi)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(rCi.gnbNum, MAX_GNB_PER_SYS);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCi.gnbNum];
    int16_t status = GOOD;

    if (!rGnb.cfg.snTermMcgBearerSnInitSupport)
    {
        MACRO_CALL_FAULT_SAVE_REF(rCi, X2_SgNBReleaseRequired_id, CauseCpInternalMeasurementReportBasedRelease);
        status = VCCB_CALL_RELEASE_TRIGGER(&rCi);
        VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "VCCB_CALL_RELEASE_TRIGGER Error!\n");
        return status;
    }

    for (uint8_t erabIdx = 0; erabIdx < MAX_ERAB_PER_CALL; erabIdx++)
    {
        callERABInfo_type &erabInfo = rCi.erabInfo[erabIdx];

        if (!IS_VALID_NODE(ERAB_NODE, &rCi, &erabInfo))
        {
            continue;
        }

        if (SCG_Bearer == erabInfo.bearerType && ERAB_Release != erabInfo.erabStatus)
        {
            MACRO_CALL_FAULT_SAVE_REF(
                rCi, X2_SgNBReleaseRequired_id, CauseX2apRadioNetworkLayerBearerOptionNotSupported);
            status = VCCB_CALL_RELEASE_TRIGGER(&rCi);
            VCCB_RETURN_ON_CALL_ERROR(&rCi, status, "VCCB_CALL_RELEASE_TRIGGER Error!\n");
            return status;
        }

        if (SPLIT_Bearer == erabInfo.bearerType && ERAB_Release != erabInfo.erabStatus)
        {
            erabInfo.erabStatus = ERAB_Modify;
            erabInfo.preveBearerType = erabInfo.bearerType;
            erabInfo.bearerType = MCG_Bearer;
            erabInfo.ulPdcpPathPrev = erabInfo.ulPdcpPath;
            erabInfo.ulPdcpPath = UlPdcpPath_McgOnly;
            erabInfo.prevPDCPatSgNB = erabInfo.pDCPatSgNB;
        }
    }

    // Increment internal statistic for SN init bearer type change
    VRRM_endcSNinitErabChgCount(&rCi, StatEndcErabModAtt);

    status = VEIL_sendE1SetupModRelRequest(&rCi, E1Procedure_BearerContextModification);
    if (ERROR == status)
    {
        VCCB_PRINT_CALL_ERROR(&rCi, "Sending VEIL_sendE1SetupModRelRequest (Modification) ERROR!\n");
        return status;
    }

    SET_STATE_CMD_REF(rCi, SgNBInitBearerChangeToMcg_cmd);

    ON_F1_PROC_REQUIRED_FLAG(rCi.modProcInfo.selectedModProc);
    rCi.f1Info.f1UeContextToRemove_flag = VCCB_FLAG_ON;

    if (MAX_SRB_PER_CALL > rCi.srb3Idx && IS_VALID_NODE(SRB_NODE, &rCi, &(rCi.srbInfo[rCi.srb3Idx])))
    {
        rCi.srbInfo[rCi.srb3Idx].srbStatus = ERAB_Release;
    }

    VLIB_SetCurStateAll(&rCi, STATE_DCE1Mod_S);
    VLIB_AttachTimer(&rCi.timer, &rCi, timE1_BearerContextModification_id);

    return status;
}

bool FnVCCB_IsIntraGnbCellSaAvailablePlmn(const uint32_t longId, uint16_t gnbNum)
{
    if (DBG->flag.intraGnbNbrSaAvailableCheckEnable != TRUE) return true;

    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, false);
    const VccbGnbInfo_type &rGnb = GNBINFO[gnbNum];

    for (auto nbrPlmnIdx = 0; nbrPlmnIdx < MAX_PLMN_INDEX; nbrPlmnIdx++)
    {
        if (rGnb.serviceAvailInfo[nbrPlmnIdx].status != EQUIP) continue;
        if (rGnb.serviceAvailInfo[nbrPlmnIdx].plmn.longId != longId) continue;
        if (rGnb.serviceAvailInfo[nbrPlmnIdx].saAvailability == TRUE) return true;
    }
    return false;
}

bool FnVCCB_IsInterGnbNbrSaAvailablePlmn(const uint32_t longId, nbrGnbCellInfo_type rNbrGnbCell)
{
    for (auto nbrPlmnIdx = 0; nbrPlmnIdx < MAX_PLMN_INDEX; nbrPlmnIdx++)
    {
        if (rNbrGnbCell.cellPlmnInfo[nbrPlmnIdx].shmStatus != EQUIP) continue;
        if (rNbrGnbCell.cellPlmnInfo[nbrPlmnIdx].longId == longId)
        {
            if (GETBIT(rNbrGnbCell.saAvailable, nbrPlmnIdx)) return true;
        }
    }
    return false;
}

/**
 * @brief Retrieves the number of available PLMN lists for a given neighbor cell in SA (Standalone) mode.
 *
 * This function checks if the call type is SA and processes the allowed PLMN list for both intra-GNB and inter-GNB neighbors.
 * It updates the provided allowed PLMN list with the available PLMNs for the given neighbor cell.
 *
 * @param rCall Reference to the call information structure.
 * @param cellNum The cell number of the neighbor cell.
 * @param nbrIdx The index of the neighbor cell.
 * @param rAllowedPlmnList Reference to the allowed PLMN list structure to be updated.
 * @return int16_t Returns GOOD if successful, ERROR otherwise.
 * @exception Throws an error if the call type is not SA or if there are issues retrieving neighbor cell information.
 * @note This function modifies the rAllowedPlmnList parameter by reference.
 */
// SVR25B FGR-MC1007 FR100 FR152
int16_t FnVCCB_GetNbrSaAvailablePlmnList_IntraGnbCell(callInfo_type &rCall, allowedPlmnList_Type &rAllowedPlmnList)
{
    AUTO_TRACE_FUNC;

    allowedPlmnList_Type saAllowedPlmnList{};

    if (rCall.callType != E_CALLTYPE_SA)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "The NSA is not supported. (callType:%d)\n", rCall.callType);
        return ERROR;
    }
    uint8_t maxVal = static_cast<uint8_t>(UMIN(rAllowedPlmnList.num_plmn, MAX_NUM_PLMN));
    for (auto plmnIndex = 0; plmnIndex < maxVal; plmnIndex++)
    {
        if (saAllowedPlmnList.num_plmn >= MAX_NUM_PLMN) break;
        auto &allowedPlmn = rAllowedPlmnList.plmn[plmnIndex];

        if (FnVCCB_IsIntraGnbCellSaAvailablePlmn(allowedPlmn.longId, rCall.gnbNum))
        {
            saAllowedPlmnList.plmn[saAllowedPlmnList.num_plmn++].longId = allowedPlmn.longId;
        }
    }

    rAllowedPlmnList.num_plmn = saAllowedPlmnList.num_plmn;
    if(rAllowedPlmnList.num_plmn == 0){
        VCCB_PRINT_CALL_ERROR(&rCall, "rAllowedPlmnList.num_plmn == 0 in FnVCCB_GetNbrSaAvailablePlmnList_IntraGnbCell.\n");
    }
    memcpy(&rAllowedPlmnList.plmn, &saAllowedPlmnList.plmn, sizeof(saAllowedPlmnList.plmn));

    return GOOD;
}

int16_t FnVCCB_GetNbrSaAvailablePlmnList_InterGnbCell(callInfo_type &rCall, uint16_t cellNum, uint16_t nbrIdx, allowedPlmnList_Type &rAllowedPlmnList)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);

    allowedPlmnList_Type saAllowedPlmnList{};

    if (rCall.callType != E_CALLTYPE_SA)
    {
        VCCB_PRINT_CALL_ERROR(&rCall, "The NSA is not supported. (callType:%d)\n", rCall.callType);
        return ERROR;
    }

    nbrGnbCellInfo_type *pNbrGnbCell = NULL;
    auto status = getNbrGnbCellByCellNbrIdx(cellNum, nbrIdx, &pNbrGnbCell);
    VCCB_RETURN_ON_CALL_ERROR(&rCall, status, "getNbrGnbCellByCellNbrIdx ERROR in FnVCCB_GetNbrSaAvailablePlmnList_InterGnbCell.\n");

    uint8_t maxVal = static_cast<uint8_t>(UMIN(rAllowedPlmnList.num_plmn, MAX_NUM_PLMN));
    for (auto plmnIndex = 0; plmnIndex < maxVal; plmnIndex++)
    {
        if (saAllowedPlmnList.num_plmn >= MAX_NUM_PLMN) break;
        auto &allowedPlmn = rAllowedPlmnList.plmn[plmnIndex];

        if (FnVCCB_IsInterGnbNbrSaAvailablePlmn(allowedPlmn.longId, *pNbrGnbCell))
        {
            saAllowedPlmnList.plmn[saAllowedPlmnList.num_plmn++].longId = allowedPlmn.longId;
        }
    }

    rAllowedPlmnList.num_plmn = saAllowedPlmnList.num_plmn;
    if(rAllowedPlmnList.num_plmn == 0){
        VCCB_PRINT_CALL_ERROR(&rCall, "rAllowedPlmnList.num_plmn == 0 in FnVCCB_GetNbrSaAvailablePlmnList_InterGnbCell.\n");
    }
    
    memcpy(&rAllowedPlmnList.plmn, &saAllowedPlmnList.plmn, sizeof(saAllowedPlmnList.plmn));

    return GOOD;
}

int16_t FnVCCB_GetNbrSaAvailablePlmnList(
    callInfo_type &rCall, uint16_t cellNum, uint16_t nbrIdx, allowedPlmnList_Type &rAllowedPlmnList)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_RETURN(nbrIdx, MAX_NBR_PER_CELL);
    VCCB_CHECK_VALID_CELLNUM_ERROR(cellNum);
    
    if (VCCB_IS_INTRA_GNB_NEIGHBOR(cellNum, nbrIdx))  // INTRA-GNB
    {
        if(GOOD != FnVCCB_GetNbrSaAvailablePlmnList_IntraGnbCell(rCall, rAllowedPlmnList))
        {
            VCCB_PRINT_CALL_ERROR(&rCall, "check FnVCCB_GetNbrSaAvailablePlmnList_IntraGnbCell in FnVCCB_GetNbrSaAvailablePlmnList\n");
            return ERROR;
        }
    }
    else
    {
        if(GOOD != FnVCCB_GetNbrSaAvailablePlmnList_InterGnbCell(rCall, cellNum, nbrIdx, rAllowedPlmnList))
        {
            VCCB_PRINT_CALL_ERROR(&rCall, "check FnVCCB_GetNbrSaAvailablePlmnList_InterGnbCell in FnVCCB_GetNbrSaAvailablePlmnList\n");
            return ERROR;
        }
    }

    if (rAllowedPlmnList.num_plmn == 0)
    {
        return ERROR;
    }
    
    if (DBG->flag.logPlmn)
    {
        VCCB_PRINT_CALL_COMMENT(&rCall, "[%u] %X %X %X %X %X %X %X %X %X %X %X %X\n", rAllowedPlmnList.num_plmn,
            rAllowedPlmnList.plmn[0].longId, rAllowedPlmnList.plmn[1].longId, rAllowedPlmnList.plmn[2].longId,
            rAllowedPlmnList.plmn[3].longId, rAllowedPlmnList.plmn[4].longId, rAllowedPlmnList.plmn[5].longId,
            rAllowedPlmnList.plmn[6].longId, rAllowedPlmnList.plmn[7].longId, rAllowedPlmnList.plmn[8].longId,
            rAllowedPlmnList.plmn[9].longId, rAllowedPlmnList.plmn[10].longId, rAllowedPlmnList.plmn[11].longId);
    }

    return GOOD;
}

uint16_t fnVCCB_GetHoPrepFailedTimer(callInfo_type &rCall, CellNum_type cellNum)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(cellNum, MAX_CELL_NUM_VCCB, 0);

    rfspBasedCtrl_type *pRfsp = NULL;
    if (VCCB_GetRfspControlInfo(&rCall, cellNum, rCall.ueInfo.servedPlmn, static_cast<uint16_t>(rCall.ueInfo.rfsp.indexToRFSP), &pRfsp) == GOOD)
    {
        if (pRfsp->controlOptionExt.handoverPrepFailedTimer >= MIN_HO_PREP_FAILED_TIMER)
        {
            return (pRfsp->controlOptionExt.handoverPrepFailedTimer);
        }
    }

    VccbCellInfo_type *const pCell = &CELLINFO[cellNum];
    return (pCell->mobilityConfig.handoverPrepFailedTimer);
}

bool FnVCCB_IsPingPongAvoidanceEnabled(callInfo_type &rCall, uint8_t reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, false);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCall.gnbNum];

    if ((reportType == measReport_A5 && reportPurpose == a5Purpose_intraNrOnDemandHandover) ||
            (reportType == measReport_B2Eutra && reportPurpose == b2Purpose_eutraOnDemandHandover))
    {
        return rGnb.cfg.gnbMobilityConfig.pingPongAvoidanceConfig.useForOnDemandHO;
    }

    if ((reportType == measReport_B1Eutra && reportPurpose == b1Purpose_trafficBasedHandover) ||
            (reportType == measReport_B2Eutra && reportPurpose == b2Purpose_trafficBasedHandover))
    {
        return rGnb.cfg.gnbMobilityConfig.pingPongAvoidanceConfig.useForTrafficBasedEutraHO;
    }

    if (FnVCCB_IsInterRatPccChangeHoMeas(static_cast<enumMeasurementReportType>(reportType), reportPurpose))
    {
        return rGnb.cfg.gnbMobilityConfig.pingPongAvoidanceConfig.useForMultiCarrierOperation;
    }

    if (FnVCCB_MapUlStatusReasonFromReportTypeAndPurpose(reportType, reportPurpose) ==
            ulStatusMobilityReason_tddInterference)
    {
        return rGnb.cfg.gnbMobilityConfig.pingPongAvoidanceConfig.useForUlStatusBasedMobility;
    }

    return false;
}

bool FnVCCB_GetPingPongAvoidanceCause(callInfo_type &rCall, uint16_t &rXnCause, uint16_t &rNgCause, uint8_t reportType, uint8_t reportPurpose)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, false);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCall.gnbNum];

    if (not FnVCCB_IsPingPongAvoidanceEnabled(rCall, reportType, reportPurpose)) return false;

    uint8_t pingPongAvoidanceCause = rGnb.cfg.gnbMobilityConfig.pingPongAvoidanceConfig.pingPongAvoidanceCause;

    switch (pingPongAvoidanceCause)
    {
        case PP_CAUSE_OM_INTERVENTION:
            rXnCause = CauseXnapMiscOMIntervention;
            rNgCause = CauseNgapMiscOMIntervention;
            return true;
        default:
            break;
    }

    return false;
}

bool VCCB_isUlInterferedCellAllowedBasedOnThresholds(const callInfo_type &rCall, const cellResults_type &cellResults)
{
    AUTO_TRACE_FUNC;

    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, false);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCall.gnbNum];

    const auto &thresholds = rGnb.cfg.ulInterferenceCellSelectionThresholds;

    if ((FALSE == cellResults.resultsSSB_CellFlag) ||
        ((0 == thresholds.thresholdRsrp) && (0 == thresholds.thresholdRsrq)))
    {
        return false;
    }

    const auto &ssbCell = cellResults.resultsSSB_Cell;

    if ((TRUE == ssbCell.rsrpFlag) && (thresholds.thresholdRsrp != 0) && (ssbCell.rsrp <= thresholds.thresholdRsrp))
    {
        return false;
    }
    if ((TRUE == ssbCell.rsrqFlag) && (thresholds.thresholdRsrq != 0) && (ssbCell.rsrq <= thresholds.thresholdRsrq))
    {
        return false;
    }
    return true;
}

bool FnVCCB_ExistIdleVoNRQoSFlow(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;

    uint8_t fiveQi;

    for(auto&qosFlow : rCall.qosFlow)
    {
        if (qosFlow.usage != CI_use) continue;
        if (qosFlow.qosFlowStatus != S_Idle) continue;

        VLIB_getFiveQi(&qosFlow, &fiveQi);

        if (fiveQi == VONR_5QI) {
            return true;
        }
    }

    return false;
}

/****************************************************************************
 * @brief           Get the string representation of the PSCell selection method
 *
 * @param[in]       ptCi     : call context pointer
 * @param[out]      buffer   : output buffer to store the selection method string
 * @return          void
 ****************************************************************************/
static void FnVCCB_GetSelMethodStr(callInfo_type *ptCi, char *buffer)
{
    AUTO_TRACE_FUNC;

    if (!buffer)
    {
        return;
    }

    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_VALID_GNBNUM_VOID(ptCi->gnbNum);

    auto gnbCfg = GNBINFO[ptCi->gnbNum].cfg;
    uint8_t method = IS_NRDC_SN(ptCi) ? gnbCfg.nrdc.pscellSelectionMethod : gnbCfg.pscellSelectionMethod;

    const char *methodStr = [&]
    {
        switch (method)
        {
            case access_s5gtype_pscell_selection_random:
                return "rndm";
            case access_s5gtype_pscell_selection_measurement:
                return "mr";
            case access_s5gtype_pscell_selection_load_balancing:
                return "lb";
            case access_s5gtype_pscell_selection_load_balancing_ue_count_based:
                return "lb_ue";
            default:
                return "Invalid";
        }
    }();

    int logBufUseSize = 0;
    LOGBUF(buffer, MAX_CMD_STR_BUF, &logBufUseSize, "%s", methodStr);
}

/****************************************************************************
 * @brief           Build a string containing PCI information for serving and neighboring cells
 *
 * @param[in]       ptMeasResult2NR   : pointer to measurement result for a frequency
 * @param[out]      pci               : output buffer to store the formatted PCI string
 * @param[in,out]   freqCnt           : reference to counter tracking the number of processed frequencies
 * @param[in,out]   nrcgiCnt          : reference to counter tracking the number of NRCGI candidates
 * @return          void
 ****************************************************************************/
static void FnVCCB_BuildPciString(measResult2NR_type *ptMeasResult2NR, char *pci, uint8_t &freqCnt, uint8_t &nrcgiCnt)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptMeasResult2NR);
    VALID_E_POINT_CHECK_VOID(pci);
    int logBufUseSize = 0;

    auto ptMeasResultServingCell = &ptMeasResult2NR->measResultServingCell;
    freqCnt++;

    if (CHECK_CONDITION_NCI(ptMeasResultServingCell))
    {
        nrcgiCnt++;
    }

    auto pci_srv = ptMeasResultServingCell->physCellId != 0xFFFF ? "%d" : "-";
    LOGBUF(pci, MAX_CMD_STR_BUF, &logBufUseSize, pci_srv, ptMeasResultServingCell->physCellId);
    LOGBUF(pci, MAX_CMD_STR_BUF, &logBufUseSize, "(");

    auto ptMeasResultNeighCellListNR = &ptMeasResult2NR->measResultNeighCellListNR;
    uint8_t loop_max = MIN(ptMeasResultNeighCellListNR->nrofCellReport, MAX_NUM_CELL_REPORT);

    for (uint8_t loop = 0; loop < loop_max; ++loop)
    {
        if (loop > 0)
        {
            LOGBUF(pci, MAX_CMD_STR_BUF, &logBufUseSize, ",");
        }

        auto ptMeasResultNR = &ptMeasResultNeighCellListNR->measResultNR[loop];
        if (CHECK_CONDITION_NCI(ptMeasResultNR))
        {
            nrcgiCnt++;
        }

        auto pci_neigh = ptMeasResultNR->physCellId != 0xFFFF ? "%d" : "-";
        LOGBUF(pci, MAX_CMD_STR_BUF, &logBufUseSize, pci_neigh, ptMeasResultNR->physCellId);
    }

    if (loop_max == 0)
    {
        LOGBUF(pci, MAX_CMD_STR_BUF, &logBufUseSize, "-");
    }

    LOGBUF(pci, MAX_CMD_STR_BUF, &logBufUseSize, ")");

    if (logBufUseSize == 0)
    {
        LOGBUF(pci, MAX_CMD_STR_BUF, &logBufUseSize, "None");
    }
}

/****************************************************************************
 * @brief           Build a string containing failure reasons for serving and neighboring cells
 *
 * @param[in]       ptCi              : call context pointer
 * @param[in]       ptMeasResult2NR   : pointer to measurement result for a frequency
 * @param[out]      spCellSelFail     : output buffer to store the formatted failure reasons string
 * @param[in,out]   num               : reference to counter tracking the number of processed cells
 * @return          void
 ****************************************************************************/
static void FnVCCB_BuildFailureReasonsString(
    callInfo_type *ptCi, measResult2NR_type *ptMeasResult2NR, char *spCellSelFail, uint8_t &num)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptMeasResult2NR);
    VALID_E_POINT_CHECK_VOID(spCellSelFail);

    int logBufUseSize = 0;

    if (num >= MAX_NUM_CELL_REPORT)
    {
        return;  // MAX_NUM_CELL_REPORT ->  MAX_NUM_CANDIDATE_CELL_FOR_PSCELL after Quality
    }

    if (ptMeasResult2NR->measResultServingCell_Flag)
    {
        uint16_t sel_fail_serv = ptCi->spCellSelFailStats.SpCellSelFailPerCandidateCell[num].spCellSelFailure;
        auto sel_fail_serv_str = sel_fail_serv != 0xFFFF ? "%d(" : "-(";
        LOGBUF(spCellSelFail, MAX_CMD_STR_BUF, &logBufUseSize, sel_fail_serv_str, sel_fail_serv);
        num++;
    }
    else
    {
        LOGBUF(spCellSelFail, MAX_CMD_STR_BUF, &logBufUseSize, "-(");
    }

    uint8_t loop_max = MIN(ptMeasResult2NR->measResultNeighCellListNR.nrofCellReport, MAX_NUM_CELL_REPORT);
    for (int loop = 0; loop < loop_max; ++loop)
    {
        if (num >= MAX_NUM_CELL_REPORT)
        {
            break;  // MAX_NUM_CELL_REPORT ->  MAX_NUM_CANDIDATE_CELL_FOR_PSCELL after Quality
        }

        uint16_t sel_fail_neigh = ptCi->spCellSelFailStats.SpCellSelFailPerCandidateCell[num].spCellSelFailure;
        auto sel_fail_neigh_str = sel_fail_neigh != 0xFFFF ? "%d," : "-,";
        LOGBUF(spCellSelFail, MAX_CMD_STR_BUF, &logBufUseSize, sel_fail_neigh_str, sel_fail_neigh);
        num++;
    }

    if (loop_max == 0)
    {
        LOGBUF(spCellSelFail, MAX_CMD_STR_BUF, &logBufUseSize, "-");
    }

    if (logBufUseSize > 0 && spCellSelFail[logBufUseSize - 1] == ',')
    {
        logBufUseSize--;
    }

    LOGBUF(spCellSelFail, MAX_CMD_STR_BUF, &logBufUseSize, ")");

    if (logBufUseSize == 0)
    {
        LOGBUF(spCellSelFail, MAX_CMD_STR_BUF, &logBufUseSize, "None");
    }
}

/****************************************************************************
 * @brief           Print information about available candidates
 *
 * @param[in]       ptCi                    : call context pointer
 * @param[in]       ptCandidateCellInfoList : pointer to array containing list of candidate cells
 * @return          void
 ****************************************************************************/
void FnVCCB_PrintCandidatesInfo(callInfo_type *ptCi, measResultList2NR_type *ptCandidateCellInfoList)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VALID_E_POINT_CHECK_VOID(ptCandidateCellInfoList);

    if (!(IS_ENDC(ptCi)) || !(DBG->flag.logCandInfoPrint))
    {
        return;
    }

    char sel_algo[MAX_CMD_STR_BUF] = {0};
    uint8_t freqCnt = 0, nrcgiCnt = 0, num = 0;

    FnVCCB_GetSelMethodStr(ptCi, sel_algo);

    VCCB_PRINT_CALL_DATA(ptCi, "----------------CAND INFO SUMMARY----------------\n");
    VCCB_PRINT_CALL_DATA(ptCi, "arfcn | pci_serv(pci_neigh) | SpCellSelFailReason\n");

    for (uint8_t measFreqIdx = 0; measFreqIdx < ptCandidateCellInfoList->nrofFreq; ++measFreqIdx)
    {
        auto ptMeasResult2NR = &ptCandidateCellInfoList->measResult2NR[measFreqIdx];

        static constexpr uint8_t MAX_ARFCN_ENTRY_SIZE = 11;
        char arfcn[MAX_ARFCN_ENTRY_SIZE] = {0}, pci[MAX_CMD_STR_BUF] = {0}, spCellSelFail[MAX_CMD_STR_BUF] = {0};

        int arfcnBufSize = 0;
        LOGBUF(arfcn, MAX_ARFCN_ENTRY_SIZE, &arfcnBufSize, ptMeasResult2NR->ssbFrequency_Flag ? "%d" : "-",
            ptMeasResult2NR->ssbFrequency);

        FnVCCB_BuildPciString(ptMeasResult2NR, pci, freqCnt, nrcgiCnt);
        FnVCCB_BuildFailureReasonsString(ptCi, ptMeasResult2NR, spCellSelFail, num);

        VCCB_PRINT_CALL_DATA(ptCi, "%s | %s | %s\n", arfcn, pci, spCellSelFail);
    }

    VCCB_PRINT_CALL_DATA(ptCi, "Ps cell selection method: %s. Number of frequencies: %d (%d nrcgi candidates).\n",
        sel_algo, freqCnt, nrcgiCnt);
    VCCB_PRINT_CALL_DATA(ptCi, "-------------------------------------------------\n");
}

/****************************************************************************
 * @brief           Print information about selected candidate
 *
 * @param[in]       ptCi                    : call context pointer
 * @param[in]       nrcgiCell               : boolean that tell us whether selected cell is nrcgi or not
 * @return          void
 ****************************************************************************/
void FnVCCB_PrintSelectedCandidateInfo(callInfo_type *ptCi, bool nrcgiCell)
{
    AUTO_TRACE_FUNC;
    VALID_E_POINT_CHECK_VOID(ptCi);
    VCCB_CHECK_E_RANGE_AND_VOID(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    VccbCellInfo_type *pCell = &CELLINFO[ptCi->servCellNum];

    if (!(IS_ENDC(ptCi)) || !(DBG->flag.logCandInfoPrint))
    {
        return;
    }

    static constexpr uint8_t MAX_MR_ENTRY_SIZE = 7;
    char MR[MAX_MR_ENTRY_SIZE] = {0}, nci[MAX_NR_CELLIDENTITY_BIT] = {0};

    int mrBufSize = 0;
    auto rsrpStr = ptCi->servingCellMeasInitialInfo.rsrpFlag ? "%d|" : "-|";
    auto rsrqStr = ptCi->servingCellMeasInitialInfo.rsrqFlag ? "%d" : "-";
    LOGBUF(MR, MAX_MR_ENTRY_SIZE, &mrBufSize, rsrpStr, ptCi->servingCellMeasInitialInfo.rsrp);
    LOGBUF(MR, MAX_MR_ENTRY_SIZE, &mrBufSize, rsrqStr, ptCi->servingCellMeasInitialInfo.rsrq);

    int nciBufSize = 0;
    LOGBUF(nci, MAX_NR_CELLIDENTITY_BIT, &nciBufSize, nrcgiCell ? "%d" : "-", pCell->cgi.ci);

    VCCB_PRINT_CALL_DATA(ptCi, "Selected cand info: pci(%d) nci(%s) freq(%d) gnb(%d) MR(%s)\n", pCell->phyCellId, nci,
        pCell->ssbArfcn, GNBINFO[ptCi->gnbNum].globalGnbId.gnbId.id, MR);
}

bool FnVCCB_GetConfigPingPongAvoidanceCause(callInfo_type &rCall, uint16_t &rXnCause, uint16_t &rNgCause)
{
    AUTO_TRACE_FUNC;
    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, false);
    const VccbGnbInfo_type &rGnb = GNBINFO[rCall.gnbNum];
    switch (rGnb.cfg.gnbMobilityConfig.pingPongAvoidanceConfig.pingPongAvoidanceCause)
    {
        case PP_CAUSE_OM_INTERVENTION:
            rXnCause = CauseXnapMiscOMIntervention;
            rNgCause = CauseNgapMiscOMIntervention;
            return true;
        default:
            break;
    }
    return false;
}
void FnVCCB_InitPpaRestrictInfo(ppaRestrictInfo_type &rPpa)
{
    memset(&rPpa, 0, sizeof(rPpa));
    rPpa.ssbFrequency = UNKNOWN_ARFCN;
    rPpa.measObjIdx = INVALID_OBJECT_ID;
}
uint32_t FnVCCB_GetPingPongRestrictionWindowSeconds(callInfo_type &rCall)
{
    AUTO_TRACE_FUNC;
    static const uint8_t minutes[] = {5, 10, 20, 30, 60, 120, 180};
    VCCB_CHECK_E_RANGE_AND_VAL(rCall.gnbNum, MAX_GNB_PER_SYS, 30u * 60u);
    uint8_t idx = GNBINFO[rCall.gnbNum].cfg.gnbMobilityConfig.pingPongAvoidanceConfig.restrictionTimer;
    if (idx >= sizeof(minutes) / sizeof(minutes[0]))
    {
        idx = 3u;
    }
    return (uint32_t)minutes[idx] * 60u;
}

