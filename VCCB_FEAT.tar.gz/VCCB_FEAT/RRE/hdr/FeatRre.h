/**
 * @file        FeatRre.h
 * @brief       Utility functions for RRE
 */

#ifndef VCCB_FEAT_FeatRre_H_
#define VCCB_FEAT_FeatRre_H_

#include "VccbStruct.h"

// mutex
int FnVCCB_InitAllocCallIdDbMutex(pthread_mutexattr_t *pAttr);

// DB
void FnVCCB_clearAllocCallDbForRRE(uint16_t gnbNum);
void FnVCCB_insertAllocCallDbForRRE(callInfo_type *ptCi);
void FnVCCB_eraseAllocCallDbForRRE(callInfo_type *ptCi);

// handler
uint32_t VLIB_FindCallWithCgiAndCrnti(uint16_t gnbNum, plmnId_type *plmn, uint64_t ci, crnti_type cRNTI);
uint32_t VLIB_FindCallWithRreInfo(callInfo_type *ptCi, uint16_t pci, uint16_t crnti, cgi_type *cgi, uint16_t shortMacI);
// int16_t VLIB_FindReestablishedCallInfo(callInfo_type *ptTmpCi, uint16_t *ptCslFetchResult, uint8_t *ptRreMatchType);
int16_t VLIB_FindReestablishedCallInfo(callInfo_type *ptTmpCi, uint8_t *ptRreMatchType, enumNrInterface_type interface);

/* Inter-Plmn RRE */
int16_t VCOM_GetSelectedPLMN_For_RRE(
    callInfo_type *ptCi, uint32_t cellNum, enumReestablishType_type rreType, plmnId_type *ptPlmn);
int16_t VCOM_GetEPLMNbasedSelectedPLMN_For_RRE(
    callInfo_type *ptCi, const allowedPlmnList_Type *pt_b_plmn_list, plmnId_type *ptPlmn);
int16_t VCOM_GetBPLMNbasedSelectedPLMN_For_RRE(callInfo_type *ptCi, const allowedPlmnList_Type *pt_b_plmn_list,
    enumReestablishType_type rreType, plmnId_type *ptPlmn);

#endif
