/**
 * @file        FeatRre.cpp
 * @brief       Utility functions for RRE
 */

#include "FeatRre.h"

#include "FeatHo.h"
#include "FeatMrl.h"
#include "FeatCommon.h"
#include "FeatSecurity.h"
#include "FeatCallProc.h"
#include "ComInclude.h"
#include "ComLibUtility.h"
#include "MsgXnapMake.h"

static pthread_mutex_t gAllocCallIdDbMutex[VCCB_CALL_THREAD_NUM];
static std::unordered_set<uint32_t> gAllocCallIdDb[MAX_GNB_CU_CP_FUNCTION_PER_SYS][VCCB_CALL_THREAD_NUM];

static uint32_t gCallIdCnt = 0;
#ifdef IPC_TEST
static uint32_t gCallIdList[200000];  // MAX_CALL_COUNT_PER_CPC (memory issue)
#else
static uint32_t gCallIdList[MAX_CALL_COUNT_PER_CPC];
#endif

void FnVCCB_InsertValidCall(uint32_t callId, uint16_t gnbNum, uint16_t thId);
void FnVCCB_EraseValidCall(uint32_t callId, uint16_t gnbNum, uint16_t thId);
void FnVCCB_ClearValidCall(uint16_t gnbNum, uint16_t thId);

/**
 * @brief   initializes mutex (gAllocCallIdDbMutex) to search the call for RRE
 */
int FnVCCB_InitAllocCallIdDbMutex(pthread_mutexattr_t *pAttr)
{
    AUTO_TRACE_FUNC;

    if (!pAttr)
    {
        return EXIT_MUTEXATTR_INIT_FAIL;
    }

    for (int thId = 0; thId < VCCB_CALL_THREAD_NUM; ++thId)
    {
        if (pthread_mutex_init(&(gAllocCallIdDbMutex[thId]), pAttr))
        {
            return EXIT_MUTEXATTR_INIT_FAIL;
        }
    }

    return 0;
}

void FnVCCB_clearAllocCallDbForRRE(uint16_t gnbNum)
{
    if (gnbNum >= MAX_GNB_PER_SYS) return;

    const int MAX_CALL_THREAD_NUM = MAX_CALL_THREAD_NUM_VCCB;
    for (uint16_t thId = 0; thId < MAX_CALL_THREAD_NUM; ++thId)
    {
        // gAllocCallIdDb[gnbNum][thId].clear();
        FnVCCB_ClearValidCall(gnbNum, thId);
    }
}

void FnVCCB_ClearValidCall(uint16_t gnbNum, uint16_t thId)
{
    if (gnbNum >= MAX_GNB_PER_SYS) return;
    if (thId >= VCCB_CALL_THREAD_NUM) return;

    MUTEX_LOCK(&gAllocCallIdDbMutex[thId]);

    gAllocCallIdDb[gnbNum][thId].clear();

    MUTEX_UNLOCK(&gAllocCallIdDbMutex[thId]);
}

void FnVCCB_insertAllocCallDbForRRE(callInfo_type *ptCi)
{
    if (ptCi == NULL) return;

    if (ptCi->callType == E_CALLTYPE_NSA) return;
    if (IS_NRDC_SN(ptCi)) return;

    // insert for SA or MR-DC MN ue
    FnVCCB_InsertValidCall(ptCi->callId, ptCi->gnbNum, ptCi->myThreadId);

    ptCi->extDb.m.isUseAllocDB = TRUE;
}

void FnVCCB_InsertValidCall(uint32_t callId, uint16_t gnbNum, uint16_t thId)
{
    if (gnbNum >= MAX_GNB_PER_SYS) return;
    if (thId >= VCCB_CALL_THREAD_NUM) return;

    MUTEX_LOCK(&gAllocCallIdDbMutex[thId]);

    try
    {
        gAllocCallIdDb[gnbNum][thId].insert(callId);
    }
    catch (const std::exception& e)
    {
        VCCB_PRINT_ERROR("[%s] exception: %s\n", __func__, e.what());
    }

    MUTEX_UNLOCK(&gAllocCallIdDbMutex[thId]);
}

void FnVCCB_eraseAllocCallDbForRRE(callInfo_type *ptCi)
{
    if (ptCi == NULL) return;
    if (ptCi->extDb.m.isUseAllocDB == FALSE) return;

    FnVCCB_EraseValidCall(ptCi->callId, ptCi->gnbNum, ptCi->myThreadId);
}

void FnVCCB_EraseValidCall(uint32_t callId, uint16_t gnbNum, uint16_t thId)
{
    if (gnbNum >= MAX_GNB_PER_SYS) return;
    if (thId >= VCCB_CALL_THREAD_NUM) return;

    MUTEX_LOCK(&gAllocCallIdDbMutex[thId]);

    try
    {
        gAllocCallIdDb[gnbNum][thId].erase(callId);
    }
    catch (const std::exception& e)
    {
        VCCB_PRINT_ERROR("[%s] exception: %s\n", __func__, e.what());
    }
    
    MUTEX_UNLOCK(&gAllocCallIdDbMutex[thId]);
}

void getValidCall(uint16_t gnbNum)
{
    gCallIdCnt = 0;

    if (gnbNum >= MAX_GNB_PER_SYS) return;

    const int MAX_CALL_THREAD_NUM = MAX_CALL_THREAD_NUM_VCCB;
    for (int thId = 0; thId < MAX_CALL_THREAD_NUM; ++thId)
    {
        MUTEX_LOCK(&gAllocCallIdDbMutex[thId]);

        for (auto callId : gAllocCallIdDb[gnbNum][thId])
        {
            gCallIdList[gCallIdCnt++] = callId;
        }

        MUTEX_UNLOCK(&gAllocCallIdDbMutex[thId]);
    }
}

bool static inline FnVCCB_isPciCrnti_matchedWithServingCell(
    const callInfo_type &callInfo, const VccbCellInfo_type &cellinfo, uint16_t pci, uint16_t crnti)
{
    return (cellinfo.phyCellId == pci) && (callInfo.ueInfo.ueId.usage == CI_use && callInfo.ueInfo.ueId.cRNTI == crnti);
}

bool static inline FnVCCB_isPciCrnti_matchedWithHoTargetCell(
    const callInfo_type &callInfo, uint16_t pci, uint16_t crnti)
{
    return (callInfo.hoInfo.phyCellId == pci) &&
           (callInfo.hoInfo.targetcRNTIUsage == CI_use && callInfo.hoInfo.targetcRNTI == crnti);
}

bool static inline FnVCCB_isCrnti_matchedWithServingCell(const callInfo_type &callInfo, uint16_t crnti)
{
    return (callInfo.ueInfo.ueId.usage == CI_use && callInfo.ueInfo.ueId.cRNTI == crnti);
}

bool static inline FnVCCB_getShortMacI(
    callInfo_type &callInfo, uint16_t pci, uint16_t crnti, uint64_t ci, uint16_t &shortMacI)
{
    return (GOOD == VLIB_MakeShortMacI(&callInfo, pci, crnti, ci, &shortMacI));
}

bool static inline FnVCCB_getShortMacI_FromReestabInfoList(
    const callInfo_type &callInfo, uint64_t ci, uint16_t &shortMacI)
{
    // Compare Target Short Mac-I
    const int maxReestabNcell = MIN(MAX_CELL_PREPARED_FOR_HO + 1, callInfo.ueInfo.reestablishInfo.numReestabNCell);
    for (auto nCellIdx = 0; nCellIdx < maxReestabNcell; nCellIdx++)
    {
        if (ci == callInfo.ueInfo.reestablishInfo.reestabNCellInfo[nCellIdx].reestabCellIdentity)
        {
            shortMacI = callInfo.ueInfo.reestablishInfo.reestabNCellInfo[nCellIdx].shortMacI;
            return true;
        }
    }

    return false;
}

bool static inline FnVCCB_isBeforeSendHandoverRequestAck(const callInfo_type &callInfo)
{
    return (callInfo.hoInfo.handoverExecutionFlag == FALSE);
}

void static inline FnVCCB_updateCallId_matchedType(
    uint32_t &callIdDb, uint32_t callId, uint8_t &matchDb, uint8_t matchValue)
{
    callIdDb = callId;
    matchDb = matchValue;
}

/**
 * @brief     find cuCpUeId with CGI and C-RNTI
 */
uint32_t VLIB_FindCallWithCgiAndCrnti(uint16_t gnbNum, plmnId_type *plmn, uint64_t ci, crnti_type crnti)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(plmn, UNKNOWN_CP_CALLID);
    VCCB_CHECK_E_RANGE_AND_VAL(gnbNum, MAX_GNB_PER_SYS, UNKNOWN_CP_CALLID);

    uint16_t cellNum;

    callInfo_type *pCallInfoBase = &ENV->callInfo[0];
    VccbCellInfo_type *pCellInfoBase = CELLINFO;
    const plmnId_type gnbPlmn = GNBINFO[gnbNum].globalGnbId.plmn;

    /* check the gnb PLMN */
    if (!VCOM_CheckPlmnIdentical(&gnbPlmn, plmn))
    {
        return UNKNOWN_CP_CALLID;
    }

    getValidCall(gnbNum);

    const uint32_t MAX_CELL_NUM = MAX_CELL_NUM_VCCB;
    const uint32_t MAX_VCCB_CALL_COUNT = VCCB_MAX_CALL_COUNT_PER_CPC;

    const uint32_t MaxOfCallIdList = MIN(gCallIdCnt, GET_ARR_SIZE(gCallIdList));

    uint32_t callId;
    for (uint32_t i = 0; i < MaxOfCallIdList; i++)
    {
        callId = gCallIdList[i];

        if (callId >= MAX_VCCB_CALL_COUNT) continue;
        callInfo_type &callInfo = pCallInfoBase[callId];

        if (callInfo.usage != CI_use) continue;
        if (GET_RRC_STATE((&callInfo)) == RRC_INACTIVE) continue;

        cellNum = callInfo.servCellNum;
        if (cellNum >= MAX_CELL_NUM) continue;

        if (FnVCCB_isCrnti_matchedWithServingCell(callInfo, crnti))
        {
            /* check the nr-cgi (plmn is already checked) */
            if (pCellInfoBase[cellNum].cgi.ci == ci)
            {
                // TODO: need to check the print
                VCCB_PRINT_CALL_INFORMATIVE(&callInfo, "Ue Context Exists!\n");
                return callInfo.gnbCuUeId;
            }
        }
    }

    // TODO: need to add the print. There is no matched call for c-rnti plmn, ci

    return UNKNOWN_CP_CALLID;
}

/**
 * @brief     find cuCpUeId with PCI, C-RNTI and shortMac-I
 */
uint32_t VLIB_FindCallWithRreInfo(callInfo_type *ptCi, uint16_t pci, uint16_t crnti, cgi_type *cgi, uint16_t shortMacI)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_RET_VAL(ptCi, UNKNOWN_CP_CALLID);
    VALID_E_POINT_CHECK_RET_VAL(cgi, UNKNOWN_CP_CALLID);

    uint16_t cellNum;
    uint16_t outShortMacI;

    callInfo_type *pCallInfoBase = &ENV->callInfo[0];
    VccbCellInfo_type *pCellInfoBase = CELLINFO;

    getValidCall(ptCi->gnbNum);

    const uint32_t MAX_CELL_NUM = MAX_CELL_NUM_VCCB;
    const uint32_t MAX_VCCB_CALL_COUNT = VCCB_MAX_CALL_COUNT_PER_CPC;

    const uint32_t MaxOfCallIdList = MIN(gCallIdCnt, GET_ARR_SIZE(gCallIdList));

    uint32_t callId;
    for (uint32_t i = 0; i < MaxOfCallIdList; i++)
    {
        callId = gCallIdList[i];

        if (callId >= MAX_VCCB_CALL_COUNT) continue;
        callInfo_type &callInfo = pCallInfoBase[callId];

        if (callInfo.usage != CI_use) continue;
        if (GET_RRC_STATE((&callInfo)) == RRC_INACTIVE) continue;

        cellNum = callInfo.servCellNum;
        if (cellNum >= MAX_CELL_NUM) continue;

        if (FnVCCB_isPciCrnti_matchedWithServingCell(callInfo, pCellInfoBase[cellNum], pci, crnti))
        {
            if (FnVCCB_getShortMacI(callInfo, pci, crnti, cgi->ci, outShortMacI))
            {
                if (outShortMacI == shortMacI)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(&callInfo, "Ue Context Exists!\n");
                    return callInfo.gnbCuUeId;
                }
            }
        }
    }

    // TODO: need to add the print. There is no matched call for c-rnti plmn, ci

    return UNKNOWN_CP_CALLID;
}

/**
 * @brief     Find Reestablished CallInfo
 * @param     ptr call context
 * @return    TRUE : success
 * @return    FALSE : failure
 */
int16_t VLIB_FindReestablishedCallInfo(callInfo_type *ptCi, uint8_t *ptRreMatchType, enumNrInterface_type interface)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptRreMatchType);

    int16_t status = GOOD;
    uint16_t crnti, pci, shortMacI;  // received from RRE request message
    uint64_t ci;
    uint16_t calcShortMacI;
    uint16_t cellNum;

    callInfo_type *pCallInfoBase = &ENV->callInfo[0];
    VccbCellInfo_type *pCellInfoBase = &CELLINFO[0];

    crnti = ptCi->ueInfo.reestablishInfo.reestCRNTI;
    pci = ptCi->ueInfo.reestablishInfo.reestPhysCellId;
    shortMacI = ptCi->ueInfo.reestablishInfo.reestShortMacI;
    ci = ptCi->nRCGI.ci;

    getValidCall(ptCi->gnbNum);

    const uint32_t MAX_CELL_NUM = MAX_CELL_NUM_VCCB;
    const uint32_t MAX_VCCB_CALL_COUNT = VCCB_MAX_CALL_COUNT_PER_CPC;

    const uint32_t MaxOfCallIdList = MIN(gCallIdCnt, GET_ARR_SIZE(gCallIdList));

    for (uint32_t i = 0; i < MaxOfCallIdList; i++)
    {
        uint32_t callId = gCallIdList[i];

        if (callId >= MAX_VCCB_CALL_COUNT) continue;
        callInfo_type &callInfo = pCallInfoBase[callId];

        if (callInfo.usage != CI_use) continue;
        if (GET_RRC_STATE((&callInfo)) == RRC_INACTIVE) continue;

        cellNum = callInfo.servCellNum;
        if (cellNum >= MAX_CELL_NUM) continue;

        VccbCellInfo_type &cellInfo = pCellInfoBase[cellNum];

        if (FnVCCB_isPciCrnti_matchedWithServingCell(callInfo, cellInfo, pci, crnti))
        {
            if (callInfo.security.pdcpCtx.securityInfo.integrityAlgo == EIA0)
            {
                VCCB_PRINT_CALL_COMMENT(&callInfo, "[RRE] integrityAlgo(EIA0), Accept RRE\n");
                FnVCCB_updateCallId_matchedType(ptCi->gnbCuUeId, callInfo.gnbCuUeId, *ptRreMatchType, RRE_CURRENT_KEY_MATCH);
                break;
            }

            if (FnVCCB_getShortMacI(callInfo, pci, crnti, ci, calcShortMacI))
            {
                // Compare Short Mac-I
                if (calcShortMacI == shortMacI)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(
                        &callInfo, "[RRE] Success Retrieve Case 1: short MAC-I using current key\n");
                    FnVCCB_updateCallId_matchedType(ptCi->gnbCuUeId, callInfo.gnbCuUeId, *ptRreMatchType, RRE_CURRENT_KEY_MATCH);
                    break;
                }
                else  // Mismatch
                {
                    VCCB_PRINT_CALL_ERROR(
                        &callInfo, "[RRE] Failure Retrieve Case 1: outShortMacI(%d)\n", calcShortMacI);
                }
            }
            else
            {
                VCCB_PRINT_CALL_ERROR(&callInfo, "FnVCCB_getShortMacI Error\n");
                // TBD: use continue ?
                return ERROR;
            }
        }

        if (callInfo.stateCmd == IntraRatHO_cmd)
        {
            if ((callInfo.hoInfo.hoType.nb == HO_TYPE_INTER_NB) && (callInfo.hoInfo.isTarget == TRUE))
            {
                if (interface == interface_xn)
                {
                    VCCB_PRINT_CALL_COMMENT(
                        &callInfo, "[RRE] Skip source gNB Key search in case of xn interface!\n");
                    continue;
                }

                // pci is source cell information. check the shortMacI with source gNB key
                if (callInfo.ueInfo.reestablishInfo.srcPhyCellId == pci)
                {
                    if (callInfo.ueInfo.reestablishInfo.srcIntegrityAlgo == EIA0)
                    {
                        VCCB_PRINT_CALL_COMMENT(
                            &callInfo, "[RRE] source integrityAlgo(EIA0), Skip this and check other call!\n");
                        continue;
                    }

                    // Compare Target Short Mac-I
                    if (FnVCCB_getShortMacI_FromReestabInfoList(callInfo, ci, calcShortMacI))
                    {
                        if (calcShortMacI == shortMacI)
                        {
                            VCCB_PRINT_CALL_INFORMATIVE(
                                &callInfo, "[RRE] Success Retrieve Case 2: short MAC-I made by source gNB\n");

                            if (HO_TYPE_SA_INTER_GNB_NG_HANDOVER == callInfo.hoInfo.hoType.initiated)
                                FnVCCB_updateCallId_matchedType(ptCi->gnbCuUeId, callInfo.gnbCuUeId, *ptRreMatchType, RRE_NG_HO_SRC_KEY_MATCH);
                            else if (HO_TYPE_SA_INTER_GNB_XN_HANDOVER == callInfo.hoInfo.hoType.initiated)
                                FnVCCB_updateCallId_matchedType(ptCi->gnbCuUeId, callInfo.gnbCuUeId, *ptRreMatchType, RRE_XN_HO_SRC_KEY_MATCH);
                            else
                            {
                                VCCB_PRINT_CALL_ERROR(
                                    &callInfo, "[RRE] SRC_KEY_MATCH: not supported handover initiated type(%d)\n", callInfo.hoInfo.hoType.initiated);
                                return ERROR;
                            }

                            if (FnVCCB_isBeforeSendHandoverRequestAck(callInfo))
                            {
                                VCCB_PRINT_CALL_INFORMATIVE(&callInfo,
                                    "[RRE] trigger Inter gNB RRE and XN Retrieve during HO preparation on target "
                                    "gNB\n");
                                return ERROR;
                            }
                            break;
                        }
                    }
                }
            }
            else if (callInfo.hoInfo.hoType.nb == HO_TYPE_INTRA_NB)
            {
                if (FnVCCB_isPciCrnti_matchedWithHoTargetCell(callInfo, pci, crnti))
                {
                    if (callInfo.security.pdcpCtx.securityInfo.integrityAlgo == EIA0)
                    {
                        VCCB_PRINT_CALL_COMMENT(&callInfo, "[RRE] integrityAlgo(EIA0), Accept RRE\n");
                        FnVCCB_updateCallId_matchedType(
                            ptCi->gnbCuUeId, callInfo.gnbCuUeId, *ptRreMatchType, RRE_CURRENT_KEY_MATCH);
                        break;
                    }

                    if (FnVCCB_getShortMacI(callInfo, pci, crnti, ci, calcShortMacI))
                    {
                        // Compare Short Mac-I
                        if (calcShortMacI == shortMacI)
                        {
                            VCCB_PRINT_CALL_INFORMATIVE(
                                &callInfo, "[RRE] Success Retrieve Case 1: short MAC-I using current key\n");
                            FnVCCB_updateCallId_matchedType(
                                ptCi->gnbCuUeId, callInfo.gnbCuUeId, *ptRreMatchType, RRE_CURRENT_KEY_MATCH);
                            break;
                        }
                        else  // Mismatch
                        {
                            VCCB_PRINT_CALL_ERROR(
                                &callInfo, "[RRE] Failure Retrieve Case 1: outShortMacI(%d)\n", calcShortMacI);
                        }
                    }
                    else
                    {
                        VCCB_PRINT_CALL_ERROR(&callInfo, "FnVCCB_getShortMacI Error\n");
                        // TBD: use continue ?
                        return ERROR;
                    }
                }
            }
        }
        else if ((callInfo.stateCmd == IntraCellHO_cmd) && (callInfo.ueInfo.securityModFlag == VCCB_FLAG_ON))
        {
            if ((callInfo.ueInfo.reestablishInfo.srcCRNTI == crnti) &&
                (callInfo.ueInfo.reestablishInfo.srcPhyCellId == pci))
            {
                if (callInfo.ueInfo.reestablishInfo.srcIntegrityAlgo == EIA0)
                {
                    VCCB_PRINT_CALL_COMMENT(&callInfo, "[RRE] srcIntegrityAlgo(EIA0), Accept RRE\n");
                    FnVCCB_updateCallId_matchedType(ptCi->gnbCuUeId, callInfo.gnbCuUeId, *ptRreMatchType, RRE_OLD_KEY_MATCH);
                    break;
                }

                status = VLIB_MakeOldShortMacI(&callInfo, ci, &calcShortMacI);
                VCCB_RETURN_ON_ERROR(status, "VLIB_MakeOldShortMacI Error\n");

                // Compare Short Mac-I
                if (calcShortMacI == shortMacI)
                {
                    VCCB_PRINT_CALL_INFORMATIVE(
                        &callInfo, "[RRE] Success Retrieve Case 4: short MAC-I using old key\n");
                    FnVCCB_updateCallId_matchedType(ptCi->gnbCuUeId, callInfo.gnbCuUeId, *ptRreMatchType, RRE_OLD_KEY_MATCH);
                    break;
                }
                else  // Mismatch
                {
                    VCCB_PRINT_CALL_ERROR(
                        &callInfo, "[RRE] Failure Retrieve Case 2: outShortMacI(%d)\n", calcShortMacI);
                }
            }
        }
    }

    if (ptCi->gnbCuUeId == UNKNOWN_CP_CALLID)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Can't Find Reestablished Call c_RNTI/PhysCellId/shortMAC_I = %d/%d/%d) \n", crnti, pci, shortMacI);
        return ERROR;
    }

    return GOOD;
}

// FGR-MC1015 FR60.CACP.SR1.HD1.DD1, FR60.CACP.SR1.HD2.DD1
int16_t VCOM_GetSelectedPLMN_For_RRE(
    callInfo_type *ptCi, uint32_t cellNum, enumReestablishType_type rreType, plmnId_type *ptPlmn) /* output */
{                                                                                                 // {{{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(ptPlmn);

    int16_t status;
    allowedPlmnList_Type b_plmn_list;

    *ptPlmn = ptCi->ueInfo.servedPlmn;

    // 0. get the b_plmn of rre cell
    status = VLIB_getBPLMN(ptCi, cellNum, &b_plmn_list);
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(ptCi, "Not Allowed PLMN Selection In SA RRE. (Cause:Invalid BPLMN List)\n");
        return ERROR;  // Reject procedure
    }

    if (rreType == RRE_TYPE_INTER_GNB /* Inter gNB RRE */)
    {
        // check amfId
        if (GOOD != VLIB_getAmfFromGuami(ptCi))
        {
            // MACRO_CALL_FAULT_SAVE fill VRRM_AMFSelection.
            if (AMF_ASSIGN_FAIL_UNKNOWN_GUAMI_ID == GET_XN_AMF_CALL_FAULT_CAUSE(ptCi))
            {
                MACRO_CALL_FAULT_SAVE(XN_RetrieveUEContextResponse_id, CauseXnapRadioNetworkLayerUnknownGuamiId);
                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerUnknownGuamiId;
            }
            else  //(AMF_ASSIGN_FAIL_INVALID_SET_ID== GET_XN_AMF_CALL_FAULT_CAUSE(ptCi))
            {
                MACRO_CALL_FAULT_SAVE(XN_RetrieveUEContextResponse_id, CauseXnapRadioNetworkLayerInvalidAmfSetId);
                ptCi->cause.xnCause = CauseXnapRadioNetworkLayerInvalidAmfSetId;
            }
            VCCB_PRINT_CALL_ERROR(ptCi, "No available AMF !!\n");
            INIT_XN_RECEIVED_TNL_ADDR_INFO(ptCi);
            return ERROR;
        }
        INIT_XN_RECEIVED_TNL_ADDR_INFO(ptCi);
    }

    // check MRL 
    if (ptCi->hoRestrict.existFlag == TRUE)
    {
        VCCB_PRINT_CALL_LOG_PLMN(ptCi, "UE Served MRL in MRL (PLMN:0x%02X/0x%02X)\n",
                ptCi->hoRestrict.servedPlmn.s2.mcc, ptCi->hoRestrict.servedPlmn.s2.mnc);

        // check servedPLMN & EPLMN
        status = VCOM_GetEPLMNbasedSelectedPLMN_For_RRE(ptCi, &b_plmn_list, ptPlmn);
        if (status != GOOD)
        {
            // NOK (RRC setup procedure)
            VCCB_PRINT_CALL_ERROR(ptCi,
                    "Not Allowed MRL Based PLMN Selection (Cause: No Match PLMN), RRE to RRC setup "
                    "procedure (Inter-gNB RRE with MRL)\n");
            return ERROR;
        }
    }
    else  // noMRL
    {
        status = VCOM_GetServedPLMNbasedSelectedPLMN(ptCi, &ptCi->servedGuami.plmn, &b_plmn_list, ptPlmn);
        if (status == ERROR)
        {
            status = VCOM_GetBPLMNbasedSelectedPLMN_For_RRE(ptCi, &b_plmn_list, rreType, ptPlmn);
            if (status != GOOD)
            {
                // NOK (RRC setup procedure)
                VCCB_PRINT_CALL_ERROR(ptCi,
                        "NO MRL Based PLMN Selection (Cause: No Match PLMN), RRE to RRC setup "
                        "procedure (Intra-gNB RRE with NO MRL)\n");
                return ERROR; // RRC Setup Fallback
            }
        }

        VCCB_PRINT_CALL_LOG_PLMN(ptCi, "Allowed Non-MRL Based PLMN Selection(PLMN:0x%02X/0x%02X)\n",
                ptPlmn->s2.mcc, ptPlmn->s2.mnc);
    }

     // OK (accept RRE, update the PLMN)
    if ((rreType != RRE_TYPE_INTER_GNB ) && (ptCi->ueInfo.servedPlmn.longId != ptPlmn->longId)) 
    {
        ptCi->ueInfo.reestablishInfo.isIntraGnbPlmnChg = FLAG_ON;
        ptCi->ueInfo.reestablishInfo.swappedPlmn.longId = ptCi->ueInfo.servedPlmn.longId;
    }

    ptCi->ueInfo.servedPlmn.longId = ptPlmn->longId;
    VCCB_PRINT_CALL_DATA(
        ptCi, "Allowed PLMN Selection In SA RRE. (PLMN:0x%02X/0x%02X)\n", ptPlmn->s2.mcc, ptPlmn->s2.mnc);

    return GOOD;
}  // }}}

int16_t VCOM_GetEPLMNbasedSelectedPLMN_For_RRE(
    callInfo_type *ptCi, const allowedPlmnList_Type *pt_b_plmn_list, plmnId_type *ptPlmn)
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pt_b_plmn_list);
    VALID_E_POINT_CHECK_ERROR(ptPlmn);

    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->servCellNum, MAX_CELL_NUM_VCCB);

    int16_t status;
    supportedAmfSetList_Type servingAmfList;

    hoRestrictInfo_type *ptHrl = &THREAD_INFO->call[ptCi->myThreadId].buf.hoRestrictInfo;

    VCCB_RETURN_ON_CALL_ERROR(
        ptCi, VLIB_DecompressHoRestrictInfo(ptCi, ptHrl), "VLIB_DecompressHoRestrictInfo ERROR!\n");

    // 2-1 AMF::supportedPlmn
    //  2.B.0) get the supported PLMN list of AMF
    //  1. get PLMN list which is supported at Serving AMF
    status = VRRM_GetAmfSetList(ptCi, ptCi->endPointInfo.ngIdx, ptCi->servedGuami,
        &servingAmfList);  // tag : ngIdx or guami, info : ngIdx or guami
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(
            ptCi, "Not Allowed MRL:EPLMN Based PLMN Selection. (Cause:No Match PLMN in Served Guami)\n");
        return ERROR;  // RRE fallback to RRC Setup procedure
    }

    // 2.B.1) Find the intersection of PLMN between AMF and Target cell
    plmnId_type *ptBPlmn = NULL;
    unsigned int numBplmn = 0, numAmfPlmn = 0;
    const VccbCellInfo_type *const pCell = &CELLINFO[ptCi->servCellNum];

    numBplmn = MIN(pt_b_plmn_list->num_plmn, MAX_NUM_PLMN);
    numAmfPlmn = MIN(servingAmfList.num_plmn, MAX_AMF_PLMN_PER_SUPPORTED_LIST);

    // matched MRL:servedPlmn
    status = VCOM_GetServedPLMNbasedSelectedPLMN(ptCi, &ptHrl->servedPlmn, pt_b_plmn_list, ptPlmn);
    if (status == GOOD)
    {
        // check Restrictions
        if ( (VCCM_CheckEmergencyCall(ptCi) == TRUE) ||
             (GOOD == VCCM_CheckPlmnAndTacInMrlAllowedList(ptCi, ptHrl, pCell->tac, ptPlmn->longId)) )
        {
            goto PLMN_UPDATE;
        }
    }

    for (unsigned int b_plmn_idx = 0; b_plmn_idx < numBplmn; b_plmn_idx++)  // for BPLMN
    {
        bool eplmnFound = false;
        ptBPlmn = (plmnId_type *)&(pt_b_plmn_list->plmn[b_plmn_idx]);

        // emergency call - ignore restrictionLists
        if(VCCM_CheckEmergencyCall(ptCi) == TRUE)
        {
            for (int eplmn_idx = 0; eplmn_idx < MIN(XN_MaxnoofEPLMNs, ptHrl->numEplmn); eplmn_idx++)
            {
                if (ptHrl->ePlmn[eplmn_idx].longId == ptBPlmn->longId)
                {
                    eplmnFound = true;
                    break;
                }
            }
        }
        else // normal call
        {
            if(GOOD == VCCM_CheckPlmnAndTacInMrlAllowedList(ptCi, ptHrl, pCell->tac, ptBPlmn->longId))
            {
                eplmnFound = true;
            }
        }

        if (true == eplmnFound)
        {
            VCCB_PRINT_CALL_COMMENT(ptCi,
                    "[MRL] matched EPLMN (0x%02X/0x%02X)\n", ptBPlmn->s2.mcc, ptBPlmn->s2.mnc);

            // matched AMF
            for (unsigned int amf_plmn_idx = 0; amf_plmn_idx < numAmfPlmn; amf_plmn_idx++)
            {
                if (ptBPlmn->longId != servingAmfList.amf_plmn[amf_plmn_idx].plmn.longId) continue;

                VCCB_PRINT_CALL_COMMENT(ptCi, "[MRL] matched AMF #%d)\n", amf_plmn_idx);

                ptPlmn->longId = ptBPlmn->longId;
                goto PLMN_UPDATE;
            }
        }
    }

    VCCB_PRINT_CALL_ERROR(ptCi,
            "Not Allowed MRL:EPLMN & AMF Based PLMN Selection. (BPLMN#%d)\n", pt_b_plmn_list->num_plmn);
    return ERROR;  // RRE fallback to RRC Setup procedure

    // update the PLMN
PLMN_UPDATE:

    // Target gNB shall use Serving PLMN and Equivalent PLMN information in 'Mobility Restriction List IE'.
    VXIL_Swap_ServingPLMN_N_EquivalentPLMN(ptHrl->servedPlmn, *ptPlmn, ptHrl);

    // Update CompressHoRestrict Info due to swap servingPlmn and EquivalentPlmn
    status = VLIB_CompressHoRestrictInfo(ptCi, ptHrl);
    if (status == ERROR)
    {
        VCCB_PRINT_CALL_ERROR(ptCi,
            "VLIB_CompressHoRestrictInfo after "
            "VCOM_getEPLMN_AMFPLMNbasedSelectedPLMN ERROR!!\n");
    }

    VCCB_PRINT_CALL_LOG_PLMN(ptCi,
        "Allowed MRL:EPLMN Based PLMN Selection. (PLMN:0x%02X/0x%02X, BPLMN(num:%d) AMF(plmn:%d set:%d))\n",
        ptCi->hoRestrict.servedPlmn.s2.mcc, ptCi->hoRestrict.servedPlmn.s2.mnc, pt_b_plmn_list->num_plmn,
        servingAmfList.num_plmn, servingAmfList.num_set);

    return GOOD;
}

int16_t VCOM_GetBPLMNbasedSelectedPLMN_For_RRE(callInfo_type *ptCi, const allowedPlmnList_Type *pt_b_plmn_list,
    enumReestablishType_type rreType,
    plmnId_type *ptPlmn)     /* output */
{
    AUTO_TRACE_FUNC;

    VALID_E_POINT_CHECK_ERROR(ptCi);
    VALID_E_POINT_CHECK_ERROR(pt_b_plmn_list);
    VALID_E_POINT_CHECK_ERROR(ptPlmn);
    
    VCCB_CHECK_E_RANGE_AND_RETURN(ptCi->myThreadId, MAX_CALL_THREAD_NUM_VCCB);

    int16_t status;
    supportedAmfSetList_Type servingAmfList;

    if (rreType == RRE_TYPE_INTER_GNB)
    {
        return ERROR;
    }

    // AMF::supportedPlmn
    status = VRRM_GetAmfSetList(ptCi, ptCi->endPointInfo.ngIdx, ptCi->servedGuami,
            &servingAmfList); // tag : ngIdx or guami, info : ngIdx or guami
    if (status != GOOD)
    {
        VCCB_PRINT_CALL_ERROR(
                ptCi, "Not Allowed MRL:EPLMN Based PLMN Selection. (Cause:No Match PLMN in Served Guami)\n");
        return ERROR;  // RRE fallback to RRC Setup procedure
    }

    plmnId_type *ptBPlmn = NULL;
    unsigned int numBplmn = 0, numAmfPlmn = 0;

    numBplmn = MIN(pt_b_plmn_list->num_plmn, MAX_NUM_PLMN);
    numAmfPlmn = MIN(servingAmfList.num_plmn, MAX_AMF_PLMN_PER_SUPPORTED_LIST);

    for (unsigned int b_plmn_idx = 0; b_plmn_idx < numBplmn; b_plmn_idx++) // for BPLMN
    {
        ptBPlmn = (plmnId_type*)&(pt_b_plmn_list->plmn[b_plmn_idx]);

        // matched AMF
        for (unsigned int amf_plmn_idx = 0; amf_plmn_idx < numAmfPlmn; amf_plmn_idx++)
        {
            if (ptBPlmn->longId != servingAmfList.amf_plmn[amf_plmn_idx].plmn.longId) continue;

            VCCB_PRINT_CALL_COMMENT(ptCi, "[MRL] matched AMF  #%d)\n", amf_plmn_idx);

            ptPlmn->longId = ptBPlmn->longId;
            return GOOD;
        }
    }

    return ERROR;
}

